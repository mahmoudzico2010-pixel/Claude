<?php

declare(strict_types=1);

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Storage;
use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;

/** iPhone Safari will not play a video unless the server answers byte-range requests (206). The PHP media route must. */
final class MediaFileRangeTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        Storage::fake('public');
        $this->seed();
        // The route exists only when MEDIA_PUBLIC_FALLBACK is on at boot; register it the same way for the test.
        \Illuminate\Support\Facades\Route::get('media/{path}', [\App\Http\Controllers\MediaFileController::class, 'show'])->where('path', '.*');
        \Illuminate\Support\Facades\Route::getRoutes()->refreshNameLookups();
    }

    private function video(string $name = 'media/news/clip.mp4'): string
    {
        $bytes = "\x00\x00\x00\x18ftypisom\x00\x00\x02\x00isomiso2".str_repeat('ABCDEFGHIJ', 500);   // 5024 bytes
        Storage::disk('public')->put($name, $bytes);

        return $bytes;
    }

    #[Test]
    public function a_full_request_is_answered_200_and_advertises_range_support(): void
    {
        $bytes = $this->video();
        $r = $this->get('/media/media/news/clip.mp4')->assertOk();
        $this->assertSame('bytes', $r->headers->get('Accept-Ranges'));
        $this->assertSame((string) strlen($bytes), $r->headers->get('Content-Length'));
        $this->assertSame('video/mp4', explode(';', (string) $r->headers->get('Content-Type'))[0]);
        $this->assertSame('nosniff', $r->headers->get('X-Content-Type-Options'));
    }

    #[Test]
    public function the_probe_and_seek_requests_iphone_safari_sends_get_206_with_content_range(): void
    {
        $bytes = $this->video();
        $probe = $this->get('/media/media/news/clip.mp4', ['Range' => 'bytes=0-1']);
        $probe->assertStatus(206);
        $this->assertSame('bytes 0-1/'.strlen($bytes), $probe->headers->get('Content-Range'));
        $this->assertSame('2', $probe->headers->get('Content-Length'));

        $mid = $this->get('/media/media/news/clip.mp4', ['Range' => 'bytes=1000-1999']);
        $mid->assertStatus(206);
        $this->assertSame('bytes 1000-1999/'.strlen($bytes), $mid->headers->get('Content-Range'));
        $this->assertSame(substr($bytes, 1000, 1000), $mid->streamedContent() ?: $mid->getContent());

        $tail = $this->get('/media/media/news/clip.mp4', ['Range' => 'bytes=5000-']);
        $tail->assertStatus(206);
        $this->assertSame('bytes 5000-5023/5024', $tail->headers->get('Content-Range'));
    }

    #[Test]
    public function an_impossible_range_is_refused_cleanly_and_a_quicktime_file_keeps_its_type(): void
    {
        $this->video();
        $this->assertContains($this->get('/media/media/news/clip.mp4', ['Range' => 'bytes=999999-'])->getStatusCode(), [200, 416], 'an unsatisfiable range never crashes');

        Storage::disk('public')->put('media/news/phone.mov', "\x00\x00\x00\x14ftypqt  \x00\x00\x00\x00qt  ".str_repeat('A', 2000));
        $r = $this->get('/media/media/news/phone.mov')->assertOk();
        $this->assertSame('video/quicktime', explode(';', (string) $r->headers->get('Content-Type'))[0]);
        $this->assertSame('bytes', $r->headers->get('Accept-Ranges'));
    }

    #[Test]
    public function the_route_still_refuses_traversal_and_executable_extensions(): void
    {
        Storage::disk('public')->put('media/news/x.php', '<?php echo 1;');
        $this->get('/media/media/news/x.php')->assertNotFound();
        $this->get('/media/..%2F..%2F.env')->assertNotFound();
    }
}
