<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Storage;
use Symfony\Component\HttpFoundation\StreamedResponse;

/**
 * Serves files from the public media disk through PHP.
 *
 * This exists only for hosts where `php artisan storage:link` cannot be used,
 * or where Apache refuses to follow the symlink (`FollowSymLinks` disabled),
 * which returns 403 for every uploaded image. Enable it with
 * `MEDIA_PUBLIC_FALLBACK=true`; MediaAsset then builds /media/... URLs instead
 * of /storage/... ones.
 *
 * Symlinked delivery is faster — Apache serves the bytes without booting
 * PHP — so this stays off unless the symlink route is unavailable.
 */
class MediaFileController extends Controller
{
    /**
     * Extensions this route will serve. Everything the media library can
     * produce, and nothing that could be executed by the server.
     */
    private const ALLOWED_EXTENSIONS = [
        'avif', 'gif', 'jpeg', 'jpg', 'pdf', 'png', 'svg', 'webp',
        // video containers (see wadi.media.video.extensions)
        'mp4', 'm4v', 'mov', 'qt', 'webm', 'mkv', 'avi', 'wmv', 'asf', 'flv', 'f4v', 'mpg', 'mpeg', 'mpe', 'm2v', 'mts', 'm2ts', 'ts', '3gp', '3g2', 'ogv', 'ogm', 'mxf', 'vob', 'divx', 'dv',
    ];

    public function show(string $path): \Symfony\Component\HttpFoundation\Response
    {
        // Reject traversal and anything outside a conservative character set
        // before touching the filesystem. `..` can arrive percent-encoded, so
        // this runs on the decoded path Laravel hands over.
        if (str_contains($path, '..') || ! preg_match('#^[A-Za-z0-9][A-Za-z0-9._/-]*$#', $path)) {
            abort(404);
        }

        $extension = strtolower(pathinfo($path, PATHINFO_EXTENSION));

        if (! in_array($extension, self::ALLOWED_EXTENSIONS, true)) {
            abort(404);
        }

        $disk = Storage::disk('public');

        if (! $disk->exists($path)) {
            abort(404);
        }

        $headers = [
            // Filenames carry a random suffix and are never reused, so a long
            // immutable cache is safe and keeps PHP out of repeat requests.
            'Cache-Control' => 'public, max-age=31536000, immutable',
            'X-Content-Type-Options' => 'nosniff',
            'Content-Disposition' => 'inline',
        ];

        // SVG is sanitised on upload, but serving it from the application's
        // own origin means a miss would be same-origin. The sandbox and null
        // default-src make that inert regardless.
        if ($extension === 'svg') {
            $headers['Content-Security-Policy'] = "default-src 'none'; style-src 'unsafe-inline'; sandbox";
        }

        // Video needs byte-range support so the browser can seek and so iPhone Safari will play it at all (it asks for `Range: bytes=0-1`
        // first and shows a dead 00:00 player when the server answers 200 with the whole file). Storage::response() is a plain stream
        // with NO Range support, so a file on a local disk is served by Symfony's BinaryFileResponse, which answers 206 / Content-Range.
        if ($disk->getAdapter() instanceof \League\Flysystem\Local\LocalFilesystemAdapter) {
            $response = new \Symfony\Component\HttpFoundation\BinaryFileResponse($disk->path($path), 200, $headers + ['Accept-Ranges' => 'bytes'], false, 'inline');
            $response->setAutoEtag();

            return $response;
        }

        return $disk->response($path, basename($path), $headers + ['Accept-Ranges' => 'bytes']);
    }
}
