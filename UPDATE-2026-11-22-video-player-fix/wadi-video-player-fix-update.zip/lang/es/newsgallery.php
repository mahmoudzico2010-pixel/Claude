<?php

return [
    'photos' => 'Galería de fotos',
    'videos' => 'Vídeos',
    'gallery' => 'Galería',
    'prev' => 'Anterior',
    'next' => 'Siguiente',
    'close' => 'Cerrar',
    'photo_n' => 'Foto %d de %d',
    'period' => [
        'from' => 'Desde',
        'to' => 'Hasta',
        'label' => 'Fechas',
        'date' => 'Fecha',
        'help' => '',
    ],
    'pause' => 'Pausar presentación',
    'play' => 'Reproducir presentación',
    'open' => 'Ver',
    'video_error' => 'Este vídeo no se puede reproducir en su navegador o aún se está cargando con una conexión lenta.',
    'open_video' => 'Abrir o descargar el vídeo',
];
