<?php

return [
    'photos' => 'Galleria fotografica',
    'videos' => 'Video',
    'gallery' => 'Galleria',
    'prev' => 'Precedente',
    'next' => 'Successiva',
    'close' => 'Chiudi',
    'photo_n' => 'Foto %d di %d',
    'period' => [
        'from' => 'Dal',
        'to' => 'Al',
        'label' => 'Date',
        'date' => 'Data',
        'help' => '',
    ],
    'pause' => 'Metti in pausa la presentazione',
    'play' => 'Avvia la presentazione',
    'open' => 'Apri',
    'video_error' => 'Questo video non può essere riprodotto nel browser oppure è ancora in caricamento su una connessione lenta.',
    'open_video' => 'Apri o scarica il video',
];
