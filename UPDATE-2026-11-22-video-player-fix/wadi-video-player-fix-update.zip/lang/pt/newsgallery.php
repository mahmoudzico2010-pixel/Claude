<?php

return [
    'photos' => 'Galeria de fotos',
    'videos' => 'Vídeos',
    'gallery' => 'Galeria',
    'prev' => 'Anterior',
    'next' => 'Seguinte',
    'close' => 'Fechar',
    'photo_n' => 'Foto %d de %d',
    'period' => [
        'from' => 'De',
        'to' => 'Até',
        'label' => 'Datas',
        'date' => 'Data',
        'help' => '',
    ],
    'pause' => 'Pausar apresentação',
    'play' => 'Reproduzir apresentação',
    'open' => 'Ver',
    'video_error' => 'Não foi possível reproduzir este vídeo no seu navegador ou ainda está a carregar numa ligação lenta.',
    'open_video' => 'Abrir ou transferir o vídeo',
];
