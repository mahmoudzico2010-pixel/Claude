<?php

return [
    'photos' => 'Galerie photos',
    'videos' => 'Vidéos',
    'gallery' => 'Galerie',
    'prev' => 'Précédente',
    'next' => 'Suivante',
    'close' => 'Fermer',
    'photo_n' => 'Photo %d sur %d',
    'period' => [
        'from' => 'Du',
        'to' => 'Au',
        'label' => 'Dates',
        'date' => 'Date',
        'help' => '',
    ],
    'pause' => 'Mettre le diaporama en pause',
    'play' => 'Lancer le diaporama',
    'open' => 'Voir',
    'video_error' => 'Cette vidéo ne peut pas être lue dans votre navigateur, ou elle charge encore sur une connexion lente.',
    'open_video' => 'Ouvrir ou télécharger la vidéo',
];
