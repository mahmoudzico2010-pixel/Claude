{{-- Photo & video gallery of a news item / exhibition. Static JS (public/js/wr-news-gallery.js), native <dialog> lightbox: no framework, no build step. --}}
@php
    $photos = $post->galleryPhotos->filter(fn ($i) => $i->media && $i->media->isImage());
    $videos = $post->galleryVideos->filter(fn ($i) => $i->media && $i->media->isVideo());
@endphp
@if ($photos->isNotEmpty() || $videos->isNotEmpty())
    <section class="container-wr mt-14 wr-ng" aria-labelledby="wr-ng-title" data-wr-ng>
        <style>
            .wr-ng-grid{display:grid;gap:.75rem;grid-template-columns:repeat(2,minmax(0,1fr))}
            @media (min-width:640px){.wr-ng-grid{grid-template-columns:repeat(3,minmax(0,1fr))}}
            @media (min-width:1024px){.wr-ng-grid{grid-template-columns:repeat(4,minmax(0,1fr))}}
            /* Tile: the WHOLE photo is shown (contain) over a blurred, enlarged copy of itself, so portrait and landscape shots fit the same
               frame without cropping heads or text. The blurred copy re-uses the thumbnail already downloaded (no extra request). */
            .wr-ng-thumb{display:block;position:relative;aspect-ratio:4/3;overflow:hidden;background:#e9e6da;border:0;padding:0;cursor:zoom-in;width:100%;isolation:isolate}
            .wr-ng-thumb::before{content:"";position:absolute;inset:0;z-index:-1;background:linear-gradient(100deg,#e9e6da 30%,#f6f3ea 50%,#e9e6da 70%) 0 0/200% 100%;animation:wr-ng-shimmer 1.4s linear infinite}
            .wr-ng-thumb.is-loaded::before{animation:none;background:none}
            .wr-ng-bg{position:absolute;inset:-12%;z-index:-1;background-size:cover;background-position:center;filter:blur(18px) saturate(1.1);transform:scale(1.1);opacity:0;transition:opacity .5s ease}
            .wr-ng-thumb.is-loaded .wr-ng-bg{opacity:.85}
            .wr-ng-thumb img{width:100%;height:100%;object-fit:contain;display:block;opacity:0;transform:scale(1.03);transition:opacity .45s ease,transform .6s cubic-bezier(.2,.7,.2,1)}
            .wr-ng-thumb.is-loaded img{opacity:1;transform:scale(1)}
            .wr-ng-thumb:hover img,.wr-ng-thumb:focus-visible img{transform:scale(1.045)}
            .wr-ng-thumb::after{content:"";position:absolute;inset:0;background:linear-gradient(to top,rgb(8 22 18 / .45),transparent 45%);opacity:0;transition:opacity .3s ease}
            .wr-ng-thumb:hover::after,.wr-ng-thumb:focus-visible::after{opacity:1}
            .wr-ng-zoom{position:absolute;bottom:.5rem;inset-inline-end:.5rem;width:2rem;height:2rem;display:grid;place-items:center;background:rgb(255 255 255 / .92);color:#173f35;opacity:0;transform:translateY(6px);transition:opacity .25s ease,transform .25s ease;z-index:1}
            .wr-ng-thumb:hover .wr-ng-zoom,.wr-ng-thumb:focus-visible .wr-ng-zoom{opacity:1;transform:none}
            .wr-ng-thumb:focus-visible{outline:3px solid #c6a15b;outline-offset:2px}
            /* Staggered reveal as the gallery scrolls into view (only when the script runs, so nothing is hidden without JS). */
            .wr-ng-anim .wr-ng-grid>li{opacity:0;transform:translateY(16px);transition:opacity .5s ease,transform .5s cubic-bezier(.2,.7,.2,1);transition-delay:calc(var(--i,0) * 70ms)}
            .wr-ng-anim .wr-ng-grid>li.is-in{opacity:1;transform:none}
            @keyframes wr-ng-shimmer{to{background-position:-200% 0}}
            .wr-ng-videos{display:grid;gap:1rem;grid-template-columns:repeat(1,minmax(0,1fr))}
            @media (min-width:768px){.wr-ng-videos{grid-template-columns:repeat(2,minmax(0,1fr))}}
            .wr-ng-videos video{width:100%;aspect-ratio:16/9;background:#0e2e27;display:block}
            dialog.wr-ng-box{border:0;padding:0;background:transparent;max-width:100vw;max-height:100dvh;width:100vw;height:100dvh}
            dialog.wr-ng-box::backdrop{background:rgb(8 22 18 / .92)}
            .wr-ng-stage{position:fixed;inset:0;display:flex;align-items:center;justify-content:center;padding:3.5rem 3.5rem 4rem}
            .wr-ng-stage img{max-width:100%;max-height:100%;object-fit:contain;transition:opacity .25s ease,transform .3s ease}
            .wr-ng-stage img.is-swap{opacity:0;transform:translateX(var(--wr-ng-dx,24px))}
            dialog.wr-ng-box[open]{animation:wr-ng-in .28s ease both}
            dialog.wr-ng-box[open]::backdrop{animation:wr-ng-fade .28s ease both}
            @keyframes wr-ng-in{from{opacity:0;transform:scale(.98)}to{opacity:1;transform:none}}
            @keyframes wr-ng-fade{from{opacity:0}to{opacity:1}}
            .wr-ng-btn{position:fixed;z-index:2;min-width:2.75rem;min-height:2.75rem;border:0;background:rgb(255 255 255 / .14);color:#fff;font-size:1.5rem;line-height:1;cursor:pointer;border-radius:2px}
            .wr-ng-btn:hover,.wr-ng-btn:focus-visible{background:rgb(255 255 255 / .3);outline:2px solid #c6a15b}
            .wr-ng-close{top:.75rem;inset-inline-end:.75rem}
            .wr-ng-prev{top:50%;inset-inline-start:.75rem;transform:translateY(-50%)}
            .wr-ng-next{top:50%;inset-inline-end:.75rem;transform:translateY(-50%)}
            .wr-ng-count{position:fixed;bottom:1rem;inset-inline:0;text-align:center;color:#fff;font-size:.875rem}
            [dir=rtl] .wr-ng-prev span,[dir=rtl] .wr-ng-next span{display:inline-block;transform:scaleX(-1)}
            @media (prefers-reduced-motion:reduce){.wr-ng-thumb::before{animation:none}.wr-ng-thumb img,.wr-ng-bg,.wr-ng-zoom,.wr-ng-thumb::after,.wr-ng-stage img{transition:none!important}.wr-ng-anim .wr-ng-grid>li{opacity:1;transform:none;transition:none}dialog.wr-ng-box[open],dialog.wr-ng-box[open]::backdrop{animation:none}.wr-ng-thumb img{opacity:1;transform:none}}
        </style>

        @if ($photos->isNotEmpty())
            <h2 id="wr-ng-title" class="text-h3 font-bold text-ink">{{ __('newsgallery.photos') }}</h2>
            <ul class="wr-ng-grid mt-6" role="list">
                @foreach ($photos as $i => $item)
                    @php($m = $item->media)
                    <li style="--i:{{ $loop->index }}">
                        <button type="button" class="wr-ng-thumb" data-wr-ng-open="{{ $loop->index }}" data-full="{{ $m->urlFor(1600) }}" data-alt="{{ $m->alt() ?: $post->title() }}"
                                aria-label="{{ sprintf(__('newsgallery.photo_n'), $loop->iteration, $photos->count()) }}">
                            <span class="wr-ng-bg" aria-hidden="true" style="background-image:url('{{ $m->urlFor(400) }}')"></span>
                            <img src="{{ $m->urlFor(640) }}" @if ($m->srcset()) srcset="{{ $m->srcset() }}" sizes="(min-width:1024px) 18rem, (min-width:640px) 30vw, 46vw" @endif
                                 alt="{{ $m->alt() ?: $post->title() }}" width="{{ $m->width ?: 640 }}" height="{{ $m->height ?: 480 }}" loading="lazy" decoding="async">
                            <span class="wr-ng-zoom" aria-hidden="true"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7"/></svg></span>
                        </button>
                    </li>
                @endforeach
            </ul>
            <dialog class="wr-ng-box" data-wr-ng-dialog aria-label="{{ __('newsgallery.photos') }}" data-label-n="{{ __('newsgallery.photo_n') }}">
                <div class="wr-ng-stage"><img alt="" data-wr-ng-img></div>
                <button type="button" class="wr-ng-btn wr-ng-close" data-wr-ng-close aria-label="{{ __('newsgallery.close') }}">&times;</button>
                <button type="button" class="wr-ng-btn wr-ng-prev" data-wr-ng-prev aria-label="{{ __('newsgallery.prev') }}"><span aria-hidden="true">&#8249;</span></button>
                <button type="button" class="wr-ng-btn wr-ng-next" data-wr-ng-next aria-label="{{ __('newsgallery.next') }}"><span aria-hidden="true">&#8250;</span></button>
                <p class="wr-ng-count" data-wr-ng-count aria-live="polite"></p>
            </dialog>
        @endif

        @if ($videos->isNotEmpty())
            <h2 @if ($photos->isEmpty()) id="wr-ng-title" @endif class="text-h3 font-bold text-ink {{ $photos->isNotEmpty() ? 'mt-12' : '' }}">{{ __('newsgallery.videos') }}</h2>
            <div class="wr-ng-videos mt-6">
                @foreach ($videos as $item)
                    <video controls preload="metadata" playsinline aria-label="{{ $item->media->alt() ?: $post->title() }}">
                        <source src="{{ $item->media->url() }}" type="{{ $item->media->mime_type }}">
                    </video>
                @endforeach
            </div>
        @endif
    </section>
    @if ($photos->isNotEmpty())
        @push('scripts')<script src="{{ asset('js/wr-news-gallery.js') }}?v={{ @filemtime(public_path('js/wr-news-gallery.js')) }}" defer></script>@endpush
    @endif
@endif
