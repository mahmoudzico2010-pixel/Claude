<?php

declare(strict_types=1);

namespace App\Filament\Resources\News;

use App\Enums\ContentStatus;
use App\Enums\NewsType;
use App\Filament\Forms\Components\MediaPicker;
use App\Filament\Resources\News\Pages\CreateNewsPost;
use App\Filament\Resources\News\Pages\EditNewsPost;
use App\Filament\Resources\News\Pages\ListNewsPosts;
use App\Models\NewsCategory;
use App\Models\NewsPost;
use App\Models\Tag;
use App\Support\Permissions;
use BackedEnum;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteAction;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Actions\RestoreBulkAction;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\DateTimePicker;
use Filament\Forms\Components\RichEditor;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Tabs;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\ImageColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Filters\TrashedFilter;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;

class NewsPostResource extends Resource
{
    protected static ?string $model = NewsPost::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedNewspaper;

    protected static ?int $navigationSort = 7;

    public static function getNavigationGroup(): ?string
    {
        return __('nav.groups.content');
    }

    public static function getModelLabel(): string
    {
        return __('admin.resources.news_post.label');
    }

    public static function getPluralModelLabel(): string
    {
        return __('admin.resources.news_post.plural');
    }

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            Section::make()->schema([
                Tabs::make('locales')->tabs(
                    collect(config('wadi.locales'))
                        ->map(fn (array $c, string $locale) => Tabs\Tab::make($c['native'])->schema([
                            TextInput::make("translations.{$locale}.title")
                                ->label(__('admin.fields.title'))
                                ->required($locale === config('app.fallback_locale'))
                                ->maxLength(255),
                            Textarea::make("translations.{$locale}.excerpt")
                                ->label(__('admin.fields.short_description'))->rows(2)->maxLength(500),
                            RichEditor::make("translations.{$locale}.body")
                                ->label(__('admin.fields.description'))
                                ->toolbarButtons(['bold', 'italic', 'link', 'bulletList', 'orderedList', 'h2', 'h3', 'blockquote', 'undo', 'redo']),
                            TextInput::make("translations.{$locale}.seo_title")
                                ->label(__('admin.fields.seo_title'))->maxLength(255),
                            Textarea::make("translations.{$locale}.seo_description")
                                ->label(__('admin.fields.seo_description'))->rows(2)->maxLength(500),
                        ]))
                        ->values()->all()
                ),
            ]),

            Section::make(__('admin.tabs.details'))->columns(3)->schema([
                TextInput::make('slug')->label(__('admin.fields.slug'))->required()
                    ->maxLength(255)->unique(ignoreRecord: true)->rules(['alpha_dash']),

                Select::make('type')->label(__('admin.fields.form'))->options(NewsType::class)
                    ->default(NewsType::News->value)->required()->native(false)->live(),

                Select::make('news_category_id')->label(__('admin.fields.category'))
                    ->options(fn (): array => NewsCategory::query()->active()->ordered()->get()
                        ->mapWithKeys(fn (NewsCategory $c): array => [$c->id => $c->localized('name')])->all())
                    ->native(false),

                MediaPicker::make('featured_image_id', __('admin.fields.primary_image'), 'news'),
                MediaPicker::make('seo_image_id', __('admin.fields.seo_image'), 'news'),

                Select::make('tags')->label('Tags')->relationship('tags')
                    ->getOptionLabelFromRecordUsing(fn (Tag $t): string => $t->localized('name'))
                    ->multiple()->preload()->searchable(),
            ]),

            // Photo and video gallery: shown under the article on the public page (news AND exhibitions).
            Section::make(__('newsgallery.admin.title'))->key('gallery')->description(__('newsgallery.admin.help'))->collapsible()
                ->headerActions([MediaPicker::multiUploadAction('galleryPhotos', 'news', 'image'), MediaPicker::multiUploadAction('galleryVideos', 'news', 'video')])
                ->schema([
                \Filament\Forms\Components\Repeater::make('galleryPhotos')
                    ->relationship()
                    ->label(__('newsgallery.admin.photos'))
                    ->orderColumn('display_order')
                    ->reorderableWithButtons()
                    ->defaultItems(0)
                    ->addActionLabel(__('newsgallery.admin.add_photo'))
                    ->columns(1)
                    ->mutateRelationshipDataBeforeCreateUsing(fn (array $data): array => $data + ['kind' => 'photo'])
                    ->schema([MediaPicker::make('media_id', __('newsgallery.admin.photo'), 'news')->required()]),
                \Filament\Forms\Components\Repeater::make('galleryVideos')
                    ->relationship()
                    ->label(__('newsgallery.admin.videos'))
                    ->orderColumn('display_order')
                    ->reorderableWithButtons()
                    ->defaultItems(0)
                    ->addActionLabel(__('newsgallery.admin.add_video'))
                    ->columns(1)
                    ->mutateRelationshipDataBeforeCreateUsing(fn (array $data): array => $data + ['kind' => 'video'])
                    ->schema([MediaPicker::video('media_id', __('newsgallery.admin.video'), 'news')->required()]),
            ]),

            // Exhibitions carry a venue and date range; other types do not.
            Section::make(__('enums.news_type.exhibition'))
                ->columns(3)
                // $get('type') is the enum on an existing record and its string on a new one: compare both shapes (the section used to stay hidden when editing an exhibition).
                ->visible(fn ($get): bool => ($t = $get('type')) === NewsType::Exhibition || $t === NewsType::Exhibition->value)
                ->description(__('newsgallery.period.help'))
                ->schema([
                    DatePicker::make('event_start_date')->label(__('newsgallery.period.from'))->native(false)->live()->requiredWith('event_end_date'),
                    DatePicker::make('event_end_date')->label(__('newsgallery.period.to'))->native(false)
                        ->afterOrEqual('event_start_date')->minDate(fn ($get) => $get('event_start_date')),
                    TextInput::make('location')->label(__('site.news.location'))->maxLength(255),
                ]),

            Section::make()->columns(4)->schema([
                Select::make('status')->label(__('admin.fields.status'))->options(ContentStatus::class)
                    ->default(ContentStatus::Draft->value)->required()->native(false)
                    ->disabled(fn (): bool => ! auth()->user()?->can(Permissions::NEWS_PUBLISH)),
                DateTimePicker::make('published_at')->label(__('admin.fields.published_at'))
                    ->seconds(false)->native(false)->default(now()),
                Toggle::make('is_featured')->label(__('admin.fields.is_featured'))->inline(false),
            ]),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->modifyQueryUsing(fn (Builder $query) => $query->withTranslation()->with('featuredImage', 'category'))
            ->defaultSort('published_at', 'desc')
            ->columns([
                ImageColumn::make('featuredImage')
                    ->label('')
                    ->getStateUsing(fn (NewsPost $r): ?string => $r->featuredImage?->urlFor(120))
                    ->square()->size(44),
                TextColumn::make('title')
                    ->label(__('admin.fields.title'))
                    ->getStateUsing(fn (NewsPost $r): string => $r->title() ?? $r->slug)
                    ->searchable(query: fn (Builder $query, string $search): Builder => $query->whereHas(
                        'translations', fn (Builder $t) => $t->where('title', 'like', "%{$search}%")
                    ))
                    ->wrap()->weight('medium'),
                TextColumn::make('type')->label(__('admin.fields.form'))->badge(),
                TextColumn::make('status')->label(__('admin.fields.status'))->badge(),
                IconColumn::make('is_featured')->label(__('admin.fields.is_featured'))->boolean()
                    ->trueIcon(Heroicon::Star)->falseIcon(Heroicon::OutlinedStar)
                    ->trueColor('warning')->falseColor('gray'),
                TextColumn::make('published_at')->label(__('admin.fields.published_at'))
                    ->date('j M Y')->sortable()->placeholder('—'),
            ])
            ->filters([
                SelectFilter::make('type')->label(__('admin.fields.form'))->options(NewsType::class),
                SelectFilter::make('status')->label(__('admin.fields.status'))->options(ContentStatus::class),
                TrashedFilter::make(),
            ])
            ->recordActions([EditAction::make(), DeleteAction::make()])
            ->toolbarActions([BulkActionGroup::make([DeleteBulkAction::make(), RestoreBulkAction::make()])]);
    }

    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()->withoutGlobalScopes([SoftDeletingScope::class]);
    }

    public static function getPages(): array
    {
        return [
            'index' => ListNewsPosts::route('/'),
            'create' => CreateNewsPost::route('/create'),
            'edit' => EditNewsPost::route('/{record}/edit'),
        ];
    }
}
