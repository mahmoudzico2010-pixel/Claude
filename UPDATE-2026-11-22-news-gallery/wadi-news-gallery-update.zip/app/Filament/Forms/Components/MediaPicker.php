<?php

declare(strict_types=1);

namespace App\Filament\Forms\Components;

use App\Filament\Pages\UploadLargeFiles;
use App\Filament\Tables\DocumentGridTable;
use App\Filament\Tables\ImageGridTable;
use App\Filament\Tables\MediaGridTable;
use App\Filament\Tables\VideoGridTable;
use App\Models\MediaAsset;
use App\Rules\SafeRasterImage;
use App\Services\Media\MediaManager;
use App\Support\ResourceLimits;
use App\Support\Uploads\UploadLimits;
use Filament\Actions\Action;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\Hidden;
use Filament\Forms\Components\ModalTableSelect;
use Filament\Forms\Components\TextInput;
use Filament\Notifications\Notification;
use Filament\Schemas\Components\Grid;
use Filament\Schemas\Components\Utilities\Get;
use Filament\Schemas\Components\Utilities\Set;
use Filament\Support\Exceptions\Halt;
use Filament\Support\Icons\Heroicon;
use Illuminate\Support\Facades\Auth;
use RuntimeException;

/**
 * A single control for choosing a file from the media library or uploading
 * a new one without leaving the form.
 *
 * Everything goes through MediaManager, so an image picked here gets the same
 * safe filename, WebP renditions and SVG sanitising as one uploaded from the
 * library screen, and every asset stays reusable and replaceable.
 *
 * ---------------------------------------------------------------------------
 * Why this is a modal grid rather than a dropdown
 * ---------------------------------------------------------------------------
 *
 * It used to be a `Select` whose options carried a 40px thumbnail. That works
 * for a library of twenty files and stops working well before two hundred: a
 * dropdown shows a handful of rows at a time, offers no way to filter by type,
 * and turns the choice between four similar product photographs into a matter
 * of reading filenames.
 *
 * The grid is the same table Filament renders for the media library screen —
 * defined once in App\Filament\Tables\MediaGridTable — so search, filtering,
 * pagination and the responsive column counts come from there rather than
 * being rebuilt here, and improving one improves both.
 *
 * The public API is unchanged. `MediaPicker::make()`, `::document()` and
 * `::video()` take the same arguments they always did, and every existing call
 * site keeps working without edits.
 */
class MediaPicker
{
    /**
     * @param  string  $accept  'image', 'video' or 'document'
     */
    public static function make(
        string $name,
        ?string $label = null,
        string $folder = 'general',
        string $accept = 'image',
    ): ModalTableSelect {
        return ModalTableSelect::make($name)
            ->label($label ?? __('admin.fields.image'))
            ->tableConfiguration(static::tableFor($accept))
            ->placeholder(__('media.actions.none_selected'))

            /*
             | What the field shows once something is chosen.
             |
             | All four callbacks are required here, and the reason is not
             | obvious. ModalTableSelect declares `$getOptionLabelUsing` and
             | `$getOptionLabelsUsing` as typed properties with **no default
             | value**, and the only method that ever assigns them is
             | `relationship()`. Its render path reads them unconditionally.
             |
             | So a ModalTableSelect used without a relationship — which is
             | this case, because a media asset is referenced by a plain id
             | column rather than an Eloquent relation — throws
             | "Typed property … must not be accessed before initialization"
             | the moment the field renders. Every admin screen carrying a
             | media field went down on that, which is exactly what happened.
             |
             | Setting them explicitly both initialises the properties and
             | gives the field a sensible label. `getSelectedRecord()` caches
             | its lookup, so the label costs no extra query.
             */
            ->getSelectedRecordUsing(fn ($state): ?MediaAsset => filled($state) ? MediaAsset::find($state) : null)
            ->getOptionLabelUsing(fn (ModalTableSelect $component): ?string => $component->getSelectedRecord()?->original_filename)
            ->getOptionLabelsUsing(fn (array $values): array => MediaAsset::query()
                ->whereIn('id', $values)
                ->pluck('original_filename', 'id')
                ->all())
            ->getOptionLabelFromRecordUsing(fn (MediaAsset $record): string => $record->original_filename)

            /*
             | Upload sits beside the field rather than inside the picker.
             |
             | Filament clears a table-select modal's header and toolbar
             | actions, so there is nowhere inside the grid to put it — and on
             | reflection that is the better placement anyway: uploading is not
             | a way of browsing the library, and burying it behind "choose an
             | existing file" is how libraries end up with six copies of the
             | same logo.
             */
            ->hintActions([
                Action::make($name.'_upload')
                    ->label(__('media.actions.upload'))
                    ->icon(Heroicon::OutlinedArrowUpTray)
                    ->modalHeading(__('media.actions.upload'))
                    ->modalSubmitActionLabel(__('media.actions.upload'))
                    /*
                     | Inside a repeater every item carries an action with this
                     | same name. Any Livewire round trip while the modal is open
                     | (typing the alt text) makes Filament re-resolve the mounted
                     | action, and it then finds the LAST item's picker: the upload
                     | was stored but landed on another item, and the one the user
                     | was editing stayed empty. The target is captured when the
                     | modal opens, while the right picker is still known.
                     */
                    ->fillForm(fn (ModalTableSelect $component): array => ['target' => $component->getStatePath()])
                    ->schema([
                        Hidden::make('target'),
                        FileUpload::make('file')
                            ->label(__('media.fields.file'))
                            ->required()
                            // MediaManager does the storing — safe filename,
                            // WebP renditions, SVG sanitising. Letting
                            // FileUpload store the file first would bypass all
                            // of that AND dehydrate the state to a path
                            // string, which is not an UploadedFile, so the
                            // handler below would silently do nothing.
                            ->storeFiles(false)
                            ->maxSize(fn (): int => UploadLimits::clientKb(static::maxSizeFor($accept)))
                            ->rule(fn (): string => 'max:'.static::maxSizeFor($accept))
                            ->acceptedFileTypes(static::mimesFor($accept))
                            ->rules($accept === 'image' ? [new SafeRasterImage] : [])
                            ->helperText(fn (): string => UploadLimits::explain(static::categoryFor($accept)).($accept === 'image' ? ' '.__('media.hints.max_dimensions', ['pixels' => ResourceLimits::formatPixels(ResourceLimits::practicalImagePixels())]) : '').($accept === 'video' || MediaManager::userMayUploadSvg() ? '' : ' '.__('media.hints.raster_only'))),

                        Grid::make(2)->schema([
                            TextInput::make('alt_en')
                                ->label(__('media.fields.alt_en'))
                                ->maxLength(255),
                            TextInput::make('alt_ar')
                                ->label(__('media.fields.alt_ar'))
                                ->maxLength(255),
                        ]),
                    ])
                    ->action(function (array $data, Set $set) use ($name, $folder): void {
                        try {
                            $id = static::store($data, $folder);
                        } catch (RuntimeException $e) {
                            // An expected refusal (dimensions, type, size) is a message, never a server error.
                            Notification::make()->danger()->title(__('media.errors.upload_failed'))->body($e->getMessage())->persistent()->send();

                            throw new Halt;
                        }
                        $target = (string) ($data['target'] ?? '');

                        // Only ever this picker's own field (in whichever item), never another path.
                        if ($target !== '' && ($target === $name || str_ends_with($target, '.'.$name))) {
                            $set($target, $id, isAbsolute: true);
                        } else {
                            $set($name, $id);
                        }
                    }),

                /*
                 | Large videos/documents: the resumable uploader is a separate page (it survives
                 | a closed tab and is not limited by the web server's single-request size).
                 | Upload there first, then use "choose an existing file" in this field.
                 */
                Action::make($name.'_upload_large')
                    ->label(__('media.actions.upload_large'))
                    ->icon(Heroicon::OutlinedCloudArrowUp)
                    ->color('gray')
                    ->url(fn (): string => UploadLargeFiles::getUrl(), shouldOpenInNewTab: true)
                    ->visible(fn (): bool => in_array($accept, ['video', 'document'], true) && UploadLargeFiles::canAccess()),
            ]);
    }

    /**
     * Convenience wrapper for PDF fields such as specification sheets.
     */
    public static function document(string $name, ?string $label = null, string $folder = 'documents'): ModalTableSelect
    {
        return static::make($name, $label, $folder, 'document');
    }

    /**
     * Convenience wrapper for video fields such as hero slides.
     */
    public static function video(string $name, ?string $label = null, string $folder = 'general'): ModalTableSelect
    {
        return static::make($name, $label, $folder, 'video');
    }

    /**
     * "Upload several files together": one dialog, many files, each stored through MediaManager exactly like a single upload (same
     * size / type / pixel checks, same duplicate reuse), then ADDED to a repeater's items as `{media_id}` rows (nothing already in the
     * repeater is touched, a file already listed is not added twice). The repeater itself is saved with the form, as usual.
     *
     * @param  string  $repeater  state path of the repeater whose items receive the new media ids
     * @param  string  $accept  'image' or 'video'
     */
    public static function multiUploadAction(string $repeater, string $folder = 'general', string $accept = 'image'): Action
    {
        $isVideo = $accept === 'video';

        return Action::make($repeater.'_upload_many')
            ->label(__($isVideo ? 'media.actions.upload_many_videos' : 'media.actions.upload_many'))
            ->icon(Heroicon::OutlinedArrowUpTray)
            ->color('primary')
            ->modalHeading(__($isVideo ? 'media.actions.upload_many_videos' : 'media.actions.upload_many'))
            ->modalSubmitActionLabel(__('media.actions.upload'))
            ->schema([
                FileUpload::make('files')
                    ->label(__($isVideo ? 'media.fields.files_videos' : 'media.fields.files'))
                    ->required()
                    ->multiple()
                    ->maxFiles($isVideo ? 10 : 40)
                    ->storeFiles(false)
                    ->panelLayout('grid')
                    ->maxSize(fn (): int => UploadLimits::clientKb(static::maxSizeFor($accept)))
                    ->rule(fn (): string => 'max:'.static::maxSizeFor($accept))
                    ->acceptedFileTypes(static::mimesFor($accept))
                    ->rules($accept === 'image' ? [new SafeRasterImage] : [])
                    ->helperText(fn (): string => __('media.hints.upload_many').' '.UploadLimits::explain(static::categoryFor($accept)).($accept === 'image' ? ' '.__('media.hints.max_dimensions', ['pixels' => ResourceLimits::formatPixels(ResourceLimits::practicalImagePixels())]) : '')),
            ])
            ->action(function (array $data, Get $get, Set $set) use ($repeater, $folder): void {
                $ids = [];
                $failed = [];
                foreach ((array) ($data['files'] ?? []) as $upload) {
                    $name = is_object($upload) && method_exists($upload, 'getClientOriginalName') ? (string) $upload->getClientOriginalName() : '?';
                    try {
                        $ids[] = static::storeUploaded($upload, $folder);
                    } catch (RuntimeException $e) {
                        $failed[] = $name.' — '.$e->getMessage();
                    }
                }

                $items = (array) ($get($repeater) ?? []);
                $present = collect($items)->pluck('media_id')->filter()->map(fn ($v): int => (int) $v)->all();
                $added = 0;
                foreach (array_values(array_unique($ids)) as $id) {
                    if (! in_array($id, $present, true)) {
                        $items[(string) \Illuminate\Support\Str::uuid()] = ['media_id' => $id];
                        $added++;
                    }
                }
                $set($repeater, $items);

                $n = Notification::make()->title(__('media.upload_many.done', ['n' => $added, 'skipped' => count($ids) - $added, 'failed' => count($failed)]));
                $failed === [] ? $n->success() : $n->warning()->body(implode("\n", array_slice($failed, 0, 6)))->persistent();
                $n->send();
            });
    }

    /** One uploaded file → the id of its media asset (an identical file already in the library is reused). */
    private static function storeUploaded(mixed $upload, string $folder): int
    {
        $file = MediaManager::resolveUpload($upload);
        if ($file === null) {
            throw new RuntimeException(__('media.errors.upload_failed'));
        }
        $manager = app(MediaManager::class);
        $existing = $manager->findDuplicate($file);
        if ($existing !== null) {
            return (int) $existing->id;
        }

        return (int) $manager->store($file, $folder, ['uploaded_by' => Auth::id()])->id;
    }

    /**
     * Store an upload and return the asset's id.
     *
     * @param  array<string, mixed>  $data
     */
    private static function store(array $data, string $folder): int
    {
        $file = MediaManager::resolveUpload($data['file'] ?? null);

        if ($file === null) {
            // Silence here is what made the original bug invisible: the modal
            // closed, nothing was saved, and the picker still said "no options
            // available".
            throw new RuntimeException(__('media.errors.upload_failed'));
        }

        $manager = app(MediaManager::class);

        // Re-uploading an identical file reuses the existing asset instead of
        // filling the library with duplicates.
        $existing = $manager->findDuplicate($file);

        if ($existing !== null) {
            return (int) $existing->id;
        }

        $asset = $manager->store($file, $folder, array_filter([
            'alt_en' => $data['alt_en'] ?? null,
            'alt_ar' => $data['alt_ar'] ?? null,
            'uploaded_by' => Auth::id(),
        ], fn ($v): bool => $v !== null));

        return (int) $asset->id;
    }

    /**
     * @return class-string<MediaGridTable>
     */
    private static function tableFor(string $accept): string
    {
        return match ($accept) {
            'image' => ImageGridTable::class,
            'video' => VideoGridTable::class,
            'document' => DocumentGridTable::class,
            default => MediaGridTable::class,
        };
    }

    /**
     * Video carries its own, larger ceiling — but it is still a ceiling, and
     * it is bounded by PHP's upload_max_filesize regardless of what is set
     * here.
     */
    private static function maxSizeFor(string $accept): int
    {
        return UploadLimits::directKb(static::categoryFor($accept));
    }

    private static function categoryFor(string $accept): string
    {
        return match ($accept) {
            'video' => 'video',
            'document' => 'document',
            default => 'image',
        };
    }

    /**
     * Accepted MIME types for the upload control.
     *
     * SVG appears only for a Super Admin. Everyone else is offered PNG and
     * WebP, which cannot execute anything — the browser file picker then
     * filters it out client-side, and MediaManager enforces the same rule
     * server-side so the restriction is not merely cosmetic.
     *
     * @return array<int, string>
     */
    private static function mimesFor(string $accept): array
    {
        $images = ['image/jpeg', 'image/png', 'image/webp'];

        if (MediaManager::userMayUploadSvg()) {
            $images[] = 'image/svg+xml';
        }

        $video = (array) config('wadi.media.video.mimes', []);

        return match ($accept) {
            'image' => $images,
            'video' => $video,
            'document' => ['application/pdf'],
            default => array_merge($images, $video, ['application/pdf']),
        };
    }
}
