<?php

declare(strict_types=1);

namespace App\Models;

use App\Enums\ContentStatus;
use App\Enums\NewsType;
use App\Models\Concerns\Auditable;
use App\Models\Concerns\HasTranslations;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class NewsPost extends Model
{
    use Auditable;
    use HasFactory;
    use HasTranslations;
    use SoftDeletes;

    protected $fillable = [
        'slug', 'news_category_id', 'featured_image_id', 'seo_image_id',
        'type', 'status', 'is_featured', 'published_at',
        'event_start_date', 'event_end_date', 'location', 'created_by',
    ];

    /** @var array<int, string> */
    public array $translatedAttributes = ['title', 'excerpt', 'body', 'seo_title', 'seo_description'];

    protected function casts(): array
    {
        return [
            'type' => NewsType::class,
            'status' => ContentStatus::class,
            'is_featured' => 'boolean',
            'published_at' => 'datetime',
            'event_start_date' => 'date',
            'event_end_date' => 'date',
        ];
    }

    public function translationModel(): string
    {
        return NewsTranslation::class;
    }

    public function getRouteKeyName(): string
    {
        return 'slug';
    }

    public function category(): BelongsTo
    {
        return $this->belongsTo(NewsCategory::class, 'news_category_id');
    }

    public function featuredImage(): BelongsTo
    {
        return $this->belongsTo(MediaAsset::class, 'featured_image_id');
    }

    public function seoImage(): BelongsTo
    {
        return $this->belongsTo(MediaAsset::class, 'seo_image_id');
    }

    /** The photos of the gallery, in the order chosen in the panel. */
    public function galleryPhotos(): HasMany
    {
        return $this->hasMany(NewsPostMedia::class, 'news_post_id')->where('kind', 'photo')->orderBy('display_order')->orderBy('id');
    }

    /** The videos of the gallery, in the order chosen in the panel. */
    public function galleryVideos(): HasMany
    {
        return $this->hasMany(NewsPostMedia::class, 'news_post_id')->where('kind', 'video')->orderBy('display_order')->orderBy('id');
    }

    public function tags(): BelongsToMany
    {
        return $this->belongsToMany(Tag::class, 'news_post_tag');
    }

    public function author(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function scopePublished(Builder $query): Builder
    {
        return $query->where('status', ContentStatus::Published)
            ->where(function (Builder $q): void {
                $q->whereNull('published_at')->orWhere('published_at', '<=', now());
            });
    }

    public function scopeOfType(Builder $query, NewsType|string $type): Builder
    {
        return $query->where('type', $type instanceof NewsType ? $type->value : $type);
    }

    public function scopeLatestFirst(Builder $query): Builder
    {
        return $query->orderByDesc('published_at')->orderByDesc('id');
    }

    public function title(?string $locale = null): ?string
    {
        return $this->t('title', $locale);
    }

    /**
     * Exhibitions render a date range; everything else shows the publish date.
     */
    public function dateLabel(): ?string
    {
        $from = $this->event_start_date;
        $to = $this->event_end_date;

        if ($from) {
            if ($to && ! $to->isSameDay($from)) {
                if ($from->year !== $to->year) {
                    return $from->translatedFormat('j M Y').' – '.$to->translatedFormat('j M Y');
                }
                if ($from->month === $to->month) {
                    return $from->translatedFormat('j').'–'.$to->translatedFormat('j M Y');      // 17–21 Oct 2026
                }

                return $from->translatedFormat('j M').' – '.$to->translatedFormat('j M Y');      // 28 Sep – 2 Oct 2026
            }

            return $from->translatedFormat('j M Y');
        }

        return $this->published_at?->translatedFormat('j M Y');
    }

    /** True when the item has an event PERIOD (start and a different end date) rather than a single day. */
    public function hasPeriod(): bool
    {
        return $this->event_start_date !== null && $this->event_end_date !== null && ! $this->event_end_date->isSameDay($this->event_start_date);
    }

    public function isUpcoming(): bool
    {
        return $this->event_start_date !== null && $this->event_start_date->isFuture();
    }
}
