<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/** One photo or video in a news item's / exhibition's gallery. */
class NewsPostMedia extends Model
{
    protected $table = 'news_post_media';

    protected $fillable = ['news_post_id', 'media_id', 'kind', 'display_order'];

    public function post(): BelongsTo
    {
        return $this->belongsTo(NewsPost::class, 'news_post_id');
    }

    public function media(): BelongsTo
    {
        return $this->belongsTo(MediaAsset::class, 'media_id');
    }
}
