<?php

return [
    'photos' => 'Galería de fotos',
    'videos' => 'Vídeos',
    'gallery' => 'Galería',
    'prev' => 'Anterior',
    'next' => 'Siguiente',
    'close' => 'Cerrar',
    'photo_n' => 'Foto %d de %d',
    'period' => [
        'from' => 'Desde',
        'to' => 'Hasta',
        'label' => 'Fechas',
        'date' => 'Fecha',
        'help' => '',
    ],
];
