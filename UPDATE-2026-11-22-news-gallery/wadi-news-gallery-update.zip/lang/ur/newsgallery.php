<?php

return [
    'photos' => 'تصاویر کی گیلری',
    'videos' => 'ویڈیوز',
    'gallery' => 'گیلری',
    'prev' => 'پچھلی',
    'next' => 'اگلی',
    'close' => 'بند کریں',
    'photo_n' => 'تصویر %d از %d',
    'period' => [
        'from' => 'از',
        'to' => 'تک',
        'label' => 'تاریخیں',
        'date' => 'تاریخ',
        'help' => '',
    ],
];
