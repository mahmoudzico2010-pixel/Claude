<?php

return [
    'photos' => 'Фотогалерея',
    'videos' => 'Видео',
    'gallery' => 'Галерея',
    'prev' => 'Назад',
    'next' => 'Вперёд',
    'close' => 'Закрыть',
    'photo_n' => 'Фото %d из %d',
    'period' => [
        'from' => 'С',
        'to' => 'По',
        'label' => 'Даты',
        'date' => 'Дата',
        'help' => '',
    ],
];
