<?php

return [
    'photos' => 'Galeria de fotos',
    'videos' => 'Vídeos',
    'gallery' => 'Galeria',
    'prev' => 'Anterior',
    'next' => 'Seguinte',
    'close' => 'Fechar',
    'photo_n' => 'Foto %d de %d',
    'period' => [
        'from' => 'De',
        'to' => 'Até',
        'label' => 'Datas',
        'date' => 'Data',
        'help' => '',
    ],
    'pause' => 'Pausar apresentação',
    'play' => 'Reproduzir apresentação',
    'open' => 'Ver',
];
