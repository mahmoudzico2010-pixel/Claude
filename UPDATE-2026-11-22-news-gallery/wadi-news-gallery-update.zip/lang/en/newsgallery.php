<?php

return [
    'photos' => 'Photo gallery',
    'videos' => 'Videos',
    'gallery' => 'Gallery',
    'prev' => 'Previous',
    'next' => 'Next',
    'close' => 'Close',
    'photo_n' => 'Photo %d of %d',
    'admin' => [
        'title' => 'Photo & video gallery',
        'help' => 'Shown under the article on the public page, for news and exhibitions. Photos and videos come from the media library (or upload new). Drag to reorder (on a phone use the arrows).',
        'photos' => 'Photos',
        'add_photo' => 'Add photo',
        'photo' => 'Photo',
        'videos' => 'Videos',
        'add_video' => 'Add video',
        'video' => 'Video',
    ],
    'period' => [
        'from' => 'From',
        'to' => 'To',
        'label' => 'Dates',
        'date' => 'Date',
        'help' => 'Start and end date of the exhibition. For a one-day event set only the start date.',
    ],
    'pause' => 'Pause slideshow',
    'play' => 'Play slideshow',
    'open' => 'View',
];
