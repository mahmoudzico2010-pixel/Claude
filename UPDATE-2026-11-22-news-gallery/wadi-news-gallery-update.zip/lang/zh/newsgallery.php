<?php

return [
    'photos' => '照片库',
    'videos' => '视频',
    'gallery' => '图库',
    'prev' => '上一张',
    'next' => '下一张',
    'close' => '关闭',
    'photo_n' => '第 %d 张，共 %d 张',
    'period' => [
        'from' => '起始日期',
        'to' => '结束日期',
        'label' => '展会日期',
        'date' => '日期',
        'help' => '',
    ],
    'pause' => '暂停幻灯片',
    'play' => '播放幻灯片',
    'open' => '查看',
];
