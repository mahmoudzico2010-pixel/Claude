<?php

return [
    'photos' => 'Galerie photos',
    'videos' => 'Vidéos',
    'gallery' => 'Galerie',
    'prev' => 'Précédente',
    'next' => 'Suivante',
    'close' => 'Fermer',
    'photo_n' => 'Photo %d sur %d',
    'period' => [
        'from' => 'Du',
        'to' => 'Au',
        'label' => 'Dates',
        'date' => 'Date',
        'help' => '',
    ],
];
