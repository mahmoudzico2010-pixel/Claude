<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** Photo and video gallery of a news item or exhibition. Additive: nothing existing is altered. */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('news_post_media', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('news_post_id')->constrained('news_posts')->cascadeOnDelete();
            $table->foreignId('media_id')->constrained('media_assets')->cascadeOnDelete();
            $table->string('kind', 8)->default('photo');                  // photo | video
            $table->unsignedInteger('display_order')->default(0);
            $table->timestamps();

            $table->unique(['news_post_id', 'media_id']);
            $table->index(['news_post_id', 'kind', 'display_order']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('news_post_media');
    }
};
