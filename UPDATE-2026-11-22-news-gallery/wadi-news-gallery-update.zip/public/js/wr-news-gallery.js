/* News / exhibition gallery: animated, auto-advancing photo slideshow + manual lightbox. No framework.
   Slideshow: cross-fade, slow zoom, auto-advance (pauses on hover, focus, hidden tab, lightbox; stopped by "reduce motion"), arrows, dots/thumbnails,
   swipe, keyboard, play/pause button. Lightbox (press a slide): full photo, prev/next, arrow keys, swipe, Esc; focus returns to the slide. */
(function () {
    'use strict';
    var root = document.querySelector('[data-wr-ng]');
    if (!root) return;
    var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    var rtl = function () { return document.documentElement.dir === 'rtl'; };

    var ss = root.querySelector('[data-wr-ss]');
    var slides = ss ? [].slice.call(ss.querySelectorAll('.wr-ss-slide')) : [];
    var opens = [].slice.call(root.querySelectorAll('[data-wr-ng-open]'));
    var goBtns = ss ? [].slice.call(ss.querySelectorAll('[data-wr-ss-go]')) : [];
    var cur = 0, timer = null, playing = false, userPaused = false, hovering = false, lightboxOpen = false;
    var interval = ss ? Math.max(2500, parseInt(ss.getAttribute('data-interval'), 10) || 5000) : 5000;
    var bar = ss && ss.querySelector('[data-wr-ss-bar]'), count = ss && ss.querySelector('[data-wr-ss-count]');
    var playBtn = ss && ss.querySelector('[data-wr-ss-play]'), playIcon = ss && ss.querySelector('[data-wr-ss-playicon]');

    function activate(i, fromUser) {
        cur = (i + slides.length) % slides.length;
        slides.forEach(function (s, k) { s.classList.toggle('is-active', k === cur); s.setAttribute('aria-hidden', k === cur ? 'false' : 'true'); });
        goBtns.forEach(function (b, k) { if (k === cur) { b.setAttribute('aria-current', 'true'); keepVisible(b); } else { b.removeAttribute('aria-current'); } });
        if (count) count.textContent = (cur + 1) + ' / ' + slides.length;
        // warm the next picture
        var nx = slides[(cur + 1) % slides.length], im = nx && nx.querySelector('img');
        if (im && im.loading === 'lazy') { im.loading = 'eager'; }
        restart();
        if (fromUser === 'user' && !reduce) { /* a manual move keeps autoplay unless the visitor paused it */ }
    }
    function keepVisible(b) {
        var strip = b.closest('.wr-ss-thumbs'); if (!strip) return;
        var r = b.getBoundingClientRect(), s = strip.getBoundingClientRect();
        if (r.left < s.left || r.right > s.right) strip.scrollLeft += (r.left + r.width / 2) - (s.left + s.width / 2);
    }
    function canPlay() { return !reduce && !userPaused && !hovering && !lightboxOpen && !document.hidden && slides.length > 1; }
    function restart() {
        window.clearTimeout(timer);
        playing = canPlay();
        ss.classList.toggle('is-playing', playing);
        if (bar) { bar.style.animation = 'none'; void bar.offsetWidth; bar.style.animation = ''; }
        if (playing) timer = window.setTimeout(function () { activate(cur + 1); }, interval);
    }
    function setPaused(v) {
        userPaused = v;
        if (playBtn) {
            playBtn.setAttribute('aria-pressed', v ? 'false' : 'true');
            playBtn.setAttribute('aria-label', ss.getAttribute(v ? 'data-l-play' : 'data-l-pause'));
            if (playIcon) playIcon.innerHTML = v ? '&#9654;' : '&#10074;&#10074;';
        }
        restart();
    }

    if (ss && slides.length) {
        ss.classList.add('is-js');
        ss.style.setProperty('--wr-ss-ms', interval + 'ms');
        slides.forEach(function (s, k) { s.setAttribute('aria-hidden', k === 0 ? 'false' : 'true'); });
        var prev = ss.querySelector('[data-wr-ss-prev]'), next = ss.querySelector('[data-wr-ss-next]');
        if (prev) prev.addEventListener('click', function () { activate(cur - 1, 'user'); });
        if (next) next.addEventListener('click', function () { activate(cur + 1, 'user'); });
        if (playBtn) playBtn.addEventListener('click', function () { setPaused(!userPaused); });
        goBtns.forEach(function (b) { b.addEventListener('click', function () { activate(parseInt(b.getAttribute('data-wr-ss-go'), 10), 'user'); }); });
        // pause while the pointer or keyboard focus is on the slideshow (WCAG 2.2.2), resume when it leaves
        ss.addEventListener('mouseenter', function () { hovering = true; restart(); });
        ss.addEventListener('mouseleave', function () { hovering = false; restart(); });
        ss.addEventListener('focusin', function () { hovering = true; restart(); });
        ss.addEventListener('focusout', function () { hovering = false; restart(); });
        document.addEventListener('visibilitychange', restart);
        // keyboard on the slideshow
        ss.addEventListener('keydown', function (e) {
            if (e.key === 'ArrowRight') { activate(cur + (rtl() ? -1 : 1), 'user'); e.preventDefault(); }
            if (e.key === 'ArrowLeft') { activate(cur + (rtl() ? 1 : -1), 'user'); e.preventDefault(); }
        });
        // swipe
        var x0 = null;
        ss.addEventListener('touchstart', function (e) { x0 = e.changedTouches[0].clientX; hovering = true; restart(); }, { passive: true });
        ss.addEventListener('touchend', function (e) {
            if (x0 !== null) { var dx = e.changedTouches[0].clientX - x0; if (Math.abs(dx) > 40) { activate(cur + ((dx < 0) !== rtl() ? 1 : -1), 'user'); } }
            x0 = null; window.setTimeout(function () { hovering = false; restart(); }, 4000);
        }, { passive: true });
        setPaused(reduce);     // "reduce motion": manual only, with the play button available
        if (reduce && playBtn) { playBtn.setAttribute('aria-pressed', 'false'); }
        activate(0);
    }

    /* ---- lightbox: press a slide to open; browse manually ---- */
    var dlg = root.querySelector('[data-wr-ng-dialog]');
    if (!dlg || typeof dlg.showModal !== 'function' || !opens.length) return;
    var img = dlg.querySelector('[data-wr-ng-img]'), lcount = dlg.querySelector('[data-wr-ng-count]');
    var tpl = dlg.getAttribute('data-label-n') || '%d / %d', lcur = 0, opener = null, lx0 = null;

    function place(n) {
        lcur = n;
        var t = opens[lcur];
        img.src = t.getAttribute('data-full'); img.alt = t.getAttribute('data-alt') || '';
        lcount.textContent = tpl.replace('%d', lcur + 1).replace('%d', opens.length);
        [lcur - 1, lcur + 1].forEach(function (k) { var p = opens[(k + opens.length) % opens.length]; if (p) { (new Image()).src = p.getAttribute('data-full'); } });
    }
    function show(i, dir) {
        var n = (i + opens.length) % opens.length;
        if (!reduce && dlg.open && dir && n !== lcur) {
            img.style.setProperty('--wr-ng-dx', (dir > 0 ? -28 : 28) * (rtl() ? -1 : 1) + 'px');
            img.classList.add('is-swap');
            window.setTimeout(function () { place(n); img.classList.remove('is-swap'); }, 160);
            return;
        }
        place(n);
    }
    function openAt(i, from) { opener = from; lightboxOpen = true; if (ss) restart(); place(i); if (!dlg.open) dlg.showModal(); }
    opens.forEach(function (t, i) { t.addEventListener('click', function () { openAt(i, t); }); });
    dlg.querySelector('[data-wr-ng-close]').addEventListener('click', function () { dlg.close(); });
    dlg.querySelector('[data-wr-ng-prev]').addEventListener('click', function () { show(lcur - 1, -1); });
    dlg.querySelector('[data-wr-ng-next]').addEventListener('click', function () { show(lcur + 1, 1); });
    dlg.addEventListener('close', function () {
        img.removeAttribute('src'); lightboxOpen = false;
        if (ss) { activate(lcur); }                         // the slideshow continues from the photo the visitor ended on
        if (opener) { try { (ss ? opens[lcur] : opener).focus(); } catch (e) { /* ignore */ } }
    });
    dlg.addEventListener('click', function (e) { if (e.target === dlg || e.target.classList.contains('wr-ng-stage')) dlg.close(); });
    dlg.addEventListener('keydown', function (e) {
        if (e.key === 'ArrowRight') { var d = rtl() ? -1 : 1; show(lcur + d, d); e.preventDefault(); }
        if (e.key === 'ArrowLeft') { var d2 = rtl() ? 1 : -1; show(lcur + d2, d2); e.preventDefault(); }
    });
    dlg.addEventListener('touchstart', function (e) { lx0 = e.changedTouches[0].clientX; }, { passive: true });
    dlg.addEventListener('touchend', function (e) {
        if (lx0 === null) return;
        var dx = e.changedTouches[0].clientX - lx0; lx0 = null;
        if (Math.abs(dx) > 50) { var d = ((dx < 0) !== rtl() ? 1 : -1); show(lcur + d, d); }
    }, { passive: true });
})();
