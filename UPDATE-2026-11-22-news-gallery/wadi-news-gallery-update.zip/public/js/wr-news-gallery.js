/* News / exhibition photo gallery lightbox: native <dialog>, keyboard (Esc, arrows), swipe, focus return. No framework. */
(function () {
    'use strict';
    var root = document.querySelector('[data-wr-ng]');
    var dlg = root && root.querySelector('[data-wr-ng-dialog]');
    if (!dlg || typeof dlg.showModal !== 'function') return;
    var thumbs = [].slice.call(root.querySelectorAll('[data-wr-ng-open]'));
    var img = dlg.querySelector('[data-wr-ng-img]'), count = dlg.querySelector('[data-wr-ng-count]');
    var tpl = dlg.getAttribute('data-label-n') || '%d / %d', cur = 0, opener = null, x0 = null;

    function show(i) {
        cur = (i + thumbs.length) % thumbs.length;
        var t = thumbs[cur];
        img.src = t.getAttribute('data-full'); img.alt = t.getAttribute('data-alt') || '';
        count.textContent = tpl.replace('%d', cur + 1).replace('%d', thumbs.length);
        // warm the neighbours
        [cur - 1, cur + 1].forEach(function (n) { var p = thumbs[(n + thumbs.length) % thumbs.length]; if (p) { (new Image()).src = p.getAttribute('data-full'); } });
    }
    function open(i, from) { opener = from; show(i); if (!dlg.open) dlg.showModal(); }
    thumbs.forEach(function (t, i) { t.addEventListener('click', function () { open(i, t); }); });
    dlg.querySelector('[data-wr-ng-close]').addEventListener('click', function () { dlg.close(); });
    dlg.querySelector('[data-wr-ng-prev]').addEventListener('click', function () { show(cur - 1); });
    dlg.querySelector('[data-wr-ng-next]').addEventListener('click', function () { show(cur + 1); });
    dlg.addEventListener('close', function () { img.removeAttribute('src'); if (opener) { try { opener.focus(); } catch (e) { /* ignore */ } } });
    dlg.addEventListener('click', function (e) { if (e.target === dlg || e.target.classList.contains('wr-ng-stage')) dlg.close(); });
    dlg.addEventListener('keydown', function (e) {
        var rtl = document.documentElement.dir === 'rtl';
        if (e.key === 'ArrowRight') { show(cur + (rtl ? -1 : 1)); e.preventDefault(); }
        if (e.key === 'ArrowLeft') { show(cur + (rtl ? 1 : -1)); e.preventDefault(); }
    });
    dlg.addEventListener('touchstart', function (e) { x0 = e.changedTouches[0].clientX; }, { passive: true });
    dlg.addEventListener('touchend', function (e) {
        if (x0 === null) return;
        var dx = e.changedTouches[0].clientX - x0; x0 = null;
        if (Math.abs(dx) > 50) { var rtl = document.documentElement.dir === 'rtl'; show(cur + ((dx < 0) !== rtl ? 1 : -1)); }
    }, { passive: true });
})();
