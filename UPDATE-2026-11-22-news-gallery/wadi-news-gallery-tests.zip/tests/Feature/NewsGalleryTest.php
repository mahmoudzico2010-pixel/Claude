<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Enums\ContentStatus;
use App\Enums\NewsType;
use App\Filament\Resources\News\Pages\EditNewsPost;
use App\Models\MediaAsset;
use App\Models\NewsPost;
use App\Models\NewsPostMedia;
use App\Models\SiteSetting;
use App\Models\User;
use Filament\Facades\Filament;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Livewire\Livewire;
use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;

final class NewsGalleryTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
        SiteSetting::setMany(['maintenance_mode' => false], 'site');
        Filament::setCurrentPanel('admin');
    }

    private function media(string $name, string $mime = 'image/webp'): MediaAsset
    {
        return MediaAsset::create(['disk' => 'public', 'path' => 'media/news/'.$name, 'filename' => $name, 'original_filename' => $name, 'mime_type' => $mime, 'extension' => pathinfo($name, PATHINFO_EXTENSION), 'size' => 100, 'width' => 800, 'height' => 600, 'folder' => 'news', 'checksum' => sha1($name)]);
    }

    private function newsPost(string $slug, NewsType $type = NewsType::News, ContentStatus $status = ContentStatus::Published): NewsPost
    {
        $p = NewsPost::create(['slug' => $slug, 'type' => $type, 'status' => $status, 'published_at' => now()->subDay()]);
        $p->translations()->create(['locale' => 'en', 'title' => 'Title '.$slug]);

        return $p;
    }

    private function admin(): void
    {
        $u = User::factory()->create(['is_active' => true]);
        $u->assignRole(User::ROLE_SUPER_ADMIN);
        $this->actingAs($u);
    }

    #[Test]
    public function the_gallery_is_ordered_and_split_into_photos_and_videos(): void
    {
        $p = $this->newsPost('sial');
        $a = $this->media('a.webp');
        $b = $this->media('b.webp');
        $v = $this->media('clip.mp4', 'video/mp4');
        NewsPostMedia::create(['news_post_id' => $p->id, 'media_id' => $b->id, 'kind' => 'photo', 'display_order' => 1]);
        NewsPostMedia::create(['news_post_id' => $p->id, 'media_id' => $a->id, 'kind' => 'photo', 'display_order' => 0]);
        NewsPostMedia::create(['news_post_id' => $p->id, 'media_id' => $v->id, 'kind' => 'video', 'display_order' => 0]);

        $this->assertSame([$a->id, $b->id], $p->galleryPhotos->pluck('media_id')->all());
        $this->assertSame([$v->id], $p->galleryVideos->pluck('media_id')->all());
    }

    #[Test]
    public function the_public_page_of_a_news_item_and_of_an_exhibition_shows_photos_and_videos(): void
    {
        foreach ([[NewsType::News, 'news-one'], [NewsType::Exhibition, 'expo-one']] as [$type, $slug]) {
            $p = $this->newsPost($slug, $type);
            foreach (['1.webp', '2.webp', '3.webp'] as $i => $f) {
                NewsPostMedia::create(['news_post_id' => $p->id, 'media_id' => $this->media($slug.$f)->id, 'kind' => 'photo', 'display_order' => $i]);
            }
            NewsPostMedia::create(['news_post_id' => $p->id, 'media_id' => $this->media($slug.'.mp4', 'video/mp4')->id, 'kind' => 'video', 'display_order' => 0]);

            $html = $this->get("/en/news/$slug")->assertOk()->getContent();
            $this->assertStringContainsString('data-wr-ng', $html, $slug);
            $this->assertSame(3, substr_count($html, 'data-wr-ng-open='), $slug);
            $this->assertSame(1, substr_count($html, '<video '), $slug);
            $this->assertStringContainsString('preload="metadata"', $html);
            $this->assertStringContainsString('js/wr-news-gallery.js', $html);
            $this->assertStringContainsString('Photo gallery', $html);
            $this->assertStringContainsString('data-wr-ss', $html, 'photos are a slideshow');
            $this->assertSame(3, substr_count($html, 'data-wr-ss-go='), 'one thumbnail-strip button per photo');
            $this->assertStringContainsString('aria-roledescription="carousel"', $html);
            $this->assertStringContainsString('data-wr-ss-play', $html, 'the slideshow can be paused');
            $this->assertStringContainsString('prefers-reduced-motion', $html);
            $this->assertSame(1, substr_count($html, '<h1'), 'the gallery adds no second H1');
        }
    }

    #[Test]
    public function a_post_without_a_gallery_gets_no_gallery_markup_and_no_extra_script(): void
    {
        $this->newsPost('plain');
        $html = $this->get('/en/news/plain')->assertOk()->getContent();
        $this->assertStringNotContainsString('data-wr-ng', $html);
        $this->assertStringNotContainsString('wr-news-gallery.js', $html);
    }

    #[Test]
    public function the_gallery_follows_the_language_labels_and_rtl(): void
    {
        $p = $this->newsPost('arabic-gallery');
        $p->translations()->create(['locale' => 'ar', 'title' => 'عنوان']);
        NewsPostMedia::create(['news_post_id' => $p->id, 'media_id' => $this->media('x.webp')->id, 'kind' => 'photo', 'display_order' => 0]);
        $html = $this->get('/ar/news/arabic-gallery')->assertOk()->getContent();
        $this->assertStringContainsString('معرض الصور', $html);
        $this->assertStringContainsString('dir="rtl"', $html);
    }

    #[Test]
    public function a_draft_post_and_its_gallery_stay_private(): void
    {
        $p = $this->newsPost('secret', NewsType::News, ContentStatus::Draft);
        NewsPostMedia::create(['news_post_id' => $p->id, 'media_id' => $this->media('s.webp')->id, 'kind' => 'photo', 'display_order' => 0]);
        $this->get('/en/news/secret')->assertNotFound();
    }

    #[Test]
    public function a_wrongly_typed_file_in_the_gallery_is_not_rendered_as_the_other_kind(): void
    {
        $p = $this->newsPost('mismatch');
        NewsPostMedia::create(['news_post_id' => $p->id, 'media_id' => $this->media('doc.pdf', 'application/pdf')->id, 'kind' => 'photo', 'display_order' => 0]);
        NewsPostMedia::create(['news_post_id' => $p->id, 'media_id' => $this->media('pic.webp')->id, 'kind' => 'video', 'display_order' => 0]);
        $html = $this->get('/en/news/mismatch')->assertOk()->getContent();
        $this->assertStringNotContainsString('data-wr-ng', $html);
        $this->assertStringNotContainsString('<video ', $html);
    }

    #[Test]
    public function the_panel_saves_reorders_and_removes_gallery_items(): void
    {
        $this->admin();
        $p = $this->newsPost('edit-me', NewsType::Exhibition);
        $a = $this->media('a.webp');
        $b = $this->media('b.webp');
        $v = $this->media('v.mp4', 'video/mp4');

        $c = Livewire::test(EditNewsPost::class, ['record' => $p->getRouteKey()])
            ->fillForm([
                'galleryPhotos' => [['media_id' => $a->id], ['media_id' => $b->id]],
                'galleryVideos' => [['media_id' => $v->id]],
            ])->call('save')->assertHasNoFormErrors();

        $p = $p->fresh();
        $this->assertSame([$a->id, $b->id], $p->galleryPhotos->pluck('media_id')->all());
        $this->assertSame([$v->id], $p->galleryVideos->pluck('media_id')->all());
        $this->assertSame(['photo', 'photo', 'video'], NewsPostMedia::orderBy('id')->pluck('kind')->all());

        // reorder
        $items = $p->galleryPhotos->pluck('id')->all();
        $c->fillForm(['galleryPhotos' => [['id' => $items[1], 'media_id' => $b->id], ['id' => $items[0], 'media_id' => $a->id]]])->call('save');
        $this->assertSame([$b->id, $a->id], $p->fresh()->galleryPhotos->pluck('media_id')->all());

        // remove one
        $c->fillForm(['galleryPhotos' => [['id' => $items[1], 'media_id' => $b->id]]])->call('save');
        $this->assertSame([$b->id], $p->fresh()->galleryPhotos->pluck('media_id')->all());
        $this->assertSame(1, NewsPostMedia::where('kind', 'video')->count(), 'the video is untouched');
        $this->assertNotNull(MediaAsset::find($a->id), 'removing a gallery item never deletes the file from the library');
    }

    #[Test]
    public function the_media_library_reports_gallery_use_and_deleting_the_post_clears_the_links_only(): void
    {
        $p = $this->newsPost('usage');
        $m = $this->media('u.webp');
        NewsPostMedia::create(['news_post_id' => $p->id, 'media_id' => $m->id, 'kind' => 'photo', 'display_order' => 0]);
        $labels = collect($m->usage())->pluck('count', 'label');
        $this->assertSame(1, $labels[__('media.usage.news_gallery')] ?? null);
    }

    private function realPng(int $seed): \Illuminate\Http\Testing\File
    {
        $im = imagecreatetruecolor(48, 48);
        imagefill($im, 0, 0, imagecolorallocate($im, ($seed * 53) % 255, ($seed * 97) % 255, ($seed * 31) % 255));
        ob_start();
        imagepng($im);

        return \Illuminate\Http\UploadedFile::fake()->createWithContent("photo-$seed.png", (string) ob_get_clean());
    }

    #[Test]
    public function several_photos_can_be_uploaded_together_and_land_in_the_gallery_list(): void
    {
        \Illuminate\Support\Facades\Storage::fake('public');
        $this->admin();
        $p = $this->newsPost('multi', NewsType::Exhibition);
        $existing = $this->media('keep.webp');
        NewsPostMedia::create(['news_post_id' => $p->id, 'media_id' => $existing->id, 'kind' => 'photo', 'display_order' => 0]);
        $before = MediaAsset::count();

        $c = Livewire::test(EditNewsPost::class, ['record' => $p->getRouteKey()])
            ->callAction(\Filament\Actions\Testing\TestAction::make('galleryPhotos_upload_many')->schemaComponent('gallery', schema: 'form'), ['files' => [$this->realPng(1), $this->realPng(2), $this->realPng(3)]])
            ->assertHasNoActionErrors();

        $this->assertSame($before + 3, MediaAsset::count(), 'three files registered in the library');
        $c->call('save')->assertHasNoFormErrors();
        $ids = $p->fresh()->galleryPhotos->pluck('media_id')->all();
        $this->assertCount(4, $ids, 'the existing item is kept and three are added');
        $this->assertContains($existing->id, $ids);
    }

    #[Test]
    public function uploading_the_same_photos_again_adds_nothing_twice(): void
    {
        \Illuminate\Support\Facades\Storage::fake('public');
        $this->admin();
        $p = $this->newsPost('twice', NewsType::News);
        $c = Livewire::test(EditNewsPost::class, ['record' => $p->getRouteKey()])
            ->callAction(\Filament\Actions\Testing\TestAction::make('galleryPhotos_upload_many')->schemaComponent('gallery', schema: 'form'), ['files' => [$this->realPng(7), $this->realPng(8)]]);
        $c->call('save');
        $media = MediaAsset::count();
        $c->callAction(\Filament\Actions\Testing\TestAction::make('galleryPhotos_upload_many')->schemaComponent('gallery', schema: 'form'), ['files' => [$this->realPng(7), $this->realPng(8)]]);
        $c->call('save')->assertHasNoFormErrors();
        $this->assertSame($media, MediaAsset::count(), 'identical files reuse the library copy');
        $this->assertSame(2, $p->fresh()->galleryPhotos->count(), 'and are not listed twice');
    }
}
