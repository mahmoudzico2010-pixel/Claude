<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Enums\ContentStatus;
use App\Enums\NewsType;
use App\Filament\Resources\News\Pages\CreateNewsPost;
use App\Filament\Resources\News\Pages\EditNewsPost;
use App\Models\NewsPost;
use App\Models\SiteSetting;
use App\Models\User;
use Filament\Facades\Filament;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Livewire\Livewire;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;

final class NewsExhibitionPeriodTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
        SiteSetting::setMany(['maintenance_mode' => false], 'site');
        Filament::setCurrentPanel('admin');
    }

    private function exhibition(string $slug, ?string $from, ?string $to): NewsPost
    {
        $p = NewsPost::create(['slug' => $slug, 'type' => NewsType::Exhibition, 'status' => ContentStatus::Published, 'published_at' => now()->subDay(), 'event_start_date' => $from, 'event_end_date' => $to, 'location' => 'Paris']);
        $p->translations()->create(['locale' => 'en', 'title' => 'Expo '.$slug]);
        $p->translations()->create(['locale' => 'ar', 'title' => 'معرض '.$slug]);

        return $p->fresh();
    }

    /** @return array<string, array{0: ?string, 1: ?string, 2: string}> */
    public static function labels(): array
    {
        return [
            'same month' => ['2026-10-17', '2026-10-21', '17–21 Oct 2026'],
            'different months' => ['2026-09-28', '2026-10-02', '28 Sep – 2 Oct 2026'],
            'across a year' => ['2026-12-29', '2027-01-03', '29 Dec 2026 – 3 Jan 2027'],
            'single day' => ['2026-10-17', null, '17 Oct 2026'],
            'end equals start' => ['2026-10-17', '2026-10-17', '17 Oct 2026'],
        ];
    }

    #[Test]
    #[DataProvider('labels')]
    public function the_period_is_written_as_a_range(?string $from, ?string $to, string $expected): void
    {
        app()->setLocale('en');
        $this->assertSame($expected, $this->exhibition('p'.md5($from.$to), $from, $to)->dateLabel());
    }

    #[Test]
    public function the_public_page_shows_the_period_with_its_own_label_and_the_schema_has_both_dates(): void
    {
        $this->exhibition('sial', '2026-10-17', '2026-10-21');
        $html = $this->get('/en/news/sial')->assertOk()->getContent();
        $this->assertStringContainsString('17–21 Oct 2026', $html);
        $this->assertStringContainsString('Dates', $html);
        $this->assertStringContainsString('"startDate":"2026-10-17"', str_replace(' ', '', $html));
        $this->assertStringContainsString('"endDate":"2026-10-21"', str_replace(' ', '', $html));

        $ar = $this->get('/ar/news/sial')->assertOk()->getContent();
        $this->assertStringContainsString('فترة المعرض', $ar);
    }

    #[Test]
    public function a_single_day_event_says_date_not_dates(): void
    {
        $this->exhibition('one-day', '2026-10-17', null);
        $html = $this->get('/en/news/one-day')->assertOk()->getContent();
        $this->assertStringContainsString('17 Oct 2026', $html);
        $this->assertStringNotContainsString('Dates', explode('spec-label', $html)[1] ?? '');
    }

    #[Test]
    public function the_period_fields_show_when_editing_an_existing_exhibition_and_hide_for_other_types(): void
    {
        $u = User::factory()->create(['is_active' => true]);
        $u->assignRole(User::ROLE_SUPER_ADMIN);
        $this->actingAs($u);

        $e = $this->exhibition('edit', '2026-10-17', '2026-10-21');
        Livewire::test(EditNewsPost::class, ['record' => $e->getRouteKey()])
            ->assertFormFieldVisible('event_start_date')->assertFormFieldVisible('event_end_date')
            ->assertFormSet(['event_start_date' => '2026-10-17', 'event_end_date' => '2026-10-21']);

        $n = NewsPost::create(['slug' => 'plain', 'type' => NewsType::News, 'status' => ContentStatus::Published]);
        $n->translations()->create(['locale' => 'en', 'title' => 'Plain']);
        Livewire::test(EditNewsPost::class, ['record' => $n->getRouteKey()])->assertFormFieldHidden('event_start_date');
    }

    #[Test]
    public function the_end_date_cannot_be_before_the_start_and_an_end_needs_a_start(): void
    {
        $u = User::factory()->create(['is_active' => true]);
        $u->assignRole(User::ROLE_SUPER_ADMIN);
        $this->actingAs($u);
        $e = $this->exhibition('rules', '2026-10-17', '2026-10-21');

        Livewire::test(EditNewsPost::class, ['record' => $e->getRouteKey()])
            ->fillForm(['event_end_date' => '2026-10-10'])->call('save')->assertHasFormErrors(['event_end_date']);
        Livewire::test(EditNewsPost::class, ['record' => $e->getRouteKey()])
            ->fillForm(['event_start_date' => null, 'event_end_date' => '2026-10-21'])->call('save')->assertHasFormErrors(['event_start_date']);
        $this->assertSame('2026-10-21', $e->fresh()->event_end_date->toDateString());

        Livewire::test(EditNewsPost::class, ['record' => $e->getRouteKey()])
            ->fillForm(['event_start_date' => '2026-11-02', 'event_end_date' => '2026-11-05'])->call('save')->assertHasNoFormErrors();
        $this->assertSame('2026-11-02', $e->fresh()->event_start_date->toDateString());
        $this->assertSame('2026-11-05', $e->fresh()->event_end_date->toDateString());
    }
}
