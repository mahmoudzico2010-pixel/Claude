<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** Who created a product<->photo link: 'import' (importer), 'manual' (review queue / admin) or 'bulk'. NULL = unknown, treated as a person's decision. */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('product_images', function (Blueprint $table): void {
            $table->string('source', 10)->nullable();
        });
    }

    public function down(): void
    {
        Schema::table('product_images', fn (Blueprint $t) => $t->dropColumn('source'));
    }
};
