<?php

declare(strict_types=1);

use App\Services\Catalog\CatalogHierarchy;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * Phase 2, additive: per-language image alt text (en/ar migrated, never dropped), bulk-edit history, import hashes that tell
 * prepared copy from human-edited copy, review-queue decision columns, variety aliases; Azizi and Red Peppers renamed in place.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('media_asset_translations', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('media_id')->constrained('media_assets')->cascadeOnDelete();
            $table->string('locale', 8);
            $table->string('alt', 400)->nullable();
            $table->boolean('generated')->default(false);   // written by the importer, not typed by a person
            $table->timestamps();
            $table->unique(['media_id', 'locale']);
        });

        // Existing English and Arabic alt text is copied, the old columns stay in place.
        foreach (DB::table('media_assets')->select('id', 'alt_en', 'alt_ar')->get() as $m) {
            foreach (['en' => $m->alt_en, 'ar' => $m->alt_ar] as $locale => $alt) {
                if (filled($alt)) {
                    DB::table('media_asset_translations')->insert(['media_id' => $m->id, 'locale' => $locale, 'alt' => $alt, 'generated' => false, 'created_at' => now(), 'updated_at' => now()]);
                }
            }
        }

        Schema::table('product_translations', function (Blueprint $table): void {
            $table->json('imported_hashes')->nullable();    // field => sha1 of the value the importer wrote
        });

        Schema::table('varieties', function (Blueprint $table): void {
            $table->json('aliases')->nullable();
        });

        // Copy imported by Phase 1: any field still equal to the prepared text is recorded as unedited.
        $file = database_path('data/catalog/products-59.json');
        if (is_file($file)) {
            foreach ((array) (json_decode((string) file_get_contents($file), true)['products'] ?? []) as $row) {
                $pid = DB::table('products')->where('import_key', $row['key'])->value('id');
                if (! $pid) {
                    continue;
                }
                foreach ($row['translations'] as $locale => $fields) {
                    $t = DB::table('product_translations')->where('product_id', $pid)->where('locale', $locale)->first();
                    if (! $t) {
                        continue;
                    }
                    $hashes = [];
                    foreach ($fields as $f => $v) {
                        if ((string) $t->{$f} === (string) $v) {
                            $hashes[$f] = sha1((string) $v);
                        }
                    }
                    DB::table('product_translations')->where('id', $t->id)->update(['imported_hashes' => json_encode($hashes)]);
                }
            }
        }

        Schema::table('catalog_media_reviews', function (Blueprint $table): void {
            $table->string('assigned_role', 10)->nullable();            // primary | gallery
            $table->foreignId('previous_primary_id')->nullable()->constrained('media_assets')->nullOnDelete();
            $table->boolean('link_created')->default(false);
            $table->timestamp('decided_at')->nullable();
            $table->foreignId('decided_by')->nullable()->constrained('users')->nullOnDelete();
            $table->text('note')->nullable();
        });

        Schema::create('bulk_edit_runs', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->string('action', 40);
            $table->json('scope')->nullable();                 // description, count, filter summary
            $table->json('outcome')->nullable();               // changed / skipped / invalid / failed
            $table->timestamp('rolled_back_at')->nullable();
            $table->json('rollback_outcome')->nullable();
            $table->timestamps();
        });

        Schema::create('bulk_edit_changes', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('run_id')->constrained('bulk_edit_runs')->cascadeOnDelete();
            $table->unsignedBigInteger('product_id');
            $table->string('kind', 16);                        // column | translation | relation | media | status | trash
            $table->string('field', 60);
            $table->string('locale', 8)->nullable();
            $table->json('before')->nullable();
            $table->json('after')->nullable();
            $table->index(['run_id', 'product_id']);
        });

        // Azizi: the existing "Aggizi" record is renamed in place (id, slug, URLs, media, relations untouched).
        DB::table('varieties')->whereIn('slug', ['aggizi', 'azizi'])->get()->each(function ($v): void {
            $aliases = array_values(array_unique(array_merge((array) json_decode((string) $v->aliases, true), ['Aggizi', 'aggizi', 'Azizi'])));
            $set = ['aliases' => json_encode($aliases)];
            if (in_array($v->name_en, ['Aggizi', 'aggizi'], true)) {
                $set['name_en'] = 'Azizi';
            }
            $set['name_ar'] = 'عزيزي';   // the owner's decision: canonical Arabic name
            DB::table('varieties')->where('id', $v->id)->update($set);
        });

        // Red Pepper -> Red Peppers (English label only; id, slug and URLs unchanged).
        if (DB::table('products')->exists()) {
            CatalogHierarchy::apply();
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('bulk_edit_changes');
        Schema::dropIfExists('bulk_edit_runs');
        Schema::table('catalog_media_reviews', function (Blueprint $table): void {
            $table->dropConstrainedForeignId('previous_primary_id');
            $table->dropConstrainedForeignId('decided_by');
            $table->dropColumn(['assigned_role', 'link_created', 'decided_at', 'note']);
        });
        Schema::table('varieties', fn (Blueprint $t) => $t->dropColumn('aliases'));
        Schema::table('product_translations', fn (Blueprint $t) => $t->dropColumn('imported_hashes'));
        Schema::dropIfExists('media_asset_translations');
    }
};
