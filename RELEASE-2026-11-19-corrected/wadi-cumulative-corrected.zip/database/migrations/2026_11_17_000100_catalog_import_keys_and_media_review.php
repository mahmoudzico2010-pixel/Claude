<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** Stable import key per product (family:cultivar:style) and the photo review queue. Additive. */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('products', function (Blueprint $table): void {
            $table->string('import_key', 120)->nullable()->unique();
        });

        Schema::create('catalog_media_reviews', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('media_id')->constrained('media_assets')->cascadeOnDelete();
            $table->string('original_filename', 255);
            $table->json('candidates')->nullable();               // product import keys that might match
            $table->string('reason', 255);
            $table->string('status', 12)->default('pending');     // pending | assigned | rejected
            $table->foreignId('product_id')->nullable()->constrained('products')->nullOnDelete();
            $table->timestamps();
            $table->unique('media_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('catalog_media_reviews');
        Schema::table('products', function (Blueprint $table): void {
            $table->dropUnique(['import_key']);
            $table->dropColumn('import_key');
        });
    }
};
