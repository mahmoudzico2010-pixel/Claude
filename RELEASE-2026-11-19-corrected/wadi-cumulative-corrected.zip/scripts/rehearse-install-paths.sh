#!/usr/bin/env bash
# Disposable rehearsal of BOTH upgrade paths on a throw-away database. Never touches the configured .env database.
# Usage:  scripts/rehearse-install-paths.sh sqlite            (any machine, proves the logic)
#         scripts/rehearse-install-paths.sh mysql DBNAME USER  (run on STAGING against an EMPTY, disposable MySQL 5.7 schema; asks for the password)
set -euo pipefail
cd "$(dirname "$0")/.."
KIND="${1:-sqlite}"; PHOTOS="${PHOTOS:-}"
if [ "$KIND" = sqlite ]; then
  export DB_CONNECTION=sqlite; DBFILE="$(mktemp -t wadi-rehearsal-XXXX.sqlite)"; export DB_DATABASE="$DBFILE"
else
  export DB_CONNECTION=mysql DB_DATABASE="${2:?db name}" DB_USERNAME="${3:?user}"; read -rsp "MySQL password: " DB_PASSWORD; export DB_PASSWORD; echo
fi
export APP_ENV=testing CACHE_STORE=array SESSION_DRIVER=array QUEUE_CONNECTION=sync
OLD="$(mktemp -d)"           # migrations as they were BEFORE this release (the 2026-11-16 baseline)
for f in database/migrations/*.php; do
  case "$(basename "$f")" in 2026_11_17_*|2026_11_18_*|2026_11_19_*) ;; *) cp "$f" "$OLD/";; esac
done
img=""; [ -n "$PHOTOS" ] && img="--photos=$PHOTOS"
run() { echo; echo "### $*"; "$@"; }
baseline() { php artisan migrate:fresh --force --path="$OLD" --realpath >/dev/null; php artisan db:seed --force >/dev/null; php artisan catalogue:hierarchy >/dev/null; }

echo "================ PATH B: neither phase installed ================"
baseline
run php artisan migrate --force                      # runs 2026_11_17, 2026_11_18, 2026_11_19
run php artisan catalogue:hierarchy
run php artisan catalog:import-59 $img               # DRY RUN: must write nothing
run php artisan catalog:import-59 --apply $img       # first apply
run php artisan catalog:import-59 --apply $img       # repeat: zero creates
php artisan tinker --execute='echo "products with import_key: ".App\Models\Product::whereNotNull("import_key")->count()." (expect 59); drafts: ".App\Models\Product::whereNotNull("import_key")->where("status","draft")->count();'
echo; echo "--- rollback rehearsal (engine): change colour on 2 products, then roll back"
php artisan tinker --execute='
$ed=new App\Services\Catalog\BulkProductEditor; $u=App\Models\User::first() ?? App\Models\User::factory()->create(["is_active"=>true]); $u->assignRole(App\Models\User::ROLE_SUPER_ADMIN);
$ids=App\Models\Product::whereNotNull("import_key")->limit(2)->pluck("id")->all(); $spec=["color"=>["mode"=>"set","value"=>"Rehearsal"]];
$run=$ed->apply($ed->plan($ed->products($ids),$spec,$u),$spec,$u,"rehearsal"); echo "changed ".$run->outcome["changed"]."\n";
$r=$ed->rollback($run->fresh(),$u); echo "restored ".$r["restored"]." denied ".count($r["denied"])." conflicts ".count($r["conflicts"])."\n";'

echo; echo "================ PATH A: Phase 1 already installed ================"
baseline
# Phase 1 state, simulated on the disposable database: Phase-1 migration only, data imported, then this release's two newer
# migrations rolled back by path (their files are removed again by `migrate` below, exactly as on a real Phase-1 site).
php artisan migrate --force >/dev/null
php artisan catalog:import-59 --apply $img | head -1
php artisan migrate:rollback --force --path=database/migrations/2026_11_19_000100_product_image_provenance.php >/dev/null
php artisan migrate:rollback --force --path=database/migrations/2026_11_18_000100_catalog_phase2.php >/dev/null
php artisan tinker --execute='echo "schema is Phase-1 shaped: imported_hashes column ".(Illuminate\Support\Facades\Schema::hasColumn("product_translations","imported_hashes")?"PRESENT (unexpected)":"absent")."\n";'
echo "--- deploy this release's files, then:"
run php artisan catalog:import-59 --apply $img || echo "(expected: refuses until migrated)"
run php artisan migrate --force                      # only the 2026_11_18 and 2026_11_19 migrations are new
run php artisan catalog:import-59 --apply $img       # repeat: must change nothing
php artisan tinker --execute='echo "products with import_key: ".App\Models\Product::whereNotNull("import_key")->count()." (expect 59); human/Phase-1 translations kept; alt rows: ".App\Models\MediaAssetTranslation::count();'
php artisan migrate:status | tail -6
echo; echo "REHEARSAL DONE ($KIND)"
[ "$KIND" = sqlite ] && rm -f "$DBFILE" && rm -rf "$OLD" || true
