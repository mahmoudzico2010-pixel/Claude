#!/usr/bin/env bash
# Disposable rehearsal of BOTH upgrade paths. It only ever resets a database that it has proven is the empty, disposable one it was given.
#
#   scripts/rehearse-install-paths.sh sqlite
#   REHEARSAL_CONFIRM_DB=wadi_rehearsal PHOTOS=/path/WebP scripts/rehearse-install-paths.sh mysql wadi_rehearsal DBUSER [HOST]
#
# Safety rules (the script exits non-zero and touches nothing if any fails):
#  * Laravel itself is asked which connection/database it would use (scripts/rehearsal-probe.php target) and it must equal what was requested;
#  * mysql: the database must not be the .env site database, its name must contain "rehearsal" or "disposable", it must hold ZERO tables when we
#    start, and you must confirm by setting REHEARSAL_CONFIRM_DB to the exact name;
#  * a marker table with a random token is created once the emptiness check passed; before EVERY reset the connection, database name and marker are
#    re-verified, then `db:wipe` runs (not migrate:fresh, which would run against whatever the environment points at);
#  * success is printed only if every check passed: 59 products, dry run writes nothing, repeat import changes nothing, rollback restores values.
# REHEARSAL_SELFTEST=count|repeat|rollback injects a deliberate fault: the script must then FAIL.
set -euo pipefail
cd "$(dirname "$0")/.."

KIND="${1:-sqlite}"; PHOTOS="${PHOTOS:-}"; SELFTEST="${REHEARSAL_SELFTEST:-}"
CHECKS=0
die() { echo "REHEARSAL FAILED: $*" >&2; exit 1; }
check() { local what="$1"; shift; if "$@"; then CHECKS=$((CHECKS+1)); echo "  ✔ $what"; else die "$what"; fi; }
probe() { php scripts/rehearsal-probe.php "$@"; }
json() { php -r '$j=json_decode(stream_get_contents(STDIN),true); $v=$j; foreach (explode(".", $argv[1]) as $k) { $v=$v[$k] ?? null; } echo is_array($v)?json_encode($v):$v;' "$1"; }

# ---- 1. pin the target and prove it is disposable -------------------------------------------------------------
ENV_DB="$(grep -E '^DB_DATABASE=' .env 2>/dev/null | head -1 | cut -d= -f2- | tr -d '"' || true)"
TOKEN="$(php -r 'echo bin2hex(random_bytes(12));')"
cleanup() { [ -n "${DBFILE:-}" ] && rm -f "$DBFILE"; [ -n "${OLD:-}" ] && rm -rf "$OLD"; true; }
trap cleanup EXIT

export APP_ENV=testing CACHE_STORE=array SESSION_DRIVER=array QUEUE_CONNECTION=sync
case "$KIND" in
  sqlite)
    if [ -n "${REHEARSAL_SQLITE_FILE:-}" ]; then DBFILE=""; EXISTING="$REHEARSAL_SQLITE_FILE"; else DBFILE="$(mktemp -t wadi-rehearsal-XXXX.sqlite)"; EXISTING="$DBFILE"; fi
    export DB_CONNECTION=sqlite DB_DATABASE="$EXISTING"
    EXPECT_DRIVER=sqlite; EXPECT_DB="$EXISTING"
    ;;
  mysql)
    DBNAME="${2:?usage: mysql DBNAME DBUSER [HOST]}"; DBUSER="${3:?usage: mysql DBNAME DBUSER [HOST]}"; DBHOST="${4:-127.0.0.1}"
    [[ "$DBNAME" =~ (rehearsal|disposable) ]] || die "database name '$DBNAME' must contain 'rehearsal' or 'disposable'"
    [ "$DBNAME" != "$ENV_DB" ] || die "'$DBNAME' is the database configured in .env (the site's own); refusing"
    [ "${REHEARSAL_CONFIRM_DB:-}" = "$DBNAME" ] || die "set REHEARSAL_CONFIRM_DB=$DBNAME to confirm this is the disposable database"
    read -rsp "MySQL password for $DBUSER: " DB_PASSWORD; echo; export DB_PASSWORD
    export DB_CONNECTION=mysql DB_HOST="$DBHOST" DB_DATABASE="$DBNAME" DB_USERNAME="$DBUSER"
    EXPECT_DRIVER=mysql; EXPECT_DB="$DBNAME"
    ;;
  *) die "first argument must be sqlite or mysql" ;;
esac

assert_target() {   # $1 = "initial" | "reset"
  local t; t="$(probe target)" || die "Laravel could not connect to the target database"
  [ "$(echo "$t" | json driver)" = "$EXPECT_DRIVER" ] || die "Laravel's effective driver is '$(echo "$t" | json driver)', expected $EXPECT_DRIVER"
  [ "$(echo "$t" | json database)" = "$EXPECT_DB" ] || die "Laravel's effective database is '$(echo "$t" | json database)', expected '$EXPECT_DB'"
  if [ "$KIND" = mysql ]; then
    [ "$(echo "$t" | json database)" != "$ENV_DB" ] || die "effective database equals the .env site database"
    [ "$(echo "$t" | json host)" = "$DBHOST" ] || die "effective host '$(echo "$t" | json host)' differs from requested '$DBHOST'"
  fi
  if [ "$1" = initial ]; then
    [ "$(echo "$t" | json tables)" = "0" ] || die "the target database is not empty ($(echo "$t" | json tables) tables); use a fresh empty schema"
    probe marker-create "$TOKEN" >/dev/null
  else
    probe marker-check "$TOKEN" >/dev/null || die "marker table missing: this is not the database the rehearsal started on"
  fi
}
reset_db() {        # re-verify the target EVERY time before wiping it
  assert_target reset
  php artisan db:wipe --force >/dev/null
  probe marker-create "$TOKEN" >/dev/null
}

echo "== target check"; assert_target initial; echo "  target: $(probe target)"

OLD="$(mktemp -d)"            # migrations as they were BEFORE this release (the 2026-11-16 baseline)
for f in database/migrations/*.php; do
  case "$(basename "$f")" in 2026_11_1[7-9]_*|2026_11_2[0-9]_*|2026_11_3[01]_*) ;; *) cp "$f" "$OLD/";; esac     # everything from the catalogue releases on is "new"
done
img=""; [ -n "$PHOTOS" ] && img="--photos=$PHOTOS"
fp() { probe fingerprint | cut -d' ' -f1; }
baseline() { reset_db; php artisan migrate --force --path="$OLD" --realpath >/dev/null; php artisan db:seed --force >/dev/null; php artisan catalogue:hierarchy >/dev/null; }

verify_import_and_rollback() {   # $1 = label
  local label="$1"
  echo "== $label: dry run must write nothing"
  local a b
  a="$(fp)"; php artisan catalog:import-59 $img >/dev/null; b="$(fp)"
  check "dry run left the database untouched" [ "$a" = "$b" ]

  echo "== $label: first apply"
  php artisan catalog:import-59 --apply $img | head -1
  [ "$SELFTEST" = count ] && probe tamper drop-product >/dev/null
  check "exactly 59 products carry an import key (found $(probe products))" [ "$(probe products)" = "59" ]

  echo "== $label: repeat import must change nothing"
  a="$(fp)"
  [ "$SELFTEST" = repeat ] && probe tamper change-data >/dev/null     # simulates an import that altered data
  php artisan catalog:import-59 --apply $img >/dev/null; b="$(fp)"
  check "repeat import left every imported table identical" [ "$a" = "$b" ]
  check "still 59 products after the repeat" [ "$(probe products)" = "59" ]

  echo "== $label: bulk edit then rollback must restore the original values"
  local r run ids before
  r="$(probe bulk-set)"; run="$(echo "$r" | json run)"; before="$(echo "$r" | json before)"
  check "bulk edit changed 2 products" [ "$(echo "$r" | json changed)" = "2" ]
  [ "$SELFTEST" = rollback ] && probe tamper edit-after-bulk >/dev/null       # a newer edit: rollback must NOT silently pass
  probe bulk-rollback "$run" >/dev/null
  ids="$(echo "$r" | json ids | tr -d '[]' | tr ',' ' ')"
  check "rollback restored the original colours ($before)" [ "$(probe colours $ids)" = "$before" ]
}

echo; echo "================ PATH B: neither phase installed ================"
baseline
php artisan migrate --force >/dev/null                  # every migration of this release
php artisan catalogue:hierarchy >/dev/null
verify_import_and_rollback "path B"

echo; echo "================ PATH A: Phase 1 already installed ================"
baseline
# Phase 1 state, simulated on THIS disposable database (never anything else): everything migrated, Phase-1-style import, then the two
# newer migrations rolled back by path so the schema is Phase-1 shaped.
php artisan migrate --force >/dev/null
php artisan catalog:import-59 --apply $img >/dev/null
for f in $(ls database/migrations/2026_11_1[89]_*.php database/migrations/2026_11_2[0-9]_*.php database/migrations/2026_11_3[01]_*.php 2>/dev/null | sort -r); do
  php artisan migrate:rollback --force --path="$f" >/dev/null 2>&1 || true       # newest first; 2026_11_17 (Phase 1) stays installed
done
out="$(php artisan catalog:import-59 --apply $img 2>&1 || true)"
check "importer refuses to run before the new migrations" bash -c 'echo "$1" | grep -q "not up to date"' _ "$out"
php artisan migrate --force >/dev/null
verify_import_and_rollback "path A"

echo
if [ "$CHECKS" -gt 0 ]; then echo "REHEARSAL PASSED ($KIND): $CHECKS checks, both paths."; else die "no checks ran"; fi
