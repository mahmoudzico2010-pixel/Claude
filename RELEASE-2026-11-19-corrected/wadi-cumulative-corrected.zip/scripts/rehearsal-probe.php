<?php

declare(strict_types=1);

/**
 * Read-only probes (plus the marker table) for scripts/rehearse-install-paths.sh. Boots Laravel with the process environment, so it reports
 * what the framework would REALLY connect to — not what the script thinks it set.
 *   php scripts/rehearsal-probe.php target
 *   php scripts/rehearsal-probe.php marker-create TOKEN | marker-check TOKEN
 *   php scripts/rehearsal-probe.php fingerprint | products | colours IDS...
 */
use Illuminate\Contracts\Console\Kernel;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

chdir(dirname(__DIR__));
require 'vendor/autoload.php';
$app = require 'bootstrap/app.php';
$app->make(Kernel::class)->bootstrap();

$cmd = $argv[1] ?? '';
$name = DB::connection()->getName();
$driver = DB::connection()->getDriverName();
$database = (string) DB::connection()->getDatabaseName();

switch ($cmd) {
    case 'target':
        $tables = 0;
        try {
            $tables = $driver === 'sqlite'
                ? (int) DB::selectOne("select count(*) c from sqlite_master where type='table'")->c
                : (int) DB::selectOne('select count(*) c from information_schema.tables where table_schema = ?', [$database])->c;
        } catch (Throwable $e) {
            fwrite(STDERR, 'cannot read the target database: '.$e->getMessage()."\n");
            exit(3);
        }
        echo json_encode(['connection' => $name, 'driver' => $driver, 'database' => $database, 'host' => (string) config("database.connections.$name.host"), 'tables' => $tables, 'env' => app()->environment()]), "\n";
        break;

    case 'marker-create':
        Schema::dropIfExists('wadi_rehearsal_marker');
        Schema::create('wadi_rehearsal_marker', function ($t): void {
            $t->string('token', 64);
        });
        DB::table('wadi_rehearsal_marker')->insert(['token' => $argv[2]]);
        echo "ok\n";
        break;

    case 'marker-check':
        $ok = Schema::hasTable('wadi_rehearsal_marker') && DB::table('wadi_rehearsal_marker')->where('token', $argv[2] ?? '')->exists();
        echo $ok ? "ok\n" : "missing\n";
        exit($ok ? 0 : 4);

    case 'products':
        echo (int) DB::table('products')->whereNotNull('import_key')->count(), "\n";
        break;

    case 'fingerprint':
        // Content of everything the import touches, without timestamps: a repeat import must leave this identical.
        $parts = [
            DB::table('products')->orderBy('id')->get(['id', 'slug', 'category_id', 'variety_id', 'product_form_id', 'primary_image_id', 'status', 'import_key', 'color', 'processing_method', 'show_in_menu'])->all(),
            DB::table('product_translations')->orderBy('id')->get(['product_id', 'locale', 'name', 'short_description', 'description', 'seo_title', 'seo_description', 'imported_hashes'])->all(),
            DB::table('product_images')->orderBy('id')->get(['product_id', 'media_id', 'is_primary', 'display_order', 'source'])->all(),
            DB::table('media_assets')->orderBy('id')->get(['path', 'checksum', 'alt_en', 'alt_ar'])->all(),
            DB::table('media_asset_translations')->orderBy('id')->get(['media_id', 'locale', 'alt', 'generated'])->all(),
            DB::table('catalog_media_reviews')->orderBy('id')->get(['media_id', 'status', 'product_id', 'assigned_role', 'note'])->all(),
            DB::table('categories')->orderBy('id')->get(['slug', 'parent_id', 'display_order'])->all(),
            DB::table('varieties')->orderBy('id')->get(['slug', 'name_en', 'name_ar', 'aliases'])->all(),
            DB::table('content_translations')->orderBy('id')->get(['entity', 'entity_id', 'locale', 'field', 'value'])->all(),
        ];
        echo md5(json_encode($parts)), ' ', count($parts[0]), ' ', count($parts[1]), "\n";
        break;

    case 'colours':
        $ids = array_map('intval', array_slice($argv, 2));
        echo json_encode(DB::table('products')->whereIn('id', $ids)->orderBy('id')->pluck('color', 'id')->all()), "\n";
        break;

    case 'bulk-set':
        // Change the colour of the first two imported products through the real bulk engine; print {"run":ID,"ids":[..],"before":{..},"after":{..}}
        $ed = new App\Services\Catalog\BulkProductEditor;
        $u = App\Models\User::query()->first() ?? App\Models\User::factory()->create(['is_active' => true]);
        $u->assignRole(App\Models\User::ROLE_SUPER_ADMIN);
        $ids = DB::table('products')->whereNotNull('import_key')->orderBy('id')->limit(2)->pluck('id')->all();
        $before = DB::table('products')->whereIn('id', $ids)->orderBy('id')->pluck('color', 'id')->all();
        $spec = ['color' => ['mode' => 'set', 'value' => 'Rehearsal colour']];
        $run = $ed->apply($ed->plan($ed->products($ids), $spec, $u), $spec, $u, 'rehearsal');
        $after = DB::table('products')->whereIn('id', $ids)->orderBy('id')->pluck('color', 'id')->all();
        echo json_encode(['run' => $run->id, 'ids' => $ids, 'before' => $before, 'after' => $after, 'changed' => $run->outcome['changed']]), "\n";
        break;

    case 'bulk-rollback':
        $ed = new App\Services\Catalog\BulkProductEditor;
        $u = App\Models\User::query()->first();
        $r = $ed->rollback(App\Models\BulkEditRun::findOrFail((int) $argv[2]), $u);
        echo json_encode(['restored' => $r['restored'], 'conflicts' => count($r['conflicts']), 'denied' => count($r['denied'])]), "\n";
        break;

    case 'tamper':
        // Fault injection for the script's own self-test ONLY (never used in a normal run).
        match ($argv[2] ?? '') {
            'drop-product' => DB::table('products')->whereNotNull('import_key')->orderByDesc('id')->limit(1)->update(['import_key' => null]),
            'change-data' => DB::table('product_translations')->orderBy('id')->limit(1)->update(['name' => 'TAMPERED']),
            'edit-after-bulk' => DB::table('products')->whereNotNull('import_key')->orderBy('id')->limit(1)->update(['color' => 'Edited by hand']),
            default => null,
        };
        echo "tampered\n";
        break;

    default:
        fwrite(STDERR, "unknown probe\n");
        exit(2);
}
