<?php

return [
    'families' => 'Famílias de produtos',
    'intro' => 'Conheça a gama :name da Wadi El Rayan for Food Industries.',
    'index_intro' => 'Explore as nossas cinco famílias de produtos e peça um orçamento da gama de que precisa.',
    'subcategories' => 'Categorias de :name',
    'view' => 'Ver :name',
    'empty_title' => 'Disponível a pedido',
    'empty_text' => 'A nossa gama :name está disponível a pedido. Diga-nos o que precisa e responderemos com disponibilidade e orçamento.',
    'enquire' => 'Pedir informações sobre :name',
    'all_in' => 'Todos os produtos de :name',
    'products_in' => 'Produtos de :name',
    'back_to' => 'Voltar a :name',
    'values' => [
        'yellow_green' => 'De verde-amarelado a verde',
        'violet_black' => 'De preto violáceo a preto',
        'spanish_style' => 'Estilo espanhol',
    ],
];
