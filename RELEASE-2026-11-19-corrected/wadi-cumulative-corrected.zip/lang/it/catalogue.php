<?php

return [
    'families' => 'Famiglie di prodotti',
    'intro' => 'Scopri la gamma :name di Wadi El Rayan for Food Industries.',
    'index_intro' => 'Scopri le nostre cinque famiglie di prodotti e richiedi un preventivo per la gamma che ti serve.',
    'subcategories' => 'Categorie di :name',
    'view' => 'Vedi :name',
    'empty_title' => 'Disponibile su richiesta',
    'empty_text' => 'La nostra gamma :name è disponibile su richiesta. Dicci di cosa hai bisogno e ti risponderemo con disponibilità e preventivo.',
    'enquire' => 'Richiedi informazioni su :name',
    'all_in' => 'Tutti i prodotti :name',
    'products_in' => 'Prodotti :name',
    'back_to' => 'Torna a :name',
    'values' => [
        'yellow_green' => 'Dal verde-giallo al verde',
        'violet_black' => 'Dal nero violaceo al nero',
        'spanish_style' => 'Stile spagnolo',
    ],
];
