<?php

return [
    'admin' => [
        'fit' => 'Photo fit', 'fit_cover' => 'Fill the frame (recommended)', 'fit_contain' => 'Show whole photo', 'fit_hint' => 'Fill: the photo covers the whole frame window (edges may be cropped slightly; padding is not used). Whole photo: nothing is cropped and the padding setting applies.',
        'label' => 'Frame design', 'plural' => 'Frame designs', 'name' => 'Name', 'padding' => 'Product padding',
        'padding_hint' => 'Space kept between the frame edge and the product so the whole product stays visible.',
        'artwork' => 'Frame artwork (transparent PNG or WebP)', 'artwork_hint' => 'Pick or upload a transparent PNG/WebP in the media library. Square artwork is shown on a square image area. Your product photos are never changed.',
        'active' => 'Available', 'source' => 'Source', 'source_builtin' => 'Built in', 'source_media' => 'Media library',
        'page_title' => 'Product image frame', 'page_hint' => 'Draws a frame above product photos on cards, category grids and product pages. Photos are never edited; turn it off at any time.',
        'mode' => 'Frame', 'mode_none' => 'No frame', 'mode_use' => 'Use a frame', 'choose' => 'Frame design', 'preview_product' => 'Preview on product',
        'preview' => 'Live preview', 'saved' => 'Saved. Public pages show the change on refresh.', 'save' => 'Save',
        'product_mode' => 'Frame for this product', 'inherit' => 'Use the site setting', 'none' => 'No frame', 'frame' => 'A different frame', 'product_frame' => 'Frame design',
        'no_frames' => 'No frame designs yet — add one under Catalogue → Frame designs.',
    ],
];
