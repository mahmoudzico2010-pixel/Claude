<?php

return [
    'families' => '产品系列',
    'intro' => '了解 Wadi El Rayan for Food Industries 的:name系列。',
    'index_intro' => '浏览我们的五大产品系列，并为所需产品申请报价。',
    'subcategories' => ':name分类',
    'view' => '查看:name',
    'empty_title' => '可按需供应',
    'empty_text' => ':name系列可按需供应。请告知您的需求，我们将回复供货情况和报价。',
    'enquire' => '咨询:name',
    'all_in' => ':name全部产品',
    'products_in' => ':name产品',
    'back_to' => '返回:name',
    'values' => [
        'yellow_green' => '黄绿色至绿色',
        'violet_black' => '紫黑色至黑色',
        'spanish_style' => '西班牙式',
    ],
];
