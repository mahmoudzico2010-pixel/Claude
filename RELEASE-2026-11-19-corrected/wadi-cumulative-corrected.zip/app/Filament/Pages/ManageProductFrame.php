<?php

declare(strict_types=1);

namespace App\Filament\Pages;

use App\Models\Product;
use App\Models\ProductFrame;
use App\Models\SiteSetting;
use App\Support\Permissions;
use App\Support\ProductFrames;
use BackedEnum;
use Filament\Forms\Components\Radio;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Notifications\Notification;
use Filament\Pages\Page;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Illuminate\Support\Facades\Auth;

/** Site-wide product image frame: No frame / Use a frame, with a live preview on a real product. */
class ManageProductFrame extends Page
{
    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedPhoto;

    protected static ?int $navigationSort = 19;

    protected static ?string $slug = 'product-image-frame';

    protected string $view = 'filament.pages.product-frame';

    /** @var array<string, mixed> */
    public ?array $data = [];

    public static function getNavigationGroup(): ?string
    {
        return __('nav.groups.catalogue');
    }

    public static function getNavigationLabel(): string
    {
        return __('frames.admin.page_title');
    }

    public function getTitle(): string
    {
        return __('frames.admin.page_title');
    }

    public static function canAccess(): bool
    {
        return Auth::user()?->can(Permissions::SETTINGS_VIEW) ?? false;
    }

    public function mount(): void
    {
        $this->form->fill([
            'mode' => filter_var(setting('media.frame_enabled', false), FILTER_VALIDATE_BOOLEAN) ? 'use' : 'none',
            'frame_id' => (int) setting('media.frame_id') ?: ProductFrame::query()->where('is_active', true)->orderBy('display_order')->value('id'),
            'fit' => setting('media.frame_fit') === 'contain' ? 'contain' : 'cover',
            'padding' => filled(setting('media.frame_padding')) ? (int) setting('media.frame_padding') : null,
            'preview_product' => Product::query()->published()->whereNotNull('primary_image_id')->orderBy('id')->value('id'),
        ]);
    }

    public function form(Schema $schema): Schema
    {
        return $schema->statePath('data')->components([
            Section::make(__('frames.admin.page_title'))->description(__('frames.admin.page_hint'))->columns(2)->schema([
                Radio::make('mode')->label(__('frames.admin.mode'))->live()
                    ->options(['none' => __('frames.admin.mode_none'), 'use' => __('frames.admin.mode_use')])->required(),
                Radio::make('fit')->label(__('frames.admin.fit'))->live()
                    ->options(['cover' => __('frames.admin.fit_cover'), 'contain' => __('frames.admin.fit_contain')])->default('cover')->helperText(__('frames.admin.fit_hint')),
                Select::make('frame_id')->label(__('frames.admin.choose'))->live()->native(false)
                    ->options(fn () => ProductFrame::query()->where('is_active', true)->orderBy('display_order')->pluck('name', 'id'))
                    ->helperText(fn () => ProductFrame::query()->where('is_active', true)->exists() ? null : __('frames.admin.no_frames')),
                TextInput::make('padding')->label(__('frames.admin.padding'))->helperText(__('frames.admin.padding_hint'))->live(onBlur: true)
                    ->numeric()->minValue(0)->maxValue(30)->suffix('%'),
                Select::make('preview_product')->label(__('frames.admin.preview_product'))->live()->native(false)->searchable()
                    ->options(fn () => Product::query()->published()->whereNotNull('primary_image_id')->orderBy('id')->limit(200)->get()->mapWithKeys(fn (Product $p) => [$p->id => $p->name()])),
            ]),
        ]);
    }

    /** Data for the preview card: frame the form currently describes, before saving. */
    public function previewFrame(): array|false
    {
        $d = $this->data;
        if (($d['mode'] ?? 'none') !== 'use' || empty($d['frame_id'])) {
            return false;
        }
        $frame = ProductFrame::query()->with('media')->find($d['frame_id']);

        return ProductFrames::describe($frame, filled($d['padding'] ?? null) ? (int) $d['padding'] : null, ($d['fit'] ?? 'cover')) ?: false;
    }

    public function previewProduct(): ?Product
    {
        return ! empty($this->data['preview_product']) ? Product::query()->with('primaryImage')->find($this->data['preview_product']) : null;
    }

    public function save(): void
    {
        if (! (Auth::user()?->can(Permissions::SETTINGS_UPDATE) ?? false)) {
            return;
        }
        $d = $this->form->getState();
        SiteSetting::setMany([
            'frame_enabled' => ($d['mode'] ?? 'none') === 'use' ? '1' : '0',
            'frame_id' => (string) ($d['frame_id'] ?? ''),
            'frame_fit' => ($d['fit'] ?? 'cover') === 'contain' ? 'contain' : 'cover',
            'frame_padding' => filled($d['padding'] ?? null) ? (string) (int) $d['padding'] : '',
        ], 'media');
        ProductFrames::forget();
        Notification::make()->success()->title(__('frames.admin.saved'))->send();
    }
}
