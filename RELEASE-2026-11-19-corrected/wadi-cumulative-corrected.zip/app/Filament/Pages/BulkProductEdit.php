<?php

declare(strict_types=1);

namespace App\Filament\Pages;

use App\Filament\Forms\Components\MediaPicker;
use App\Filament\Resources\Products\ProductResource;
use App\Models\BulkEditRun;
use App\Models\Category;
use App\Models\PackagingType;
use App\Models\ProductForm;
use App\Models\Variety;
use App\Services\Catalog\BulkProductEditor;
use App\Support\Permissions;
use Filament\Forms\Components\CheckboxList;
use Filament\Forms\Components\Radio;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Notifications\Notification;
use Filament\Pages\Page;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Utilities\Get;
use Filament\Schemas\Schema;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;

/** Preview-then-apply editor for the products selected in the Products table. */
class BulkProductEdit extends Page
{
    protected static bool $shouldRegisterNavigation = false;

    protected static ?string $slug = 'products/bulk-edit';

    protected string $view = 'filament.pages.bulk-product-edit';

    public string $token = '';

    /** @var array<string, mixed> */
    public ?array $data = [];

    /** @var array<int, int> */
    public array $ids = [];

    public string $selectionMode = 'ticked';

    /** @var list<string> */
    public array $filters = [];

    /** @var array<string, mixed>|null */
    public ?array $preview = null;

    public string $previewHash = '';

    /** @var list<array{id: int, label: string, why: string}> */
    public array $conflicts = [];

    public function getTitle(): string
    {
        return __('bulk.title');
    }

    public static function canAccess(): bool
    {
        return Auth::user()?->can(Permissions::PRODUCTS_UPDATE) ?? false;
    }

    public function mount(): void
    {
        $sel = Cache::get('bulk-edit:'.request()->query('token', ''));
        if (! is_array($sel) || ($sel['user'] ?? null) !== Auth::id()) {
            Notification::make()->warning()->title(__('bulk.expired'))->send();
            $this->redirect(ProductResource::getUrl());

            return;
        }
        $this->token = (string) request()->query('token');
        $this->ids = $sel['ids'];
        $this->selectionMode = $sel['mode'];
        $this->filters = $sel['filters'];
        $this->form->fill($this->defaults());
    }

    /** @return array<string, mixed> */
    private function defaults(): array
    {
        $d = [];
        foreach (['category_id', 'variety_id', 'product_form_id', 'processing_method', 'color', 'is_featured', 'packaging', 'media'] as $k) {
            $d[$k.'_mode'] = 'keep';
        }
        $d += ['text_fields' => [], 'text_locales' => [], 'text_mode' => 'fill_missing', 'text_source' => 'prepared', 'overwrite_human' => false, 'allow_shared_primary' => false];

        return $d;
    }

    public function form(Schema $schema): Schema
    {
        $single = fn (string $key, string $label, $value, array $modes = ['keep', 'set', 'clear']) => Section::make($label)->columns(2)->compact()->schema([
            Radio::make($key.'_mode')->label(__('bulk.keep'))->hiddenLabel()->inline()->live()->default('keep')
                ->options(collect($modes)->mapWithKeys(fn ($m) => [$m => __('bulk.'.$m)])->all()),
            $value->visible(fn (Get $get) => in_array($get($key.'_mode'), ['set', 'add', 'remove', 'replace'], true)),
        ]);
        $locales = collect((array) config('wadi.locales', []))->mapWithKeys(fn ($v, $code) => [$code => strtoupper($code).' — '.($v['name'] ?? $v['native'] ?? $code)])->all();

        return $schema->statePath('data')->components([
            $single('category_id', __('bulk.category'), Select::make('category_id')->hiddenLabel()->native(false)->searchable()
                ->options(fn () => Category::query()->active()->with('translations')->ordered()->get()->mapWithKeys(fn ($c) => [$c->id => ($c->parent_id ? '— ' : '').$c->name('en')])->all()), ['keep', 'set']),
            $single('variety_id', __('bulk.variety'), Select::make('variety_id')->hiddenLabel()->native(false)->searchable()
                ->options(fn () => Variety::query()->ordered()->pluck('name_en', 'id')->all())),
            $single('product_form_id', __('bulk.form'), Select::make('product_form_id')->hiddenLabel()->native(false)
                ->options(fn () => ProductForm::query()->ordered()->pluck('name_en', 'id')->all())),
            $single('processing_method', __('bulk.processing'), TextInput::make('processing_method')->hiddenLabel()->maxLength(80)),
            $single('color', __('bulk.colour'), TextInput::make('color')->hiddenLabel()->maxLength(60)),
            $single('is_featured', __('bulk.featured'), Toggle::make('is_featured')->label(__('bulk.featured'))->default(true)),
            $single('packaging', __('bulk.packaging'), Select::make('packaging')->hiddenLabel()->multiple()->native(false)->searchable()
                ->options(fn () => PackagingType::query()->where('is_active', true)->get()->mapWithKeys(fn ($p) => [$p->id => (string) ($p->t('name', 'en') ?? $p->slug ?? $p->id)])->all()), ['keep', 'add', 'remove', 'replace', 'clear']),

            Section::make(__('bulk.sec_text'))->columns(2)->schema([
                CheckboxList::make('text_fields')->label(__('bulk.p_fields'))->columns(2)->options([
                    'short_description' => __('bulk.f_short'), 'description' => __('bulk.f_desc'), 'seo_title' => __('bulk.f_seo_title'), 'seo_description' => __('bulk.f_seo_desc'),
                ]),
                CheckboxList::make('text_locales')->label(__('bulk.p_languages'))->columns(2)->options($locales),
                Radio::make('text_mode')->label(__('bulk.p_when_exists'))->options(['fill_missing' => __('bulk.p_fill'), 'overwrite' => __('bulk.p_overwrite')]),
                Toggle::make('overwrite_human')->label(__('bulk.p_overwrite_human'))->visible(fn (Get $get) => $get('text_mode') === 'overwrite'),
                Radio::make('text_source')->label(__('bulk.p_new_text'))->live()->options(['prepared' => __('bulk.p_prepared'), 'text' => __('bulk.p_typed')]),
                Textarea::make('text_value')->label(__('bulk.p_text'))->rows(3)->visible(fn (Get $get) => $get('text_source') === 'text'),
            ]),

            Section::make(__('bulk.sec_photos'))->columns(2)->compact()->schema([
                Radio::make('media_mode')->hiddenLabel()->inline()->live()->default('keep')->options([
                    'keep' => __('bulk.keep'), 'add_gallery' => __('bulk.m_add_gallery'), 'remove_gallery' => __('bulk.m_remove_gallery'), 'replace_primary' => __('bulk.m_replace_primary'),
                ]),
                MediaPicker::make('media_id', __('bulk.photo'), 'products')->visible(fn (Get $get) => ($get('media_mode') ?? 'keep') !== 'keep'),
                Toggle::make('allow_shared_primary')->label(__('bulk.shared_primary'))
                    ->visible(fn (Get $get) => ($get('media_mode') ?? 'keep') === 'replace_primary'),
            ]),
        ]);
    }

    /** @return array<string, mixed> */
    private function spec(): array
    {
        $d = (array) $this->data;
        $one = fn (string $k, bool $int = false) => ['mode' => $d[$k.'_mode'] ?? 'keep', 'value' => $int && filled($d[$k] ?? null) ? (int) $d[$k] : ($d[$k] ?? null)];
        $spec = [
            'category_id' => $one('category_id', true), 'variety_id' => $one('variety_id', true), 'product_form_id' => $one('product_form_id', true),
            'processing_method' => $one('processing_method'), 'color' => $one('color'), 'is_featured' => ['mode' => $d['is_featured_mode'] ?? 'keep', 'value' => (bool) ($d['is_featured'] ?? true)],
            'packaging' => ['mode' => $d['packaging_mode'] ?? 'keep', 'ids' => (array) ($d['packaging'] ?? [])],
            'media' => ['mode' => $d['media_mode'] ?? 'keep', 'media_id' => (int) ($d['media_id'] ?? 0), 'allow_shared_primary' => (bool) ($d['allow_shared_primary'] ?? false)],
            'text' => ['fields' => (array) ($d['text_fields'] ?? []), 'locales' => (array) ($d['text_locales'] ?? []), 'mode' => $d['text_mode'] ?? 'fill_missing',
                'overwrite_human' => (bool) ($d['overwrite_human'] ?? false), 'source' => $d['text_source'] ?? 'prepared', 'value' => $d['text_value'] ?? null],
        ];

        return $spec;
    }

    public function previewChanges(): void
    {
        $ed = new BulkProductEditor;
        $spec = $this->spec();
        $plan = $ed->plan($ed->products($this->ids), $spec, Auth::user());
        $this->preview = $plan;
        $this->previewHash = sha1(json_encode([$this->ids, $spec]));
    }

    public function applyChanges(): void
    {
        $this->conflicts = [];
        if ($this->preview === null || $this->previewHash !== sha1(json_encode([$this->ids, $this->spec()]))) {
            Notification::make()->warning()->title(__('bulk.changed_since'))->send();

            return;
        }
        $ed = new BulkProductEditor;
        $spec = $this->spec();
        $plan = $ed->plan($ed->products($this->ids), $spec, Auth::user());

        // Apply exactly what was previewed: if anything differs now (another editor saved meanwhile) write nothing.
        $conflicts = $ed->conflicts($this->preview, $plan);
        if ($conflicts !== []) {
            $this->conflicts = $conflicts;
            $this->preview = null;
            Notification::make()->warning()->title(__('bulk.conflict_title'))->send();

            return;
        }

        $run = $ed->apply($plan, $spec, Auth::user(), 'bulk_edit', ['description' => 'bulk edit', 'count' => count($this->ids), 'mode' => $this->selectionMode, 'filters' => $this->filters]);
        $o = $run->outcome;
        Notification::make()->success()->title(__('bulk.done', ['changed' => $o['changed'], 'skipped' => $o['skipped'], 'invalid' => $o['invalid'], 'failed' => $o['failed']]))->send();
        $this->preview = null;
    }

    public function rollbackRun(int $id): void
    {
        abort_unless(Auth::user()?->can(Permissions::PRODUCTS_UPDATE), 403);
        $r = (new BulkProductEditor)->rollback(BulkEditRun::findOrFail($id), Auth::user());
        Notification::make()->success()->title(__('bulk.rolled_back', ['restored' => $r['restored'], 'denied' => count($r['denied']), 'conflicts' => count($r['conflicts'])]))->send();
    }

    /** @return \Illuminate\Support\Collection<int, BulkEditRun> */
    public function history()
    {
        return BulkEditRun::query()->with('user')->latest('id')->limit(10)->get();
    }
}
