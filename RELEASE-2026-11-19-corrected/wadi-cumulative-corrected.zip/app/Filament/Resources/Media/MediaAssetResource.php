<?php

declare(strict_types=1);

namespace App\Filament\Resources\Media;

use App\Filament\Resources\Media\Pages\ManageMediaAssets;
use App\Models\MediaAsset;
use App\Rules\SafeRasterImage;
use App\Services\Media\MediaIntegrity;
use App\Services\Media\MediaManager;
use App\Support\Permissions;
use App\Support\ResourceLimits;
use App\Support\Uploads\UploadLimits;
use BackedEnum;
use Filament\Actions\Action;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteAction;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Notifications\Notification;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Grid;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Columns\Layout\Split;
use Filament\Tables\Columns\Layout\Stack;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Columns\ViewColumn;
use Filament\Tables\Filters\Filter;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Auth;

class MediaAssetResource extends Resource
{
    protected static ?string $model = MediaAsset::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedPhoto;

    protected static ?int $navigationSort = 1;

    public static function getNavigationGroup(): ?string
    {
        return __('nav.groups.media');
    }

    public static function getModelLabel(): string
    {
        return __('admin.resources.media_asset.label');
    }

    public static function getPluralModelLabel(): string
    {
        return __('admin.resources.media_asset.plural');
    }

    /**
     * MIME types this user may upload.
     *
     * SVG is appended only for a Super Admin; MediaManager enforces the same
     * rule server-side, so hiding it here is a convenience, not the control.
     *
     * @return array<int, string>
     */
    public static function acceptedMimes(): array
    {
        $mimes = config('wadi.media.allowed_mimes', []);

        if (MediaManager::userMayUploadSvg()) {
            $mimes[] = config('wadi.media.svg.mime', 'image/svg+xml');
        }

        if (config('wadi.media.video.enabled', false)) {
            $mimes = array_merge($mimes, (array) config('wadi.media.video.mimes', []));
        }

        return array_values(array_unique($mimes));
    }

    /** @return array<string, string> */
    public static function folderOptions(): array
    {
        return collect(['general', 'products', 'packaging', 'certifications', 'news', 'pages', 'branding', 'documents'])
            ->mapWithKeys(fn (string $f): array => [$f => __('media.folders.'.$f)])
            ->all();
    }

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            Section::make()->schema([
                // Only shown on create: replacing an existing file is a
                // separate action so references are never silently swapped.
                FileUpload::make('upload')
                    ->label(__('media.fields.file'))
                    ->required()
                    ->visibleOn('create')
                    // MediaManager stores the file. If FileUpload stores it
                    // first, the state dehydrates to a path string and the
                    // handler's UploadedFile check silently fails.
                    ->storeFiles(false)
                    ->maxSize(fn (): int => UploadLimits::clientKb(UploadLimits::directKb('video')))
                    ->rule(fn (): string => 'max:'.UploadLimits::directKb('video'))
                    ->rules([new SafeRasterImage])
                    ->acceptedFileTypes(fn (): array => static::acceptedMimes())
                    ->helperText(fn (): string => 'Images up to '.UploadLimits::human(UploadLimits::bytes('image')).', videos up to '.UploadLimits::human(UploadLimits::directKb('video') * 1024).' per direct upload ('.UploadLimits::explain('video').') '.__('media.hints.max_dimensions', [
                        'pixels' => ResourceLimits::formatPixels(ResourceLimits::practicalImagePixels()),
                    ]).(MediaManager::userMayUploadSvg() ? '' : ' '.__('media.hints.raster_only'))),

                Select::make('folder')
                    ->label(__('media.fields.folder'))
                    ->options(static::folderOptions())
                    ->default('general')
                    ->required()
                    ->native(false),

                Grid::make(2)->schema([
                    ...collect((array) config('wadi.locales', []))->keys()->map(fn (string $code) => TextInput::make('alt_'.$code)
                        ->label('Alt text — '.strtoupper($code))->maxLength(400)
                        ->afterStateHydrated(fn ($component, $record) => $record ? $component->state($record->altTexts()->where('locale', $code)->value('alt') ?? ($record->getAttributes()['alt_'.$code] ?? null)) : null)
                        ->saveRelationshipsUsing(fn ($record, $state) => $record->setAlt($code, filled($state) ? (string) $state : null))
                        ->dehydrated(in_array($code, ['en', 'ar'], true)))->all(),
                    TextInput::make('title_en')->label(__('media.fields.title_en'))->maxLength(255),
                    TextInput::make('title_ar')->label(__('media.fields.title_ar'))->maxLength(255),
                ]),
            ]),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->defaultSort('created_at', 'desc')
            // A grid of cards rather than rows. Media is chosen by eye —
            // nobody recognises an image from its filename — so the thumbnail
            // is the primary control and everything else is a caption.
            ->contentGrid(['sm' => 2, 'md' => 3, 'xl' => 4, '2xl' => 5])
            ->paginationPageOptions([24, 48, 96])
            ->defaultPaginationPageOption(24)
            ->columns([
                Stack::make([
                    // The same thumbnail partial the picker grid uses, so the
                    // library and every picker show a file identically.
                    //
                    // This replaced an ImageColumn that cropped to a fixed
                    // 160px height with object-cover. Cropping a preview hides
                    // the part of the file someone is looking for, and a
                    // library is nothing but previews. The partial also draws
                    // its own placeholder for video and documents, which is
                    // what placeholderFor() used to be for.
                    ViewColumn::make('preview')
                        ->label('')
                        ->view('filament.tables.columns.media-thumbnail'),

                    TextColumn::make('original_filename')
                        ->label(__('media.fields.file'))
                        ->weight('medium')
                        ->size('sm')
                        ->limit(40)
                        ->tooltip(fn (MediaAsset $record): string => $record->original_filename)
                        ->searchable(),

                    TextColumn::make('file_state')
                        ->label('')
                        ->getStateUsing(fn (MediaAsset $record): ?string => app(MediaIntegrity::class)->isMissing($record)
                            ? __('media.fields.file_missing') : null)
                        ->badge()
                        ->color('danger')
                        ->visible(),

                    Split::make([
                        TextColumn::make('size')
                            ->label(__('media.fields.size'))
                            ->getStateUsing(fn (MediaAsset $record): string => $record->humanSize())
                            ->size('xs')
                            ->color('gray')
                            ->sortable(),

                        TextColumn::make('created_at')
                            ->label(__('admin.fields.created_at'))
                            ->date('j M Y')
                            ->size('xs')
                            ->color('gray')
                            ->alignEnd()
                            ->sortable(),
                    ]),

                    Split::make([
                        TextColumn::make('folder')
                            ->label(__('media.fields.folder'))
                            ->formatStateUsing(fn (string $state): string => __('media.folders.'.$state))
                            ->badge()
                            ->color('gray')
                            ->size('xs'),

                        TextColumn::make('usage')
                            ->label(__('media.fields.usage'))
                            ->getStateUsing(fn (MediaAsset $record): string => $record->isInUse()
                                ? __('media.fields.in_use')
                                : __('media.fields.not_used'))
                            ->badge()
                            ->size('xs')
                            ->alignEnd()
                            ->color(fn (MediaAsset $record): string => $record->isInUse() ? 'primary' : 'gray')
                            ->tooltip(fn (MediaAsset $record): ?string => $record->isInUse()
                                ? collect($record->usage())
                                    ->map(fn (array $u): string => $u['label'].' ('.$u['count'].')')
                                    ->implode(', ')
                                : null),
                    ]),
                ])->space(2),
            ])
            ->filters([
                Filter::make('missing_file')
                    ->label(__('media.fields.only_missing'))
                    ->toggle()
                    ->query(fn (Builder $query): Builder => $query->whereIn('id', array_column(
                        app(MediaIntegrity::class)->problems(), 'id'))),
                SelectFilter::make('folder')
                    ->label(__('media.fields.folder'))
                    ->options(static::folderOptions()),

                // Grouped by what the file *is*, not by its exact MIME
                // type: an administrator looking for "that video" does not
                // know or care whether it is MP4 or WebM.
                SelectFilter::make('kind')
                    ->label(__('media.fields.type'))
                    ->options([
                        'image' => __('media.kinds.image'),
                        'video' => __('media.kinds.video'),
                        'document' => __('media.kinds.document'),
                    ])
                    ->query(fn (Builder $query, array $data): Builder => match ($data['value'] ?? null) {
                        'image' => $query->images(),
                        'video' => $query->videos(),
                        'document' => $query->documents(),
                        default => $query,
                    }),
            ])
            ->recordActions([
                Action::make('download')
                    ->label(__('media.actions.download'))
                    ->icon(Heroicon::OutlinedArrowDownTray)
                    ->color('gray')
                    ->url(fn (MediaAsset $r): string => $r->url())
                    ->openUrlInNewTab(),

                EditAction::make(),

                Action::make('replace')
                    ->label(__('media.actions.replace'))
                    ->icon(Heroicon::OutlinedArrowPath)
                    ->color('gray')
                    ->visible(fn (): bool => Auth::user()?->can(Permissions::MEDIA_UPLOAD) ?? false)
                    ->schema([
                        FileUpload::make('file')
                            ->label(__('media.fields.file'))
                            ->required()
                            ->storeFiles(false)
                            ->maxSize(fn (): int => UploadLimits::clientKb(UploadLimits::directKb('video')))
                            ->rule(fn (): string => 'max:'.UploadLimits::directKb('video'))
                            ->rules([new SafeRasterImage])
                            ->acceptedFileTypes(fn (): array => static::acceptedMimes()),
                    ])
                    ->action(function (MediaAsset $record, array $data): void {
                        $file = MediaManager::resolveUpload($data['file'] ?? null);

                        if ($file === null) {
                            Notification::make()->danger()
                                ->title(__('media.errors.upload_failed'))
                                ->send();

                            return;
                        }

                        try {
                            app(MediaManager::class)->replace($record, $file);
                        } catch (\RuntimeException $e) {
                            // Refusals (size, type, dimensions) are shown; the existing file and record are untouched.
                            Notification::make()->danger()->title(__('media.errors.upload_failed'))->body($e->getMessage())->persistent()->send();

                            return;
                        }

                        Notification::make()->success()->title(__('admin.settings.saved'))->send();
                    }),

                DeleteAction::make()
                    // Refuse while anything still points at the file, so a
                    // product page can never end up with a broken image.
                    ->disabled(fn (MediaAsset $record): bool => $record->isInUse())
                    ->tooltip(fn (MediaAsset $record): ?string => $record->isInUse()
                        ? __('media.errors.in_use', ['count' => collect($record->usage())->sum('count')])
                        : null)
                    ->before(fn (MediaAsset $record) => app(MediaManager::class)->deleteFiles($record)),
            ])
            ->toolbarActions([
                BulkActionGroup::make([DeleteBulkAction::make()]),
            ]);
    }

    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()->withoutGlobalScopes([SoftDeletingScope::class]);
    }

    public static function getPages(): array
    {
        return [
            'index' => ManageMediaAssets::route('/'),
        ];
    }
}
