<?php

declare(strict_types=1);

namespace App\Filament\Support;

use App\Filament\Pages\BulkProductEdit;
use App\Services\Catalog\BulkProductEditor;
use App\Support\Permissions;
use Filament\Actions\BulkAction;
use Filament\Notifications\Notification;
use Filament\Tables\Contracts\HasTable;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Str;

/** Bulk actions of the Products table. Each works on exactly the rows Filament selected (ticked, this page, or all matching the filters). */
final class ProductBulkActions
{
    /** @return array<int, BulkAction> */
    public static function make(): array
    {
        return [
            BulkAction::make('bulkEdit')
                ->label(__('bulk.edit'))->icon('heroicon-o-pencil-square')->color('primary')
                ->visible(fn () => Auth::user()?->can(Permissions::PRODUCTS_UPDATE) ?? false)
                ->deselectRecordsAfterCompletion()
                ->action(function (Collection $records, HasTable $livewire) {
                    $token = (string) Str::uuid();
                    $all = (bool) ($livewire->isTrackingDeselectedTableRecords ?? false);
                    Cache::put('bulk-edit:'.$token, [
                        'ids' => $records->pluck('id')->map(fn ($i) => (int) $i)->all(),
                        'mode' => $all ? 'all_filtered' : 'ticked',
                        'filters' => self::filterSummary($livewire),
                        'user' => Auth::id(),
                    ], now()->addHours(2));

                    $livewire->redirect(BulkProductEdit::getUrl(['token' => $token]));
                }),

            self::simple('activate', 'bulk.activate', 'heroicon-o-eye', 'success', Permissions::PRODUCTS_PUBLISH, ['status' => 'activate']),
            self::simple('deactivate', 'bulk.deactivate', 'heroicon-o-eye-slash', 'gray', Permissions::PRODUCTS_PUBLISH, ['status' => 'deactivate']),
            self::simple('trashSelected', 'bulk.delete', 'heroicon-o-trash', 'danger', Permissions::PRODUCTS_DELETE, ['trash' => 'delete']),
            self::simple('restoreSelected', 'bulk.restore', 'heroicon-o-arrow-uturn-left', 'gray', Permissions::PRODUCTS_DELETE, ['trash' => 'restore']),
        ];
    }

    /** @param  array<string, string>  $spec */
    private static function simple(string $name, string $label, string $icon, string $color, string $permission, array $spec): BulkAction
    {
        return BulkAction::make($name)
            ->label(__($label))->icon($icon)->color($color)
            ->visible(fn () => Auth::user()?->can($permission) ?? false)
            ->requiresConfirmation()
            ->modalHeading(fn (Collection $records) => __($label).' — '.trans_choice('bulk.n_products', $records->count(), ['count' => $records->count()]))
            ->modalDescription(function (Collection $records, HasTable $livewire) use ($spec): string {
                $ed = new BulkProductEditor;
                $plan = $ed->plan($ed->products($records->pluck('id')->all()), $spec, Auth::user());
                $t = $plan['totals'];
                $names = collect($plan['rows'])->where('status', 'change')->take(5)->pluck('label')->implode(', ');
                $scope = ($livewire->isTrackingDeselectedTableRecords ?? false) ? __('bulk.scope_all', ['count' => $t['selected']]) : __('bulk.scope_ticked', ['count' => $t['selected']]);

                return $scope.' '.__('bulk.counts', ['change' => $t['change'], 'skip' => $t['skip'], 'invalid' => $t['invalid']]).($names !== '' ? ' '.__('bulk.sample', ['names' => $names]) : '');
            })
            ->deselectRecordsAfterCompletion()
            ->action(function (Collection $records) use ($spec, $name): void {
                $ed = new BulkProductEditor;
                $plan = $ed->plan($ed->products($records->pluck('id')->all()), $spec, Auth::user());
                $run = $ed->apply($plan, $spec, Auth::user(), $name, ['description' => $name, 'count' => $records->count()]);
                Notification::make()->success()->title(__('bulk.done', ['changed' => $run->outcome['changed'], 'skipped' => $run->outcome['skipped'], 'invalid' => $run->outcome['invalid'], 'failed' => $run->outcome['failed']]))->send();
            });
    }

    /** @return list<string> */
    private static function filterSummary(HasTable $livewire): array
    {
        $out = [];
        foreach ((array) ($livewire->tableFilters ?? []) as $name => $state) {
            $vals = is_array($state) ? ($state['values'] ?? ($state['value'] ?? null)) : $state;
            $vals = array_filter((array) $vals, fn ($v) => filled($v));
            if ($vals !== []) {
                $out[] = $name.': '.implode(', ', array_map('strval', $vals));
            }
        }
        if (filled($search = $livewire->tableSearch ?? null)) {
            $out[] = 'search: '.$search;
        }

        return $out;
    }
}
