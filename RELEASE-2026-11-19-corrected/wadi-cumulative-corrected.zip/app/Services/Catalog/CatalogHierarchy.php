<?php

declare(strict_types=1);

namespace App\Services\Catalog;

use App\Models\Category;
use App\Models\NavigationItem;
use App\Models\Product;
use Illuminate\Support\Facades\DB;

/**
 * Five product families and thirteen subcategories, in the agreed English spelling and order, with names in ten languages.
 * Idempotent and fill-only: an existing category keeps its id, slug, image and any text the owner edited; products are moved
 * to a subcategory only when the data identifies it reliably and they still sit on the family root. Anything uncertain is
 * reported for review and left where it is.
 *
 * Names are machine translations of short product terms (trade names kept as is); they are never marked human-reviewed.
 */
final class CatalogHierarchy
{
    /** Names the earlier release seeded; replaced only while still untouched. */
    private const OLD_DEFAULTS = [
        'pickled-products' => ['en' => 'Pickled Products'],
        'red-pepper' => ['en' => 'Red Pepper'],
        'olive-oil' => ['en' => 'Extra Virgin Olive Oil', 'ar' => 'زيت الزيتون البكر الممتاز'],
    ];

    private static bool $forceOrder = false;

    /** @return array{created: int, filled: int, moved: int, review: list<string>, no_image: list<string>} */
    public static function apply(): array
    {
        $data = (array) json_decode((string) file_get_contents(database_path('data/catalog/hierarchy.json')), true);
        $r = ['created' => 0, 'filled' => 0, 'moved' => 0, 'review' => [], 'no_image' => []];

        // The agreed order is imposed once; after that the owner's own reordering (Filament) is never overwritten.
        $force = ! filter_var(\App\Models\SiteSetting::get('catalogue.hierarchy_ordered', false), FILTER_VALIDATE_BOOLEAN);
        self::$forceOrder = $force;

        DB::transaction(function () use ($data, &$r): void {
            $order = 0;
            foreach ($data['families'] as $family) {
                $root = self::node($family['slug'], $family['name'], null, $order++, $r);
                $childOrder = 0;
                foreach ($family['children'] as $child) {
                    self::node($child['slug'], $child['name'], $root, $childOrder++, $r);
                }
            }
            $leaves = Category::query()->whereIn('slug', array_values($data['rules']))->pluck('id', 'slug');
            foreach ($data['rules'] as $productSlug => $leafSlug) {
                $p = Product::query()->where('slug', $productSlug)->first();
                $leaf = $leaves[$leafSlug] ?? null;
                if ($p && $leaf && Category::query()->whereKey($p->category_id)->whereNull('parent_id')->exists()) {
                    DB::table('products')->where('id', $p->id)->update(['category_id' => $leaf]);
                    $r['moved']++;
                }
            }
            foreach ($data['review'] as $productSlug => $note) {
                if (Product::query()->where('slug', $productSlug)->exists()) {
                    $r['review'][] = $productSlug.': '.$note;
                }
            }
        });
        if ($force) {
            \App\Models\SiteSetting::setMany(['hierarchy_ordered' => '1'], 'catalogue');
        }
        NavigationItem::flushCache();

        return $r;
    }

    /** @param array<string, string> $names */
    private static function node(string $slug, array $names, ?Category $parent, int $order, array &$r): Category
    {
        $c = Category::query()->where('slug', $slug)->first();
        if (! $c) {
            $c = Category::create(['slug' => $slug, 'parent_id' => $parent?->id, 'is_active' => true, 'show_in_menu' => true, 'display_order' => $order]);
            $r['created']++;
        } else {
            $set = [];
            if ($parent && $c->parent_id === null) {
                $set['parent_id'] = $parent->id;
            }
            if (self::$forceOrder) {
                $set['display_order'] = $order;
            }
            if ($set !== []) {
                DB::table('categories')->where('id', $c->id)->update($set);
            }
        }

        foreach ($names as $locale => $name) {
            $t = $c->translations()->where('locale', $locale)->first();
            $old = self::OLD_DEFAULTS[$slug][$locale] ?? null;
            if (! $t) {
                $c->translations()->create(['locale' => $locale, 'name' => $name]);
                $r['filled']++;
            } elseif (trim((string) $t->name) === '' || ($old !== null && $t->name === $old)) {
                $t->update(['name' => $name]);
                $r['filled']++;
            }
        }
        if (! $c->image_id) {
            $r['no_image'][] = $slug;
        }

        return $c;
    }
}
