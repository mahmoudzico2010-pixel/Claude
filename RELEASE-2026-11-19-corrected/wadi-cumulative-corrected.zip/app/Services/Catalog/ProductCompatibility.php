<?php

declare(strict_types=1);

namespace App\Services\Catalog;

use App\Models\Category;
use App\Models\ProductForm;
use App\Models\Variety;

/**
 * Which category / cultivar / cut combinations may exist. Applied to the RESULT of a bulk edit so contradictory data
 * (a pitted cut on olive oil, a cultivar on black oxidized olives, stuffed natural black olives) is rejected, not stored.
 * Categories outside the agreed catalogue are not judged.
 */
final class ProductCompatibility
{
    private const CULTIVARS = [
        'green-olives' => ['manzanilla', 'azizi', 'aks', 'picual', 'dolce'],
        'natural-black-olives' => ['manzanilla', 'picual', 'kalamata', 'dolce', 'sers-cola'],
    ];

    private const FORMS = [
        'green-olives' => ['whole', 'pitted', 'sliced', 'halved', 'stuffed'],
        'natural-black-olives' => ['whole', 'pitted', 'sliced', 'halved'],
        'black-oxidized-olives' => ['whole', 'pitted', 'sliced'],
    ];

    private const PEPPER_FORMS = ['whole', 'sliced', 'cored'];

    /** Variety slugs are compared through their canonical name ("aggizi" is Azizi). */
    private static function canon(?Variety $v): ?string
    {
        if ($v === null) {
            return null;
        }

        return $v->slug === 'aggizi' ? 'azizi' : $v->slug;
    }

    /** @return list<string> reasons the combination is invalid (empty = fine) */
    public static function problems(?Category $category, ?Variety $variety, ?ProductForm $form, ?string $processing = null): array
    {
        if ($category === null) {
            return ['A category is required.'];
        }
        $slug = $category->slug;
        $root = $category->parent?->slug ?? $slug;
        $out = [];
        $vs = self::canon($variety);

        if (isset(self::CULTIVARS[$slug])) {
            if ($vs !== null && ! in_array($vs, self::CULTIVARS[$slug], true)) {
                $out[] = "Cultivar {$variety->name_en} is not part of {$category->name('en')}.";
            }
        } elseif ($slug === 'black-oxidized-olives' && $vs !== null) {
            $out[] = 'Black oxidized olives take no cultivar.';
        } elseif (in_array($root, ['olive-oil', 'mixes-paste', 'pickled-products', 'peppers'], true) && $vs !== null) {
            $out[] = "A cultivar cannot be applied to {$category->name('en')}.";
        }

        if ($form !== null) {
            $fs = $form->slug;
            if (isset(self::FORMS[$slug]) && ! in_array($fs, self::FORMS[$slug], true)) {
                $out[] = "The cut \"{$form->name_en}\" is not offered for {$category->name('en')}.";
            } elseif ($root === 'peppers' && ! in_array($fs, self::PEPPER_FORMS, true)) {
                $out[] = "The cut \"{$form->name_en}\" is not offered for peppers.";
            } elseif (in_array($root, ['olive-oil', 'mixes-paste', 'pickled-products'], true)) {
                $out[] = "An olive/pepper cut (\"{$form->name_en}\") cannot be applied to {$category->name('en')}.";
            }
        }
        if (filled($processing) && in_array($root, ['olive-oil', 'pickled-products', 'mixes-paste'], true)) {
            $out[] = "An olive processing option cannot be applied to {$category->name('en')}.";
        }

        return $out;
    }
}
