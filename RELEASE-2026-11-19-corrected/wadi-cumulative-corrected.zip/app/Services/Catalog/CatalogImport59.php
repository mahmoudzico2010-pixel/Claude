<?php

declare(strict_types=1);

namespace App\Services\Catalog;

use App\Enums\ContentStatus;
use App\Models\CatalogMediaReview;
use App\Models\Category;
use App\Models\MediaAsset;
use App\Models\Product;
use App\Models\ProductForm;
use App\Models\ProductImage;
use App\Models\Variety;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Storage;

/**
 * The 59-entry catalogue: products (reconciled by category + cultivar + style, never duplicated), ten-language copy (fill-only,
 * human edits kept), and photos (matched by the owner's file names only; everything else goes to the review queue).
 * A re-run with unchanged input changes nothing. Publication state is never touched: new products are drafts.
 */
final class CatalogImport59
{
    private const CULTIVARS = ['manzanilla' => 'Manzanilla', 'azizi' => 'Azizi', 'aks' => 'AKS', 'picual' => 'Picual', 'dolce' => 'Dolce', 'kalamata' => 'Kalamata', 'sers-cola' => 'Sers Cola'];

    private const FORMS = ['whole' => 'Whole', 'pitted' => 'Pitted', 'sliced' => 'Sliced', 'halves' => 'Halves', 'stuffed' => 'Stuffed', 'cored' => 'Cored'];

    /** @var array<string, int> */
    public array $stats = ['products_created' => 0, 'products_reconciled' => 0, 'translations_filled' => 0, 'translations_kept' => 0, 'varieties_created' => 0, 'forms_created' => 0,
        'media_created' => 0, 'media_reused' => 0, 'gallery_links' => 0, 'primary_set' => 0, 'review_queued' => 0];

    /** @var list<string> */
    public array $notes = [];

    /** @var list<array<string, string>> */
    public array $mapping = [];

    /** @return array<string, mixed> */
    public function run(bool $apply, ?string $photoDir): array
    {
        foreach ([['product_translations', 'imported_hashes'], ['product_images', 'source'], ['products', 'import_key']] as [$table, $col]) {
            if (! Schema::hasColumn($table, $col)) {
                throw new \RuntimeException("The database is not up to date ($table.$col is missing). Run `php artisan migrate --force` first, then the import.");
            }
        }
        if (! Schema::hasTable('media_asset_translations') || ! Schema::hasTable('catalog_media_reviews')) {
            throw new \RuntimeException('The database is not up to date (alt-text or review tables missing). Run `php artisan migrate --force` first, then the import.');
        }
        DB::beginTransaction();
        try {
            $this->catalogue();
            $this->lookups();
            if ($photoDir !== null && is_dir($photoDir)) {
                $this->photos($photoDir, $apply);
            } else {
                $this->notes[] = 'Photo folder not supplied or not found: media step skipped (re-run with --photos=PATH; it is repeatable).';
            }
            $apply ? DB::commit() : DB::rollBack();
        } catch (\Throwable $e) {
            DB::rollBack();
            throw $e;
        }

        return ['applied' => $apply, 'stats' => $this->stats, 'notes' => $this->notes];
    }

    // ------------------------------------------------------------------ catalogue

    private function catalogue(): void
    {
        $data = (array) json_decode((string) file_get_contents(database_path('data/catalog/products-59.json')), true);
        $cats = Category::query()->whereIn('slug', collect($data['products'])->pluck('cat')->unique())->pluck('id', 'slug');
        foreach (collect($data['products'])->pluck('cat')->unique() as $slug) {
            if (! isset($cats[$slug])) {
                throw new \RuntimeException("Category '$slug' is missing: run `php artisan catalogue:hierarchy` first.");
            }
        }
        $varieties = $this->varieties();
        $forms = $this->forms();

        foreach ($data['products'] as $row) {
            $varietyId = $row['cultivar'] ? $varieties[self::slugOf($row['cultivar'])] : null;
            $formId = $row['style'] ? $forms[$row['style']] : null;
            $product = Product::query()->where('import_key', $row['key'])->first()
                ?? ($varietyId && $formId ? Product::query()->whereNull('import_key')->where('category_id', $cats[$row['cat']])->where('variety_id', $varietyId)->where('product_form_id', $formId)->first() : null)
                ?? Product::query()->whereNull('import_key')->where('slug', $row['slug'])->first();

            if ($product === null) {
                $slug = $this->freeSlug($row['slug']);
                $product = Product::create(['slug' => $slug, 'category_id' => $cats[$row['cat']], 'variety_id' => $varietyId, 'product_form_id' => $formId,
                    'status' => ContentStatus::Draft, 'import_key' => $row['key'], 'color' => $row['color'], 'processing_method' => $row['processing'], 'show_in_menu' => false]);
                $this->stats['products_created']++;
            } else {
                $set = array_filter(['import_key' => $product->import_key ?: $row['key'], 'color' => $product->color ?: $row['color'], 'processing_method' => $product->processing_method ?: $row['processing']], fn ($v) => filled($v));
                if ($product->category_id !== $cats[$row['cat']]) {
                    $this->notes[] = "{$row['key']}: existing product '{$product->slug}' sits in another category; left where it is for review.";
                }
                DB::table('products')->where('id', $product->id)->update($set);
                $this->stats['products_reconciled']++;
            }
            $this->fillTranslations($product, $row['translations']);
        }
    }

    private static function slugOf(string $name): string
    {
        return strtolower(str_replace(' ', '-', $name));
    }

    /** @return array<string, int> slug => id */
    private function varieties(): array
    {
        $map = [];
        foreach (self::CULTIVARS as $slug => $name) {
            $v = Variety::query()->where('slug', $slug)->first();
            // Aliases (e.g. the old "Aggizi" spelling of Azizi) resolve to the existing record, so a re-import never duplicates it.
            if (! $v && Schema::hasColumn('varieties', 'aliases')) {
                $v = Variety::query()->whereNotNull('aliases')->get()->first(fn (Variety $x): bool => in_array(strtolower($name), array_map('strtolower', (array) $x->aliases), true));
            }
            if (! $v && $slug === 'azizi') {
                $v = Variety::query()->where('slug', 'aggizi')->first();
            }
            if (! $v) {
                $v = Variety::create(['slug' => $slug, 'name_en' => $name, 'name_ar' => $name, 'is_active' => true]);
                $this->stats['varieties_created']++;
            }
            $map[$slug] = $v->id;
        }

        return $map;
    }

    /** @return array<string, int> style => id */
    private function forms(): array
    {
        $map = [];
        foreach (self::FORMS as $style => $name) {
            $slug = $style === 'halves' ? 'halved' : $style;
            $f = ProductForm::query()->where('slug', $slug)->first();
            if (! $f) {
                $f = ProductForm::create(['slug' => $slug, 'name_en' => $name, 'name_ar' => $name, 'is_active' => true]);
                $this->stats['forms_created']++;
            }
            $map[$style] = $f->id;
        }

        return $map;
    }

    private function freeSlug(string $slug): string
    {
        $try = $slug;
        for ($i = 2; Product::withTrashed()->where('slug', $try)->exists(); $i++) {
            $try = $slug.'-'.$i;
        }

        return $try;
    }

    /** Fill only empty fields; anything a person wrote stays. */
    private function fillTranslations(Product $product, array $translations): void
    {
        foreach ($translations as $locale => $fields) {
            $row = $product->translations()->where('locale', $locale)->first();
            $update = [];
            foreach ($fields as $field => $value) {
                if ($row && filled($row->{$field})) {
                    $this->stats['translations_kept']++;
                } else {
                    $update[$field] = $value;
                }
            }
            if ($update !== []) {
                $hashes = (array) ($row?->imported_hashes ?? []);
                foreach ($update as $field => $value) {
                    $hashes[$field] = sha1((string) $value);
                }
                $product->translations()->updateOrCreate(['locale' => $locale], $update + ['imported_hashes' => $hashes]);
                $this->stats['translations_filled'] += count($update);
            }
        }
    }

    /** Cut names in ten languages (content_translations, origin machine). Existing cells are never replaced. */
    private function lookups(): void
    {
        $file = database_path('data/catalog/lookups.json');
        if (! is_file($file) || ! Schema::hasTable('content_translations')) {
            return;
        }
        foreach ((array) json_decode((string) file_get_contents($file), true)['forms'] as $slug => $names) {
            $form = ProductForm::query()->where('slug', $slug)->first();
            if (! $form) {
                continue;
            }
            foreach ($names as $locale => $name) {
                if ($locale === 'en') {
                    continue;
                }
                if ($locale === 'ar') {
                    if (blank($form->name_ar) || $form->name_ar === $form->name_en) {
                        DB::table('product_forms')->where('id', $form->id)->update(['name_ar' => $name]);
                    }

                    continue;
                }
                \App\Models\ContentTranslation::query()->firstOrCreate(
                    ['entity' => 'product_forms', 'entity_id' => $form->id, 'locale' => $locale, 'field' => 'name'],
                    ['value' => $name, 'value_hash' => sha1((string) $form->name_en), 'origin' => 'machine'],
                );
            }
        }
        \App\Models\ContentTranslation::forget();
    }

    // ------------------------------------------------------------------ photos

    /** @return array{0: ?string, 1: list<string>, 2: string} key, candidates, reason */
    public static function classify(string $file): array
    {
        $base = preg_replace('/\.webp$/i', '', $file);
        if (preg_match('/^(MANZANILLA|AZIZI|AKS|PICUAL|DOLCE|KALAMATA|SERS COLA) (GREEN|BLACK) OLIVES - (WHOLE|PITTED|SLICED|HALVES|STUFFED)\d*$/', $base, $m)) {
            $fam = $m[2] === 'GREEN' ? 'green' : 'black';

            return [sprintf('%s:%s:%s', $fam, self::slugOf(ucwords(strtolower($m[1]))), strtolower($m[3])), [], 'file name states cultivar, colour and cut'];
        }
        if (preg_match('/^BLACK OXIDIZED OLIVES - (WHOLE|PITTED|SLICED)\d*$/', $base, $m)) {
            return ['ox:none:'.strtolower($m[1]), [], 'file name states the black oxidized cut'];
        }
        if (preg_match('/^GUINDILLAS GREEN PEPPER\d*$/', $base)) {
            // Looked at the picture: the peppers shown are bright yellow although the file name says green.
            return [null, ['item:guindillas', 'item:baby_y'], 'file name says green guindillas but the peppers pictured look yellow: confirm which product this is'];
        }
        if (preg_match('/^RED BABY PEPPER\d*$/', $base)) {
            return ['item:baby_r', [], 'file name states the pepper'];
        }
        if (preg_match('/^RED CHERRY PEPPER - CORED\d*$/', $base)) {
            return ['item:cherry_c', [], 'file name states the cored cherry pepper'];
        }
        if (str_starts_with($base, 'BEKO')) {
            return [null, [], 'numbered camera file: not assigned by sequence or by appearance'];
        }
        if (str_contains($base, '_') || str_contains($base, '&')) {
            return [null, [], 'group photograph naming several products'];
        }
        if (in_array($base, ['GROUP PRODUCTS', 'EMPTY PLATE'], true)) {
            return [null, [], 'group / generic photograph: category level only'];
        }

        return [null, [], 'name does not identify one product'];
    }

    private function photos(string $dir, bool $apply): void
    {
        $byProduct = [];
        foreach (File::files($dir) as $f) {
            $name = $f->getFilename();
            if (strtolower($f->getExtension()) !== 'webp') {
                continue;
            }
            [$key, $cand, $reason] = self::classify($name);
            $sum = sha1_file($f->getPathname());
            $media = MediaAsset::query()->where('checksum', $sum)->first();
            if ($media) {
                $this->stats['media_reused']++;
            } else {
                $path = 'products/catalog/'.$this->cleanName($name);
                if ($apply) {
                    Storage::disk('public')->put($path, file_get_contents($f->getPathname()));
                }
                [$w, $h] = @getimagesize($f->getPathname()) ?: [null, null];
                $media = MediaAsset::create(['disk' => 'public', 'path' => $path, 'filename' => basename($path), 'original_filename' => $name, 'mime_type' => 'image/webp', 'extension' => 'webp',
                    'size' => $f->getSize(), 'width' => $w, 'height' => $h, 'folder' => 'products', 'checksum' => $sum]);
                $this->stats['media_created']++;
            }
            if ($key === null) {
                $kept = [];
                if ($cand !== []) {
                    // This file now needs a person. An earlier run may have linked it: remove a link ONLY when the importer
                    // demonstrably created it and nobody touched it since; any other link is somebody's decision and stays.
                    foreach (ProductImage::where('media_id', $media->id)->get() as $link) {
                        $untouched = $link->source === 'import' && $link->updated_at !== null && $link->created_at !== null && $link->updated_at->equalTo($link->created_at);
                        if ($untouched) {
                            if ($link->is_primary && (int) Product::whereKey($link->product_id)->value('primary_image_id') === (int) $media->id) {
                                DB::table('products')->where('id', $link->product_id)->update(['primary_image_id' => null]);
                            }
                            $link->delete();
                        } else {
                            $kept[] = $link;
                        }
                    }
                }
                $r = CatalogMediaReview::query()->firstOrNew(['media_id' => $media->id]);
                if (! $r->exists) {
                    $r->fill(['original_filename' => $name, 'candidates' => $cand, 'reason' => $reason, 'status' => 'pending'])->save();
                    $this->stats['review_queued']++;
                }
                if ($kept !== [] && blank($r->note)) {
                    $r->update(['note' => 'Already linked to product id(s) '.collect($kept)->pluck('product_id')->unique()->implode(', ').' (not created by the importer, or edited since): link kept, please confirm.']);
                    $this->notes[] = "$name: existing link kept and flagged for review.";
                }
                $this->mapping[] = ['key' => '', 'source_filename' => $name, 'role' => 'review', 'status' => 'review: '.$reason];

                continue;
            }
            $byProduct[$key][] = [$name, $media];
        }

        foreach ($byProduct as $key => $items) {
            $product = Product::query()->where('import_key', $key)->first();
            if (! $product) {
                $this->notes[] = "Photos for $key skipped: product not found.";

                continue;
            }
            usort($items, fn ($a, $b) => strnatcasecmp($a[0], $b[0]));
            $hasPrimary = $product->primary_image_id !== null;
            foreach ($items as $i => [$name, $media]) {
                $this->altTexts($media, $product, in_array($name, self::verified(), true));
                $role = 'gallery';
                if (! $hasPrimary && $i === 0) {
                    DB::table('products')->where('id', $product->id)->update(['primary_image_id' => $media->id]);
                    $hasPrimary = true;
                    $role = 'primary';
                    $this->stats['primary_set']++;
                }
                $link = ProductImage::query()->firstOrCreate(['product_id' => $product->id, 'media_id' => $media->id], ['is_primary' => $role === 'primary', 'display_order' => $i, 'source' => 'import']);
                if ($link->wasRecentlyCreated) {
                    $this->stats['gallery_links']++;
                }
                $this->mapping[] = ['key' => $key, 'source_filename' => $name, 'role' => (int) $product->fresh()->primary_image_id === (int) $media->id ? 'primary' : 'gallery', 'status' => 'matched: file name'];
            }
        }
    }

    private const ALT = [
        'en' => '%s in a dark wooden bowl on a white background', 'ar' => '%s في وعاء خشبي داكن على خلفية بيضاء', 'es' => '%s en un cuenco de madera oscura sobre fondo blanco',
        'fr' => '%s dans un bol en bois foncé sur fond blanc', 'it' => '%s in una ciotola di legno scuro su sfondo bianco', 'pt' => '%s numa taça de madeira escura sobre fundo branco',
        'el' => '%s σε σκούρο ξύλινο μπολ σε λευκό φόντο', 'ru' => '%s в тёмной деревянной миске на белом фоне', 'zh' => '%s，盛在深色木碗中，白色背景', 'ur' => '%s گہرے لکڑی کے پیالے میں سفید پس منظر پر',
    ];

    /** What is visible in the confirmed photographs: the product in a dark wooden bowl on white. Only the product name carries the cultivar. */
    /** @return list<string> files whose pictures were inspected: product in a dark wooden bowl on white */
    private static function verified(): array
    {
        static $list = null;

        return $list ??= (array) (json_decode((string) @file_get_contents(database_path('data/catalog/verified-photos.json')), true)['files'] ?? []);
    }

    private function altTexts(MediaAsset $media, Product $product, bool $verified = false): void
    {
        if (! Schema::hasTable('media_asset_translations')) {
            return;
        }
        foreach (self::ALT as $locale => $pattern) {
            $existing = $media->altTexts()->where('locale', $locale)->first();
            $name = (string) ($product->t('name', $locale) ?: $product->t('name', 'en'));
            // Phase 1 stored the bare product name as alt text; that is machine-made too and may be replaced. Anything else a person wrote stays.
            if ($existing && ! $existing->generated && filled($existing->alt) && trim((string) $existing->alt) !== $name) {
                continue;
            }
            // Only inspected photos get the visual description; any other photo gets the plain product name, never an assumed scene.
            $media->setAlt($locale, $verified ? sprintf($pattern, $name) : $name, true);
        }
    }

    private function cleanName(string $name): string
    {
        return strtolower(trim(preg_replace('/[^A-Za-z0-9]+/', '-', pathinfo($name, PATHINFO_FILENAME)), '-')).'.webp';
    }
}
