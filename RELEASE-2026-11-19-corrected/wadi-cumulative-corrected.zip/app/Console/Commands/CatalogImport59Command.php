<?php

declare(strict_types=1);

namespace App\Console\Commands;

use App\Services\Catalog\CatalogImport59;
use Illuminate\Console\Command;

class CatalogImport59Command extends Command
{
    protected $signature = 'catalog:import-59 {--apply : Write changes (default is a dry run)} {--photos= : Use another folder of WebP photographs instead of the 124 bundled with the release} {--no-photos : Skip the photograph step} {--mapping= : Write the photo mapping CSV to this path}';

    protected $description = 'Create/reconcile the 59 catalogue entries with ten-language copy and photo matches (dry run by default; repeatable)';

    public function handle(): int
    {
        $svc = new CatalogImport59;
        // Default: the photographs that ship inside the release (database/data/catalog/photos). Unconfirmed matches still go to the review queue.
        $dir = $this->option('no-photos') ? null : ($this->option('photos') ?: CatalogImport59::bundledPhotoDir());
        $r = $svc->run((bool) $this->option('apply'), $dir);
        $this->info(($r['applied'] ? 'APPLIED' : 'DRY RUN (nothing written)').': '.json_encode($r['stats']));
        foreach ($r['notes'] as $n) {
            $this->warn($n);
        }
        if ($path = $this->option('mapping')) {
            file_put_contents($path, (new \App\Services\Catalog\PhotoReviewService)->csv());
            $this->line("Mapping written to $path");
        }

        return self::SUCCESS;
    }
}
