<?php

declare(strict_types=1);

namespace App\Models;

use App\Models\Concerns\Auditable;
use App\Models\Concerns\HasBilingualFields;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Variety extends Model
{
    use Auditable;
    use HasBilingualFields;
    use HasFactory;

    protected $table = 'varieties';

    protected $fillable = [
        'slug', 'name_en', 'name_ar', 'description_en', 'description_ar',
        'intro_en', 'intro_ar', 'characteristics_en', 'characteristics_ar', 'culinary_uses_en', 'culinary_uses_ar',
        'image_id', 'is_active', 'show_in_menu', 'display_order', 'aliases',
    ];

    protected function casts(): array
    {
        return [
            'aliases' => 'array',
            'is_active' => 'boolean',
            'show_in_menu' => 'boolean',
            'display_order' => 'integer',
        ];
    }

    public function products(): HasMany
    {
        return $this->hasMany(Product::class);
    }

    public function image(): BelongsTo
    {
        return $this->belongsTo(MediaAsset::class, 'image_id');
    }
}
