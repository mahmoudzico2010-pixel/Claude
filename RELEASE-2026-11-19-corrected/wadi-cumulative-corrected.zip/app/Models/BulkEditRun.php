<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class BulkEditRun extends Model
{
    protected $fillable = ['user_id', 'action', 'scope', 'outcome', 'rolled_back_at', 'rollback_outcome'];

    protected function casts(): array
    {
        return ['scope' => 'array', 'outcome' => 'array', 'rollback_outcome' => 'array', 'rolled_back_at' => 'datetime'];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function changes(): HasMany
    {
        return $this->hasMany(BulkEditChange::class, 'run_id');
    }
}
