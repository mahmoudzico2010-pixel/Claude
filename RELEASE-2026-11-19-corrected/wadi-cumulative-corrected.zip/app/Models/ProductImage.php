<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ProductImage extends Model
{
    protected $fillable = ['product_id', 'media_id', 'is_primary', 'display_order', 'source'];

    /** Exactly one primary photo per product: marking one primary unmarks the others and keeps products.primary_image_id in step. */
    protected static function booted(): void
    {
        static::saved(function (self $image): void {
            if ($image->is_primary) {
                static::query()->where('product_id', $image->product_id)->whereKeyNot($image->getKey())->where('is_primary', true)->update(['is_primary' => false]);
                \Illuminate\Support\Facades\DB::table('products')->where('id', $image->product_id)->update(['primary_image_id' => $image->media_id]);
            }
        });
    }

    protected function casts(): array
    {
        return [
            'is_primary' => 'boolean',
            'display_order' => 'integer',
        ];
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }

    public function media(): BelongsTo
    {
        return $this->belongsTo(MediaAsset::class, 'media_id');
    }
}
