<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BulkEditChange extends Model
{
    public $timestamps = false;

    protected $fillable = ['run_id', 'product_id', 'kind', 'field', 'locale', 'before', 'after'];

    protected function casts(): array
    {
        return ['before' => 'array', 'after' => 'array'];
    }
}
