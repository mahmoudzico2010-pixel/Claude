<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class MediaAssetTranslation extends Model
{
    protected $fillable = ['media_id', 'locale', 'alt', 'generated'];

    protected function casts(): array
    {
        return ['generated' => 'boolean'];
    }

    public function media(): BelongsTo
    {
        return $this->belongsTo(MediaAsset::class, 'media_id');
    }
}
