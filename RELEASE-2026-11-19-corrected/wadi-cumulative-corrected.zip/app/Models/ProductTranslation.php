<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ProductTranslation extends Model
{
    public $timestamps = false;

    protected $table = 'product_translations';

    protected $fillable = [
        'product_id', 'locale', 'name', 'short_description', 'description',
        'ingredients', 'storage_conditions', 'export_notes',
        'seo_title', 'seo_description', 'imported_hashes',
    ];

    protected function casts(): array
    {
        return ['imported_hashes' => 'array'];
    }

    /** True when the stored value is exactly what the importer wrote (so it has never been edited by a person). */
    public function isPristine(string $field): bool
    {
        $hash = ($this->imported_hashes ?? [])[$field] ?? null;

        return $hash !== null && hash_equals($hash, sha1((string) $this->getAttribute($field)));
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }
}
