// Real-browser test of Filament's "Select all matching" + exclusion + bulk edit apply.
// Usage: BASE=http://127.0.0.1:8000 ADMIN_EMAIL=... ADMIN_PASSWORD=... node tests/Browser/bulk-select-all.e2e.mjs
// Needs a running site + `npm i playwright` (or global). Prints PASS/FAIL lines and exits non-zero on failure.
import { createRequire } from 'module';
import { execSync } from 'child_process';
const require = createRequire(process.env.PW_PATH || '/opt/node22/lib/node_modules/');
const { chromium } = require('playwright');
const BASE = process.env.BASE || 'http://127.0.0.1:8000';
const q = (php) => execSync(`php artisan tinker --execute='${php}'`, { encoding: 'utf8' }).trim().split('\n').pop();
let fail = 0; const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) fail++; };

q('App\\Models\\Product::query()->update(["color"=>null]);');
const b = await chromium.launch(); const p = await (await b.newContext({ viewport: { width: 1500, height: 1000 } })).newPage();
await p.goto(BASE + '/admin/login'); await p.fill('input[type=email]', process.env.ADMIN_EMAIL); await p.fill('input[type=password]', process.env.ADMIN_PASSWORD);
await p.click('button[type=submit]'); await p.waitForTimeout(2500);
await p.goto(BASE + '/admin/products'); await p.waitForLoadState('networkidle');
await p.locator('input[placeholder="Search"]').last().fill('Green Olives'); await p.waitForTimeout(2500);

await p.locator('select:visible:has(option[value="10"])').first().selectOption('10'); await p.waitForTimeout(1500);   // 10 rows per page => the matches span 3 pages
const total = +q('echo App\\Models\\Product::whereHas("translations", fn($t)=>$t->where("name","like","%Green Olives%"))->count();');
await p.locator('thead input[type=checkbox]').first().check(); await p.waitForTimeout(600);
await p.locator('button:visible', { hasText: /Select all \d+/ }).first().click(); await p.waitForTimeout(900);
ok(await p.getByText(new RegExp(`${total} records? selected`)).count() > 0, `"Select all" selects all ${total} matching rows across pages`);

// go to page 2 and untick one row there
await p.locator('nav[aria-label*="agination"] button, .fi-pagination button').filter({ hasText: '2' }).first().click(); await p.waitForTimeout(1500);
const row = p.locator('tbody tr').nth(1);
const excludedName = (await row.locator('td').nth(2).innerText()).split('\n')[0].trim();
await row.locator('input[type=checkbox]').uncheck(); await p.waitForTimeout(800);
ok(await p.getByText(new RegExp(`${total - 1} records? selected`)).count() > 0, `unticking one row on page 2 leaves ${total - 1} selected (excluded: ${excludedName})`);

await p.getByText('Bulk actions').first().click(); await p.getByText('Bulk edit').first().click(); await p.waitForTimeout(4000);
ok(p.url().includes('/bulk-edit'), 'bulk edit screen opened');
ok(await p.getByText(new RegExp(`${total - 1}`)).first().isVisible(), 'screen shows the exact count of the selection');
// Radio groups in order: Category, Cultivar, Cut, Processing, Colour, ... — "Set" is value=set (Category has only Keep/Set)
await p.locator('input[type=radio][value=set]').nth(4).check(); await p.waitForTimeout(800);
await p.locator('input[type=text]:visible').last().fill('E2E tone');
await p.getByRole('button', { name: /Preview/ }).click(); await p.waitForTimeout(3000);
const changeText = await p.getByText(/Preview:/).first().innerText();
ok(changeText.includes(`${total - 1}`), 'preview counts exactly the selected rows: ' + changeText);
p.on('dialog', (d) => d.accept());
await p.locator('[data-testid=apply]').click(); await p.waitForTimeout(4000);

const changed = +q('echo App\\Models\\Product::where("color","E2E tone")->count();');
ok(changed === total - 1, `rows changed = ${changed}, expected ${total - 1}`);
const excluded = q(`echo App\\Models\\Product::whereHas("translations", fn($t)=>$t->where("name", "${excludedName.replace(/"/g, '\\"')}"))->value("color") ?? "NULL";`);
ok(excluded === 'NULL', `excluded row "${excludedName}" stayed untouched (color=${excluded})`);
const outside = +q('echo App\\Models\\Product::whereDoesntHave("translations", fn($t)=>$t->where("name","like","%Green Olives%"))->where("color","E2E tone")->count();');
ok(outside === 0, 'no non-matching product changed');
await b.close(); process.exit(fail ? 1 : 0);
