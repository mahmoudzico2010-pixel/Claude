<x-filament-panels::page>
    @php($counts = $this->counts())
    <div style="display:flex;flex-wrap:wrap;align-items:center;gap:.5rem" role="group" aria-label="{{ __('photoreview.queue_status') }}">
        @foreach (['pending' => 'tab_pending', 'assigned' => 'tab_assigned', 'group' => 'tab_group', 'rejected' => 'tab_rejected', 'all' => 'tab_all'] as $key => $label)
            <x-filament::button size="sm" :color="$status === $key ? 'primary' : 'gray'" wire:click="$set('status', '{{ $key }}')">
                {{ __('photoreview.'.$label) }}@if ($key !== 'all') ({{ $counts[$key] ?? 0 }})@endif
            </x-filament::button>
        @endforeach
        <input type="search" wire:model.live.debounce.300ms="search" placeholder="{{ __('photoreview.search') }}" style="border:1px solid #ccc;border-radius:.5rem;padding:.35rem .6rem" aria-label="{{ __('photoreview.search') }}">
        <x-filament::button size="sm" color="gray" icon="heroicon-o-arrow-down-tray" wire:click="downloadMapping">{{ __('photoreview.download') }}</x-filament::button>
    </div>

    <div class="wr-pq-grid" style="display:grid;gap:1.5rem;align-items:start">
        <div>
            <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:.5rem;max-height:75vh;overflow-y:auto" role="list">
                @forelse ($this->items() as $item)
                    <div role="listitem" style="position:relative;border:2px solid {{ $focus === $item->id ? '#1f6f4a' : '#e5e5e5' }};border-radius:.4rem;overflow:hidden">
                        <input type="checkbox" value="{{ $item->id }}" wire:model.live="selected" style="position:absolute;top:4px;inset-inline-start:4px;z-index:2" aria-label="{{ __('photoreview.select_photo', ['name' => $item->original_filename]) }}">
                        <button type="button" wire:click="focusOn({{ $item->id }})" style="display:block;width:100%;text-align:start" title="{{ $item->original_filename }}">
                            <img src="{{ $item->media->urlFor(240) }}" alt="{{ $item->original_filename }}" loading="lazy" style="width:100%;aspect-ratio:1/1;object-fit:cover;display:block">
                            <span dir="ltr" style="display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding:0 4px;font-size:11px">{{ $item->original_filename }}</span>
                            @if ($item->status !== 'pending')<span style="display:block;padding:0 4px;font-size:11px;color:#777">{{ $item->status }}{{ $item->product ? ' → '.($item->product->t('name')) : '' }}</span>@endif
                        </button>
                    </div>
                @empty
                    <p style="grid-column:1/-1;color:#777">{{ __('photoreview.nothing') }}</p>
                @endforelse
            </div>
            @if ($selected)<p style="margin-top:.5rem;font-size:.9rem">{{ __('photoreview.ticked', ['n' => count($selected)]) }}</p>@endif
        </div>

        <div style="display:flex;flex-direction:column;gap:.75rem">
            @if ($f = $this->focused())
                <img src="{{ $f->media->url() }}" alt="{{ $f->original_filename }}" style="max-height:60vh;width:100%;object-fit:contain;background:#fff;border:1px solid #ddd;border-radius:.5rem">
                <p style="font-size:.9rem"><strong dir="ltr">{{ $f->original_filename }}</strong><br><span style="color:#555">{{ __('photoreview.why', ['reason' => $f->reason]) }}</span>@if ($f->note)<br><span style="color:#a16207">{{ $f->note }}</span>@endif</p>
                @if ($f->status !== 'pending')
                    <p style="font-size:.9rem">{{ __('photoreview.status_line', ['status' => $f->status]) }}{{ $f->product ? ' → '.$f->product->t('name').' ('.$f->assigned_role.')' : '' }}</p>
                    <div><x-filament::button size="sm" color="warning" wire:click="undo({{ $f->id }})">{{ __('photoreview.undo') }}</x-filament::button></div>
                @else
                    <div style="display:flex;flex-wrap:wrap;gap:.5rem">
                        <x-filament::button size="sm" color="gray" wire:click="decide('group')">{{ __('photoreview.group') }}</x-filament::button>
                        <x-filament::button size="sm" color="danger" wire:click="decide('rejected')">{{ __('photoreview.reject') }}</x-filament::button>
                    </div>
                @endif
            @else
                <p style="color:#777">{{ __('photoreview.pick') }}</p>
            @endif
        </div>

        <div style="display:flex;flex-direction:column;gap:.75rem">
            <label style="font-size:.9rem;font-weight:500" for="psearch">{{ __('photoreview.find') }}</label>
            <input id="psearch" type="search" wire:model.live.debounce.300ms="productSearch" style="width:100%;border:1px solid #ccc;border-radius:.5rem;padding:.4rem .6rem" placeholder="{{ __('photoreview.find_ph') }}">
            <ul style="max-height:12rem;overflow-y:auto;font-size:.875rem;display:flex;flex-direction:column;gap:.25rem">
                @foreach ($this->results() as $p)
                    <li><button type="button" wire:click="chooseProduct({{ $p->id }})" style="width:100%;text-align:start;border:1px solid {{ $productId === $p->id ? '#1f6f4a' : '#ddd' }};background:{{ $productId === $p->id ? '#eef7f1' : '#fff' }};border-radius:.4rem;padding:.25rem .5rem">
                        {{ $p->t('name') ?: $p->slug }} <span style="color:#777">· {{ $p->variety?->localized('name') }} {{ $p->form?->localized('name') }}</span></button></li>
                @endforeach
            </ul>

            @if ($c = $this->chosen())
                <div style="border:1px solid #ddd;border-radius:.5rem;padding:.5rem;display:flex;flex-direction:column;gap:.5rem">
                    <p style="font-weight:500">{{ $c->t('name') }}</p>
                    @if (count($selected) > 1)
                        <label style="font-size:.9rem" for="pchoice">{{ __('photoreview.choose_primary') }}</label>
                        <select id="pchoice" wire:model.live="primaryChoice" style="border:1px solid #ccc;border-radius:.4rem;padding:.3rem">
                            <option value="">{{ __('photoreview.keep_primary') }}</option>
                            @foreach ($this->items()->whereIn('id', $selected) as $it)<option value="{{ $it->id }}">{{ $it->original_filename }}</option>@endforeach
                        </select>
                        <p style="font-size:.8rem;color:#666">{{ __('photoreview.rest_gallery') }}</p>
                    @else
                        <label style="font-size:.9rem"><input type="checkbox" wire:model.live="primaryChoice" true-value="this" false-value=""> {{ __('photoreview.primary') }}</label>
                    @endif
                    <div style="display:flex;flex-wrap:wrap;gap:.5rem">
                        <x-filament::button size="sm" wire:click="assign(false)">{{ $selected ? __('photoreview.assign_ticked', ['n' => count($selected)]) : __('photoreview.assign_this') }}</x-filament::button>
                        <x-filament::button size="sm" color="success" wire:click="assign(true)">{{ __('photoreview.save_next') }}</x-filament::button>
                    </div>
                    <p style="font-size:.9rem;font-weight:500">{{ __('photoreview.gallery_order') }}</p>
                    <ol style="display:flex;flex-direction:column;gap:.25rem">
                        @foreach ($c->images->sortBy('display_order') as $img)
                            <li style="display:flex;align-items:center;gap:.5rem;font-size:.875rem">
                                <img src="{{ $img->media->urlFor(120) }}" alt="" style="width:40px;height:40px;object-fit:cover;border-radius:4px">
                                <span dir="ltr" style="min-width:0;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">{{ $img->media->original_filename }}@if ((int) $c->primary_image_id === (int) $img->media_id) <strong>· {{ __('photoreview.primary_badge') }}</strong>@endif</span>
                                <button type="button" wire:click="move({{ $img->media_id }}, -1)" aria-label="{{ __('photoreview.up') }}">↑</button>
                                <button type="button" wire:click="move({{ $img->media_id }}, 1)" aria-label="{{ __('photoreview.down') }}">↓</button>
                                @if ((int) $c->primary_image_id !== (int) $img->media_id)<button type="button" wire:click="makePrimary({{ $img->media_id }})" style="font-size:.75rem;text-decoration:underline">{{ __('photoreview.make_primary') }}</button>@endif
                            </li>
                        @endforeach
                    </ol>
                </div>
            @endif
        </div>
    </div>
    <style>.wr-pq-grid{grid-template-columns:minmax(260px,1.1fr) minmax(300px,1.3fr) minmax(280px,1.1fr)}@media (max-width:900px){.wr-pq-grid{grid-template-columns:1fr}}</style>
</x-filament-panels::page>
