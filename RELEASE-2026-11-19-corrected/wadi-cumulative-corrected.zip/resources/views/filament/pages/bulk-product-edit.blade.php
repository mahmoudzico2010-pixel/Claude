<x-filament-panels::page>
    <div role="status" style="border:1px solid #9bc7ad;background:#eef7f1;border-radius:.5rem;padding:1rem">
        <p style="font-size:1.1rem;font-weight:600">
            {{ $selectionMode === 'all_filtered' ? __('bulk.selected_all', ['count' => count($ids)]) : __('bulk.selected_ticked', ['count' => count($ids)]) }}
        </p>
        @if ($selectionMode === 'all_filtered')<p style="font-size:.85rem;color:#555">{{ __('bulk.excluded_note') }}</p>@endif
        @if ($filters)<p style="font-size:.85rem;color:#555">{{ __('bulk.filters') }}: {{ implode(' · ', $filters) }}</p>@endif
    </div>

    @if ($conflicts)
        <div role="alert" data-testid="conflicts" style="border:1px solid #e0a3a3;background:#fdf0f0;border-radius:.5rem;padding:1rem">
            <p style="font-weight:600">{{ __('bulk.conflict_title') }}</p>
            <ul style="margin-top:.5rem;list-style:disc;padding-inline-start:1.25rem">
                @foreach ($conflicts as $c)<li>{{ __('bulk.conflict_row', ['label' => $c['label'], 'why' => $c['why']]) }}</li>@endforeach
            </ul>
        </div>
    @endif

    <form wire:submit.prevent="previewChanges" style="display:flex;flex-direction:column;gap:1rem">
        {{ $this->form }}
        <div><x-filament::button type="submit" color="gray" icon="heroicon-o-eye" data-testid="preview">{{ __('bulk.preview') }}</x-filament::button></div>
    </form>

    @if ($preview)
        @php($t = $preview['totals'])
        <section aria-live="polite" style="border:1px solid #ddd;border-radius:.5rem;padding:1rem;display:flex;flex-direction:column;gap:.75rem">
            <h3 style="font-weight:600">{{ __('bulk.preview') }}: {{ $t['selected'] }} · <span style="color:#15803d">{{ $t['change'] }} {{ __('bulk.r_change') }}</span> · {{ $t['skip'] }} {{ __('bulk.r_skip') }} · <span style="color:#b91c1c">{{ $t['invalid'] }} {{ __('bulk.r_invalid') }}</span></h3>
            <div style="overflow-x:auto">
                <table style="width:100%;font-size:.875rem;border-collapse:collapse">
                    <thead><tr style="color:#777"><th style="text-align:start;padding:.25rem">{{ __('bulk.th_product') }}</th><th style="text-align:start;padding:.25rem">{{ __('bulk.th_result') }}</th><th style="text-align:start;padding:.25rem">{{ __('bulk.th_change') }}</th></tr></thead>
                    <tbody>
                    @foreach ($preview['rows'] as $row)
                        <tr style="border-top:1px solid #e5e5e5;vertical-align:top">
                            <td style="padding:.25rem;font-weight:500">{{ $row['label'] }}</td>
                            <td style="padding:.25rem"><x-filament::badge :color="['change' => 'success', 'skip' => 'gray', 'invalid' => 'danger'][$row['status']]">{{ __('bulk.r_'.$row['status']) }}</x-filament::badge></td>
                            <td style="padding:.25rem">
                                @foreach ($row['changes'] as $c)
                                    <div><span style="color:#777">{{ $c['field'] }}{{ $c['locale'] ? ' ('.$c['locale'].')' : '' }}:</span>
                                        <s style="color:#999">{{ \Illuminate\Support\Str::limit(is_array($c['before']) ? json_encode($c['before']) : (string) ($c['before'] ?? '—'), 50) }}</s>
                                        → <strong>{{ \Illuminate\Support\Str::limit(is_array($c['after']) ? json_encode($c['after']) : (string) ($c['after'] ?? '—'), 70) }}</strong></div>
                                @endforeach
                                @foreach ($row['reasons'] as $r)<div style="color:#777">{{ $r }}</div>@endforeach
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
            @if ($t['change'] > 0)
                <div><x-filament::button wire:click="applyChanges" wire:confirm="{{ __('bulk.confirm_apply', ['n' => $t['change']]) }}" color="primary" icon="heroicon-o-check" data-testid="apply">{{ __('bulk.apply_n', ['n' => $t['change']]) }}</x-filament::button></div>
            @else
                <p style="color:#777">{{ __('bulk.nothing') }}</p>
            @endif
        </section>
    @endif

    <section style="display:flex;flex-direction:column;gap:.5rem">
        <h3 style="font-weight:600">{{ __('bulk.history') }}</h3>
        @forelse ($this->history() as $run)
            <div style="display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:.5rem;border:1px solid #ddd;border-radius:.4rem;padding:.5rem;font-size:.875rem">
                <span>{{ __('bulk.run_line', ['id' => $run->id, 'date' => $run->created_at->format('Y-m-d H:i'), 'user' => $run->user?->name ?? '—', 'action' => $run->action, 'n' => $run->outcome['changed'] ?? 0]) }}</span>
                @if ($run->rolled_back_at)
                    <span style="color:#777">{{ __('bulk.rolled') }}</span>
                @elseif (($run->outcome['changed'] ?? 0) > 0)
                    @if ($run->rollback_outcome)<span style="color:#a16207">{{ __('bulk.partial') }}</span>@endif
                    <x-filament::button size="xs" color="gray" wire:click="rollbackRun({{ $run->id }})" wire:confirm="{{ __('bulk.confirm_rollback', ['id' => $run->id]) }}">{{ __('bulk.rollback') }}</x-filament::button>
                @endif
            </div>
        @empty
            <p style="color:#777">—</p>
        @endforelse
    </section>
</x-filament-panels::page>
