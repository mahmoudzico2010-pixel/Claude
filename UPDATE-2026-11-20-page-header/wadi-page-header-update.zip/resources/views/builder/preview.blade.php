@extends('layouts.public')

{{--
    The draft homepage, rendered for the builder's preview pane.

    It extends the real public layout on purpose: the header, the footer, the
    theme tokens, the fonts and the compiled section CSS are all the ones a
    visitor gets. A preview built from its own simplified layout is a second
    implementation of the page, and the two drift — the preview keeps looking
    correct while the real page breaks.

    The only thing added is the selection overlay, and it is added only here.
--}}

@push('head')
    {{-- Not indexable, and not reachable by a visitor anyway: the route is
         behind the admin auth guard. This is belt and braces for the case
         where a preview URL is pasted somewhere it should not be. --}}
    <meta name="robots" content="noindex, nofollow">
@endpush

@section('content')
    @if (str_starts_with($pageKey, 'page:'))
        @php($__h = app(\App\Services\PageHeaders\PageHeaderService::class))
        @php($__h->usePreview(true))
        @php($__p = $__h->pageProps($pageKey, $locale))
        <x-page-hero :page-key="$pageKey" :eyebrow="$__p['eyebrow']" :title="$__p['title']" :subtitle="$__p['subtitle']" :breadcrumbs="$__p['breadcrumbs']" />
    @endif
    @include('builder.page', ['payload' => $payload])

    @if (empty($payload['nodes']))
        <div class="container-wr py-24 text-center">
            <p class="text-ink-muted">{{ __('admin.builder.preview_empty') }}</p>
        </div>
    @endif
@endsection

@push('scripts')
    {{-- A Blade partial rather than part of the compiled bundle, because the
         bundle is served to visitors and this view is not. --}}
    @include('builder.preview-script')
@endpush
