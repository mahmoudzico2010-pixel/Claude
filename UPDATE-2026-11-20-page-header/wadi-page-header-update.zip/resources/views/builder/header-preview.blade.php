@extends('layouts.public')

@push('head')
    <meta name="robots" content="noindex, nofollow">
@endpush

@section('content')
    {{-- The very same component the public page uses; only the data source (draft vs published) differs. --}}
    <x-page-hero :page-key="$key" :eyebrow="$props['eyebrow']" :title="$props['title']" :subtitle="$props['subtitle']" :breadcrumbs="$props['breadcrumbs']" />
    @if (! empty($payload['nodes']))
        @include('builder.page', ['payload' => $payload])
    @endif
@endsection

@push('scripts')
    @include('builder.preview-script')
@endpush
