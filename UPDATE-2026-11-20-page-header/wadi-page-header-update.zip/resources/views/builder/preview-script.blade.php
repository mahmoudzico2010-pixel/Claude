{{--
    Makes the rendered preview selectable.

    Included only by builder/preview.blade.php, which is behind the admin auth
    guard — so none of this reaches a public page. It is a Blade partial rather
    than part of the compiled bundle for exactly that reason: the bundle is
    served to visitors, this view is not.

    Three jobs:
      1. Outline the node under the pointer, so it is obvious what a click will
         select.
      2. Tell the builder which node was clicked.
      3. Highlight and scroll to whichever node the builder says is selected.

    It also suppresses navigation. Every link in the preview is a real link to a
    real page, and following one would replace the preview with the live site
    inside the builder's own pane — the click is a selection gesture here, not
    navigation.
--}}
<script>
(function () {
    'use strict';

    /*
     | The parent is same-origin, which is what allows this conversation at all.
     | The origin is still checked on every inbound message rather than trusted:
     | an iframe can be addressed by anything that can reach the page, and
     | `event.origin` is the only part of a message that cannot be forged.
     */
    var ORIGIN = window.location.origin;

    if (window.parent === window) {
        // Opened directly rather than in the builder. Leave the page alone —
        // it is then simply a rendered draft, which is a reasonable thing to
        // want to look at on its own.
        return;
    }

    var selected = null;

    function nodeFrom(target) {
        return target && target.closest ? target.closest('[data-builder-node]') : null;
    }

    function idOf(element) {
        if (!element) { return null; }
        var raw = element.getAttribute('data-builder-node');
        return raw === 'header' ? 'header' : parseInt(raw, 10);
    }

    function send(type, payload) {
        window.parent.postMessage(Object.assign({ source: 'wr-builder-preview', type: type }, payload), ORIGIN);
    }

    // ------------------------------------------------------------- hovering

    document.addEventListener('mouseover', function (event) {
        var node = nodeFrom(event.target);

        document.querySelectorAll('.wr-preview-hover').forEach(function (el) {
            el.classList.remove('wr-preview-hover');
        });

        if (node) {
            node.classList.add('wr-preview-hover');
        }
    });

    document.addEventListener('mouseleave', function () {
        document.querySelectorAll('.wr-preview-hover').forEach(function (el) {
            el.classList.remove('wr-preview-hover');
        });
    });

    // ------------------------------------------------------------- selecting

    document.addEventListener('click', function (event) {
        var node = nodeFrom(event.target);

        if (!node) {
            return;
        }

        // While a block is being edited in place, clicks place the caret instead of re-selecting.
        if (node.getAttribute('contenteditable') === 'true') {
            event.preventDefault();
            return;
        }

        // A click here means "select this", never "go there".
        event.preventDefault();
        event.stopPropagation();

        highlight(idOf(node));
        send('select', { id: idOf(node) });
    }, true);

    // ---------------------------------------------------------- inline edit
    // Double-click a heading or paragraph to type on the canvas; leaving the block (or Escape) saves it.
    var EDITABLE = ['wr-heading', 'wr-text', 'wr-rich-text'];

    function isEditable(node) {
        return node && EDITABLE.some(function (c) { return node.classList.contains(c); });
    }

    document.addEventListener('dblclick', function (event) {
        var node = nodeFrom(event.target);

        if (!isEditable(node) || node.getAttribute('contenteditable') === 'true') {
            return;
        }

        event.preventDefault();
        var rich = node.classList.contains('wr-rich-text');
        var before = rich ? node.innerHTML : node.innerText;

        node.setAttribute('contenteditable', 'true');
        node.setAttribute('spellcheck', 'true');
        node.focus();

        function finish(save) {
            node.removeAttribute('contenteditable');
            node.removeEventListener('blur', onBlur);
            node.removeEventListener('keydown', onKey);
            var after = rich ? node.innerHTML : node.innerText;

            if (save && after !== before) {
                send('inline', { id: idOf(node), value: after });
            } else if (!save) {
                if (rich) { node.innerHTML = before; } else { node.innerText = before; }
            }
        }

        function onBlur() { finish(true); }
        function onKey(e) {
            if (e.key === 'Escape') { e.preventDefault(); finish(false); }
            if (e.key === 'Enter' && !rich) { e.preventDefault(); node.blur(); }
        }

        node.addEventListener('blur', onBlur);
        node.addEventListener('keydown', onKey);
    });

    // Keyboard equivalent, so the preview is not mouse-only. Elements are not
    // focusable by default, so this relies on the builder's own tree for
    // keyboard navigation and only handles Enter on anything that did receive
    // focus — a link or a button inside a node.
    document.addEventListener('keydown', function (event) {
        if (event.key !== 'Enter') {
            return;
        }

        var node = nodeFrom(event.target);

        if (node && node.getAttribute('contenteditable') !== 'true') {
            event.preventDefault();
            highlight(idOf(node));
            send('select', { id: idOf(node) });
        }
    }, true);

    // ------------------------------------------------------------ responding

    function highlight(id) {
        if (selected) {
            selected.classList.remove('wr-preview-selected');
        }

        selected = id ? document.querySelector('[data-builder-node="' + id + '"]') : null;

        if (selected) {
            selected.classList.add('wr-preview-selected');
        }
    }

    window.addEventListener('message', function (event) {
        if (event.origin !== ORIGIN) {
            return;
        }

        var data = event.data;

        if (!data || data.source !== 'wr-builder') {
            return;
        }

        if (data.type === 'highlight') {
            highlight(data.id);

            if (selected) {
                // `nearest` rather than `center`: scrolling a node that is
                // already visible into the middle of the pane is disorienting
                // when all you did was click it in the tree.
                selected.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            }
        }
    });

    // Tell the builder the preview is ready, so it can send the current
    // selection rather than waiting for the next interaction to show it.
    send('ready', {});
}());
</script>

<style>
    /*
     | Selection affordances.
     |
     | `outline` rather than `border`, because a border occupies space and would
     | move the layout being previewed — the preview would stop showing what the
     | published page looks like at the exact moment someone is inspecting it.
     */
    [data-builder-node] {
        outline-offset: -2px;
    }

    .wr-preview-hover {
        outline: 2px dashed color-mix(in oklch, var(--color-gold, #b8912f) 70%, transparent);
    }

    .wr-preview-selected {
        outline: 2px solid var(--color-gold, #b8912f);
    }

    /* Nothing in the preview navigates: a click is a selection gesture. The
       cursor says so rather than promising a link that will not follow. */
    [data-builder-node] a,
    [data-builder-node] button {
        cursor: default;
    }
</style>
