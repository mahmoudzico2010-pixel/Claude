<div>
    @if ($media)
        <img src="{{ $media->urlFor(320) }}" alt="" style="max-height:110px;border-radius:.4rem;border:1px solid #ddd">
        <p dir="ltr" style="font-size:.75rem;color:#777;margin-top:.25rem">{{ $media->original_filename }}</p>
    @else
        <p style="font-size:.85rem;color:#777">{{ $label }}</p>
    @endif
</div>
