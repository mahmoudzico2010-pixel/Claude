@php($path = $getStatePath())
<x-dynamic-component :component="$getFieldWrapperView()" :field="$field">
    {{-- Slider and number box edit the SAME value (0–100). An explicit 0 stays 0. --}}
    <div style="display:flex;align-items:center;gap:.75rem" x-data>
        <input type="range" min="0" max="100" step="1" wire:model.live.debounce.250ms="{{ $path }}" style="flex:1" aria-label="{{ $getLabel() }}">
        <input type="number" min="0" max="100" step="1" wire:model.live.debounce.400ms="{{ $path }}" style="width:5rem;border:1px solid #ccc;border-radius:.4rem;padding:.25rem .4rem" aria-label="{{ $getLabel() }} (%)">
        <span aria-hidden="true">%</span>
    </div>
</x-dynamic-component>
