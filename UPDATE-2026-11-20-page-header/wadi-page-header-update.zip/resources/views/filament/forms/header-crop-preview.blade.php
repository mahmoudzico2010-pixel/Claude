@php($src = $mobile ?? $desktop)
<div style="display:flex;gap:1rem;align-items:flex-start;flex-wrap:wrap">
    @if ($src)
        <figure style="margin:0">
            {{-- What stays visible on a phone: a 9:16 portrait window onto the photo, using the focal point. --}}
            <div style="width:110px;height:196px;border:2px solid #333;border-radius:14px;overflow:hidden;background:#222">
                <img src="{{ $src->urlFor(640) }}" alt="" style="width:100%;height:100%;object-fit:{{ $fit }};object-position:{{ $x }}% {{ $y }}%">
            </div>
            <figcaption style="font-size:.75rem;color:#666;text-align:center;margin-top:.25rem">{{ __('pageheader.phone_view') }}</figcaption>
        </figure>
        @if ($desktop)
        <figure style="margin:0">
            <div style="width:240px;height:96px;border:2px solid #333;border-radius:6px;overflow:hidden;background:#222">
                <img src="{{ $desktop->urlFor(640) }}" alt="" style="width:100%;height:100%;object-fit:{{ $fit }};object-position:{{ $x }}% {{ $y }}%">
            </div>
            <figcaption style="font-size:.75rem;color:#666;text-align:center;margin-top:.25rem">{{ __('pageheader.desktop_view') }}</figcaption>
        </figure>
        @endif
    @endif
</div>
