<x-filament-panels::page>
    @if ($headerKey === '')
        <p style="color:#555">{{ __('pageheader.pick_page') }}</p>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:.5rem">
            @foreach ($this->keys() as $k)
                <a href="{{ \App\Filament\Pages\PageHeaderEditor::urlFor($k['key']) }}" style="border:1px solid #ddd;border-radius:.5rem;padding:.5rem .75rem;display:block;background:#fff">
                    <strong>{{ $k['label'] }}</strong><br><span style="font-size:.8rem;color:#777">{{ __('pageheader.kind_'.$k['kind']) }}</span>
                </a>
            @endforeach
        </div>
    @else
        <div class="wr-ph-grid" style="display:grid;gap:1.5rem;align-items:start">
            <div style="display:flex;flex-direction:column;gap:1rem">
                <div style="display:flex;justify-content:space-between;gap:.5rem;flex-wrap:wrap;align-items:center">
                    <a href="{{ \App\Filament\Pages\PageHeaderEditor::getUrl() }}" style="text-decoration:underline">← {{ __('pageheader.pick_page') }}</a>
                    <span style="font-size:.8rem;color:{{ $headerUnpublished ? '#a16207' : '#15803d' }}">{{ $headerUnpublished ? __('pageheader.unpublished') : __('pageheader.published_state') }}</span>
                </div>
                {{ $this->headerForm }}
                <div style="display:flex;gap:.5rem;flex-wrap:wrap">
                    <x-filament::button wire:click="publishHeader" icon="heroicon-m-check">{{ __('pageheader.publish') }}</x-filament::button>
                    <x-filament::button wire:click="discardHeader" color="gray" wire:confirm="{{ __('pageheader.discard') }}?">{{ __('pageheader.discard') }}</x-filament::button>
                </div>
            </div>
            <div x-data="{ src: @js($this->headerPreviewUrl()) }" x-on:builder-refresh.window="src = $event.detail.url">
                <iframe wire:ignore :src="src" title="{{ __('pageheader.preview') }}" style="width:100%;height:70vh;border:1px solid #ddd;border-radius:.5rem;background:#fff"></iframe>
            </div>
        </div>
        <style>.wr-ph-grid{grid-template-columns:minmax(320px,1fr) minmax(320px,1.2fr)}@media (max-width:1000px){.wr-ph-grid{grid-template-columns:1fr}}</style>
    @endif
</x-filament-panels::page>
