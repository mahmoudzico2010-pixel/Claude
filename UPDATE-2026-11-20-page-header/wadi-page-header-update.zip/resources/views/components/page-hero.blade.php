@props([
    'eyebrow' => null,
    'title',
    'subtitle' => null,
    'image' => null,
    'breadcrumbs' => [],
    'pageKey' => null,
])

@php
    /* One component renders every inner-page banner, on the public site AND in the editor preview. A page whose banner was
       never customised (no row, or "Use default") takes the original markup below, unchanged. */
    $headers = app(\App\Services\PageHeaders\PageHeaderService::class);
    $hdrKey = $pageKey ?? $headers->currentKey();
    $hdr = $headers->resolve($hdrKey);
    $preview = $headers->isPreview();
@endphp

@if ($hdr && $hdr['mode'] === 'hidden')
    {{-- Banner hidden: the page keeps exactly one main title for assistive technology and search engines. --}}
    <h1 class="sr-only" @if ($preview) data-builder-node="header" @endif>{{ $title }}</h1>
@elseif ($hdr)
    @php
        $s = $hdr['s'];
        $loc = app()->getLocale();
        $pick = fn (string $k, $fallback) => filled($s[$k][$loc] ?? null) ? $s[$k][$loc] : $fallback;
        $hEyebrow = $pick('eyebrow', $eyebrow);
        $hTitle = $pick('title', $title);
        $hSub = $pick('subtitle', $subtitle);
        $img = $s['image_id'] ? \App\Models\MediaAsset::query()->with('altTexts')->find($s['image_id']) : null;
        $mob = $s['mobile_image_id'] ? \App\Models\MediaAsset::query()->find($s['mobile_image_id']) : null;
        $uid = 'ph-'.substr(md5((string) $hdrKey), 0, 8);
        $fit = $s['fit'] === 'contain' ? 'contain' : 'cover';
        $pos = $s['focal_x'].'% '.$s['focal_y'].'%';
    @endphp
    <style>
        #{{ $uid }}{min-height:{{ $s['height_desktop'] }}px;background-color:{{ $s['bg_color'] }};color:{{ $s['text_color'] }}}
        #{{ $uid }} .ph-inner{padding-block:{{ $s['pad_desktop'] }}px;text-align:{{ $s['align'] }}}
        #{{ $uid }} .ph-text{color:{{ $s['text_color'] }}}
        #{{ $uid }} nav, #{{ $uid }} nav *{color:inherit}
        #{{ $uid }} .ph-text-block{{ $s['align'] === 'center' ? '{margin-inline:auto}' : ($s['align'] === 'end' ? '{margin-inline-start:auto}' : '{}') }}
        @media (max-width:767px){#{{ $uid }}{min-height:{{ $s['height_mobile'] }}px}#{{ $uid }} .ph-inner{padding-block:{{ $s['pad_mobile'] }}px}}
    </style>
    <section id="{{ $uid }}" data-page-header style="position:relative;isolation:isolate;overflow:hidden" @if ($preview) data-builder-node="header" @endif>
        @if ($img)
            {{-- The photograph has its OWN opacity; the colour layer below has its own; the text is outside both and is never faded. --}}
            <picture aria-hidden="true" style="position:absolute;inset:0;z-index:-2;display:block">
                @if ($mob)<source media="(max-width: 767px)" srcset="{{ $mob->urlFor(1080) }}">@endif
                <img src="{{ $img->urlFor(1920) }}" alt="" loading="eager" fetchpriority="high" decoding="async"
                     style="width:100%;height:100%;object-fit:{{ $fit }};object-position:{{ $pos }};opacity:{{ $s['image_opacity'] / 100 }}">
            </picture>
        @endif
        <div aria-hidden="true" data-page-header-overlay style="position:absolute;inset:0;z-index:-1;background-color:{{ $s['overlay_color'] }};opacity:{{ $s['overlay_opacity'] / 100 }}"></div>

        <div class="container-wr ph-inner" style="position:relative">
            @if ($s['show_breadcrumb'] && ! empty($breadcrumbs))
                <x-breadcrumbs :items="$breadcrumbs" light />
            @endif
            <div class="ph-text-block max-w-3xl">
                @if ($hEyebrow)<p class="eyebrow eyebrow-light ph-text {{ ($s['show_breadcrumb'] && ! empty($breadcrumbs)) ? 'mt-6' : '' }}">{{ $hEyebrow }}</p>@endif
                <h1 class="ph-text text-balance font-bold text-h1 lg:text-display {{ $hEyebrow || ($s['show_breadcrumb'] && ! empty($breadcrumbs)) ? 'mt-4' : '' }}">{{ $hTitle }}</h1>
                @if ($hSub)<p class="ph-text mt-5 max-w-2xl text-lead" style="opacity:.85">{{ $hSub }}</p>@endif
            </div>
            {{ $slot }}
        </div>
    </section>
@else
{{-- Inner-page header. Uses the dark brand green with an optional image
     behind it; the overlay keeps text contrast well above AA either way. --}}
<section class="relative isolate overflow-hidden bg-forest" @if ($preview) data-builder-node="header" @endif>
    @if ($image)
        <img src="{{ $image->urlFor(1920) }}"
             @if ($image->srcset()) srcset="{{ $image->srcset() }}" sizes="100vw" @endif
             alt="{{ $image->alt() }}"
             class="absolute inset-0 -z-10 size-full object-cover opacity-30"
             loading="eager" fetchpriority="high"
             width="{{ $image->width }}" height="{{ $image->height }}">
        <div class="absolute inset-0 -z-10 bg-gradient-to-t from-forest via-forest/80 to-forest/50" aria-hidden="true"></div>
    @endif

    <div class="container-wr py-16 lg:py-24">
        @if (! empty($breadcrumbs))
            <x-breadcrumbs :items="$breadcrumbs" light />
        @endif

        @if ($eyebrow)
            <p class="eyebrow eyebrow-light {{ empty($breadcrumbs) ? '' : 'mt-6' }}">{{ $eyebrow }}</p>
        @endif

        <h1 @class([
            'max-w-3xl text-balance font-bold text-white',
            'text-h1 lg:text-display' => true,
            'mt-4' => $eyebrow || ! empty($breadcrumbs),
        ])>{{ $title }}</h1>

        @if ($subtitle)
            <p class="mt-5 max-w-2xl text-lead text-white/75">{{ $subtitle }}</p>
        @endif

        {{ $slot }}
    </div>
</section>
@endif
