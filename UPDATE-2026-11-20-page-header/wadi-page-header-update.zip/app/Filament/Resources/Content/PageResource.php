<?php

declare(strict_types=1);

namespace App\Filament\Resources\Content;

use App\Filament\Forms\Components\MediaPicker;
use App\Filament\Resources\Content\Pages\CreatePage;
use App\Filament\Resources\Content\Pages\EditPage;
use App\Filament\Resources\Content\Pages\ListPages;
use App\Models\Page;
use App\Support\Permissions;
use BackedEnum;
use Filament\Actions\Action;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteAction;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Forms\Components\RichEditor;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Notifications\Notification;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Tabs;
use Filament\Schemas\Components\Text;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Auth;

class PageResource extends Resource
{
    protected static ?string $model = Page::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedDocument;

    protected static ?int $navigationSort = 2;

    public static function getNavigationGroup(): ?string
    {
        return __('nav.groups.content');
    }

    public static function getModelLabel(): string
    {
        return __('admin.resources.page.label');
    }

    public static function getPluralModelLabel(): string
    {
        return __('admin.resources.page.plural');
    }

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            Section::make()->schema([
                Tabs::make('locales')->tabs(
                    collect(config('wadi.locales'))
                        ->map(fn (array $c, string $locale) => Tabs\Tab::make($c['native'])->schema([
                            TextInput::make("translations.{$locale}.title")
                                ->label(__('admin.fields.title'))
                                ->required($locale === config('app.fallback_locale'))
                                ->maxLength(255),
                            TextInput::make("translations.{$locale}.subtitle")
                                ->label(__('admin.fields.short_description'))->maxLength(255),
                            RichEditor::make("translations.{$locale}.body")
                                ->label(__('admin.fields.description'))
                                ->toolbarButtons(['bold', 'italic', 'link', 'bulletList', 'orderedList', 'h2', 'h3', 'blockquote', 'undo', 'redo']),
                            TextInput::make("translations.{$locale}.seo_title")
                                ->label(__('admin.fields.seo_title'))->maxLength(255),
                            Textarea::make("translations.{$locale}.seo_description")
                                ->label(__('admin.fields.seo_description'))->rows(2)->maxLength(500),
                        ]))
                        ->values()->all()
                ),
            ]),

            // Shown only for pages behind the review gate — the reviewer needs
            // to see exactly what is outstanding before approving.
            Section::make(__('admin.pages.review_required'))
                ->visible(fn (?Page $record): bool => (bool) $record?->requires_review)
                ->schema([
                    Text::make(
                        fn (?Page $record): string => $record?->admin_notes ?? ''
                    ),
                    Textarea::make('admin_notes')
                        ->label(__('admin.pages.admin_notes'))
                        ->helperText(__('admin.pages.admin_notes_hint'))
                        ->rows(4),
                ]),

            Section::make()->columns(3)->schema([
                TextInput::make('slug')->label(__('admin.fields.slug'))->required()
                    ->maxLength(255)->unique(ignoreRecord: true)->rules(['alpha_dash']),

                // System pages keep a fixed key so controllers can find them
                // even after the slug is renamed; it is read-only once set.
                TextInput::make('key')
                    ->label('System key')
                    ->maxLength(48)
                    ->unique(ignoreRecord: true)
                    ->disabled(fn (?Page $record): bool => filled($record?->key))
                    ->dehydrated()
                    ->helperText('Set for built-in pages such as about, quality, export, privacy, terms.'),

                MediaPicker::make('featured_image_id', __('admin.fields.primary_image'), 'pages'),
                MediaPicker::make('seo_image_id', __('admin.fields.seo_image'), 'pages'),

                TextInput::make('nav_order')->label(__('admin.fields.display_order'))->numeric()->default(0),
                Toggle::make('show_in_nav')->label('Show in navigation')->inline(false),
                Toggle::make('is_active')->label(__('admin.fields.is_active'))->default(true)->inline(false),
            ]),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->modifyQueryUsing(fn (Builder $query) => $query->withTranslation())
            ->defaultSort('nav_order')
            ->reorderable('nav_order')
            ->columns([
                TextColumn::make('title')
                    ->label(__('admin.fields.title'))
                    ->getStateUsing(fn (Page $r): string => $r->t('title') ?? $r->slug)
                    ->description(fn (Page $r): ?string => $r->slug)
                    ->weight('medium'),
                TextColumn::make('key')->label('Key')->badge()->color('gray')->placeholder('—'),

                TextColumn::make('review_state')
                    ->label(__('admin.pages.review_state'))
                    ->badge()
                    ->getStateUsing(fn (Page $record): string => match (true) {
                        $record->awaitsReview() => __('admin.pages.awaiting_review'),
                        $record->requires_review => __('admin.pages.reviewed'),
                        default => __('admin.pages.not_applicable'),
                    })
                    ->color(fn (Page $record): string => match (true) {
                        $record->awaitsReview() => 'warning',
                        $record->requires_review => 'success',
                        default => 'gray',
                    })
                    ->description(fn (Page $record): ?string => $record->reviewed_at
                        ? $record->reviewed_at->translatedFormat('j M Y')
                        : null),

                IconColumn::make('show_in_nav')->label('In navigation')->boolean(),

                IconColumn::make('is_public')
                    ->label(__('admin.pages.publicly_visible'))
                    ->boolean()
                    ->getStateUsing(fn (Page $record): bool => $record->isPubliclyVisible()),
            ])
            ->recordActions([
                \Filament\Actions\Action::make('editHeader')
                    ->label(__('pageheader.edit'))->icon('heroicon-m-photo')
                    ->url(fn ($record): string => \App\Filament\Pages\PageBuilder::urlForPage($record, true))
                    ->visible(fn (): bool => \App\Filament\Pages\PageBuilder::canAccess()),
                \Filament\Actions\Action::make('editVisually')
                    ->label(__('admin.builder.edit_visually'))->icon('heroicon-m-squares-2x2')
                    ->url(fn ($record): string => \App\Filament\Pages\PageBuilder::urlForPage($record))
                    ->visible(fn (): bool => \App\Filament\Pages\PageBuilder::canAccess()),
                EditAction::make(),

                // Recording review is a deliberate, attributable act: it
                // publishes the page and stamps who approved it.
                Action::make('markReviewed')
                    ->label(__('admin.pages.mark_reviewed'))
                    ->icon(Heroicon::OutlinedCheckBadge)
                    ->color('success')
                    ->visible(fn (Page $record): bool => $record->awaitsReview()
                        && (Auth::user()?->can(Permissions::CONTENT_MANAGE) ?? false))
                    ->requiresConfirmation()
                    ->modalHeading(__('admin.pages.mark_reviewed'))
                    ->modalDescription(__('admin.pages.mark_reviewed_confirm'))
                    ->action(function (Page $record): void {
                        $record->markReviewed(Auth::user());

                        Notification::make()
                            ->success()
                            ->title(__('admin.pages.marked_reviewed'))
                            ->send();
                    }),

                Action::make('revokeReview')
                    ->label(__('admin.pages.revoke_review'))
                    ->icon(Heroicon::OutlinedArrowUturnLeft)
                    ->color('danger')
                    ->visible(fn (Page $record): bool => $record->requires_review
                        && $record->reviewed_at !== null
                        && (Auth::user()?->can(Permissions::CONTENT_MANAGE) ?? false))
                    ->requiresConfirmation()
                    ->action(function (Page $record): void {
                        $record->forceFill(['reviewed_at' => null, 'reviewed_by' => null])->save();

                        Notification::make()
                            ->warning()
                            ->title(__('admin.pages.review_revoked'))
                            ->send();
                    }),

                // A built-in page is referenced by a controller; removing it
                // would 404 a menu link, so only custom pages are deletable.
                DeleteAction::make()->visible(fn (Page $record): bool => blank($record->key)),
            ])
            ->toolbarActions([BulkActionGroup::make([DeleteBulkAction::make()])]);
    }

    public static function getPages(): array
    {
        return [
            'index' => ListPages::route('/'),
            'create' => CreatePage::route('/create'),
            'edit' => EditPage::route('/{record}/edit'),
        ];
    }
}
