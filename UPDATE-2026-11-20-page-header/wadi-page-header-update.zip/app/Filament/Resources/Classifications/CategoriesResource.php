<?php

declare(strict_types=1);

namespace App\Filament\Resources\Classifications;

use App\Filament\Forms\Components\MediaPicker;
use App\Filament\Resources\Classifications\Pages\CreateCategory;
use App\Filament\Resources\Classifications\Pages\EditCategory;
use App\Filament\Resources\Classifications\Pages\ListCategories;
use App\Models\Category;
use BackedEnum;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteAction;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Tabs;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;

class CategoriesResource extends Resource
{
    protected static ?string $model = Category::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedRectangleStack;

    protected static ?int $navigationSort = 2;

    public static function getNavigationGroup(): ?string
    {
        return __('nav.groups.catalogue');
    }

    public static function getModelLabel(): string
    {
        return __('admin.resources.category.label');
    }

    public static function getPluralModelLabel(): string
    {
        return __('admin.resources.category.plural');
    }

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            Section::make()->schema([
                Tabs::make('locales')->tabs(
                    collect(config('wadi.locales'))
                        ->map(fn (array $config, string $locale) => Tabs\Tab::make($config['native'])->schema([
                            TextInput::make("translations.{$locale}.name")
                                ->label(__('admin.fields.name'))
                                ->required($locale === config('app.fallback_locale'))
                                ->maxLength(255),
                            Textarea::make("translations.{$locale}.description")
                                ->label(__('admin.fields.description'))
                                ->rows(3),
                            TextInput::make("translations.{$locale}.seo_title")
                                ->label(__('admin.fields.seo_title'))
                                ->maxLength(255),
                            Textarea::make("translations.{$locale}.seo_description")
                                ->label(__('admin.fields.seo_description'))
                                ->rows(2)
                                ->maxLength(500),
                        ]))
                        ->values()
                        ->all()
                ),
            ]),

            Section::make()->columns(2)->schema([
                TextInput::make('slug')
                    ->label(__('admin.fields.slug'))
                    ->required()
                    ->maxLength(255)
                    ->unique(ignoreRecord: true)
                    ->rules(['alpha_dash']),

                Select::make('parent_id')
                    ->label('Parent category')
                    ->options(fn (?Category $record): array => Category::query()
                        ->when($record, fn (Builder $q) => $q->whereKeyNot($record->getKey()))
                        ->withTranslation()
                        ->ordered()
                        ->get()
                        ->mapWithKeys(fn (Category $c): array => [$c->id => $c->t('name') ?? $c->slug])
                        ->all())
                    ->native(false)
                    ->searchable(),

                MediaPicker::make('image_id', __('admin.fields.image'), 'products'),

                TextInput::make('display_order')
                    ->label(__('admin.fields.display_order'))
                    ->numeric()
                    ->default(0),

                Toggle::make('show_in_menu')
                    ->label(__('catalog.admin.show_in_menu'))
                    ->default(true)
                    ->inline(false),

                Toggle::make('is_active')
                    ->label(__('admin.fields.is_active'))
                    ->default(true)
                    ->inline(false),
            ]),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->modifyQueryUsing(fn (Builder $query) => $query->withTranslation()->withCount('products'))
            ->defaultSort('display_order')
            ->reorderable('display_order')
            ->columns([
                TextColumn::make('name')
                    ->label(__('admin.fields.name'))
                    ->getStateUsing(fn (Category $record): string => $record->t('name') ?? $record->slug)
                    ->description(fn (Category $record): ?string => $record->slug)
                    ->weight('medium'),

                TextColumn::make('products_count')
                    ->label(__('admin.resources.product.plural'))
                    ->badge()
                    ->color('gray'),

                IconColumn::make('is_active')
                    ->label(__('admin.fields.is_active'))
                    ->boolean(),
            ])
            ->recordActions([
                EditAction::make(),
                \Filament\Actions\Action::make('editHeader')
                    ->label(__('pageheader.edit'))->icon('heroicon-m-photo')
                    ->url(fn (\App\Models\Category $record): string => \App\Filament\Pages\PageHeaderEditor::urlFor('category:'.$record->slug))
                    ->visible(fn (): bool => \App\Filament\Pages\PageHeaderEditor::canAccess()),
                DeleteAction::make()
                    // A category with products would orphan them; the FK is
                    // restrictOnDelete, so refuse here with a clear reason.
                    ->disabled(fn (Category $record): bool => $record->products()->exists())
                    ->tooltip(fn (Category $record): ?string => $record->products()->exists()
                        ? 'This category still has products.'
                        : null),
            ])
            ->toolbarActions([
                BulkActionGroup::make([DeleteBulkAction::make()]),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => ListCategories::route('/'),
            'create' => CreateCategory::route('/create'),
            'edit' => EditCategory::route('/{record}/edit'),
        ];
    }
}
