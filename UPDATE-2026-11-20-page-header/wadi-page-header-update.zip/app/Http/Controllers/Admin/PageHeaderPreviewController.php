<?php

declare(strict_types=1);

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Page;
use App\Services\Builder\PageRenderer;
use App\Services\PageHeaders\PageHeaderService;
use App\Support\Permissions;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

/** Staff-only render of ONE page's banner (draft settings) inside the real site layout, through the same component visitors get. */
class PageHeaderPreviewController extends Controller
{
    public function __invoke(Request $request, PageHeaderService $headers): View
    {
        abort_unless(Auth::check() && Auth::user()?->can(Permissions::CONTENT_VIEW), 403);
        $key = (string) $request->query('key', '');
        abort_unless(preg_match('/^(page|category|route):[A-Za-z0-9._-]+$/', $key) === 1, 404);

        $locale = (string) $request->query('locale', app()->getLocale());
        $locale = array_key_exists($locale, (array) config('wadi.locales', [])) ? $locale : app()->getLocale();
        app()->setLocale($locale);
        $headers->usePreview(true);

        $payload = null;
        if (str_starts_with($key, 'page:') && ($page = Page::query()->where('slug', substr($key, 5))->first())) {
            $payload = app(PageRenderer::class)->draftPayload($key, $locale);
        }

        return view('builder.header-preview', ['key' => $key, 'props' => $headers->pageProps($key, $locale), 'payload' => $payload, 'locale' => $locale]);
    }
}
