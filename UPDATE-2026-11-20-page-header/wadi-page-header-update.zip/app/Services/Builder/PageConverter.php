<?php

declare(strict_types=1);

namespace App\Services\Builder;

use App\Models\BuilderNode;
use App\Models\Page;
use Illuminate\Support\Facades\DB;

/**
 * Gives an existing CMS page a starting builder draft made from what it already says, so "Edit visually" opens on the real
 * content rather than an empty canvas. The page record is never changed; nothing is public until a revision is published,
 * and until then the page keeps rendering exactly as before.
 */
final class PageConverter
{
    public function __construct(private readonly TreeManager $tree) {}

    public static function key(Page $page): string
    {
        return 'page:'.$page->slug;
    }

    /** Create the starter draft once; returns false when a draft already exists. */
    public function ensureDraft(Page $page): bool
    {
        $key = self::key($page);
        if (BuilderNode::hasTreeFor($key)) {
            return false;
        }

        DB::transaction(function () use ($page, $key): void {
            $section = $this->tree->add($key, null, 'section');
            $container = $this->tree->add($key, (int) $section->id, 'container');
            $column = $this->tree->add($key, (int) $container->id, 'column');
            // No title heading: the page title lives in the Page Header / Hero banner, so a page never shows two main titles.
            $body = $this->tree->add($key, (int) $column->id, 'rich_text');

            foreach (array_keys((array) config('wadi.locales', [])) as $locale) {
                $text = trim((string) $page->t('body', $locale));
                if ($text !== '') {
                    $body->translations()->updateOrCreate(['locale' => $locale], ['content' => ['body' => $text]]);
                }
            }
        });

        return true;
    }
}
