<?php

declare(strict_types=1);

namespace App\Services\PageHeaders;

use App\Models\MediaAsset;
use App\Models\Page;
use App\Models\PageHeader;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Schema;

/**
 * Per-page banner settings with the same draft/publish split as the page builder: visitors read the PUBLISHED copy, staff
 * previews read the DRAFT. A page with no row (or mode "default") renders the banner it always had.
 */
final class PageHeaderService
{
    public const MODES = ['default', 'custom', 'hidden'];

    /** Built-in storefront routes whose banner belongs to a CMS page row (by its stable `key`). */
    private const KEYED_ROUTES = ['about' => 'about', 'quality' => 'quality', 'export' => 'export', 'private-label' => 'private-label', 'privacy' => 'privacy', 'terms' => 'terms', 'contact.show' => 'contact', 'packaging.index' => 'packaging'];

    /** Other pages that carry the shared banner. */
    private const ROUTE_PAGES = ['products.index', 'news.index', 'quote.create'];

    /** Staff preview is a property of THIS request only (never of the shared service), so it cannot leak to a visitor. */
    public function usePreview(bool $on = true): void
    {
        request()->attributes->set('page_header_preview', $on);
    }

    public function isPreview(): bool
    {
        return (bool) request()->attributes->get('page_header_preview', false);
    }

    /** @return array<string, mixed> */
    public static function defaults(): array
    {
        return [
            'bg_color' => '#0f2d24', 'image_id' => null, 'mobile_image_id' => null, 'fit' => 'cover', 'focal_x' => 50, 'focal_y' => 50,
            'image_opacity' => 100, 'overlay_color' => '#0b3d2e', 'overlay_opacity' => 35,
            'height_desktop' => 360, 'height_mobile' => 260, 'pad_desktop' => 80, 'pad_mobile' => 48,
            'align' => 'start', 'text_color' => '#ffffff', 'show_breadcrumb' => true,
            'eyebrow' => [], 'title' => [], 'subtitle' => [],
        ];
    }

    // ------------------------------------------------------------------ keys

    public function keyForPage(Page $page): string
    {
        return 'page:'.$page->slug;
    }

    /** The key of the banner on the page being rendered, or null where the page has none we manage. */
    public function currentKey(?Request $request = null): ?string
    {
        $request ??= request();
        $route = $request->route();
        $name = $route?->getName();
        if (! $name) {
            return null;
        }
        if (isset(self::KEYED_ROUTES[$name])) {
            $slug = Page::query()->where('key', self::KEYED_ROUTES[$name])->value('slug');

            return $slug ? 'page:'.$slug : 'route:'.$name;
        }
        if ($name === 'page.show') {
            return 'page:'.$route->parameter('page');
        }
        if ($name === 'products.category') {
            return 'category:'.$route->parameter('category');
        }
        if (in_array($name, self::ROUTE_PAGES, true)) {
            return 'route:'.$name;
        }

        return null;
    }

    /**
     * What the page itself would put in its banner (title, eyebrow, subtitle, breadcrumb) for the editor and the preview.
     *
     * @return array{eyebrow: ?string, title: string, subtitle: ?string, breadcrumbs: list<array{label: string, url: ?string}>, label: string}
     */
    public function pageProps(string $key, string $locale): array
    {
        $home = ['label' => __('site.home', [], $locale), 'url' => url('/'.$locale)];
        if (str_starts_with($key, 'page:')) {
            $page = Page::query()->withTranslation()->where('slug', substr($key, 5))->first();
            $title = (string) ($page?->t('title', $locale) ?: substr($key, 5));
            $nav = $page?->key ? 'site.nav.'.str_replace('-', '_', $page->key) : null;
            $eyebrow = $nav && \Illuminate\Support\Facades\Lang::has($nav, $locale) ? __($nav, [], $locale) : null;

            return ['eyebrow' => $eyebrow, 'title' => $title, 'subtitle' => $page?->t('subtitle', $locale) ?: null, 'breadcrumbs' => [$home, ['label' => $title, 'url' => null]], 'label' => $title];
        }
        if (str_starts_with($key, 'category:')) {
            $c = \App\Models\Category::query()->with('translations')->where('slug', substr($key, 9))->first();
            $title = (string) ($c?->t('name', $locale) ?: substr($key, 9));

            return ['eyebrow' => $c?->parent ? (string) $c->parent->t('name', $locale) : __('site.nav.products', [], $locale), 'title' => $title, 'subtitle' => null, 'breadcrumbs' => [$home, ['label' => $title, 'url' => null]], 'label' => $title];
        }
        $name = substr($key, 6);
        $title = match ($name) { 'products.index' => __('site.products.title', [], $locale), 'news.index' => __('site.news.title', [], $locale), 'quote.create' => __('forms.rfq.title', [], $locale), default => $name };

        return ['eyebrow' => null, 'title' => (string) $title, 'subtitle' => null, 'breadcrumbs' => [$home, ['label' => (string) $title, 'url' => null]], 'label' => (string) $title];
    }

    /** Every banner the editor can reach, for the page-header list. @return list<array{key: string, label: string, kind: string}> */
    public function allKeys(): array
    {
        $out = [];
        foreach (Page::query()->withTranslation()->orderBy('id')->get() as $p) {
            $out[] = ['key' => 'page:'.$p->slug, 'label' => (string) ($p->t('title', 'en') ?: $p->slug), 'kind' => 'page'];
        }
        foreach (['products.index', 'news.index', 'quote.create'] as $r) {
            $out[] = ['key' => 'route:'.$r, 'label' => $this->pageProps('route:'.$r, 'en')['title'], 'kind' => 'storefront'];
        }
        foreach (\App\Models\Category::query()->with('translations')->ordered()->get() as $c) {
            $out[] = ['key' => 'category:'.$c->slug, 'label' => (string) $c->t('name', 'en'), 'kind' => 'category'];
        }

        return $out;
    }

    // ------------------------------------------------------------------ reading

    /**
     * Resolved banner state for rendering. Returns null for "default" so callers keep the existing markup untouched.
     *
     * @return array{mode: string, s: array<string, mixed>}|null
     */
    public function resolve(?string $key, ?bool $preview = null): ?array
    {
        if ($key === null || ! Schema::hasTable('page_headers')) {
            return null;
        }
        $row = PageHeader::query()->where('page_key', $key)->first();
        if (! $row) {
            return null;
        }
        $preview ??= $this->isPreview();
        $mode = $preview ? $row->mode : ($row->published_mode ?? 'default');
        $settings = $preview ? ($row->settings ?? []) : ($row->published_settings ?? []);
        if (! in_array($mode, ['custom', 'hidden'], true)) {
            return null;
        }

        return ['mode' => $mode, 's' => $this->clean($settings)];
    }

    /** @return array{mode: string, settings: array<string, mixed>, unpublished: bool, published_at: ?string} what the EDITOR shows (the draft) */
    public function draft(string $key): array
    {
        $row = Schema::hasTable('page_headers') ? PageHeader::query()->where('page_key', $key)->first() : null;

        return [
            'mode' => $row?->mode ?? 'default',
            'settings' => $this->clean($row?->settings ?? []),
            'unpublished' => $row ? $row->hasUnpublishedChanges() : false,
            'published_at' => $row?->published_at?->toDateTimeString(),
        ];
    }

    // ------------------------------------------------------------------ writing

    /** @param array<string, mixed> $settings */
    public function saveDraft(string $key, string $mode, array $settings, ?User $by): PageHeader
    {
        abort_unless(in_array($mode, self::MODES, true), 422);

        return PageHeader::query()->updateOrCreate(['page_key' => $key], ['mode' => $mode, 'settings' => $this->clean($settings), 'updated_by' => $by?->id]);
    }

    public function publish(string $key, ?User $by = null): ?PageHeader
    {
        $row = PageHeader::query()->where('page_key', $key)->first();
        if (! $row) {
            return null;
        }
        $row->update(['published_mode' => $row->mode, 'published_settings' => $row->settings, 'published_at' => now(), 'updated_by' => $by?->id ?? $row->updated_by]);

        return $row;
    }

    /** Throw the draft away: back to what is published (or to the default banner if nothing was ever published). */
    public function discard(string $key): void
    {
        $row = PageHeader::query()->where('page_key', $key)->first();
        $row?->update(['mode' => $row->published_mode ?? 'default', 'settings' => $row->published_settings]);
    }

    // ------------------------------------------------------------------ cleaning

    /**
     * Every value is clamped or whitelisted, so a stored setting can never carry markup into the page, and an explicit 0 stays 0.
     *
     * @param  array<string, mixed>  $in
     * @return array<string, mixed>
     */
    public function clean(array $in): array
    {
        $d = self::defaults();
        $int = fn (string $k, int $min, int $max) => array_key_exists($k, $in) && is_numeric($in[$k]) ? max($min, min($max, (int) round((float) $in[$k]))) : $d[$k];
        $color = fn (string $k) => isset($in[$k]) && is_string($in[$k]) && preg_match('/^#[0-9a-fA-F]{6}$/', $in[$k]) ? strtolower($in[$k]) : $d[$k];
        $media = fn (string $k) => isset($in[$k]) && is_numeric($in[$k]) && (int) $in[$k] > 0 && MediaAsset::query()->whereKey((int) $in[$k])->exists() ? (int) $in[$k] : null;
        $text = function (string $k): array {
            return [];
        };
        $langs = fn (string $k) => collect((array) ($in[$k] ?? []))->filter(fn ($v, $l) => is_string($l) && array_key_exists($l, (array) config('wadi.locales', [])) && is_string($v) && trim($v) !== '')->map(fn ($v) => mb_substr(trim(strip_tags($v)), 0, 300))->all();

        return [
            'bg_color' => $color('bg_color'),
            'image_id' => $media('image_id'), 'mobile_image_id' => $media('mobile_image_id'),
            'fit' => in_array($in['fit'] ?? 'cover', ['cover', 'contain'], true) ? ($in['fit'] ?? 'cover') : 'cover',
            'focal_x' => $int('focal_x', 0, 100), 'focal_y' => $int('focal_y', 0, 100),
            'image_opacity' => $int('image_opacity', 0, 100), 'overlay_color' => $color('overlay_color'), 'overlay_opacity' => $int('overlay_opacity', 0, 100),
            'height_desktop' => $int('height_desktop', 120, 900), 'height_mobile' => $int('height_mobile', 100, 700),
            'pad_desktop' => $int('pad_desktop', 0, 300), 'pad_mobile' => $int('pad_mobile', 0, 200),
            'align' => in_array($in['align'] ?? 'start', ['start', 'center', 'end'], true) ? ($in['align'] ?? 'start') : 'start',
            'text_color' => $color('text_color'),
            'show_breadcrumb' => array_key_exists('show_breadcrumb', $in) ? filter_var($in['show_breadcrumb'], FILTER_VALIDATE_BOOLEAN) : true,
            'eyebrow' => $langs('eyebrow'), 'title' => $langs('title'), 'subtitle' => $langs('subtitle'),
        ];
    }
}
