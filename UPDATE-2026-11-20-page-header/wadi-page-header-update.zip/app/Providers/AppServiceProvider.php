<?php

declare(strict_types=1);

namespace App\Providers;

use App\Models\SiteSetting;
use App\Packaging\Catalog\CatalogResolver;
use App\Packaging\Catalog\DatabasePackagingCatalog;
use App\Packaging\Catalog\ImageProbe;
use App\Packaging\Catalog\SnapshotValidator;
use App\Packaging\Catalog\SourceReader;
use App\Packaging\DevelopmentPackagingImages;
use App\Packaging\MediaAwarePackagingImages;
use App\Packaging\PackagingCatalog;
use App\Packaging\PackagingImages;
use App\Packaging\PublicPackagingImages;
use App\Services\Homepage\HomepageContext;
use App\Services\Homepage\HomepageMediaUsage;
use App\Services\Homepage\HomepageRepository;
use App\Services\Locales\Interface\OverridingLoader;
use App\Services\Media\MediaManager;
use App\Services\Media\SvgSanitizer;
use App\Services\Modules\TrustedKeys;
use App\Services\Navigation\NavigationService;
use App\Support\ResourceLimits;
use App\Support\Uploads\UploadLimits;
use Filament\Tables\Table;
use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->singleton(\App\Services\PageHeaders\PageHeaderService::class);
        $this->app->singleton(\App\Plugins\PluginRegistry::class);
        $this->app->singleton(\App\Plugins\PluginManager::class);

        if (is_string($public = config('app.public_path')) && $public !== '' && is_dir($public)) {
            $this->app->usePublicPath($public);
        }

        // Resolved fresh each time so the trusted-key set always reflects current config.
        $this->app->bind(TrustedKeys::class, fn () => TrustedKeys::fromConfig());

        // Administrator-edited interface texts sit on top of the lang files (which stay the defaults).
        $this->app->extend('translation.loader', fn ($loader) => new OverridingLoader($loader));

        // One instance per request: the published homepage is decoded once
        // per page view, and a preview's pinned draft never leaks into the
        // next request.
        $this->app->scoped(HomepageRepository::class);
        $this->app->scoped(HomepageContext::class);
        $this->app->scoped(HomepageMediaUsage::class);

        $this->app->singleton(SvgSanitizer::class);
        $this->app->singleton(MediaManager::class);

        // Packaging: the catalog is the published database tables (never the import file,
        // never a draft). Images are the verified public/packaging-assets files, with an
        // admin-uploaded MediaAsset taking precedence where one is configured.
        $this->app->singleton(ImageProbe::class, fn () => new ImageProbe(
            base_path('database/data/packaging/assets.manifest.json'),
            (string) (config('packaging.assets_root') ?: public_path('packaging-assets')),
        ));
        $this->app->bind(SourceReader::class, fn () => new SourceReader((string) config('packaging.import_source')));
        $this->app->bind(SnapshotValidator::class, fn ($app) => new SnapshotValidator(
            $app->make(ImageProbe::class),
            // Every text the approved pages need must exist before anything can be published.
            SnapshotValidator::REQUIRED_COPY_KEYS,
        ));
        $this->app->bind(CatalogResolver::class);
        $this->app->bind(PackagingCatalog::class, DatabasePackagingCatalog::class);
        // Local development with an extracted package keeps the comparison route; every
        // other environment (staging, production) serves public/packaging-assets directly.
        $this->app->singleton(PackagingImages::class,
            fn () => new MediaAwarePackagingImages(
                filled(config('packaging.dev_assets_path')) && ! $this->app->isProduction()
                    ? new DevelopmentPackagingImages(config('packaging.dev_assets_path'))
                    : new PublicPackagingImages((string) (config('packaging.assets_root') ?: public_path('packaging-assets'))),
            ));
    }

    public function boot(): void
    {
        // Plugin slots in the public layout: @pluginSlot('public.footer'). A plugin that is not active renders nothing.
        \Illuminate\Support\Facades\Blade::directive('pluginSlot', fn (string $name): string => "<?php echo app(\\App\\Plugins\\PluginRegistry::class)->render({$name}); ?>");
        $this->app->booted(fn () => $this->app->make(\App\Plugins\PluginManager::class)->bootActive());

        // Catch N+1 queries and mass-assignment mistakes during development;
        // never enabled in production, where a strict violation would turn a
        // cosmetic bug into a 500 for a visitor.
        Model::shouldBeStrict(! $this->app->isProduction());

        // Livewire ships a fixed 12 MB / 5 minute temporary-upload rule that silently overrides the forms' own limits.
        try {
            UploadLimits::applyToLivewire();
        } catch (\Throwable) {
            // no database yet (installer): Livewire keeps its defaults
        }

        Model::unguard(false);

        // The Products menu is generated from the published catalogue: any change to it rebuilds the menu cache.
        foreach ([\App\Models\Product::class, \App\Models\Variety::class, \App\Models\ProductForm::class, \App\Models\Category::class] as $catalogModel) {
            foreach (array_filter(['saved', 'deleted', $catalogModel === \App\Models\Product::class ? 'restored' : null]) as $event) {
                $catalogModel::{$event}(fn () => \App\Models\NavigationItem::flushCache());
            }
        }

        if ($this->app->isProduction()) {
            URL::forceScheme('https');
        }

        // Baseline locale for URL generation.
        //
        // SetLocale sets this per request, but it only runs on the public
        // route group. The admin panel, the console and — critically — error
        // rendering never pass through it, and the error views extend the
        // public layout. Without a default, `route('home')` inside the shared
        // header throws "Missing required parameter [locale]" while rendering
        // the error page, which replaces the real exception with a useless
        // one. SetLocale still overrides this per request.
        URL::defaults(['locale' => config('app.locale', 'en')]);

        $this->configureRateLimiting();
        $this->configureMailFromSettings();
        $this->shareLayoutData();
        $this->configureAdminTables();
    }

    /**
     * Global defaults for every admin table.
     *
     * Applied centrally rather than per-resource so a new resource cannot
     * accidentally ship without pagination. There is deliberately no "all"
     * page-size option: on a table with thousands of rows it is a guaranteed
     * memory kill within a 256 MB limit.
     */
    private function configureAdminTables(): void
    {
        Table::configureUsing(function (Table $table): void {
            $table
                ->paginated(ResourceLimits::paginationOptions())
                ->defaultPaginationPageOption(ResourceLimits::PAGINATION_DEFAULT)
                ->extremePaginationLinks()
                // Counting a very large table on every page render is itself
                // a cost; Filament can skip the total where it is not needed.
                ->deferLoading()
                ->persistFiltersInSession()
                ->persistSearchInSession();
        });
    }

    /**
     * The public layout needs the menus on every render. Composing them here
     * keeps controllers free of chrome concerns, and both lookups are cached.
     */
    private function shareLayoutData(): void
    {
        View::composer(['layouts.public', 'partials.*'], function ($view): void {
            $navigation = app(NavigationService::class);

            $view->with([
                'headerMenu' => $navigation->location('header'),
                'footerProducts' => $navigation->location('footer_products'),
                'footerCompany' => $navigation->location('footer_company'),
                'legalMenu' => $navigation->location('legal'),
            ]);
        });
    }

    /**
     * Throttles for the public forms, keyed by IP so one abusive visitor
     * cannot lock out the rest. The admin sign-in is throttled by
     * App\Support\Auth\LoginThrottle (per account + IP, and per account).
     */
    private function configureRateLimiting(): void
    {
        RateLimiter::for('rfq', fn (Request $request) => [
            Limit::perMinute((int) config('wadi.throttle.rfq', 5))->by($request->ip()),
            Limit::perDay(40)->by($request->ip()),
        ]);

        RateLimiter::for('contact', fn (Request $request) => [
            Limit::perMinute((int) config('wadi.throttle.contact', 5))->by($request->ip()),
            Limit::perDay(40)->by($request->ip()),
        ]);

    }

    /**
     * Lets the administrator configure SMTP from the control panel without
     * editing .env. Values in .env still win, so a broken setting in the
     * database can always be overridden on the server.
     */
    private function configureMailFromSettings(): void
    {
        // Web requests always; the console only for commands that send mail (a plain migrate on a fresh database must not touch settings).
        if ($this->app->runningInConsole() && ! $this->app->environment('testing')
            && ! preg_match('/^(rfq:|mail:|schedule:|queue:|plugins:|wadi:diagnose)/', (string) ($_SERVER['argv'][1] ?? ''))) {
            return;
        }

        \App\Services\Mail\EffectiveMail::apply();
    }
}
