<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BuilderNodeReview extends Model
{
    protected $fillable = ['builder_node_id', 'page_key', 'reason', 'status', 'resolved_at', 'resolved_by'];

    protected function casts(): array
    {
        return ['resolved_at' => 'datetime'];
    }
}
