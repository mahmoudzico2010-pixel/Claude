<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PageHeader extends Model
{
    protected $fillable = ['page_key', 'mode', 'settings', 'published_mode', 'published_settings', 'published_at', 'updated_by'];

    protected function casts(): array
    {
        return ['settings' => 'array', 'published_settings' => 'array', 'published_at' => 'datetime'];
    }

    public function hasUnpublishedChanges(): bool
    {
        return $this->mode !== ($this->published_mode ?? 'default')
            || json_encode($this->settings ?? []) !== json_encode($this->published_settings ?? []);
    }
}
