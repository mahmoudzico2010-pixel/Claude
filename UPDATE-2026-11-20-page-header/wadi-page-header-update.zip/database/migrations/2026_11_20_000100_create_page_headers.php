<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** Per-page banner settings. No row = the page keeps its current default banner. Additive. */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('page_headers', function (Blueprint $table): void {
            $table->id();
            $table->string('page_key', 120)->unique();                 // page:{slug} | category:{slug} | route:{name}
            $table->string('mode', 10)->default('default');            // DRAFT: default | custom | hidden
            $table->json('settings')->nullable();                      // DRAFT settings
            $table->string('published_mode', 10)->nullable();          // what visitors see
            $table->json('published_settings')->nullable();
            $table->timestamp('published_at')->nullable();
            $table->foreignId('updated_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('page_headers');
    }
};
