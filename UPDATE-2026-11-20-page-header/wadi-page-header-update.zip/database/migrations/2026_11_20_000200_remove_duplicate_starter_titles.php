<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * The earlier "Edit visually" starter draft added a heading repeating the page title; the banner now carries the title. Remove
 * ONLY such headings: in an unpublished page tree, a heading whose every translation equals the page's own title.
 */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('builder_nodes') || ! Schema::hasTable('builder_revisions')) {
            return;
        }
        $published = DB::table('builder_revisions')->where('kind', 'published')->pluck('page_key')->all();
        foreach (DB::table('builder_nodes')->where('page_key', 'like', 'page:%')->where('type', 'heading')->get() as $node) {
            if (in_array($node->page_key, $published, true)) {
                continue;
            }
            $page = DB::table('pages')->where('slug', substr($node->page_key, 5))->first();
            if (! $page) {
                continue;
            }
            $titles = DB::table('page_translations')->where('page_id', $page->id)->pluck('title', 'locale');
            $mine = DB::table('builder_node_translations')->where('builder_node_id', $node->id)->get();
            $same = $mine->isNotEmpty() && $mine->every(fn ($t) => (json_decode((string) $t->content, true)['text'] ?? null) === ($titles[$t->locale] ?? $titles['en'] ?? '\0'));
            if ($same) {
                DB::table('builder_node_translations')->where('builder_node_id', $node->id)->delete();
                DB::table('builder_nodes')->where('id', $node->id)->delete();
            }
        }
    }

    public function down(): void {}
};
