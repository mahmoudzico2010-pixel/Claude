<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * The earlier "Edit visually" starter draft added a heading repeating the page title; the banner now carries the title.
 *
 * This migration DELETES NOTHING. Text equal to the page title is not proof that nobody wrote the heading (a person can type exactly the
 * title), and the earlier release left no marker on the nodes it generated. So every unpublished heading whose text matches the page's own
 * title is only FLAGGED for review; the page builder then offers "Remove this heading" or "Keep it" to a person. Published trees are not
 * looked at. Reversible: down() drops only the flags table; every heading stays exactly as it was.
 */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('builder_node_reviews')) {
            Schema::create('builder_node_reviews', function (Blueprint $table): void {
                $table->id();
                $table->foreignId('builder_node_id')->unique()->constrained('builder_nodes')->cascadeOnDelete();
                $table->string('page_key', 120);
                $table->string('reason', 255);
                $table->string('status', 10)->default('open');         // open | removed | kept
                $table->timestamp('resolved_at')->nullable();
                $table->foreignId('resolved_by')->nullable()->constrained('users')->nullOnDelete();
                $table->timestamps();
            });
        }
        if (! Schema::hasTable('builder_nodes') || ! Schema::hasTable('builder_revisions')) {
            return;
        }

        $published = DB::table('builder_revisions')->where('kind', 'published')->pluck('page_key')->all();
        foreach (DB::table('builder_nodes')->where('page_key', 'like', 'page:%')->where('type', 'heading')->get() as $node) {
            if (in_array($node->page_key, $published, true) || DB::table('builder_node_reviews')->where('builder_node_id', $node->id)->exists()) {
                continue;
            }
            $page = DB::table('pages')->where('slug', substr($node->page_key, 5))->first();
            if (! $page) {
                continue;
            }
            $titles = DB::table('page_translations')->where('page_id', $page->id)->pluck('title', 'locale');
            $mine = DB::table('builder_node_translations')->where('builder_node_id', $node->id)->get();
            $sameAsTitle = $mine->isNotEmpty() && $mine->every(fn ($t) => (json_decode((string) $t->content, true)['text'] ?? null) === ($titles[$t->locale] ?? $titles['en'] ?? "\0"));
            if ($sameAsTitle) {
                DB::table('builder_node_reviews')->insert([
                    'builder_node_id' => $node->id, 'page_key' => $node->page_key, 'status' => 'open', 'created_at' => now(), 'updated_at' => now(),
                    'reason' => 'This heading repeats the page title, which the Page Header / Hero banner now shows. It may be an automatic starter heading or something you wrote — it was NOT removed.',
                ]);
            }
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('builder_node_reviews');     // headings themselves are never touched
    }
};
