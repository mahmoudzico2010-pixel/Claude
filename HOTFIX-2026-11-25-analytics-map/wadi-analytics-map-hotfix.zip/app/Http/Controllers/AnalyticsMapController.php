<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Services\Analytics\MapData;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

/**
 * The neutral world outline behind the Countries map. It is built from the shipped database/data/world-map.json, so it does not
 * depend on any file inside the public web folder (hosts differ in where that is, and some block /vendor/ URLs). Static geography:
 * no visitor data, cacheable. A failure here only means the outline is missing; the ranked table is always available.
 */
class AnalyticsMapController extends Controller
{
    public function base(Request $request): Response
    {
        $svg = MapData::baseSvg();
        $etag = '"wr-map-'.md5($svg).'"';
        $headers = ['Content-Type' => 'image/svg+xml; charset=utf-8', 'Cache-Control' => 'public, max-age=604800', 'ETag' => $etag, 'X-Content-Type-Options' => 'nosniff'];
        if ($svg === '') {
            return response('', 404, ['Cache-Control' => 'no-store']);
        }
        if ($request->headers->get('If-None-Match') === $etag) {
            return response('', 304, $headers);
        }

        return response($svg, 200, $headers);
    }
}
