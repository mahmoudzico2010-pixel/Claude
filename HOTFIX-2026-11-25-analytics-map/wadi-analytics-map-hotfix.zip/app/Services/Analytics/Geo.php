<?php

declare(strict_types=1);

namespace App\Services\Analytics;

use Illuminate\Http\Request;

/**
 * Approximate country of the CONNECTION (not nationality, company domicile or shipping destination).
 * Sources, in order: (1) a country header set by a proxy/CDN that this application already trusts (TRUSTED_PROXIES);
 * (2) an optional local MaxMind country database. Otherwise null = "Unknown". The IP is read transiently and never stored.
 */
final class Geo
{
    public static function country(Request $request): ?string
    {
        if ($request->isFromTrustedProxy()) {
            foreach (AnalyticsSettings::geoHeaders() as $header) {
                $v = strtoupper(trim((string) $request->headers->get($header)));
                if (preg_match('/^[A-Z]{2}$/', $v) === 1 && ! in_array($v, ['XX', 'T1', 'ZZ', 'A1', 'A2', 'EU', 'AP'], true)) {
                    return $v;
                }
            }
        }

        $db = storage_path('app/geoip/GeoLite2-Country.mmdb');
        if (class_exists(\MaxMind\Db\Reader::class) && is_file($db) && ($ip = $request->ip())) {
            try {
                $reader = new \MaxMind\Db\Reader($db);
                $rec = $reader->get($ip);
                $reader->close();
                $iso = strtoupper((string) ($rec['country']['iso_code'] ?? ''));
                if (preg_match('/^[A-Z]{2}$/', $iso) === 1) {
                    return $iso;
                }
            } catch (\Throwable) {
                // an unreadable database simply means Unknown
            }
        }

        return null;
    }

    /**
     * What the country lookup can see on THIS request, for the administrator's "Country source check". Reports presence and validity only:
     * never the IP address, and a client-sent header is reported but not used unless the request comes from a trusted proxy.
     *
     * @return array{trusted_configured: bool, from_trusted_proxy: bool, headers: array<string, string>, database_file: bool, database_reader: bool, result: ?string, verdict: string}
     */
    public static function diagnose(Request $request): array
    {
        $trusted = (array) config('wadi.proxies.trusted', []);
        $from = $request->isFromTrustedProxy();
        $headers = [];
        foreach (AnalyticsSettings::geoHeaders() as $h) {
            $v = strtoupper(trim((string) $request->headers->get($h)));
            $headers[$h] = $v === '' ? 'absent' : (preg_match('/^[A-Z]{2}$/', $v) === 1 ? 'present' : 'present, not a valid country code');
        }
        $file = is_file(storage_path('app/geoip/GeoLite2-Country.mmdb'));
        $reader = class_exists(\MaxMind\Db\Reader::class);
        $result = self::country($request);
        $verdict = match (true) {
            $result !== null => 'working',
            ! $trusted && ! ($file && $reader) => 'no_source',
            $trusted && ! $from => 'proxy_not_matched',
            $from && ! in_array('present', $headers, true) => 'header_missing',
            $file && ! $reader => 'reader_missing',
            default => 'unknown',
        };

        return ['trusted_configured' => $trusted !== [], 'from_trusted_proxy' => $from, 'headers' => $headers, 'database_file' => $file, 'database_reader' => $reader, 'result' => $result, 'verdict' => $verdict];
    }
}
