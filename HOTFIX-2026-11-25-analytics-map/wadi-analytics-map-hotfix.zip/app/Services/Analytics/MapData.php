<?php

declare(strict_types=1);

namespace App\Services\Analytics;

/** Local world-map outlines (CC BY 4.0, @svg-maps/world). Nothing is fetched from the network. */
final class MapData
{
    /** @return array<string, string> ISO-2 => SVG path */
    public static function paths(): array
    {
        static $p = null;

        return $p ??= (array) json_decode((string) @file_get_contents(database_path('data/world-map.json')), true);
    }

    /** The whole outline as one standalone SVG (all countries, neutral colour). Empty string if the data file is missing. */
    public static function baseSvg(): string
    {
        return \Illuminate\Support\Facades\Cache::remember('wr.analytics.world-base.v2', 86400, function (): string {
            $paths = self::paths();
            if ($paths === []) {
                return '';
            }
            $d = '';
            foreach ($paths as $path) {
                $d .= '<path d="'.preg_replace_callback('/-?\d+\.\d{2,}/', fn ($m) => rtrim(rtrim(number_format((float) $m[0], 1, '.', ''), '0'), '.'), (string) $path).'"/>';
            }

            return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1010 666" width="1010" height="666"><g fill="#e6e1d0" stroke="#ffffff" stroke-width=".4">'.$d.'</g></svg>';
        });
    }
}
