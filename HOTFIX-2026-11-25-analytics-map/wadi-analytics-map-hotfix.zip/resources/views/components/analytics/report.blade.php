@props(['report', 'rtl' => false, 'export' => false, 'wire' => null])
<section style="background:#fff;border:1px solid #e5e0cf;border-radius:.9rem;padding:1rem 1.1rem;min-width:0;max-width:100%;box-sizing:border-box" aria-labelledby="r-{{ $report['key'] }}" data-report-key="{{ $report['key'] }}">
    <div style="display:flex;justify-content:space-between;gap:.8rem;flex-wrap:wrap;align-items:baseline">
        <h3 id="r-{{ $report['key'] }}" style="font-weight:700;color:#14382a;font-size:1rem;margin:0">{{ $report['title'] }}</h3>
        @if ($export)<button type="button" wire:click="exportCsv('{{ $report['key'] }}')" style="font-size:.72rem;color:#14382a;border:1px solid #d9d2bd;border-radius:.4rem;padding:.15rem .5rem">⬇ CSV</button>@endif
    </div>
    @if ($report['denominator'])<p style="font-size:.74rem;color:#6b7280;margin:.3rem 0 .6rem">{{ $report['denominator'] }}</p>@endif
    <x-analytics.chart :report="$report" :rtl="$rtl"/>
    <details open style="margin-top:.7rem"><summary style="font-size:.78rem;color:#14382a;cursor:pointer">{{ __('analytics.ui.the_table') }}</summary><x-analytics.table :report="$report"/></details>
    @if ($report['note'])<p style="font-size:.74rem;color:#6b7280;margin:.5rem 0 0">{{ $report['note'] }}</p>@endif
</section>
