<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Filament\Pages\Analytics\AnalyticsAudience;
use App\Filament\Pages\Analytics\TrackingSettings;
use App\Models\User;
use App\Services\Analytics\Geo;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Livewire\Livewire;
use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;

final class AnalyticsMapHotfixTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
    }

    private function admin(): User
    {
        $u = User::factory()->create(['is_active' => true]);
        $u->assignRole(User::ROLE_ADMIN);
        $this->actingAs($u->fresh());

        return $u;
    }

    #[Test]
    public function the_map_outline_is_served_by_the_application_without_any_public_file(): void
    {
        $r = $this->get('/_wr/world-map.svg')->assertOk()->assertHeader('Content-Type', 'image/svg+xml; charset=utf-8');
        $svg = (string) $r->getContent();
        $this->assertStringStartsWith('<svg', $svg);
        $this->assertGreaterThan(150, substr_count($svg, '<path'));
        $this->assertStringContainsString('viewBox="0 0 1010 666"', $svg);
        $this->assertNotEmpty($r->headers->get('ETag'));
        $this->get('/_wr/world-map.svg', ['If-None-Match' => $r->headers->get('ETag')])->assertStatus(304);
    }

    #[Test]
    public function the_countries_report_points_at_the_relative_map_route_and_shows_a_neutral_map_with_an_empty_state(): void
    {
        $this->admin();
        $at = now()->utc()->format('Y-m-d H:i:s');
        DB::table('analytics_sessions')->insert(['session_uid' => bin2hex(random_bytes(16)), 'started_at' => $at, 'last_seen_at' => $at, 'local_day' => \App\Services\Analytics\AnalyticsSettings::localDay(\Carbon\CarbonImmutable::now('UTC')), 'country' => null, 'locale' => 'en', 'browser_lang' => 'en', 'device' => 'desktop', 'browser' => 'Chrome', 'os' => 'Windows', 'source_type' => 'direct', 'landing_page' => 'route:home', 'pageviews' => 0, 'product_views' => 0, 'rfq_clicks' => 0, 'rfq_starts' => 0, 'rfq_submits' => 0]);
        $html = Livewire::test(AnalyticsAudience::class)->html();
        $this->assertStringContainsString('href="/_wr/world-map.svg"', $html);
        $this->assertStringNotContainsString('vendor/world-map', $html);
        $this->assertStringContainsString('data-testid="map-empty"', $html);
    }

    #[Test]
    public function the_country_source_check_explains_a_missing_setup_and_never_trusts_a_client_header(): void
    {
        config(['wadi.proxies.trusted' => []]);
        $req = Request::create('/', 'GET', [], [], [], ['REMOTE_ADDR' => '203.0.113.9', 'HTTP_CF_IPCOUNTRY' => 'ES']);
        $d = Geo::diagnose($req);
        $this->assertNull($d['result']);                    // a header sent by the client itself is ignored
        $this->assertFalse($d['from_trusted_proxy']);
        $this->assertSame('no_source', $d['verdict']);
        $this->assertSame('present', $d['headers']['CF-IPCountry']);

        $this->admin();
        Livewire::test(TrackingSettings::class)->assertSee(__('analytics.set.geo_verdict.no_source'), false);
    }

    #[Test]
    public function a_header_from_a_listed_proxy_is_accepted_and_reported(): void
    {
        config(['wadi.proxies.trusted' => ['203.0.113.9']]);
        $req = Request::create('/', 'GET', [], [], [], ['REMOTE_ADDR' => '203.0.113.9', 'HTTP_CF_IPCOUNTRY' => 'es']);
        Request::setTrustedProxies(['203.0.113.9'], Request::HEADER_X_FORWARDED_FOR);
        $d = Geo::diagnose($req);
        $this->assertSame('ES', $d['result']);
        $this->assertSame('working', $d['verdict']);
    }
}
