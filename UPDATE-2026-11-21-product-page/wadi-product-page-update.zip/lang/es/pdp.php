<?php

return [
    'overview' => 'Descripción general',
    'highlights' => 'De un vistazo',
    'packaging_title' => 'Opciones de envase disponibles',
    'packaging_linked' => 'Disponible para este producto',
    'packaging_general_note' => 'Estos son los formatos de envase que ofrecemos. Confirme cuál encaja con este producto al solicitar presupuesto.',
    'packaging_preview' => 'Ilustración del tipo de envase: el envase real puede variar',
    'packaging_all' => 'Ver todos los envases',
    'packaging_jump' => 'Opciones de envase',
    'other_cuts' => 'Otros cortes y estilos',
    'quote_title' => '¿Listo para pedir %s?',
    'quote_text' => 'Indíquenos cantidad, envase y destino y le responderemos con disponibilidad y presupuesto.',
    'gallery_hint' => 'Pase el cursor sobre la foto para ampliarla',
    'drained_whole' => 'Peso escurrido · Entero',
    'drained_pitted_sliced' => 'Peso escurrido · Deshuesado / en rodajas',
    'on_request' => 'Bajo consulta',
    'unit_g' => 'g',
    'unit_kg' => 'kg',
    'gross_weight' => 'Peso bruto',
];
