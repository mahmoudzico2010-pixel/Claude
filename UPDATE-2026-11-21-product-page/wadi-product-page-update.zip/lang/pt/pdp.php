<?php

return [
    'overview' => 'Visão geral',
    'highlights' => 'Em resumo',
    'packaging_title' => 'Embalagens disponíveis',
    'packaging_linked' => 'Disponível para este produto',
    'packaging_general_note' => 'Estes são os formatos de embalagem que oferecemos. Confirme qual serve este produto ao pedir orçamento.',
    'packaging_preview' => 'Ilustração do tipo de embalagem — a embalagem real pode diferir',
    'packaging_all' => 'Ver todas as embalagens',
    'packaging_jump' => 'Embalagens',
    'other_cuts' => 'Outros cortes e estilos',
    'quote_title' => 'Pronto para encomendar %s?',
    'quote_text' => 'Indique a quantidade, a embalagem e o destino e responderemos com disponibilidade e orçamento.',
    'gallery_hint' => 'Passe o cursor sobre a foto para ampliar',
];
