<?php

return [
    'overview' => 'Présentation',
    'highlights' => 'En un coup d’œil',
    'packaging_title' => 'Conditionnements disponibles',
    'packaging_linked' => 'Disponible pour ce produit',
    'packaging_general_note' => 'Voici les formats de conditionnement que nous proposons. Confirmez celui qui convient à ce produit en demandant un devis.',
    'packaging_preview' => 'Illustration du type de conditionnement — l’emballage réel peut différer',
    'packaging_all' => 'Voir tous les conditionnements',
    'packaging_jump' => 'Conditionnements',
    'other_cuts' => 'Autres coupes et styles',
    'quote_title' => 'Prêt à commander %s ?',
    'quote_text' => 'Indiquez la quantité, le conditionnement et la destination ; nous répondons avec la disponibilité et un devis.',
    'gallery_hint' => 'Survolez la photo pour l’agrandir',
    'drained_whole' => 'Poids égoutté · Entier',
    'drained_pitted_sliced' => 'Poids égoutté · Dénoyauté / en rondelles',
    'on_request' => 'Sur demande',
    'unit_g' => 'g',
    'unit_kg' => 'kg',
    'gross_weight' => 'Poids brut',
    'weights_table' => 'Tableau des poids par conditionnement',
];
