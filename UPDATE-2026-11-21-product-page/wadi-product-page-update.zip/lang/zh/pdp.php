<?php

return [
    'overview' => '概览',
    'highlights' => '要点一览',
    'packaging_title' => '可选包装',
    'packaging_linked' => '适用于此产品',
    'packaging_general_note' => '以下是我们提供的包装规格。询价时请确认哪种适合此产品。',
    'packaging_preview' => '包装类型示意图——实际包装可能不同',
    'packaging_all' => '查看全部包装',
    'packaging_jump' => '包装选项',
    'other_cuts' => '其他切法与款式',
    'quote_title' => '准备订购%s了吗？',
    'quote_text' => '告诉我们数量、包装和目的地，我们将回复供货情况和报价。',
    'gallery_hint' => '将鼠标移到照片上可放大',
];
