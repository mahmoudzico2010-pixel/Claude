<?php

return [
    'overview' => 'Panoramica',
    'highlights' => 'In sintesi',
    'packaging_title' => 'Confezioni disponibili',
    'packaging_linked' => 'Disponibile per questo prodotto',
    'packaging_general_note' => 'Questi sono i formati di confezione che offriamo. Confermi quale è adatto a questo prodotto quando richiede un preventivo.',
    'packaging_preview' => 'Illustrazione del tipo di confezione: la confezione reale può differire',
    'packaging_all' => 'Vedi tutte le confezioni',
    'packaging_jump' => 'Confezioni',
    'other_cuts' => 'Altri tagli e stili',
    'quote_title' => 'Pronto a ordinare %s?',
    'quote_text' => 'Indicaci quantità, confezione e destinazione e le risponderemo con disponibilità e preventivo.',
    'gallery_hint' => 'Passa il cursore sulla foto per ingrandirla',
    'drained_whole' => 'Peso sgocciolato · Intero',
    'drained_pitted_sliced' => 'Peso sgocciolato · Denocciolato / a rondelle',
    'on_request' => 'Su richiesta',
    'unit_g' => 'g',
    'unit_kg' => 'kg',
    'gross_weight' => 'Peso lordo',
    'weights_table' => 'Tabella dei pesi per confezione',
];
