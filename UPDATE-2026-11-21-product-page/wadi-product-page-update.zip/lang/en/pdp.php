<?php

return [
    'overview' => 'Overview',
    'highlights' => 'At a glance',
    'packaging_title' => 'Available packaging options',
    'packaging_linked' => 'Available for this product',
    'packaging_general_note' => 'These are the pack formats we offer. Confirm which one suits this product when you request a quote.',
    'packaging_preview' => 'Illustration of the pack type — the actual pack may differ',
    'packaging_all' => 'See all packaging',
    'packaging_jump' => 'Packaging options',
    'other_cuts' => 'Other cuts and styles',
    'quote_title' => 'Ready to order %s?',
    'quote_text' => 'Tell us the quantity, packaging and destination and we will reply with availability and a quote.',
    'gallery_hint' => 'Hover the photo to magnify',
    'drained_whole' => 'Drained weight · Whole',
    'drained_pitted_sliced' => 'Drained weight · Pitted / sliced',
    'on_request' => 'On request',
    'unit_g' => 'g',
    'unit_kg' => 'kg',
    'gross_weight' => 'Gross weight',
    'weights_table' => 'Packaging weights table',
];
