{{-- Schematic preview of a pack type (jar, tin, pail, drum, pouch, box, bottle) for packs without a photograph. Scale follows the real size family. --}}
@props(['kind' => 'other', 'scale' => 0.5])
@php($h = (int) round(70 + $scale * 60))
<svg viewBox="0 0 120 140" width="{{ (int) round($h * 0.86) }}" height="{{ $h }}" role="img" aria-hidden="true" focusable="false">
    <defs>
        <linearGradient id="pk-body-{{ $kind }}" x1="0" x2="1"><stop offset="0" stop-color="#cfe3d3"/><stop offset=".45" stop-color="#f4faf5"/><stop offset="1" stop-color="#b9d2be"/></linearGradient>
        <linearGradient id="pk-lid-{{ $kind }}" x1="0" x2="1"><stop offset="0" stop-color="#b8903a"/><stop offset=".5" stop-color="#f0d98c"/><stop offset="1" stop-color="#9a7628"/></linearGradient>
    </defs>
    @switch($kind)
        @case('glass_jar')
        @case('pet_jar')
            <rect x="30" y="14" width="60" height="16" rx="4" fill="url(#pk-lid-{{ $kind }})"/>
            <path d="M34 30h52c6 0 10 5 10 11v78c0 8-6 14-14 14H38c-8 0-14-6-14-14V41c0-6 4-11 10-11Z" fill="url(#pk-body-{{ $kind }})" stroke="#8fb09a" stroke-width="2"/>
            <rect x="34" y="58" width="52" height="40" rx="6" fill="#fff" opacity=".7"/>
            @break
        @case('tin')
            <ellipse cx="60" cy="30" rx="38" ry="9" fill="url(#pk-lid-{{ $kind }})"/>
            <path d="M22 30v86c0 5 17 10 38 10s38-5 38-10V30c0 5-17 9-38 9s-38-4-38-9Z" fill="url(#pk-body-{{ $kind }})" stroke="#8fb09a" stroke-width="2"/>
            <rect x="24" y="62" width="72" height="34" fill="#fff" opacity=".7"/>
            @break
        @case('plastic_pail')
            <path d="M22 36q38-32 76 0" fill="none" stroke="#7d8f86" stroke-width="3"/>
            <rect x="20" y="34" width="80" height="12" rx="4" fill="url(#pk-lid-{{ $kind }})"/>
            <path d="M24 46h72l-8 78c-1 6-14 10-28 10s-27-4-28-10Z" fill="url(#pk-body-{{ $kind }})" stroke="#8fb09a" stroke-width="2"/>
            @break
        @case('drum')
            <ellipse cx="60" cy="26" rx="40" ry="10" fill="url(#pk-lid-{{ $kind }})"/>
            <path d="M20 26v92c0 6 18 12 40 12s40-6 40-12V26c0 6-18 12-40 12S20 32 20 26Z" fill="url(#pk-body-{{ $kind }})" stroke="#8fb09a" stroke-width="2"/>
            <path d="M20 62c0 6 18 12 40 12s40-6 40-12M20 94c0 6 18 12 40 12s40-6 40-12" fill="none" stroke="#8fb09a" stroke-width="2"/>
            @break
        @case('pouch')
            <path d="M28 18h64l6 14v86c0 6-5 12-12 12H34c-7 0-12-6-12-12V32Z" fill="url(#pk-body-{{ $kind }})" stroke="#8fb09a" stroke-width="2"/>
            <rect x="28" y="18" width="64" height="9" fill="url(#pk-lid-{{ $kind }})"/>
            <rect x="36" y="56" width="48" height="36" rx="6" fill="#fff" opacity=".7"/>
            @break
        @case('bag_in_box')
            <path d="M20 40l20-12h60v90l-20 12H20Z" fill="url(#pk-body-{{ $kind }})" stroke="#8fb09a" stroke-width="2"/>
            <path d="M20 40h60v90M80 40l20-12" fill="none" stroke="#8fb09a" stroke-width="2"/>
            <circle cx="62" cy="112" r="6" fill="url(#pk-lid-{{ $kind }})"/>
            @break
        @case('bottle')
            <rect x="48" y="8" width="24" height="14" rx="3" fill="url(#pk-lid-{{ $kind }})"/>
            <path d="M50 22h20v16c0 8 14 12 14 28v52c0 8-6 14-14 14H50c-8 0-14-6-14-14V66c0-16 14-20 14-28Z" fill="url(#pk-body-{{ $kind }})" stroke="#8fb09a" stroke-width="2"/>
            <rect x="42" y="78" width="36" height="34" rx="5" fill="#fff" opacity=".7"/>
            @break
        @default
            <rect x="24" y="30" width="72" height="96" rx="8" fill="url(#pk-body-{{ $kind }})" stroke="#8fb09a" stroke-width="2"/>
            <rect x="24" y="30" width="72" height="14" rx="6" fill="url(#pk-lid-{{ $kind }})"/>
    @endswitch
</svg>
