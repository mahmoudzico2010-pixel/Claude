@extends('layouts.public')

@php
    $frameData = \App\Support\ProductFrames::for($product);
    $gallery = $product->galleryImages();
    $specs = $product->publicSpecifications();
@endphp

@section('content')
    <div class="border-b border-line bg-surface-alt">
        <div class="container-wr py-5">
            <x-breadcrumbs :items="$seo->breadcrumbs" />
        </div>
    </div>

    <section class="pdp py-10 lg:py-14">
        <div class="container-wr">
            <div class="pdp-hero">

@push('head')
<style>
    .pdp{position:relative;isolation:isolate;overflow:hidden;background:linear-gradient(160deg,#f6f3e8 0%,#e9f0e6 48%,#dde9dd 100%)}
    .pdp::before,.pdp::after{content:"";position:absolute;z-index:-1;border-radius:50%;filter:blur(70px);pointer-events:none}
    .pdp::before{width:34rem;height:34rem;inset-block-start:-8rem;inset-inline-start:-10rem;background:radial-gradient(circle,rgba(79,134,96,.38),rgba(79,134,96,0) 70%)}
    .pdp::after{width:30rem;height:30rem;inset-block-end:6rem;inset-inline-end:-8rem;background:radial-gradient(circle,rgba(201,162,74,.34),rgba(201,162,74,0) 70%)}
    .pdp-glass{background:rgba(255,255,255,.58);-webkit-backdrop-filter:blur(18px) saturate(150%);backdrop-filter:blur(18px) saturate(150%);border:1px solid rgba(255,255,255,.72);border-radius:26px;box-shadow:0 14px 44px rgba(20,60,45,.11),inset 0 1px 0 rgba(255,255,255,.85)}
    @supports not ((backdrop-filter:blur(1px)) or (-webkit-backdrop-filter:blur(1px))){.pdp-glass{background:rgba(255,255,255,.93)}}
    @media (prefers-reduced-transparency:reduce){.pdp-glass{background:#fff;-webkit-backdrop-filter:none;backdrop-filter:none}}
    .pdp-pad{padding:clamp(1.25rem,2.4vw,2.25rem)}
    .pdp-eyebrow{display:inline-flex;align-items:center;gap:.6rem;font-size:.75rem;letter-spacing:.14em;text-transform:uppercase;font-weight:600;color:#4b6b3a}
    .pdp-eyebrow::before{content:"";width:2rem;height:1px;background:#b8903a}
    .pdp-title{font-size:clamp(1.9rem,3.6vw,3rem);line-height:1.12;font-weight:700;color:#14281f;text-wrap:balance;margin-top:.9rem}
    .pdp-lead{margin-top:1.1rem;font-size:1.1rem;line-height:1.7;color:#43544b}
    .pdp-h2{font-size:1.45rem;font-weight:700;color:#14281f;display:flex;align-items:center;gap:.75rem}
    .pdp-h2::after{content:"";flex:1;height:1px;background:linear-gradient(90deg,rgba(184,144,58,.7),rgba(184,144,58,0))}
    [dir=rtl] .pdp-h2::after{background:linear-gradient(270deg,rgba(184,144,58,.7),rgba(184,144,58,0))}
    .pdp-chips{display:flex;flex-wrap:wrap;gap:.5rem;margin-top:1.4rem}
    .pdp-chip{display:inline-flex;flex-direction:column;gap:.1rem;padding:.55rem .95rem;border-radius:16px;background:rgba(255,255,255,.65);border:1px solid rgba(255,255,255,.85);box-shadow:0 2px 10px rgba(20,60,45,.06)}
    .pdp-chip small{font-size:.68rem;letter-spacing:.08em;text-transform:uppercase;color:#7a8a80}
    .pdp-chip span{font-weight:600;color:#14281f;font-size:.95rem}
    .pdp-actions{display:flex;flex-wrap:wrap;gap:.75rem;margin-top:1.6rem}
    .pdp-btn{display:inline-flex;align-items:center;gap:.5rem;padding:.8rem 1.4rem;border-radius:999px;font-weight:600;font-size:.95rem;transition:transform .2s,box-shadow .2s}
    .pdp-btn-primary{background:linear-gradient(135deg,#1f5a43,#14382a);color:#fff;box-shadow:0 8px 22px rgba(20,56,42,.32)}
    .pdp-btn-glass{background:rgba(255,255,255,.7);color:#14382a;border:1px solid rgba(20,56,42,.18)}
    .pdp-btn:hover{transform:translateY(-2px)}
    .pdp-cuts{display:flex;flex-wrap:wrap;gap:.6rem;margin-top:1rem}
    .pdp-cut{display:flex;align-items:center;gap:.6rem;padding:.4rem .9rem .4rem .45rem;border-radius:999px;background:rgba(255,255,255,.7);border:1px solid rgba(255,255,255,.9);color:#14382a;font-weight:500;font-size:.9rem}
    .pdp-cut img{width:2.1rem;height:2.1rem;border-radius:50%;object-fit:cover;background:#fff}
    .pdp-grid-2{display:grid;gap:1.5rem;align-items:start}
    @media (min-width:1024px){.pdp-grid-2{grid-template-columns:1.25fr 1fr}.pdp-grid-2.is-single{grid-template-columns:1fr}.pdp-hero{grid-template-columns:1fr 1fr;gap:2.5rem}}
    .pdp-hero{display:grid;gap:1.75rem;align-items:start}
    .pdp-prose p{margin:0 0 1rem;line-height:1.8;color:#3b4b43}
    .pdp-prose p:last-child{margin-bottom:0}
    .pdp-spec{display:grid;grid-template-columns:minmax(7rem,.8fr) 1.4fr;gap:.25rem 1rem;padding:.8rem 0;border-bottom:1px solid rgba(20,56,42,.1)}
    .pdp-spec:last-child{border-bottom:0}
    .pdp-spec dt{font-size:.72rem;letter-spacing:.08em;text-transform:uppercase;color:#7a8a80;align-self:center}
    .pdp-spec dd{margin:0;font-weight:600;color:#14281f}
    .pdp-packs{display:grid;gap:1.1rem;grid-template-columns:repeat(auto-fill,minmax(17rem,1fr));margin-top:1.4rem}
    .pdp-pack{position:relative;display:flex;flex-direction:column;border-radius:22px;background:rgba(255,255,255,.62);border:1px solid rgba(255,255,255,.85);overflow:hidden;transition:transform .25s,box-shadow .25s}
    .pdp-pack:hover{transform:translateY(-4px);box-shadow:0 16px 36px rgba(20,60,45,.15)}
    .pdp-pack-art{display:flex;align-items:flex-end;justify-content:center;min-height:11.5rem;padding:1.2rem 1rem .6rem;background:radial-gradient(120% 90% at 50% 100%,rgba(79,134,96,.2),rgba(255,255,255,0) 70%),linear-gradient(180deg,rgba(255,255,255,.7),rgba(233,240,230,.5))}
    .pdp-pack-art img{max-height:10rem;width:auto;object-fit:contain}
    .pdp-pack-body{padding:1rem 1.2rem 1.25rem;display:flex;flex-direction:column;gap:.5rem}
    .pdp-pack-name{font-weight:700;color:#14281f;font-size:1.02rem}
    .pdp-pack-badge{position:absolute;inset-block-start:.8rem;inset-inline-start:.8rem;font-size:.68rem;font-weight:700;letter-spacing:.05em;padding:.25rem .65rem;border-radius:999px;background:rgba(31,90,67,.92);color:#fff}
    .pdp-wt-wrap{margin-top:1.6rem;overflow-x:auto;border-radius:18px;background:rgba(255,255,255,.6);border:1px solid rgba(255,255,255,.85)}
    .pdp-wt{width:100%;min-width:42rem;border-collapse:collapse;font-size:.9rem}
    .pdp-wt thead th{font-size:.7rem;letter-spacing:.06em;text-transform:uppercase;color:#6a7a71;font-weight:600;text-align:start;padding:.9rem 1rem;background:rgba(31,90,67,.07)}
    .pdp-wt tbody th{font-weight:700;text-align:start;color:#14281f;padding:.8rem 1rem;border-top:1px solid rgba(20,56,42,.1)}
    .pdp-wt td{font-weight:600;color:#14281f;text-align:start;padding:.8rem 1rem;border-top:1px solid rgba(20,56,42,.1);white-space:nowrap}
    .pdp-wt tbody tr:hover{background:rgba(255,255,255,.55)}
    .pdp-note{font-size:.8rem;color:#6a7a71;margin-top:1rem}
    .pdp-quote{display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:1.25rem;background:linear-gradient(135deg,rgba(20,56,42,.92),rgba(31,90,67,.86));color:#fff;border-color:rgba(255,255,255,.18)}
    .pdp-quote h2{font-size:1.5rem;font-weight:700}
    .pdp-quote p{margin-top:.4rem;color:rgba(255,255,255,.82);max-width:36rem}
    .pdp-quote .pdp-btn-primary{background:linear-gradient(135deg,#d8b45c,#b8903a);color:#1b2a22;box-shadow:0 8px 22px rgba(0,0,0,.25)}
    .pdp-stack>*+*{margin-top:1.75rem}
    .pdp-gallery{padding:clamp(.6rem,1.4vw,1rem)}
</style>
@endpush

                <div class="pdp-glass pdp-gallery">
                {{-- Gallery --}}
                <div x-data="productGallery({{ Js::from($gallery->map(fn ($m) => [
                    'url' => $m->urlFor(1280),
                    'srcset' => $m->srcset(),
                    'alt' => $m->alt(),
                    'thumb' => $m->urlFor(200),
                ])->values()) }})">
                    @if ($gallery->isNotEmpty())
                        {{-- Shared media frame, square. `contain` rather than
                             `cover`: this is the customer's closest look at the
                             product, and cropping a jar's lid off here is the
                             worst place on the site to do it.

                             The hover treatment here is a real magnifier, not
                             the `media-frame-zoom` scale the catalogue cards
                             use. Scaling the displayed image by a few per cent
                             makes it bigger and reveals nothing — the pixels on
                             screen are the same pixels. The layer below paints
                             a genuinely larger source and pans it with the
                             cursor, so a customer can read a label.

                             The frame clips, so the enlargement never reaches
                             the title, the thumbnails or anything beside them,
                             and no layout moves. --}}
                        <div class="media-frame {{ $frameData ? '' : 'media-frame-1-1' }} media-frame-magnify {{ $frameData ? 'bg-white' : 'border border-line' }}" @if ($frameData) style="--media-frame-ratio: {{ $frameData['ratio'] }}" @endif data-framed="{{ $frameData ? '1' : '0' }}"
                             x-on:mouseenter="enter($event)"
                             x-on:mousemove="move($event)"
                             x-on:mouseleave="leave()">

                            <template x-if="current">
                                <img :src="current.url"
                                     :srcset="current.srcset"
                                     :alt="current.alt"
                                     sizes="(min-width: 1024px) 40rem, 92vw"
                                     @if ($frameData) style="object-fit: {{ $frameData['fit'] }}; padding: {{ $frameData['padding'] }}%; box-sizing: border-box" @endif
                                     fetchpriority="high" decoding="async">
                            </template>

                            @if ($frameData)
                                {{-- The decorative frame sits above the photo and the magnifier, never intercepts clicks, and leaves the
                                     "view larger" button (z-10), swipe and thumbnails working. Originals and the lightbox are untouched. --}}
                                <img src="{{ $frameData['url'] }}" alt="" aria-hidden="true" class="wr-frame-overlay"
                                     style="position:absolute;inset:0;width:100%;height:100%;object-fit:fill;pointer-events:none;z-index:5;padding:0">
                            @endif

                            {{-- encodeURI on a path we generated ourselves: the
                                 value lands in a style attribute, and url() is
                                 the one place a stray quote would matter.

                                 The style is bound as an OBJECT on purpose. A
                                 string binding replaces the whole style
                                 attribute, which erases the `display:none` that
                                 x-show applies — after a thumbnail change the
                                 white layer would then sit over the product
                                 until the next hover. --}}
                            <div class="media-zoom-layer"
                                 x-show="zooming"
                                 x-cloak
                                 :style="{ backgroundImage: `url('${encodeURI(zoomSource)}')`,
                                           backgroundSize: backgroundSize,
                                           backgroundPosition: backgroundPosition }"
                                 aria-hidden="true"></div>

                            {{-- Touch and keyboard reach the same detail here.
                                 A magnifier that only answers to a moving mouse
                                 leaves everyone else unable to look closely. --}}
                            <button type="button"
                                    x-on:click.stop="openLightbox()"
                                    x-show="! zooming"
                                    class="absolute bottom-3 end-3 z-10 inline-flex items-center gap-1.5 rounded-badge
                                           bg-surface/90 px-2.5 py-1.5 text-xs font-medium text-ink shadow-card
                                           backdrop-blur-sm transition-colors hover:bg-surface
                                           focus-visible:outline focus-visible:outline-2 focus-visible:outline-olive-deep">
                                <svg class="size-3.5" viewBox="0 0 20 20" fill="none" stroke="currentColor"
                                     stroke-width="1.7" aria-hidden="true">
                                    <circle cx="9" cy="9" r="6"/>
                                    <path d="M13.5 13.5 17 17M9 6.5v5M6.5 9h5" stroke-linecap="round"/>
                                </svg>
                                {{ __('site.products.view_larger') }}
                            </button>
                        </div>

                        @if ($gallery->count() > 1)
                            <ul class="mt-4 grid grid-cols-5 gap-3" role="list" aria-label="{{ __('site.products.gallery') }}">
                                @foreach ($gallery as $index => $image)
                                    <li>
                                        <button type="button"
                                                @click="select({{ $index }})"
                                                :class="active === {{ $index }} ? 'border-olive-deep' : 'border-line hover:border-line-strong'"
                                                class="media-frame media-frame-1-1 block w-full border transition-colors">
                                            <img src="{{ $image->urlFor(200) }}"
                                                 alt="{{ $image->alt() }}"
                                                 loading="lazy" decoding="async">
                                        </button>
                                    </li>
                                @endforeach
                            </ul>
                        @endif
                    @else
                        <div class="flex aspect-square items-center justify-center border border-line bg-surface-sunken text-ink-subtle/40">
                            <svg class="size-16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" aria-hidden="true">
                                <path d="M3 6h18v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6ZM8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
                            </svg>
                        </div>
                    @endif

                    {{-- Full-screen view.

                         This is how a phone gets to the detail a mouse gets
                         from the magnifier: the browser's own pinch-to-zoom on
                         a full-resolution image, which is more capable and more
                         familiar than anything worth reimplementing. It is also
                         the keyboard route — the button above opens it and
                         Escape closes it.

                         `touch-action: pinch-zoom` is what permits the gesture
                         inside an element the page would otherwise treat as
                         scrollable. --}}
                    <div x-show="lightbox"
                         x-cloak
                         x-on:keydown.escape.window="closeLightbox()"
                         x-transition:enter="transition-opacity duration-200"
                         x-transition:enter-start="opacity-0"
                         x-transition:leave="transition-opacity duration-150"
                         x-transition:leave-end="opacity-0"
                         class="fixed inset-0 z-[var(--z-modal)] flex items-center justify-center bg-charcoal/90 p-4"
                         role="dialog"
                         aria-modal="true"
                         :aria-label="current?.alt">

                        <div class="absolute inset-0" x-on:click="closeLightbox()" aria-hidden="true"></div>

                        <div class="relative flex size-full max-w-6xl flex-col" x-trap.noscroll="lightbox">
                            <div class="flex flex-none justify-end pb-3">
                                <button type="button"
                                        x-on:click="closeLightbox()"
                                        class="rounded-sm p-2 text-white/80 transition-colors hover:text-white
                                               focus-visible:outline focus-visible:outline-2 focus-visible:outline-white"
                                        aria-label="{{ __('site.close') }}">
                                    <svg class="size-6" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                         stroke-width="1.8" aria-hidden="true">
                                        <path d="m6 6 12 12M18 6 6 18" stroke-linecap="round"/>
                                    </svg>
                                </button>
                            </div>

                            <div class="min-h-0 flex-1 overflow-auto" style="touch-action: pinch-zoom;">
                                <template x-if="lightbox && current">
                                    <img :src="zoomSource"
                                         :alt="current.alt"
                                         class="mx-auto h-auto w-auto max-w-none"
                                         decoding="async">
                                </template>
                            </div>

                            <p class="flex-none pt-3 text-center text-xs text-white/60">
                                {{ __('site.products.zoom_hint') }}
                            </p>
                        </div>
                    </div>
                </div>
                </div>

                {{-- Summary --}}
                <div class="pdp-glass pdp-pad">
                    @if ($product->category)
                        <p class="pdp-eyebrow">{{ $product->category->t('name') }}</p>
                    @endif
                    <h1 class="pdp-title">{{ $product->name() }}</h1>
                    @if ($product->t('short_description'))
                        <p class="pdp-lead">{{ $product->t('short_description') }}</p>
                    @endif

                    @php $facts = $product->keyFacts(); @endphp
                    @if ($facts)
                        <ul class="pdp-chips" role="list" aria-label="{{ __('pdp.highlights') }}">
                            @foreach ($facts as $key => $value)
                                <li class="pdp-chip"><small>{{ __($key === 'processing' ? 'catalog.spec.processing' : 'product.spec.'.$key) }}</small><span>{{ $value }}</span></li>
                            @endforeach
                        </ul>
                    @endif

                    <div class="pdp-actions">
                        <a href="{{ route('quote.create', ['product' => $product->id]) }}" class="pdp-btn pdp-btn-primary">{{ __('site.cta.request_quote') }}</a>
                        @if ($product->specSheet)
                            <a href="{{ route('products.spec-sheet', ['product' => $product->slug]) }}" class="pdp-btn pdp-btn-glass">{{ __('site.cta.download_spec') }}</a>
                        @endif
                        <a href="#packaging" class="pdp-btn pdp-btn-glass">{{ __('pdp.packaging_jump') }}</a>
                    </div>

                    @if ($siblings->isNotEmpty())
                        <h2 class="pdp-h2" style="margin-top:2rem;font-size:1.05rem">{{ __('pdp.other_cuts') }}</h2>
                        <ul class="pdp-cuts" role="list">
                            @foreach ($siblings as $sib)
                                <li><a class="pdp-cut" href="{{ route('products.show', ['product' => $sib->slug]) }}">
                                    @if ($sib->primaryImage)<img src="{{ $sib->primaryImage->urlFor(120) }}" alt="" loading="lazy" decoding="async">@endif
                                    {{ $sib->form?->localized('name') ?: $sib->name() }}</a></li>
                            @endforeach
                        </ul>
                    @endif
                </div>
            </div>

            <div class="pdp-stack" style="margin-top:2rem">

                {{-- Overview + specifications --}}
                @php
                    $desc = (string) $product->t('description');
                    $isHtml = $desc !== strip_tags($desc);
                    $short = trim((string) $product->t('short_description'));
                    $paras = $isHtml ? [] : array_values(array_filter(array_map('trim', preg_split('/\R{2,}/', $desc)), fn ($p) => $p !== '' && $p !== $short));
                @endphp
                <div class="pdp-grid-2">
                    <section class="pdp-glass pdp-pad" aria-labelledby="ov-h">
                        <h2 id="ov-h" class="pdp-h2">{{ __('pdp.overview') }}</h2>
                        <div class="pdp-prose" style="margin-top:1.1rem">
                            @if ($isHtml)
                                {!! $desc !!}
                            @elseif ($paras !== [])
                                @foreach ($paras as $para)<p>{{ $para }}</p>@endforeach
                            @elseif ($product->variety?->localized('description') || $product->form?->localized('description'))
                                @if ($product->variety?->localized('description'))<p>{{ $product->variety->localized('description') }}</p>@endif
                                @if ($product->form?->localized('description'))<p>{{ $product->form->localized('description') }}</p>@endif
                            @else
                                <p>{{ $short }}</p>
                            @endif
                        </div>
                    </section>

                    @if ($specs !== [])
                        <section class="pdp-glass pdp-pad" aria-labelledby="sp-h">
                            <h2 id="sp-h" class="pdp-h2">{{ __('site.products.specifications') }}</h2>
                            <dl style="margin-top:.9rem">
                                @foreach ($specs as $spec)
                                    <div class="pdp-spec"><dt>{{ $spec['label'] }}</dt><dd class="break-anywhere">{{ $spec['value'] }}</dd></div>
                                @endforeach
                            </dl>
                        </section>
                    @endif
                </div>

                {{-- Packaging options, with previews --}}
                @php $packs = $product->packagingTypes->isNotEmpty() ? $product->packagingTypes : $generalPackaging; @endphp
                @if ($packs->isNotEmpty())
                    <section id="packaging" class="pdp-glass pdp-pad" aria-labelledby="pk-h">
                        <h2 id="pk-h" class="pdp-h2">{{ __('pdp.packaging_title') }}</h2>
                        @if ($product->packagingTypes->isEmpty())<p class="pdp-note" style="margin-top:.6rem">{{ __('pdp.packaging_general_note') }}</p>@endif
                        @php $weightRows = []; @endphp
                        <ul class="pdp-packs" role="list">
                            @foreach ($packs as $packaging)
                                @php $pivot = $product->packagingTypes->isNotEmpty() ? $packaging->pivot : null; @endphp
                                @php
                                    $info = $packInfo[$packaging->id] ?? null;
                                    $words = ['on_request' => __('pdp.on_request'), 'g' => __('pdp.unit_g'), 'kg' => __('pdp.unit_kg')];
                                    $fmt = fn (?int $g) => \App\Packaging\Weight::format($g, $words);
                                    // Both drained weights always appear: the catalogue pack's own values, else the stored pack type's whole-weight and "on request" for pitted/sliced.
                                    $drainedWhole = $info ? ($info['weights']['drained_whole_g'] ?? null) : ($pivot?->drained_weight_g ?? $packaging->drained_weight_g);
                                    $drainedCut = $info ? ($info['weights']['drained_pitted_sliced_g'] ?? null) : null;
                                    $net = $info ? ($info['weights']['net_g'] ?? null) : ($pivot?->net_weight_g ?? $packaging->net_weight_g);
                                    $gross = $info ? ($info['weights']['gross_g'] ?? null) : $packaging->gross_weight_g;
                                    $units = $info ? $info['units'] : ($pivot?->units_per_carton ?? $packaging->units_per_carton);
                                    $weightRows[] = ['name' => $packaging->t('name'), 'capacity' => $packaging->capacityLabel(), 'whole' => $fmt($drainedWhole), 'cut' => $fmt($drainedCut), 'net' => $fmt($net), 'gross' => $gross ? $fmt($gross) : null, 'units' => $units];
                                @endphp
                                <li class="pdp-pack">
                                    @if ($pivot)<span class="pdp-pack-badge">{{ __('pdp.packaging_linked') }}</span>@endif
                                    <div class="pdp-pack-art">
                                        @if ($info && $info['photo'])
                                            <img src="{{ $info['photo']['src'] }}" @if ($info['photo']['srcset']) srcset="{{ $info['photo']['srcset'] }}" sizes="(min-width:1024px) 20rem, 90vw" @endif alt="{{ $info['photo']['alt'] }}" loading="lazy" decoding="async">
                                        @elseif ($packaging->image)
                                            <img src="{{ $packaging->image->urlFor(400) }}" alt="{{ $packaging->image->alt() }}" loading="lazy" decoding="async">
                                        @else
                                            @include('partials.pack-preview', ['kind' => $packaging->kind->value, 'scale' => $packaging->kind->relativeScale()])
                                        @endif
                                    </div>
                                    <div class="pdp-pack-body">
                                        <p class="pdp-pack-name">@if ($info)<a href="{{ $info['url'] }}" style="color:inherit">{{ $packaging->t('name') }}</a>@else{{ $packaging->t('name') }}@endif</p>
                                    </div>
                                </li>
                            @endforeach
                        </ul>
                        <div class="pdp-wt-wrap" tabindex="0" role="region" aria-label="{{ __('pdp.weights_table') }}">
                            <table class="pdp-wt">
                                <thead><tr>
                                    <th scope="col">{{ __('admin.fields.packaging') }}</th>
                                    <th scope="col">{{ __('site.packaging.capacity') }}</th>
                                    <th scope="col">{{ __('pdp.drained_whole') }}</th>
                                    <th scope="col">{{ __('pdp.drained_pitted_sliced') }}</th>
                                    <th scope="col">{{ __('site.packaging.net_weight') }}</th>
                                    @if (collect($weightRows)->contains(fn ($r) => $r['gross']))<th scope="col">{{ __('pdp.gross_weight') }}</th>@endif
                                    <th scope="col">{{ __('site.packaging.units_per_carton') }}</th>
                                </tr></thead>
                                <tbody>
                                    @foreach ($weightRows as $r)
                                        <tr>
                                            <th scope="row">{{ $r['name'] }}</th>
                                            <td>{{ $r['capacity'] ?? '—' }}</td>
                                            <td>{{ $r['whole'] }}</td>
                                            <td>{{ $r['cut'] }}</td>
                                            <td>{{ $r['net'] }}</td>
                                            @if (collect($weightRows)->contains(fn ($x) => $x['gross']))<td>{{ $r['gross'] ?? '—' }}</td>@endif
                                            <td>{{ $r['units'] ?? '—' }}</td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                        <p class="pdp-note">{{ __('pdp.packaging_preview') }} · <a href="{{ route('packaging.index') }}" style="text-decoration:underline;color:#14382a;font-weight:600">{{ __('pdp.packaging_all') }}</a></p>
                    </section>
                @endif

                {{-- Nutrition & certifications --}}
                @php $hasNutrition = $product->nutrition !== null; @endphp
                @if ($hasNutrition || $product->certifications->isNotEmpty())
                    <div class="pdp-grid-2 {{ ($hasNutrition && $product->certifications->isNotEmpty()) ? '' : 'is-single' }}">
                        @if ($hasNutrition)<section class="pdp-glass pdp-pad">@include('partials.nutrition')</section>@endif
                        @if ($product->certifications->isNotEmpty())
                            <section class="pdp-glass pdp-pad">
                                <h2 class="pdp-h2">{{ __('site.products.certifications') }}</h2>
                                <ul class="pdp-chips" role="list">
                                    @foreach ($product->certifications as $certification)
                                        <li>@if ($certification->logo)<img src="{{ $certification->logo->urlFor(120) }}" alt="{{ $certification->localized('name') }}" style="height:2.5rem;width:auto" loading="lazy" decoding="async">@else<span class="pdp-chip"><span>{{ $certification->localized('name') }}</span></span>@endif</li>
                                    @endforeach
                                </ul>
                            </section>
                        @endif
                    </div>
                @endif

                {{-- Request a quote --}}
                <section class="pdp-glass pdp-pad pdp-quote" aria-labelledby="q-h">
                    <div>
                        <h2 id="q-h">{{ sprintf(__('pdp.quote_title'), $product->name()) }}</h2>
                        <p>{{ __('pdp.quote_text') }}</p>
                    </div>
                    <a href="{{ route('quote.create', ['product' => $product->id]) }}" class="pdp-btn pdp-btn-primary">{{ __('site.cta.request_quote') }}</a>
                </section>

                @if ($product->relatedProducts->isNotEmpty())
                    <section aria-labelledby="rel-h">
                        <h2 id="rel-h" class="pdp-h2" style="margin-bottom:1.25rem">{{ __('site.products.related') }}</h2>
                        <div class="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
                            @foreach ($product->relatedProducts as $related)<x-product-card :product="$related" />@endforeach
                        </div>
                    </section>
                @endif
            </div>
        </div>
    </section>
@endsection
