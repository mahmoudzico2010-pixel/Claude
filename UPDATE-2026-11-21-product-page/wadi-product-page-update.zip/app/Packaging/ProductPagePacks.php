<?php

declare(strict_types=1);

namespace App\Packaging;

use App\Models\Packaging\PackagingLegacyMapping;
use App\Models\PackagingType;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Throwable;

/**
 * For the packaging cards on a product page: the approved catalogue pack behind each pack type, so the card can show the pack's
 * REAL photograph and both drained weights (whole and pitted/sliced). A type with no approved pack keeps its own stored values.
 */
final class ProductPagePacks
{
    /**
     * @param  Collection<int, PackagingType>  $types
     * @return array<int, array{photo: ?array{src: string, srcset: ?string, alt: string}, weights: array<string, ?int>, units: ?int, url: string}>
     */
    public function resolve(Collection $types): array
    {
        try {
            $catalog = app(PackagingCatalog::class);
            if ($types->isEmpty() || $catalog->isEmpty()) {
                return [];
            }
            $images = app(PackagingImages::class);
        } catch (Throwable) {
            return [];     // catalogue not published / tables missing: the page falls back to the stored pack-type values
        }

        $mapped = PackagingLegacyMapping::query()->whereIn('packaging_type_id', $types->pluck('id'))->where('status', PackagingLegacyMapping::MAPPED)->pluck('target_slug', 'packaging_type_id')->all();
        $direct = DB::table('packaging_packs')->whereIn('packaging_type_id', $types->pluck('id'))->where('is_active', true)->pluck('slug', 'packaging_type_id')->all();

        $out = [];
        foreach ($types as $type) {
            $slug = $mapped[$type->id] ?? $direct[$type->id] ?? null;
            $pack = $slug ? $catalog->pack($slug) : null;
            if ($pack === null) {
                continue;
            }
            $hero = $pack->heroImage;
            $out[$type->id] = [
                'photo' => $hero ? ['src' => $images->src($hero, 640), 'srcset' => $images->srcset($hero), 'alt' => $hero->alt] : null,
                'weights' => $pack->weights,
                'units' => $pack->unitsPerCarton,
                'url' => route('packaging.show', ['slug' => $pack->slug]),
            ];
        }

        return $out;
    }
}
