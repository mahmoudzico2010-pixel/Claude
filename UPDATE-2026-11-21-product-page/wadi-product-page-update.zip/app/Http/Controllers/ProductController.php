<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Enums\Availability;
use App\Models\Category;
use App\Models\Product;
use App\Models\ProductForm;
use App\Models\Variety;
use App\Services\Catalog\CatalogTree;
use App\Packaging\Legacy\LegacyReconciler;
use App\Services\Seo\SchemaBuilder;
use App\Services\Seo\SeoData;
use Illuminate\Contracts\View\View;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;
use Symfony\Component\HttpFoundation\StreamedResponse;

class ProductController extends Controller
{
    /**
     * Filters that accept several values at once.
     *
     * Only taxonomy-shaped fields are here. `hs_code`, `shelf_life_months`,
     * `storage_temp_min/max` and `country_of_origin` are deliberately absent:
     * the first three are numeric or free text, where "match any of these
     * exact values" is not a question anyone asks, and the fourth is a single
     * sourcing fact rather than a filter dimension in this catalogue.
     *
     * `color` and `availability` are plain columns rather than relations, so
     * they filter with whereIn on the column itself — which is why none of
     * this needs a migration.
     */
    private const MULTI_FILTERS = ['category', 'variety', 'form', 'color', 'availability'];

    public function index(Request $request): View
    {
        $this->normaliseFilters($request);

        $filters = $request->validate([
            'category' => ['nullable', 'array', 'max:30'],
            'category.*' => ['string', 'max:255'],
            'variety' => ['nullable', 'array', 'max:30'],
            'variety.*' => ['string', 'max:255'],
            'form' => ['nullable', 'array', 'max:30'],
            'form.*' => ['string', 'max:255'],
            'color' => ['nullable', 'array', 'max:30'],
            'color.*' => ['string', 'max:60'],
            'availability' => ['nullable', 'array', 'max:10'],
            // Bounded to the enum, so an invented value is rejected rather
            // than silently returning nothing.
            'availability.*' => ['string', Rule::in(array_keys(Availability::options()))],
        ]);

        /*
         | Within a group the values are OR'd; across groups they are AND'd.
         |
         | "Table Olives or Olive Oil, and Whole or Pitted" is what a buyer
         | means by ticking those four boxes. AND-ing within a group would
         | return nothing, since no product is in two categories at once.
         */
        $query = Product::query()
            ->published()
            ->forCard()
            ->ordered()
            ->when($filters['category'] ?? null, fn (Builder $q, array $slugs) => $q
                ->whereHas('category', fn (Builder $c) => $c->whereIn('slug', $slugs)->orWhereHas('parent', fn (Builder $p) => $p->whereIn('slug', $slugs))))
            ->when($filters['variety'] ?? null, fn (Builder $q, array $slugs) => $q
                ->whereHas('variety', fn (Builder $c) => $c->whereIn('slug', $slugs)))
            ->when($filters['form'] ?? null, fn (Builder $q, array $slugs) => $q
                ->whereHas('form', fn (Builder $c) => $c->whereIn('slug', $slugs)))
            ->when($filters['color'] ?? null, fn (Builder $q, array $colors) => $q
                ->whereIn('color', $colors))
            ->when($filters['availability'] ?? null, fn (Builder $q, array $values) => $q
                ->whereIn('availability', $values));

        $products = $query->paginate(12)->withQueryString();

        $seo = SeoData::make()
            ->title(__('site.products.title'))
            ->breadcrumbs([
                ['label' => __('site.home'), 'url' => route('home')],
                ['label' => __('site.products.title'), 'url' => null],
            ])
            // Filtered views are near-duplicates of the main listing.
            ->noindex(array_filter($filters) !== []);

        return view('pages.products.index', [
            'seo' => $seo,
            'products' => $products,
            // Families first, each followed by its subcategories (indented in the filter).
            'categories' => (function () {
                $all = Category::query()->active()->withTranslation()->ordered()->get();

                return $all->whereNull('parent_id')->flatMap(fn ($f) => collect([$f])->merge($all->where('parent_id', $f->id)))->values();
            })(),
            'families' => Category::query()->active()->roots()->with(['image', 'translations'])->ordered()->get(),
            'varieties' => Variety::query()->active()->ordered()->get(),
            'forms' => ProductForm::query()->active()->ordered()->get(),
            'colors' => $this->colorOptions(),
            'availabilities' => Availability::options(),
            'filters' => $filters,
        ]);
    }

    /**
     * Accept a single value where an array is expected.
     *
     * The filters were single-value until now, so every existing link, saved
     * bookmark, shared URL and search-engine result carries `?category=olives`
     * rather than `?category[]=olives`. Promoting a scalar to a one-element
     * array before validation means all of those keep working unchanged, and
     * the query below never has to care which shape it came from.
     */
    private function normaliseFilters(Request $request): void
    {
        foreach (self::MULTI_FILTERS as $key) {
            $value = $request->input($key);

            if ($value !== null && ! is_array($value)) {
                $request->merge([$key => [$value]]);
            }
        }
    }

    /**
     * Colours actually present in the published catalogue.
     *
     * `color` is a plain string column rather than a lookup table, so the
     * options are the distinct values in use. Offering a colour that matches
     * nothing would be a filter that can only ever return an empty page.
     *
     * @return array<int, string>
     */
    private function colorOptions(): array
    {
        return Product::query()
            ->published()
            ->whereNotNull('color')
            ->where('color', '!=', '')
            ->distinct()
            ->orderBy('color')
            ->pluck('color')
            ->all();
    }

    public function show(string $locale, Product $product): View
    {
        abort_unless($product->isPublished(), 404);

        $product->load([
            'nutrition',
            'translations', 'specSheet', 'seoImage',
            'images.media.altTexts', 'primaryImage.altTexts', 'specifications', 'calibers', 'certifications.logo',
            'variety', 'form', 'category.translations', 'category.parent.translations',
            'packagingTypes.translations', 'packagingTypes.image',
            'relatedProducts' => fn ($q) => $q->published()->forCard()->limit(4),
        ]);

        // Not offered any more: deactivated packs, and legacy types an administrator mapped or retired
        // (the product keeps the catalog pack they were mapped to).
        $resolved = app(LegacyReconciler::class)->resolvedIds();
        $product->setRelation('packagingTypes', $product->packagingTypes->reject(fn ($t): bool => ! $t->is_active || in_array($t->id, $resolved, true))->values());

        $seo = SeoData::make()
            ->title($product->t('seo_title') ?: $product->name())
            ->description($product->t('seo_description') ?: $product->t('short_description'))
            ->image($product->seoImage ?? $product->displayImage())
            ->type('product')
            ->schema(SchemaBuilder::product($product))
            ->breadcrumbs(array_values(array_filter([
                ['label' => __('site.home'), 'url' => route('home')],
                ['label' => __('site.products.title'), 'url' => route('products.index')],
                $product->category?->parent ? ['label' => (string) $product->category->parent->t('name'), 'url' => route('products.category', ['category' => $product->category->parent->slug])] : null,
                $product->category ? ['label' => (string) $product->category->t('name'), 'url' => route('products.category', ['category' => $product->category->slug])] : null,
                $product->variety && $product->variety->is_active ? ['label' => (string) $product->variety->localized('name'), 'url' => route('products.variety', ['variety' => $product->variety->slug])] : null,
                ['label' => (string) $product->name(), 'url' => null],
            ])));

        // No pack linked to this product: show the formats we offer in general (labelled as such on the page), never a claim of compatibility.
        $general = $product->packagingTypes->isEmpty()
            ? \App\Models\PackagingType::query()->where('is_active', true)->with(['translations', 'image'])->orderBy('display_order')->limit(6)->get()
            : collect();

        return view('pages.products.show', [
            'seo' => $seo,
            'product' => $product,
            'siblings' => $product->siblingForms(),
            'generalPackaging' => $general,
            'packInfo' => (new \App\Packaging\ProductPagePacks)->resolve($product->packagingTypes->isNotEmpty() ? $product->packagingTypes : $general),
        ]);
    }

    /**
     * The parent page of a variety: what the variety is, which forms exist (each linking to its own product page), the
     * packaging that fits them and a quotation call to action. It lists only published products, so a form that is
     * archived or unpublished disappears from it at once.
     */
    /** A family page (its products and its subcategories' products, each once) or a subcategory page (only its own). */
    public function category(string $locale, string $category): View
    {
        $model = Category::query()->active()->with(['parent', 'image', 'translations'])->where('slug', $category)->firstOrFail();
        $isFamily = $model->parent_id === null;
        $children = $isFamily ? Category::query()->active()->with(['image', 'translations'])->where('parent_id', $model->id)->ordered()->get() : collect();
        $ids = $children->pluck('id')->push($model->id)->all();

        $products = Product::query()->published()->forCard()->ordered()->whereIn('category_id', $ids)->get();
        $name = (string) $model->name();

        $crumbs = [['label' => __('site.home'), 'url' => route('home')], ['label' => __('site.products.title'), 'url' => route('products.index')]];
        if ($model->parent) {
            $crumbs[] = ['label' => (string) $model->parent->name(), 'url' => route('products.category', ['category' => $model->parent->slug])];
        }
        $crumbs[] = ['label' => $name, 'url' => null];

        $intro = filled($model->t('description')) ? (string) $model->t('description') : __('catalogue.intro', ['name' => $name]);
        $seo = SeoData::make()
            ->title((string) ($model->t('seo_title') ?: $name))
            ->description((string) ($model->t('seo_description') ?: $intro))
            ->image($model->image)
            ->breadcrumbs($crumbs);

        return view('pages.products.category', [
            'seo' => $seo, 'category' => $model, 'children' => $children, 'products' => $products, 'name' => $name, 'intro' => $intro, 'isFamily' => $isFamily,
        ]);
    }

    public function variety(string $locale, string $variety): View
    {
        $model = Variety::query()->active()->where('slug', $variety)->firstOrFail();
        $groups = CatalogTree::forVariety($model->id);
        abort_if($groups->isEmpty(), 404);

        $all = new \Illuminate\Database\Eloquent\Collection($groups->flatMap(fn (array $g) => $g['products']->all())->all());
        $all->load(['primaryImage', 'images.media', 'calibers', 'packagingTypes.translations']);

        $category = $groups->first()['category'];
        $related = Variety::query()->active()->whereKeyNot($model->id)
            ->whereHas('products', fn ($q) => $q->published()->where('category_id', $category->id))
            ->ordered()->limit(6)->get();

        $seo = SeoData::make()
            ->title((string) $model->localized('name').' — '.$category->t('name'))
            ->description((string) ($model->localized('intro') ?: $model->localized('description')))
            ->image($model->image ?? $all->map(fn ($p) => $p->displayImage())->filter()->first())
            ->breadcrumbs([
                ['label' => __('site.home'), 'url' => route('home')],
                ['label' => __('site.products.title'), 'url' => route('products.index')],
                ['label' => (string) $category->t('name'), 'url' => route('products.category', ['category' => $category->slug])],
                ['label' => (string) $model->localized('name'), 'url' => null],
            ]);

        return view('pages.products.variety', [
            'seo' => $seo, 'variety' => $model, 'groups' => $groups, 'products' => $all,
            'related' => $related,
            'colours' => $all->pluck('color')->filter()->unique()->values(),
            'processing' => $all->pluck('processing_method')->filter()->unique()->values(),
            'calibers' => $all->flatMap(fn ($p) => $p->calibers->all())->unique('id')->values(),
            'packaging' => $all->flatMap(fn ($p) => $p->packagingTypes->all())->unique('id')->filter(fn ($t) => $t->is_active)->values(),
        ]);
    }

    /**
     * Streams the specification sheet rather than exposing the storage path,
     * so the file can be moved or replaced without breaking the link.
     */
    public function specSheet(string $locale, Product $product): StreamedResponse
    {
        abort_unless($product->isPublished(), 404);

        $asset = $product->specSheet;

        abort_if($asset === null, 404);

        $disk = Storage::disk($asset->disk);

        abort_unless($disk->exists($asset->path), 404);

        return $disk->download($asset->path, $asset->original_filename);
    }
}
