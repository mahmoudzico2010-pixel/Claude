{{-- Phone-only control-panel chrome (language strip + bottom bar). Hidden everywhere above 599 px by one inline rule in the head;
     everything here is additive markup: the panel's own topbar, sidebar and pages are not replaced. --}}
@php
    $wamLangs = \App\Support\Admin\AdminLocales::items();
    $wamAuth = \Filament\Facades\Filament::auth()->check();
    $wamTry = static function (string $class): bool {
        try {
            return class_exists($class) && $class::canAccess();
        } catch (\Throwable) {
            return false;
        }
    };
    $wamUrl = static function (string $class): ?string {
        try {
            return $class::getUrl();
        } catch (\Throwable) {
            return null;
        }
    };
    $wamItems = [];
    if ($wamAuth) {
        $candidates = [
            ['dashboard', __('adminmobile.dashboard'), \Filament\Pages\Dashboard::class],
            ['products', __('adminmobile.products'), \App\Filament\Resources\Products\ProductResource::class],
            ['requests', __('adminmobile.requests'), \App\Filament\Resources\QuoteRequests\QuoteRequestResource::class],
            ['media', __('adminmobile.media'), \App\Filament\Resources\Media\MediaAssetResource::class],
        ];
        foreach ($candidates as [$key, $label, $class]) {
            if ($wamTry($class) && ($url = $wamUrl($class))) {
                $wamItems[] = ['key' => $key, 'label' => $label, 'url' => $url];
            }
        }
    }
    $wamPath = '/'.trim(parse_url(request()->url(), PHP_URL_PATH) ?: '/', '/');
    $wamIcons = [
        'dashboard' => '<path d="M3 11.5 12 4l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
        'products' => '<path d="M12 3 4 7.5v9L12 21l8-4.5v-9z"/><path d="M4 7.5 12 12l8-4.5M12 12v9"/>',
        'requests' => '<path d="M4 5h16v11H8l-4 4z"/>',
        'media' => '<rect x="3" y="4" width="18" height="16" rx="1"/><circle cx="9" cy="10" r="1.6"/><path d="m21 16-5-5-8 8"/>',
        'more' => '<circle cx="5" cy="12" r="1.4"/><circle cx="12" cy="12" r="1.4"/><circle cx="19" cy="12" r="1.4"/>',
    ];
    $wamIcon = static fn (string $k): string => '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">'.($wamIcons[$k] ?? '').'</svg>';
@endphp

@if (count($wamLangs) > 1)
    <div class="wam wam-langs" data-wam-langs>
        <form method="post" action="{{ route('filament.admin.ui-language') }}" data-wam-lang-form>
            @csrf
            <input type="hidden" name="return" value="{{ request()->fullUrl() }}">
            <nav aria-label="{{ __('adminmobile.interface_language') }}">
                <ul class="wam-langs-list" role="list" data-wam-langs-list>
                    @foreach ($wamLangs as $l)
                        <li>
                            <button type="submit" name="lang" value="{{ $l['code'] }}" class="wam-lang" lang="{{ $l['code'] }}" dir="{{ $l['dir'] }}"
                                    @if ($l['active']) aria-current="true" @endif>
                                @php($fc = strtolower($l['flag']))
                                <span class="wam-flag">@if (is_file(public_path('flags/sm/'.$fc.'.webp')))<img src="{{ asset('flags/sm/'.$fc.'.webp') }}" alt="" width="21" height="16" decoding="async">@elseif (is_file(public_path('flags/'.$fc.'.svg')))<img src="{{ asset('flags/'.$fc.'.svg') }}" alt="" width="21" height="16" decoding="async">@endif</span>
                                <span class="wam-lang-name">{{ $l['native'] }}</span>
                            </button>
                        </li>
                    @endforeach
                </ul>
            </nav>
        </form>
    </div>
@endif

@if ($wamAuth)
    <nav class="wam wam-nav" aria-label="{{ __('adminmobile.quick_navigation') }}" data-wam-nav>
        @foreach ($wamItems as $it)
            @php($p = '/'.trim(parse_url($it['url'], PHP_URL_PATH) ?: '/', '/'))
            @php($active = $it['key'] === 'dashboard' ? $wamPath === $p : ($wamPath === $p || str_starts_with($wamPath, $p.'/')))
            <a href="{{ $it['url'] }}" class="wam-nav-item" @if ($active) aria-current="page" @endif>
                {!! $wamIcon($it['key']) !!}<span>{{ $it['label'] }}</span>
            </a>
        @endforeach
        <button type="button" class="wam-nav-item" data-wam-more aria-haspopup="dialog" aria-controls="fi-main-sidebar" aria-expanded="false">
            {!! $wamIcon('more') !!}<span>{{ __('adminmobile.more') }}</span>
        </button>
    </nav>
@endif
