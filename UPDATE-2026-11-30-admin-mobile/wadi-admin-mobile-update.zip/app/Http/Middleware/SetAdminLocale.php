<?php

declare(strict_types=1);

namespace App\Http\Middleware;

use App\Support\Admin\AdminLocales;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Symfony\Component\HttpFoundation\Response;

/**
 * Applies the administrator's chosen interface language to the control panel (and to Livewire updates, which is why it is a
 * persistent panel middleware). With no valid choice the panel keeps the site's configured language, so nothing changes for
 * an administrator who never switches.
 */
final class SetAdminLocale
{
    public function handle(Request $request, Closure $next): Response
    {
        $chosen = $request->cookie(AdminLocales::COOKIE);

        if (AdminLocales::isAvailable(is_string($chosen) ? $chosen : null)) {
            App::setLocale($chosen);
        }

        return $next($request);
    }
}
