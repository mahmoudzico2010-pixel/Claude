<?php

declare(strict_types=1);

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Support\Admin\AdminLocales;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

/** Stores the control-panel interface language (cookie only: no database change, no effect on content or the public site). */
final class AdminLanguageController extends Controller
{
    public function __invoke(Request $request): RedirectResponse
    {
        $code = (string) $request->input('lang', '');
        abort_unless(AdminLocales::isAvailable($code), 422);

        // Back to the page the administrator was on, but only inside the panel.
        $back = (string) $request->input('return', '');
        $path = parse_url($back, PHP_URL_PATH);
        $prefix = '/'.trim((string) config('wadi.admin.path', 'admin'), '/');
        $to = is_string($path) && str_starts_with($path, $prefix)
            ? $path.(($q = parse_url($back, PHP_URL_QUERY)) ? '?'.$q : '')
            : $prefix;

        return redirect($to)->withCookie(cookie(AdminLocales::COOKIE, $code, 60 * 24 * 365, '/', null, $request->isSecure(), true, false, 'lax'));
    }
}
