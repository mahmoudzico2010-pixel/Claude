<?php

declare(strict_types=1);

namespace App\Support\Admin;

use App\Support\LanguagePicker;
use App\Support\Locales;

/**
 * The control panel's interface languages. Only a language that has its own admin translation file (lang/<code>/admin.php) is
 * offered, so the panel never advertises a language it cannot display. This is the INTERFACE language of the panel; it is
 * independent of the content-editing language tabs inside forms. The choice lives in a cookie, so an administrator who never
 * uses the phone language strip keeps exactly the panel language the site is configured with.
 */
final class AdminLocales
{
    public const COOKIE = 'wr_admin_lang';

    /** @return list<string> */
    public static function available(): array
    {
        $out = [];
        foreach (array_keys((array) config('wadi.locales', [])) as $code) {
            if (is_file(lang_path($code.'/admin.php'))) {
                $out[] = (string) $code;
            }
        }

        return $out;
    }

    public static function isAvailable(?string $code): bool
    {
        return is_string($code) && in_array($code, self::available(), true);
    }

    /** @return list<array{code: string, native: string, flag: string, dir: string, active: bool}> */
    public static function items(): array
    {
        $current = app()->getLocale();
        $items = [];
        foreach (self::available() as $code) {
            $config = (array) config('wadi.locales.'.$code, []);
            $items[] = [
                'code' => $code,
                'native' => (string) ($config['native'] ?? strtoupper($code)),
                'flag' => LanguagePicker::flag($code),
                'dir' => Locales::dir($code),
                'active' => $code === $current,
            ];
        }

        return $items;
    }
}
