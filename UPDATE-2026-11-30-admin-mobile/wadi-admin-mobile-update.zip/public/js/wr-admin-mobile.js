/* Wadi El Rayan — control panel, phone-only behaviour (no framework, no service worker, no storage of panel data).
   Runs only while (max-width: 599px) matches and is fully torn down when the viewport leaves that range. */
(function () {
    'use strict';
    var mq = window.matchMedia('(max-width: 599px)');
    var cleanup = [];
    var S = {};
    try { S = JSON.parse((document.currentScript && document.currentScript.getAttribute('data-wam-strings')) || '{}'); } catch (e) { S = {}; }

    function on(el, type, fn, opts) { if (!el) return; el.addEventListener(type, fn, opts); cleanup.push(function () { el.removeEventListener(type, fn, opts); }); }
    function $(s, r) { return (r || document).querySelector(s); }
    function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
    function sidebarStore() { return window.Alpine && window.Alpine.store ? window.Alpine.store('sidebar') : null; }

    /* ---- language strip: current language scrolled into view, end-of-list fade ---- */
    function endFade(list) {
        function upd() {
            var max = list.scrollWidth - list.clientWidth, x = Math.abs(list.scrollLeft);
            list.classList.toggle('wam-at-end', max <= 2 || x >= max - 2);
        }
        on(list, 'scroll', upd, { passive: true });
        upd();
    }
    function initLangs() {
        var list = $('[data-wam-langs-list]');
        if (!list) return;
        var cur = $('[aria-current]', list);
        if (cur) {
            var l = list.getBoundingClientRect(), c = cur.getBoundingClientRect();
            list.scrollLeft += (c.left + c.width / 2) - (l.left + l.width / 2);
        }
        endFade(list);
        // Switching reloads the page: protect unsaved edits first (the panel's own native prompt is skipped once confirmed here).
        var form = $('[data-wam-lang-form]');
        var skip = false;
        on(form, 'submit', function (e) {
            if (!dirty) return;
            if (!window.confirm(S.unsaved || 'You have unsaved changes. Switch anyway?')) { e.preventDefault(); return; }
            skip = true;
        });
        on(window, 'beforeunload', function (e) { if (skip) e.stopImmediatePropagation(); }, true);
    }

    /* ---- unsaved-change tracking (any edit inside a panel form, not the strip or search) ---- */
    var dirty = false;
    function initDirty() {
        dirty = false;
        function mark(e) {
            var t = e.target;
            if (!t || !t.closest) return;
            if (t.closest('.wam, .fi-global-search-ctn, .fi-ta-filters, .fi-ta-header-toolbar, .fi-modal')) return;
            if (t.closest('form, .fi-sc-form')) dirty = true;
        }
        on(document, 'input', mark, true);
        on(document, 'change', mark, true);
    }

    /* ---- compact header: identity + current screen title; search icon; titles follow the page ---- */
    var injected = [];
    function pageTitle() {
        var h = $('h1.fi-header-heading') || $('.fi-simple-header-heading') || $('h1');
        var t = h ? h.textContent.replace(/\s+/g, ' ').trim() : '';
        return t || (document.title || '').split('|')[0].trim();
    }
    function brandName() {
        var a = $('.fi-topbar-start a') || $('.fi-sidebar-header a');
        return a ? (a.textContent.replace(/\s+/g, ' ').trim() || a.getAttribute('aria-label') || (a.querySelector('img') && a.querySelector('img').alt) || '') : '';
    }
    function initHeader() {
        var topbar = $('.fi-topbar');
        var endBox = $('.fi-topbar-end');
        if (topbar && !$('.wam-title', topbar)) {
            var link = $('.fi-topbar-start a') || $('.fi-sidebar-header a');
            var a = document.createElement('a');
            a.className = 'wam-title';
            a.href = link ? link.getAttribute('href') : '/';
            var s = document.createElement('small'); s.textContent = brandName();
            var st = document.createElement('strong'); st.textContent = pageTitle();
            a.appendChild(s); a.appendChild(st);
            topbar.insertBefore(a, endBox && endBox.parentNode === topbar ? endBox : null);
            injected.push(a);
        }
        var end = $('.fi-topbar-end');
        var field = $('.fi-global-search-ctn');
        if (end && field && !$('.wam-search-btn', end)) {
            var b = document.createElement('button');
            b.type = 'button'; b.className = 'wam-search-btn'; b.setAttribute('aria-label', S.search || 'Search'); b.setAttribute('aria-expanded', 'false');
            b.innerHTML = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="6.5"/><path d="m20 20-4-4"/></svg>';
            end.insertBefore(b, end.firstChild);
            injected.push(b);
            on(b, 'click', function () {
                var open = document.documentElement.classList.toggle('wam-search-open');
                b.setAttribute('aria-expanded', open ? 'true' : 'false');
                if (open) { var i = $('input', field); if (i) i.focus(); }
            });
            on(document, 'keydown', function (e) {
                if (e.key === 'Escape' && document.documentElement.classList.contains('wam-search-open')) {
                    document.documentElement.classList.remove('wam-search-open'); b.setAttribute('aria-expanded', 'false'); b.focus();
                }
            });
        }
    }

    /* ---- tabs: end-of-row fade follows the scroll position ---- */
    function initTabs() {
        $$('.fi-tabs').forEach(function (t) {
            endFade(t);
            var active = $('[aria-selected="true"], .fi-active', t);
            if (active) { var r = t.getBoundingClientRect(), c = active.getBoundingClientRect(); t.scrollLeft += (c.left + c.width / 2) - (r.left + r.width / 2); }
        });
    }

    /* ---- keyboard: the bar steps aside while a field has focus or the viewport shrinks ---- */
    var FIELD = 'input:not([type=checkbox]):not([type=radio]):not([type=button]):not([type=submit]), textarea, select, [contenteditable=""], [contenteditable="true"]';
    function initKeyboard() {
        var root = document.documentElement, base = window.innerHeight;
        function set(v) { root.classList.toggle('wam-kb', !!v); }
        on(document, 'focusin', function (e) { if (e.target && e.target.matches && e.target.matches(FIELD)) { set(true); setTimeout(function () { try { e.target.scrollIntoView({ block: 'center', behavior: 'auto' }); } catch (x) { /* ignore */ } }, 250); } });
        on(document, 'focusout', function () { setTimeout(function () { var a = document.activeElement; if (!(a && a.matches && a.matches(FIELD))) set(false); }, 50); });
        function keepFocusedVisible() {
            var a = document.activeElement;
            if (a && a.matches && a.matches(FIELD)) {
                var vv = window.visualViewport, h = vv ? vv.height : window.innerHeight, r = a.getBoundingClientRect();
                if (r.top < 0 || r.bottom > h) { try { a.scrollIntoView({ block: 'center', behavior: 'auto' }); } catch (x) { /* ignore */ } }
            }
        }
        if (window.visualViewport) {
            on(window.visualViewport, 'resize', function () {
                var shrunk = window.visualViewport.height < base * 0.78;
                if (shrunk) set(true); else if (!(document.activeElement && document.activeElement.matches && document.activeElement.matches(FIELD))) set(false);
                keepFocusedVisible();
            });
        }
        on(window, 'resize', function () { setTimeout(keepFocusedVisible, 60); });
        cleanup.push(function () { root.classList.remove('wam-kb'); });
    }


    /* ---- form actions (Save / Cancel): pinned above the bottom bar until the end of the form is on screen ---- */
    function initActions() {
        var rows = $$('.fi-sc-form .fi-sc-actions').filter(function (a) { return a.querySelector('button[type="submit"]'); });
        if (!rows.length) return;
        var ticking = false;
        function update() {
            ticking = false;
            var nav = $('.wam-nav'), kb = document.documentElement.classList.contains('wam-kb');
            var limit = kb || !nav ? window.innerHeight : nav.getBoundingClientRect().top;
            rows.forEach(function (a) {
                var holder = a.parentNode, fixed = a.classList.contains('wam-actions-fixed');
                var h = fixed ? (parseFloat(holder.style.minHeight) || a.offsetHeight) : a.offsetHeight;
                var ref = fixed ? holder : a;
                var natBottom = ref.getBoundingClientRect().bottom, natTop = ref.getBoundingClientRect().top;
                var shouldFix = natBottom > limit && natTop < window.innerHeight * 3;
                if (shouldFix && !fixed) { holder.style.minHeight = h + 'px'; a.classList.add('wam-actions-fixed'); }
                else if (!shouldFix && fixed) { a.classList.remove('wam-actions-fixed'); holder.style.minHeight = ''; }
            });
        }
        function req() { if (!ticking) { ticking = true; window.requestAnimationFrame(update); } }
        on(window, 'scroll', req, { passive: true }); on(window, 'resize', req);
        on(document, 'click', function () { setTimeout(req, 350); }); on(document, 'input', req);
        if (window.visualViewport) on(window.visualViewport, 'resize', req);
        update();
        cleanup.push(function () { rows.forEach(function (a) { a.classList.remove('wam-actions-fixed'); if (a.parentNode) a.parentNode.style.minHeight = ''; }); });
    }


    /* ---- resource lists as cards: label every cell from its column header (re-applied after Livewire re-renders the table) ---- */
    function labelTables() {
        $$('.fi-resource-list-records-page .fi-ta-table').forEach(function (t) {
            var heads = $$('thead th', t);
            if (!heads.length) return;
            t.setAttribute('data-wam-cards', '');
            $$('tbody > tr.fi-ta-row', t).forEach(function (tr) {
                var primary = false;
                [].slice.call(tr.children).forEach(function (td, i) {
                    var h = heads[i], lab = h ? (h.textContent || '').replace(/\s+/g, ' ').trim() : '';
                    if (lab) td.setAttribute('data-wam-label', lab);
                    var txt = (td.textContent || '').replace(/\s+/g, ' ').trim(), role;
                    if (td.classList.contains('fi-ta-selection-cell')) role = 'select';
                    else if (!h || h.classList.contains('fi-ta-actions-header-cell')) role = 'actions';
                    else if (td.querySelector('img') && !txt) role = 'image';
                    else if (!primary && txt) { role = 'primary'; primary = true; }
                    else role = 'field';
                    td.setAttribute('data-wam-role', role);
                });
            });
        });
    }
    function initCards() {
        labelTables();
        var host = $('.fi-page-content') || document.body, timer = null;
        if (!window.MutationObserver) return;
        var mo = new MutationObserver(function () { if (timer) return; timer = setTimeout(function () { timer = null; labelTables(); }, 120); });
        mo.observe(host, { childList: true, subtree: true });
        cleanup.push(function () {
            mo.disconnect();
            $$('[data-wam-cards]').forEach(function (n) { n.removeAttribute('data-wam-cards'); });
            $$('[data-wam-role]').forEach(function (n) { n.removeAttribute('data-wam-role'); n.removeAttribute('data-wam-label'); });
        });
    }

    /* ---- "More" opens the panel's own organised drawer, with focus handling ---- */
    var opener = null;
    function setBackgroundInert(on_) {
        $$('.fi-main-ctn, .fi-topbar, .wam-langs, .wam-nav').forEach(function (n) { if (on_) n.setAttribute('inert', ''); else n.removeAttribute('inert'); });
    }
    function initDrawer() {
        var more = $('[data-wam-more]');
        var side = $('#fi-main-sidebar') || $('.fi-sidebar');
        if (!more || !side) return;
        on(more, 'click', function () { var st = sidebarStore(); if (st) { opener = more; st.open(); } });
        function sync() {
            var st = sidebarStore(); if (!st) return;
            var open = !!st.isOpen && mq.matches;
            more.setAttribute('aria-expanded', open ? 'true' : 'false');
            if (open) {
                side.setAttribute('role', 'dialog'); side.setAttribute('aria-modal', 'true');
                side.setAttribute('aria-label', (more.textContent || '').trim());
                setBackgroundInert(true);
                var tryFocus = function (n) {
                    if (side.contains(document.activeElement)) return;
                    var first = $('.fi-sidebar-item-btn, .fi-sidebar-group-btn, a', side);
                    if (first) { first.focus(); }
                    if (!side.contains(document.activeElement) && n < 8) setTimeout(function () { tryFocus(n + 1); }, 120);
                };
                tryFocus(0);
            } else {
                side.removeAttribute('role'); side.removeAttribute('aria-modal'); side.removeAttribute('aria-label');
                setBackgroundInert(false);
                if (opener) { var o = opener; opener = null; try { o.focus(); } catch (x) { /* ignore */ } }
            }
        }
        var stop = window.Alpine && window.Alpine.effect ? window.Alpine.effect(function () { var st = sidebarStore(); if (st) { void st.isOpen; sync(); } }) : null;
        cleanup.push(function () { try { if (stop && window.Alpine.release) window.Alpine.release(stop); } catch (x) { /* ignore */ } setBackgroundInert(false); more.setAttribute('aria-expanded', 'false'); });
        on(document, 'keydown', function (e) { var st = sidebarStore(); if (e.key === 'Escape' && st && st.isOpen) st.close(); });
    }

    /* ---- activate / deactivate ---- */
    function activate() {
        initDirty(); initLangs(); initHeader(); initTabs(); initKeyboard(); initDrawer(); initActions(); initCards();
        // Livewire re-renders parts of the page after actions: keep the title and tab fades in step.
        on(document, 'livewire:navigated', function () { initHeader(); initTabs(); });
        var t = $('.wam-title strong');
        var h = $('h1.fi-header-heading');
        if (h && t && window.MutationObserver) {
            var mo = new MutationObserver(function () { t.textContent = pageTitle(); });
            mo.observe(h, { childList: true, characterData: true, subtree: true });
            cleanup.push(function () { mo.disconnect(); });
        }
    }
    function deactivate() {
        cleanup.splice(0).forEach(function (f) { try { f(); } catch (e) { /* ignore */ } });
        injected.splice(0).forEach(function (n) { if (n.parentNode) n.parentNode.removeChild(n); });
        document.documentElement.classList.remove('wam-search-open', 'wam-kb');
        $$('.wam-at-end').forEach(function (n) { n.classList.remove('wam-at-end'); });
    }
    function sync() { deactivate(); if (mq.matches) activate(); }
    function start() { sync(); if (mq.addEventListener) mq.addEventListener('change', sync); else mq.addListener(sync); }
    if (window.Alpine) start(); else document.addEventListener('alpine:initialized', start, { once: true });
    if (document.readyState !== 'loading' && !window.Alpine) setTimeout(function () { if (!cleanup.length && mq.matches && !injected.length) start(); }, 1500);
})();
