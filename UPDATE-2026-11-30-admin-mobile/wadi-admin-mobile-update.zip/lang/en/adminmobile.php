<?php

return [
    'dashboard' => 'Dashboard',
    'products' => 'Products',
    'requests' => 'Requests',
    'media' => 'Media',
    'more' => 'More',
    'quick_navigation' => 'Quick navigation',
    'interface_language' => 'Panel language',
    'search' => 'Search',
    'unsaved_switch' => 'You have unsaved changes. Switching the panel language reloads this page and they will be lost. Switch anyway?',
    'saving' => 'Saving…',
    'filters' => 'Filters',
    'close' => 'Close',
    'move_up' => 'Move up',
    'move_down' => 'Move down',
];
