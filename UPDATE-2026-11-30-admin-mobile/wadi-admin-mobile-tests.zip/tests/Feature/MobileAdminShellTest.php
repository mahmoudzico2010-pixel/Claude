<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Models\User;
use App\Support\Admin\AdminLocales;
use Illuminate\Foundation\Testing\RefreshDatabase;
use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;

final class MobileAdminShellTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
    }

    private function as(string $role): User
    {
        $u = User::factory()->create(['is_active' => true]);
        $u->assignRole($role);
        $this->actingAs($u->fresh());

        return $u;
    }

    #[Test]
    public function only_languages_with_an_admin_translation_file_are_offered(): void
    {
        $codes = AdminLocales::available();
        $this->assertContains('en', $codes);
        $this->assertContains('ar', $codes);
        foreach ($codes as $c) {
            $this->assertFileExists(lang_path($c.'/admin.php'), 'a language must not be advertised without admin translations');
        }
        $this->assertNotContains('xx', $codes);
        $this->assertFalse(AdminLocales::isAvailable('zz'));
        $this->assertFalse(AdminLocales::isAvailable(null));
    }

    #[Test]
    public function the_phone_shell_is_rendered_hidden_by_default_with_the_strip_and_the_bottom_bar(): void
    {
        $this->as(User::ROLE_ADMIN);
        $html = $this->get('/admin')->getContent();

        $this->assertStringContainsString('<style>.wam{display:none}', $html, 'hidden everywhere until the phone stylesheet applies');
        $this->assertStringContainsString('css/wr-admin-mobile.css', $html);
        $this->assertMatchesRegularExpression('#<link rel="stylesheet" href="[^"]*wr-admin-mobile\.css\?v=\d+" media="\(max-width: 599px\)">#', $html);
        $this->assertStringContainsString('class="wam wam-langs"', $html);
        $this->assertStringContainsString('class="wam wam-nav"', $html);
        $this->assertSame(1, substr_count($html, 'js/wr-admin-mobile.js'));
        // The language strip lists each admin language with its native name and marks the active one.
        $this->assertMatchesRegularExpression('#class="wam-lang"[^>]*lang="en"[^>]*aria-current="true"|class="wam-lang"[^>]*aria-current="true"#', $html);
        $this->assertStringContainsString('English', $html);
        $this->assertStringContainsString('العربية', $html);
        $this->assertStringNotContainsString('Español', explode('wam-nav', $html)[0] === '' ? '' : substr($html, (int) strpos($html, 'wam-langs'), 2500), 'languages without admin translations are not advertised');
    }

    #[Test]
    public function the_bottom_bar_lists_only_what_the_user_may_open(): void
    {
        $this->as(User::ROLE_ADMIN);
        $admin = $this->get('/admin')->getContent();
        $bar = (string) preg_replace('#^.*?(<nav class="wam wam-nav".*?</nav>).*$#s', '$1', $admin);
        foreach (['admin/products', 'admin/quote-requests', 'admin/media'] as $path) {
            $this->assertStringContainsString($path, $bar, "$path is listed for an administrator");
        }

    }

    /** @return array<string, array{0: string}> */
    public static function roles(): array
    {
        return ['sales' => [User::ROLE_SALES], 'content editor' => [User::ROLE_CONTENT_EDITOR], 'viewer' => [User::ROLE_VIEWER], 'admin' => [User::ROLE_ADMIN]];
    }

    #[Test]
    #[\PHPUnit\Framework\Attributes\DataProvider('roles')]
    public function the_bottom_bar_offers_exactly_the_destinations_the_user_may_open(string $role): void
    {
        $this->as($role);
        $r = $this->get('/admin');
        if ($r->getStatusCode() === 302) {   // a role without a dashboard is sent to its first allowed screen
            $r = $this->get($r->headers->get('Location'));
        }
        $this->assertSame(200, $r->getStatusCode());
        $bar = (string) preg_replace('#^.*?(<nav class="wam wam-nav".*?</nav>).*$#s', '$1', $r->getContent());
        $this->assertStringContainsString('data-wam-more', $bar, 'More is always available');

        $expect = [
            'admin/products' => \App\Filament\Resources\Products\ProductResource::canAccess(),
            'admin/quote-requests' => \App\Filament\Resources\QuoteRequests\QuoteRequestResource::canAccess(),
            'admin/media/media-assets' => \App\Filament\Resources\Media\MediaAssetResource::canAccess(),
        ];
        foreach ($expect as $path => $allowed) {
            $allowed
                ? $this->assertStringContainsString($path, $bar, "$role may open $path")
                : $this->assertStringNotContainsString($path, $bar, "$role may not open $path, so the bar must not offer it");
        }
    }

    #[Test]
    public function the_bottom_bar_marks_the_current_route(): void
    {
        $this->as(User::ROLE_ADMIN);
        $html = $this->get('/admin/products')->getContent();
        $bar = (string) preg_replace('#^.*?(<nav class="wam wam-nav".*?</nav>).*$#s', '$1', $html);
        $this->assertSame(1, preg_match_all('#aria-current="page"#', $bar));
        $this->assertMatchesRegularExpression('#href="[^"]*admin/products"[^>]*aria-current="page"#', $bar);
    }

    #[Test]
    public function switching_language_sets_a_cookie_only_for_an_available_language_and_stays_in_the_panel(): void
    {
        $this->as(User::ROLE_ADMIN);

        $ok = $this->post('/admin/ui-language', ['lang' => 'ar', 'return' => url('/admin/products?tab=x')]);
        $ok->assertRedirect('/admin/products?tab=x');
        $ok->assertCookie(AdminLocales::COOKIE);

        $this->post('/admin/ui-language', ['lang' => 'es'])->assertStatus(422);
        $this->post('/admin/ui-language', ['lang' => 'ar', 'return' => 'https://evil.example/phish'])->assertRedirect('/admin');
        $this->post('/admin/ui-language', ['lang' => 'ar', 'return' => '/not-the-panel'])->assertRedirect('/admin');
    }

    #[Test]
    public function the_chosen_language_reaches_the_panel_and_never_touches_the_public_site(): void
    {
        $this->as(User::ROLE_ADMIN);

        $en = $this->get('/admin')->getContent();
        $this->assertStringContainsString('dir="ltr"', $en);

        $ar = $this->withUnencryptedCookie(AdminLocales::COOKIE, 'ar')->get('/admin')->getContent();
        $this->assertStringContainsString('dir="rtl"', $ar);
        $this->assertStringContainsString('lang="ar"', $ar);

        $this->get('/en')->assertOk()->assertSee('lang="en"', false);
    }

    #[Test]
    public function the_switch_requires_the_csrf_token_in_a_real_request_and_the_strip_form_carries_it(): void
    {
        $this->as(User::ROLE_ADMIN);
        $html = $this->get('/admin')->getContent();
        $this->assertMatchesRegularExpression('#<form method="post" action="[^"]*admin/ui-language"[^>]*data-wam-lang-form>\s*<input type="hidden" name="_token"#', $html);
    }

    #[Test]
    public function the_login_page_shows_the_language_strip_but_no_bottom_bar(): void
    {
        $html = $this->get('/admin/login')->getContent();
        $this->assertStringContainsString('class="wam wam-langs"', $html);
        $this->assertStringNotContainsString('class="wam wam-nav"', $html);
    }

    #[Test]
    public function the_gallery_reorder_buttons_exist_but_are_hidden_above_the_phone_breakpoint(): void
    {
        $html = $this->get('/admin/login')->getContent();
        $this->assertStringContainsString('@media (min-width:600px){.fi-fo-repeater-item-header-start-actions li:has(', $html);
        $this->assertStringContainsString("'moveUp'", $html);
    }

    #[Test]
    public function the_phone_assets_are_static_files_with_no_service_worker_or_private_storage(): void
    {
        foreach (['css/wr-admin-mobile.css', 'js/wr-admin-mobile.js'] as $f) {
            $this->assertFileExists(public_path($f));
        }
        $js = (string) file_get_contents(public_path('js/wr-admin-mobile.js'));
        $this->assertStringNotContainsString('serviceWorker', $js);
        $this->assertStringNotContainsString('localStorage', $js);
        $this->assertStringNotContainsString('sessionStorage', $js);
        $this->assertStringNotContainsString('indexedDB', $js);
        $this->assertStringContainsString('(max-width: 599px)', $js);
        $this->assertLessThan(40 * 1024, filesize(public_path('css/wr-admin-mobile.css')));
        $this->assertLessThan(30 * 1024, filesize(public_path('js/wr-admin-mobile.js')));
    }
}
