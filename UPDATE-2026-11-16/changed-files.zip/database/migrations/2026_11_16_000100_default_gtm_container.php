<?php

declare(strict_types=1);

use App\Models\SiteSetting;
use Illuminate\Database\Migrations\Migration;

/** Google Tag Manager container for the site. Only fills an empty setting; the owner can change or clear it under Settings → SEO → Analytics. */
return new class extends Migration
{
    public function up(): void
    {
        if (blank(SiteSetting::get('analytics.gtm_id'))) {
            SiteSetting::setMany(['gtm_id' => 'GTM-WLVMLZTN'], 'analytics');
            SiteSetting::flushCache();
        }
    }

    public function down(): void
    {
    }
};
