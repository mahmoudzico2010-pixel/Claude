<?php

declare(strict_types=1);

use App\Services\Catalog\CatalogHierarchy;
use Illuminate\Database\Migrations\Migration;

/** Five families and thirteen subcategories with ten-language names. Fill-only and safe to re-run (also `php artisan catalogue:hierarchy`). */
return new class extends Migration
{
    public function up(): void
    {
        // Existing sites only; a fresh install gets it from CatalogContentSeeder.
        if (\Illuminate\Support\Facades\DB::table('products')->exists()) {
            CatalogHierarchy::apply();
        }
    }

    public function down(): void {}
};
