<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** Product photo frames: a library of transparent overlay designs, a site-wide choice (settings) and a per-product override. Additive. */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('product_frames', function (Blueprint $table): void {
            $table->id();
            $table->string('name', 120);
            $table->string('source', 10)->default('media');          // builtin | media
            $table->string('builtin_path', 190)->nullable();         // under public/
            $table->foreignId('media_id')->nullable()->constrained('media_assets')->nullOnDelete();
            $table->decimal('ratio', 7, 4)->default(1);              // artwork width / height
            $table->unsignedTinyInteger('padding_pct')->default(9);  // inner padding around the product, % of the frame
            $table->boolean('is_active')->default(true);
            $table->unsignedInteger('display_order')->default(0);
            $table->timestamps();
        });

        Schema::table('products', function (Blueprint $table): void {
            $table->string('frame_mode', 10)->default('inherit');   // inherit | none | frame
            $table->foreignId('frame_id')->nullable()->constrained('product_frames')->nullOnDelete();
        });

        // The supplied emerald-and-gold design (1200 x 1200 WebP, transparent centre) is a selectable frame from the start.
        \Illuminate\Support\Facades\DB::table('product_frames')->insert([
            'name' => 'Wadi emerald & gold', 'source' => 'builtin', 'builtin_path' => 'frames/wadi-emerald-gold-frame.webp', 'ratio' => 1, 'padding_pct' => 9,
            'is_active' => true, 'display_order' => 0, 'created_at' => now(), 'updated_at' => now(),
        ]);
    }

    public function down(): void
    {
        Schema::table('products', function (Blueprint $table): void {
            $table->dropConstrainedForeignId('frame_id');
            $table->dropColumn('frame_mode');
        });
        Schema::dropIfExists('product_frames');
    }
};
