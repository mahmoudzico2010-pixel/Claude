<?php

declare(strict_types=1);

namespace Database\Seeders;

use App\Services\Catalog\CatalogContent;
use Illuminate\Database\Seeder;

/** Parent-page copy, variant attributes, nutrition references and the catalogue-driven menu. Idempotent; fills empty values only. */
class CatalogContentSeeder extends Seeder
{
    public function run(): void
    {
        CatalogContent::apply();
        \App\Services\Catalog\CatalogHierarchy::apply();
    }
}
