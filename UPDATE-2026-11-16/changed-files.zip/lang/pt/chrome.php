<?php

declare(strict_types=1);

return [
    'export_map' => ['title' => 'Mapa-múndi: :count rotas de exportação a partir do Egito'],
    'footer' => ['developed_by' => 'Desenvolvido por'],
    'lang' => ['switch' => 'Idioma', 'menu' => 'Escolher idioma'],
];
