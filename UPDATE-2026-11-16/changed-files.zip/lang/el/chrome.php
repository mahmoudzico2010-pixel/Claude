<?php

declare(strict_types=1);

return [
    'export_map' => ['title' => 'Παγκόσμιος χάρτης: :count διαδρομές εξαγωγής από την Αίγυπτο'],
    'footer' => ['developed_by' => 'Ανάπτυξη από'],
    'lang' => ['switch' => 'Γλώσσα', 'menu' => 'Επιλογή γλώσσας'],
];
