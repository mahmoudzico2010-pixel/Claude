<?php

declare(strict_types=1);

return [
    'export_map' => ['title' => 'Carte du monde : :count routes d\'exportation depuis l\'Égypte'],
    'footer' => ['developed_by' => 'Développé par'],
    'lang' => ['switch' => 'Langue', 'menu' => 'Choisir la langue'],
];
