<?php

return [
    'families' => 'Familles de produits',
    'intro' => 'Découvrez la gamme :name de Wadi El Rayan for Food Industries.',
    'index_intro' => 'Explorez nos cinq familles de produits, puis demandez un devis pour la gamme qui vous intéresse.',
    'subcategories' => 'Catégories de :name',
    'view' => 'Voir :name',
    'empty_title' => 'Disponible sur demande',
    'empty_text' => 'Notre gamme :name est disponible sur demande. Dites-nous ce dont vous avez besoin et nous vous répondrons avec la disponibilité et un devis.',
    'enquire' => 'Se renseigner sur :name',
    'all_in' => 'Tous les produits :name',
    'products_in' => 'Produits :name',
    'back_to' => 'Retour à :name',
];
