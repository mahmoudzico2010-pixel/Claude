<?php

declare(strict_types=1);

return [
    'export_map' => ['title' => 'World map: :count export routes from Egypt'],
    'footer' => ['developed_by' => 'Developed by'],
    'lang' => ['switch' => 'Language', 'menu' => 'Choose language'],
    'admin' => [
        'header_footer' => 'Header & footer',
        'lang_section' => 'Language picker',
        'lang_help' => 'Shows each enabled language as a flag above its native name. The flag is chosen per language and is independent of the language code.',
        'lang_mode' => 'Display mode',
        'mode_horizontal' => 'Horizontal (all languages side by side)',
        'mode_dropdown' => 'Dropdown (current language, opens the others)',
        'flags' => 'Representative flag per language',
        'dev_section' => 'Developer credit',
        'dev_help' => 'Shown right after the copyright as “Developed by …”. Hidden when switched off or when the name is empty.',
        'dev_enabled' => 'Show the developer credit',
        'dev_name' => 'Developer name',
        'dev_url' => 'Developer website (https://…)',
        'dev_url_invalid' => 'Enter a full web address starting with http:// or https://.',
        'dev_logo' => 'Developer logo (optional, shown about 15 px high)',
    ],
];
