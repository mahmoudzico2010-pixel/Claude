<?php

return [
    'families' => 'Product families',
    'intro' => 'Explore the :name range from Wadi El Rayan for Food Industries.',
    'index_intro' => 'Explore our five product families, then request a quote for the range you need.',
    'subcategories' => 'Categories in :name',
    'view' => 'View :name',
    'empty_title' => 'Availability on request',
    'empty_text' => 'Our :name range is available on enquiry. Tell us what you need and we will reply with availability and a quote.',
    'enquire' => 'Enquire about :name',
    'all_in' => 'All products in :name',
    'products_in' => 'Products in :name',
    'back_to' => 'Back to :name',
];
