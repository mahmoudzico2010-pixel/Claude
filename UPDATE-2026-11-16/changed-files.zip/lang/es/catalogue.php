<?php

return [
    'families' => 'Familias de productos',
    'intro' => 'Descubra la gama :name de Wadi El Rayan for Food Industries.',
    'index_intro' => 'Explore nuestras cinco familias de productos y solicite un presupuesto de la gama que necesite.',
    'subcategories' => 'Categorías de :name',
    'view' => 'Ver :name',
    'empty_title' => 'Disponible bajo consulta',
    'empty_text' => 'Nuestra gama :name está disponible bajo consulta. Cuéntenos lo que necesita y le responderemos con disponibilidad y presupuesto.',
    'enquire' => 'Consultar sobre :name',
    'all_in' => 'Todos los productos de :name',
    'products_in' => 'Productos de :name',
    'back_to' => 'Volver a :name',
];
