<?php

declare(strict_types=1);

return [
    'export_map' => ['title' => 'Mapa mundial: :count rutas de exportación desde Egipto'],
    'footer' => ['developed_by' => 'Desarrollado por'],
    'lang' => ['switch' => 'Idioma', 'menu' => 'Elegir idioma'],
];
