<?php

declare(strict_types=1);

return [
    'export_map' => ['title' => '世界地图：从埃及出发的 :count 条出口路线'],
    'footer' => ['developed_by' => '开发方：'],
    'lang' => ['switch' => '语言', 'menu' => '选择语言'],
];
