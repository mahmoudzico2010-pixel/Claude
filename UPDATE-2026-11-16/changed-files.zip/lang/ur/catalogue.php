<?php

return [
    'families' => 'مصنوعات کے خاندان',
    'intro' => 'Wadi El Rayan for Food Industries کی :name رینج دریافت کریں۔',
    'index_intro' => 'ہمارے پانچ مصنوعات خاندان دیکھیں، پھر مطلوبہ رینج کے لیے کوٹیشن طلب کریں۔',
    'subcategories' => ':name کی اقسام',
    'view' => ':name دیکھیں',
    'empty_title' => 'طلب پر دستیاب',
    'empty_text' => 'ہماری :name رینج طلب پر دستیاب ہے۔ اپنی ضرورت بتائیں، ہم دستیابی اور کوٹیشن کے ساتھ جواب دیں گے۔',
    'enquire' => ':name کے بارے میں دریافت کریں',
    'all_in' => ':name کی تمام مصنوعات',
    'products_in' => ':name کی مصنوعات',
    'back_to' => ':name پر واپس',
];
