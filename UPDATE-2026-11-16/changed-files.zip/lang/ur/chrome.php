<?php

declare(strict_types=1);

return [
    'export_map' => ['title' => 'دنیا کا نقشہ: مصر سے :count برآمدی راستے'],
    'footer' => ['developed_by' => 'تیار کردہ از'],
    'lang' => ['switch' => 'زبان', 'menu' => 'زبان منتخب کریں'],
];
