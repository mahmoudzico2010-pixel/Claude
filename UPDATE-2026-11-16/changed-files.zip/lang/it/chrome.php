<?php

declare(strict_types=1);

return [
    'export_map' => ['title' => 'Mappa del mondo: :count rotte di esportazione dall\'Egitto'],
    'footer' => ['developed_by' => 'Sviluppato da'],
    'lang' => ['switch' => 'Lingua', 'menu' => 'Scegli la lingua'],
];
