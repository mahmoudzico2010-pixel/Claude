<?php

declare(strict_types=1);

return [
    'export_map' => ['title' => 'Карта мира: :count экспортных маршрутов из Египта'],
    'footer' => ['developed_by' => 'Разработка:'],
    'lang' => ['switch' => 'Язык', 'menu' => 'Выбрать язык'],
];
