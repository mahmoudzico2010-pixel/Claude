@props(['code', 'name' => '', 'height' => 16])
{{-- The actual flag of an ISO 3166-1 country, from the bundled local set (public/flags, 4:3). Decorative: the country name beside it is the label. --}}
@php($c = strtolower(preg_replace('/[^A-Za-z]/', '', (string) $code)))
@if (strlen($c) === 2 && is_file(public_path('flags/'.$c.'.svg')))
    <img src="{{ asset('flags/'.$c.'.svg') }}" alt="" width="{{ round($height * 4 / 3) }}" height="{{ $height }}" loading="lazy" decoding="async"
         {{ $attributes->merge(['class' => 'inline-block flex-none rounded-[2px] object-cover shadow-[0_0_0_1px_rgba(0,0,0,0.12)]', 'style' => 'width:'.round($height * 4 / 3).'px;height:'.$height.'px']) }}>
@endif
