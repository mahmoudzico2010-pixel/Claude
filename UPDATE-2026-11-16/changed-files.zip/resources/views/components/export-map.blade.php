@props(['markets', 'light' => true])
@php
    $locale = app()->getLocale();
    $map = \App\Support\Geo\WorldMap::routes($markets, $locale);
    $H = $map['height'];
    [$ox, $oy] = $map['origin'];
    $egypt = \App\Support\Countries::name('EG', $locale) ?? 'Egypt';
    $uid = 'wrm'.substr(md5(uniqid('', true)), 0, 6);
@endphp
{{-- Animated export map: dotted land, Egypt as the fixed origin, gold arcs and lights that travel FROM Egypt TO each
     published market. Data-driven from the same market records as the list below; geometry is never mirrored in RTL.
     Under prefers-reduced-motion the lights are removed and the arcs stay as static routes. --}}
<figure class="wr-map" dir="ltr" data-routes="{{ count($map['routes']) }}">
    <svg viewBox="0 0 {{ \App\Support\Geo\WorldMap::WIDTH }} {{ $H }}" role="img" aria-labelledby="{{ $uid }}-t" preserveAspectRatio="xMidYMid meet" xmlns="http://www.w3.org/2000/svg">
        <title id="{{ $uid }}-t">{{ __('chrome.export_map.title', ['count' => count($map['routes'])]) }}</title>
        <defs>
            <radialGradient id="{{ $uid }}-glow" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#ffe9a8" stop-opacity=".95"/><stop offset="1" stop-color="#e0b24a" stop-opacity="0"/></radialGradient>
        </defs>
        <path d="{{ \App\Support\Geo\WorldMap::landPath() }}" fill="none" stroke="#76a98a" stroke-width="2.5" stroke-linecap="round" opacity=".85"/>

        @foreach ($map['routes'] as $r)
            @php
                $dur = 3.8 + ($r['i'] % 4) * 0.45;
                $begin = round(0.4 + $r['i'] * 0.55, 2);
            @endphp
            <path d="{{ $r['d'] }}" fill="none" stroke="#e2b955" stroke-width="1" stroke-opacity=".5" stroke-linecap="round" class="wr-arc"/>
            <g class="wr-light" opacity="0">
                <circle r="7" fill="url(#{{ $uid }}-glow)"/>
                <circle r="2.2" fill="#fff6d6"/>
                <animateMotion path="{{ $r['d'] }}" dur="{{ $dur }}s" begin="{{ $begin }}s" repeatCount="indefinite" calcMode="spline" keyTimes="0;1" keyPoints="0;1" keySplines=".42 0 .58 1"/>
                <animate attributeName="opacity" values="0;1;1;0" keyTimes="0;.1;.86;1" dur="{{ $dur }}s" begin="{{ $begin }}s" repeatCount="indefinite"/>
            </g>
            <circle cx="{{ $r['to'][0] }}" cy="{{ $r['to'][1] }}" r="3.1" fill="#e9c46a" stroke="#0d3b26" stroke-width="1"><title>{{ $r['name'] }}</title></circle>
            <circle cx="{{ $r['to'][0] }}" cy="{{ $r['to'][1] }}" r="3" fill="none" stroke="#f3d27a" stroke-width="1" opacity="0" class="wr-pulse">
                <animate attributeName="r" values="3;3;4;11" keyTimes="0;.82;.86;1" dur="{{ $dur }}s" begin="{{ $begin }}s" repeatCount="indefinite"/>
                <animate attributeName="opacity" values="0;0;.9;0" keyTimes="0;.82;.86;1" dur="{{ $dur }}s" begin="{{ $begin }}s" repeatCount="indefinite"/>
            </circle>
        @endforeach

        {{-- Origin --}}
        <circle cx="{{ $ox }}" cy="{{ $oy }}" r="12" fill="url(#{{ $uid }}-glow)" opacity=".8"/>
        <circle cx="{{ $ox }}" cy="{{ $oy }}" r="4.6" fill="#fff3c4" stroke="#c9972b" stroke-width="1.6"/>
        <circle cx="{{ $ox }}" cy="{{ $oy }}" r="4.6" fill="none" stroke="#f3d27a" stroke-width="1" class="wr-pulse">
            <animate attributeName="r" values="4.6;15" dur="2.6s" repeatCount="indefinite"/>
            <animate attributeName="opacity" values=".9;0" dur="2.6s" repeatCount="indefinite"/>
        </circle>
        <text x="{{ $ox }}" y="{{ $oy - 14 }}" text-anchor="middle" font-size="13" font-weight="700" fill="#fff3c4" paint-order="stroke" stroke="#0d3b26" stroke-width="3" stroke-linejoin="round" style="direction: {{ is_rtl($locale) ? 'rtl' : 'ltr' }}; unicode-bidi: plaintext">{{ $egypt }}</text>
    </svg>
    <style>
        .wr-map{margin:0;border-radius:14px;overflow:hidden;background:radial-gradient(120% 120% at 50% 40%,#12503a 0%,#0b3a29 55%,#082a1e 100%);box-shadow:inset 0 0 0 1px rgba(226,185,85,.22)}
        .wr-map svg{display:block;width:100%;height:auto}
        @media (prefers-reduced-motion: reduce){.wr-map .wr-light,.wr-map .wr-pulse{display:none}.wr-map .wr-arc{stroke-opacity:.8;stroke-dasharray:5 4}}
    </style>
</figure>
