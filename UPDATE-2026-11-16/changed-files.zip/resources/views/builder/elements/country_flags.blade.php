@php
    $markets = app(\App\Services\Builder\ElementData::class)->markets();
    $locale = app()->getLocale();
    $cols = max(1, min(8, (int) ($settings['columns'] ?? 4)));
    $names = ($settings['show_names'] ?? 'on') === 'on';
@endphp

@if ($markets->isNotEmpty())
    <ul data-builder-node="{{ $node['id'] }}" class="wr-node wr-country-flags grid gap-3" style="grid-template-columns: repeat(auto-fill, minmax({{ intdiv(1200, $cols * 2) }}px, 1fr))">
        @foreach ($markets as $market)
            <li class="flex items-center gap-2">
                <x-flag :code="$market->country_code" class="h-4 w-6 flex-none rounded-[2px]" />
                @if ($names)<span class="text-sm text-ink">{{ $market->localized('name') }}</span>@endif
            </li>
        @endforeach
    </ul>
@endif
