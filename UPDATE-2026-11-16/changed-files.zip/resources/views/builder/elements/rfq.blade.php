<div data-builder-node="{{ $node['id'] }}" class="wr-node wr-rfq rounded-lg bg-forest px-6 py-10 text-center text-white">
    <h2 class="text-h2">{{ filled($content['heading'] ?? null) ? $content['heading'] : __('site.cta.request_quote') }}</h2>
    @if (filled($content['text'] ?? null))<p class="mx-auto mt-3 max-w-xl text-white/80">{{ $content['text'] }}</p>@endif
    <a href="{{ route('quote.create') }}" class="btn btn-gold mt-6">{{ filled($content['button_label'] ?? null) ? $content['button_label'] : __('site.cta.request_quote') }}</a>
</div>
