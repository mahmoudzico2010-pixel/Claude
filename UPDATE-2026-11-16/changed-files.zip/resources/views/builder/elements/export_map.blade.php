<div data-builder-node="{{ $node['id'] }}" class="wr-node wr-export-map">
    <x-export-map :markets="app(\App\Services\Builder\ElementData::class)->markets()" />
</div>
