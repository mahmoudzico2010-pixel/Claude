@php
    $rows = collect(preg_split('/\R/', (string) ($content['data'] ?? '')))->map(function ($l) {
        [$label, $value] = array_pad(array_map('trim', explode('|', (string) $l, 2)), 2, '');

        return $label !== '' && is_numeric($value) && (float) $value >= 0 ? ['label' => $label, 'value' => (float) $value] : null;
    })->filter()->values();
    $total = max(0.0001, $rows->sum('value'));
    $max = max(0.0001, (float) $rows->max('value'));
    $color = ($settings['color'] ?? '') ?: 'var(--color-forest, #1f4d3a)';
    $donut = ($settings['chart_type'] ?? 'bar') === 'donut';
    $palette = ['#1f4d3a', '#b8903a', '#5b8a5a', '#8a6d2a', '#3b6e8f', '#a0522d'];
@endphp

@if ($rows->isNotEmpty())
    <figure data-builder-node="{{ $node['id'] }}" class="wr-node wr-chart">
        @if (filled($content['title'] ?? null))<figcaption class="mb-3 text-h3 text-ink">{{ $content['title'] }}</figcaption>@endif
        @if ($donut)
            @php($acc = 0)
            <div class="flex flex-wrap items-center gap-6">
                <svg width="160" height="160" viewBox="0 0 42 42" role="img" aria-label="{{ $content['title'] ?? '' }}">
                    @foreach ($rows as $i => $r)
                        @php($pct = $r['value'] / $total * 100)
                        <circle cx="21" cy="21" r="15.915" fill="none" stroke="{{ $palette[$i % count($palette)] }}" stroke-width="6" stroke-dasharray="{{ round($pct, 3) }} {{ round(100 - $pct, 3) }}" stroke-dashoffset="{{ round(25 - $acc, 3) }}"/>
                        @php($acc += $pct)
                    @endforeach
                </svg>
                <ul class="space-y-1 text-sm">
                    @foreach ($rows as $i => $r)
                        <li class="flex items-center gap-2"><span class="inline-block size-3 rounded-sm" style="background: {{ $palette[$i % count($palette)] }}"></span>{{ $r['label'] }} <span class="tabular-nums text-ink-muted">{{ rtrim(rtrim(number_format($r['value'], 2, '.', ''), '0'), '.') }}</span></li>
                    @endforeach
                </ul>
            </div>
        @else
            <ul class="space-y-2" dir="auto">
                @foreach ($rows as $r)
                    <li class="grid grid-cols-[8rem_1fr_auto] items-center gap-3 text-sm">
                        <span class="truncate text-ink">{{ $r['label'] }}</span>
                        <span class="h-3 rounded-sm bg-surface-sunken"><span class="block h-3 rounded-sm" style="width: {{ round($r['value'] / $max * 100, 1) }}%; background: {{ $color }}"></span></span>
                        <span class="tabular-nums text-ink-muted">{{ rtrim(rtrim(number_format($r['value'], 2, '.', ''), '0'), '.') }}</span>
                    </li>
                @endforeach
            </ul>
        @endif
    </figure>
@endif
