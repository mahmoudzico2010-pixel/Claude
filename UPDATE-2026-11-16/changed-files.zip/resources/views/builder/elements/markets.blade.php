@php
    $markets = app(\App\Services\Builder\ElementData::class)->markets();
    $locale = app()->getLocale();
@endphp

@if ($markets->isNotEmpty())
    <ul data-builder-node="{{ $node['id'] }}" class="wr-node wr-markets grid gap-4">
        @foreach ($markets as $market)
            <li class="flex items-center gap-3 rounded-lg bg-surface-alt px-4 py-3">
                <x-flag :code="$market->country_code" class="h-4 w-6 flex-none rounded-[2px]" />
                <span class="text-sm font-semibold text-ink">{{ $market->localized('name') }}</span>
            </li>
        @endforeach
    </ul>
@endif
