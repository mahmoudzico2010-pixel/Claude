@php
    $name = $settings['name'] ?? 'check';
    $size = max(16, min(160, (int) ($settings['size'] ?? 48)));
    $color = $settings['color'] ?? '';
    $paths = [
        'check' => '<circle cx="12" cy="12" r="9"/><path d="M8 12.5l3 3 5-6"/>',
        'globe' => '<circle cx="12" cy="12" r="9"/><ellipse cx="12" cy="12" rx="4" ry="9"/><path d="M3 12h18"/>',
        'truck' => '<path d="M3 6h11v9H3zM14 9h4l3 3v3h-7"/><circle cx="7" cy="17" r="2"/><circle cx="17" cy="17" r="2"/>',
        'ship' => '<path d="M3 15l2 4h14l2-4zM6 15V9h12v6M12 9V4"/>',
        'shield' => '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/>',
        'leaf' => '<path d="M5 19C5 10 10 5 20 4c0 10-5 15-14 15zM5 19l8-8"/>',
        'star' => '<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>',
        'clock' => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    ];
@endphp
<div data-builder-node="{{ $node['id'] }}" class="wr-node wr-icon text-center" @if ($color) style="color: {{ $color }}" @endif>
    <svg class="mx-auto" width="{{ $size }}" height="{{ $size }}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">{!! $paths[$name] ?? $paths['check'] !!}</svg>
    @if (filled($content['label'] ?? null))<p class="mt-2 text-sm font-medium text-ink">{{ $content['label'] }}</p>@endif
</div>
