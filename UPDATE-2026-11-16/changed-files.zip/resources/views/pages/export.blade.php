@extends('layouts.public')

@php($locale = app()->getLocale())

@section('content')
    <x-page-hero
        :eyebrow="__('site.nav.export')"
        :title="$page->t('title')"
        :subtitle="$page->t('subtitle')"
        :image="$page->featuredImage"
        :breadcrumbs="$seo->breadcrumbs"
    />

    @if ($page->t('body'))
        <section class="section">
            <div class="container-narrow">
                <div class="prose-wr">{!! $page->t('body') !!}</div>
            </div>
        </section>
    @endif

    @if ($services->isNotEmpty())
        <section class="section {{ $page->t('body') ? 'pt-0' : '' }}">
            <div class="container-wr">
                <x-section-heading :title="__('content.sections.export_services')" />
                <div class="mt-12 grid gap-10 sm:grid-cols-2 lg:grid-cols-3">
                    @foreach ($services as $service)
                        <div class="border-t-2 border-gold pt-6">
                            <h3 class="text-h3 text-ink">{{ $service->title($locale) }}</h3>
                            @if ($service->body($locale))
                                <p class="mt-3 text-[0.9375rem] leading-relaxed text-ink-muted">{{ $service->body($locale) }}</p>
                            @endif
                        </div>
                    @endforeach
                </div>
            </div>
        </section>
    @endif

    @if ($markets->isNotEmpty())
        <section class="section bg-forest text-white">
            <div class="container-wr">
                <x-section-heading light :title="__('admin.resources.export_market.plural')" />
                {{-- The map and the list read the same published markets, in the same order. --}}
                <div class="mt-10"><x-export-map :markets="$markets" /></div>
                <ul class="mt-10 grid grid-cols-2 gap-x-8 gap-y-3 sm:grid-cols-3 lg:grid-cols-4">
                    @foreach ($markets as $market)
                        <li class="flex items-center gap-3 border-b border-white/10 py-2.5 text-[0.9375rem] text-white/80">
                            <x-flag :code="$market->country_code" :height="18" />
                            <span>{{ $market->localized('name') }}</span>
                        </li>
                    @endforeach
                </ul>
            </div>
        </section>
    @endif

    <section class="bg-olive-deep">
        <div class="container-wr flex flex-col items-start gap-6 py-14 lg:flex-row lg:items-center lg:justify-between">
            <h2 class="text-h2 font-bold text-white">{{ __('forms.rfq.title') }}</h2>
            <a href="{{ route('quote.create') }}" class="btn btn-gold">{{ __('site.cta.request_quote') }}</a>
        </div>
    </section>
@endsection
