@extends('layouts.public')

@section('content')
    <x-page-hero :eyebrow="$category->parent ? (string) $category->parent->name() : __('site.nav.products')" :title="$name" :subtitle="$intro" :image="$category->image" :breadcrumbs="$seo->breadcrumbs" />

    @if ($isFamily && $children->isNotEmpty())
        <section class="section pb-0" aria-labelledby="subs-h">
            <div class="container-wr">
                <h2 id="subs-h" class="text-h2 text-ink">{{ __('catalogue.subcategories', ['name' => $name]) }}</h2>
                <div class="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                    @foreach ($children as $child)
                        @include('pages.products.partials.category-card', ['cat' => $child])
                    @endforeach
                </div>
            </div>
        </section>
    @endif

    <section class="section">
        <div class="container-wr">
            @if ($products->isNotEmpty())
                <h2 class="text-h2 text-ink">{{ __('catalogue.products_in', ['name' => $name]) }}</h2>
                <div class="mt-8 grid gap-6 sm:grid-cols-2 xl:grid-cols-3">
                    @foreach ($products as $product)
                        <x-product-card :product="$product" />
                    @endforeach
                </div>
            @else
                <div class="border border-line bg-surface-alt px-6 py-16 text-center">
                    <h2 class="text-h3 text-ink">{{ __('catalogue.empty_title') }}</h2>
                    <p class="mx-auto mt-3 max-w-md text-[0.9375rem] text-ink-muted">{{ __('catalogue.empty_text', ['name' => $name]) }}</p>
                    <div class="mt-7 flex flex-wrap justify-center gap-3">
                        <a href="{{ route('quote.create') }}" class="btn btn-primary">{{ __('catalogue.enquire', ['name' => $name]) }}</a>
                    </div>
                </div>
            @endif
        </div>
    </section>
@endsection
