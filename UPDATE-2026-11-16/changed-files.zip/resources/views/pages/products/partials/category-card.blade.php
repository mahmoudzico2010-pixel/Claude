@php($catName = (string) $cat->name())
<a href="{{ route('products.category', ['category' => $cat->slug]) }}" class="card card-hover group flex h-full flex-col overflow-hidden" aria-label="{{ __('catalogue.view', ['name' => $catName]) }}">
    <div class="media-frame media-frame-4-3 bg-forest">
        @if ($cat->image)
            <img src="{{ $cat->image->urlFor(640) }}" alt="{{ $cat->image->alt() ?: $catName }}" loading="lazy" decoding="async">
        @else
            <span class="flex size-full items-center justify-center bg-gradient-to-br from-forest to-olive-deep text-gold/70" aria-hidden="true"><svg width="56" height="56" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 19C5 10 10 5 20 4c0 10-5 15-14 15zM5 19l8-8"/></svg></span>
        @endif
    </div>
    <div class="p-5">
        <h3 class="text-h3 text-ink">{{ $catName }}</h3>
    </div>
</a>
