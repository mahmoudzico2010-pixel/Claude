@extends('layouts.public')

@section('content')
    <x-page-hero :title="$page->t('title')" :subtitle="$page->t('subtitle')" :image="$page->featuredImage" :breadcrumbs="$seo->breadcrumbs" />
    <div class="wr-built-page">
        @include('builder.page', ['payload' => $payload])
    </div>
@endsection
