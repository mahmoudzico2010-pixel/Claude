<x-filament-panels::page>
    <form wire:submit="save" class="space-y-6">
        {{ $this->form }}
        <x-filament::button type="submit">{{ __('frames.admin.save') }}</x-filament::button>
    </form>

    @php($p = $this->previewProduct())
    @if ($p)
        <section class="space-y-2" aria-label="{{ __('frames.admin.preview') }}">
            <h3 class="text-sm font-semibold">{{ __('frames.admin.preview') }}</h3>
            <div class="grid max-w-3xl gap-6 sm:grid-cols-2">
                <div class="max-w-xs"><x-product-card :product="$p" :frame="$this->previewFrame()" /></div>
                <div class="max-w-xs"><p class="mb-2 text-xs text-gray-500">{{ __('frames.admin.mode_none') }}</p><x-product-card :product="$p" :frame="false" /></div>
            </div>
        </section>
    @endif
</x-filament-panels::page>
