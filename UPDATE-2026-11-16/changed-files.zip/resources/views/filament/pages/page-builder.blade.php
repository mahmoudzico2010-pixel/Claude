{{--
    The visual builder.

    Left: the element library. Centre: the canvas. Right: the selected node's
    settings. Top: undo, save, preview and publish.

    Drag and drop is native HTML5, not a library. That is a deliberate choice —
    it adds no dependency to a build that has no Node on the server, and it
    degrades to the move buttons on each node rather than to nothing. Those
    buttons are not a fallback bolted on afterwards: a drag-only builder is
    unusable with a keyboard, so every structural change is reachable both ways.
--}}

<x-filament-panels::page>

    @php
        $tree = $this->tree();
        $selected = $this->selectedNode();
        $locales = array_keys((array) config('wadi.locales', []));
        $devices = ['desktop' => 'w-full', 'tablet' => 'w-[768px]', 'mobile' => 'w-[390px]'];

        /* A cache-busting token so the frame reloads after a change rather than
           showing a stale render. It is the draft's own fingerprint, so the URL
           only changes when the tree actually did. */
        $previewUrl = $this->previewUrl();
    @endphp

    {{-- ============================================================ TOOLBAR --}}
    <div class="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-gray-200 bg-white p-3 dark:border-white/10 dark:bg-gray-900">

        <div class="flex flex-wrap items-center gap-2">
            <x-filament::button
                wire:click="undo"
                color="gray"
                icon="heroicon-m-arrow-uturn-left"
                :disabled="! $this->canUndo()">
                {{ __('admin.builder.undo') }}
            </x-filament::button>

            <x-filament::button
                wire:click="redo"
                color="gray"
                icon="heroicon-m-arrow-uturn-right"
                :disabled="! $this->canRedo()">
                {{ __('admin.builder.redo') }}
            </x-filament::button>

            <x-filament::button wire:click="save" color="gray" icon="heroicon-m-check">
                {{ __('admin.builder.save_draft') }}
            </x-filament::button>

            {{-- Publish is the only control here that changes what a visitor
                 sees. Everything else acts on the draft. --}}
            <x-filament::button
                wire:click="publish"
                color="success"
                icon="heroicon-m-globe-alt"
                :disabled="! $this->isDirty()">
                {{ __('admin.builder.publish') }}
            </x-filament::button>
        </div>

        <div class="flex flex-wrap items-center gap-3">
            {{-- What is actually live, said plainly.

                 Without this the builder looks identical whether or not the
                 work has been made public, which is exactly the confusion that
                 separating draft from published exists to remove. --}}
            @if ($this->isDirty())
                <span class="inline-flex items-center gap-1.5 rounded-full bg-warning-50 px-2.5 py-1 text-xs font-medium text-warning-700 dark:bg-warning-500/10 dark:text-warning-400">
                    <span class="size-1.5 rounded-full bg-warning-500" aria-hidden="true"></span>
                    {{ __('admin.builder.unpublished') }}
                </span>
            @elseif ($this->publishedVersion() !== null)
                <span class="text-xs text-gray-400">
                    {{ __('admin.builder.live_version', ['version' => $this->publishedVersion()]) }}
                </span>
            @else
                <span class="text-xs text-gray-400">{{ __('admin.builder.never_published') }}</span>
            @endif

            {{-- Preview width. Changes the frame's width only: the page inside
                 is rendered by the same templates at every size, so this is the
                 real responsive behaviour rather than a simulation of it. --}}
            <div class="flex items-center gap-1" role="group" aria-label="{{ __('admin.builder.preview_width') }}">
                @foreach (['desktop', 'tablet', 'mobile'] as $device)
                    <x-filament::button
                        wire:click="$set('device', '{{ $device }}')"
                        :color="$this->device === $device ? 'primary' : 'gray'"
                        size="sm"
                        :aria-pressed="$this->device === $device ? 'true' : 'false'">
                        {{ __('admin.builder.devices.'.$device) }}
                    </x-filament::button>
                @endforeach
            </div>

            <x-filament::button
                tag="a"
                href="{{ route('home', ['locale' => app()->getLocale()]) }}"
                target="_blank"
                rel="noopener"
                color="gray"
                size="sm"
                icon="heroicon-m-arrow-top-right-on-square">
                {{ __('admin.builder.open_site') }}
            </x-filament::button>
        </div>
    </div>

    {{-- ==================================================== PUBLISHED HISTORY --}}
    @if ($this->history()->isNotEmpty())
        <details class="rounded-xl border border-gray-200 bg-white p-3 dark:border-white/10 dark:bg-gray-900">
            <summary class="cursor-pointer text-sm font-semibold text-gray-700 dark:text-gray-200">
                {{ __('admin.builder.history') }}
            </summary>

            <ul class="mt-3 divide-y divide-gray-100 dark:divide-white/5">
                @foreach ($this->history() as $revision)
                    <li class="flex flex-wrap items-center justify-between gap-2 py-2">
                        <div class="min-w-0 text-sm">
                            <span class="font-medium text-gray-700 dark:text-gray-200">
                                {{ __('admin.builder.version', ['version' => (int) $revision->version]) }}
                            </span>
                            <span class="text-gray-400">
                                · {{ $revision->created_at?->translatedFormat('j M Y, H:i') }}
                                @if ($revision->author)
                                    · {{ $revision->author->name }}
                                @endif
                                @if (filled($revision->label))
                                    · {{ $revision->label }}
                                @endif
                            </span>
                        </div>

                        @if (! $loop->first)
                            {{-- Reverting loads the version back into the DRAFT.
                                 It does not republish it — that stays a second,
                                 separate decision, so an accidental revert is
                                 not immediately visible to visitors. --}}
                            <x-filament::button
                                wire:click="revertTo({{ $revision->id }})"
                                wire:confirm="{{ __('admin.builder.confirm_revert') }}"
                                color="gray"
                                size="sm"
                                icon="heroicon-m-arrow-path">
                                {{ __('admin.builder.revert') }}
                            </x-filament::button>
                        @else
                            <span class="text-xs text-gray-400">{{ __('admin.builder.currently_live') }}</span>
                        @endif
                    </li>
                @endforeach
            </ul>
        </details>
    @endif

    <div class="grid gap-4 lg:grid-cols-[16rem_minmax(0,1fr)_20rem]">

        {{-- ==================================================== ELEMENT LIBRARY --}}
        <aside class="rounded-xl border border-gray-200 bg-white p-3 dark:border-white/10 dark:bg-gray-900">
            <h2 class="mb-3 text-sm font-semibold text-gray-700 dark:text-gray-200">
                {{ __('admin.builder.library') }}
            </h2>

            @foreach ($this->library() as $group => $types)
                <p class="mt-4 text-xs font-semibold uppercase tracking-wide text-gray-400">
                    {{ __('admin.builder.groups.'.$group) }}
                </p>

                <ul class="mt-2 space-y-1">
                    @foreach ($types as $type)
                        <li>
                            {{-- Draggable onto a column, and clickable as well:
                                 a click adds it to the selected column, which
                                 is the only route available from a keyboard. --}}
                            <button type="button"
                                    draggable="true"
                                    x-on:dragstart="$event.dataTransfer.setData('text/builder-type', '{{ $type }}')"
                                    wire:click="add('{{ $type }}', {{ $this->selectedId ?? 'null' }})"
                                    class="flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-start text-sm text-gray-700 hover:bg-gray-100 dark:text-gray-200 dark:hover:bg-white/5">
                                {{ __('admin.builder.types.'.$type) }}
                            </button>
                        </li>
                    @endforeach
                </ul>
            @endforeach
        </aside>

        {{-- ============================================================= CANVAS --}}
        <section class="rounded-xl border border-gray-200 bg-gray-50 dark:border-white/10 dark:bg-gray-950"
                 x-data="builderCanvas()"
                 x-on:builder-refresh.window="refresh($event.detail.url)"
                 x-on:builder-selected.window="highlight($event.detail.id)">

            {{-- Two views of the same tree.

                 The rendered preview is the page as it will actually publish —
                 same templates, same CSS, same partials. The outline is the
                 structural tree, which stays because it is the only way to see
                 and reach a node the preview cannot show: an empty column, a
                 hidden section, a node behind an overlay. They are views, not
                 modes: selecting in one selects in the other. --}}
            <div class="flex items-center justify-between gap-3 border-b border-gray-200 px-3 py-2 dark:border-white/10">
                <div class="flex items-center gap-1">
                    @foreach (['preview', 'outline'] as $view)
                        <button type="button"
                                wire:click="$set('canvasView', '{{ $view }}')"
                                @class([
                                    'rounded-lg px-3 py-1.5 text-xs font-semibold',
                                    'bg-primary-600 text-white' => $this->canvasView === $view,
                                    'text-gray-600 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-white/5' => $this->canvasView !== $view,
                                ])
                                aria-pressed="{{ $this->canvasView === $view ? 'true' : 'false' }}">
                            {{ __('admin.builder.views.'.$view) }}
                        </button>
                    @endforeach
                </div>

                @if ($this->trail() !== [])
                    <nav class="flex min-w-0 flex-wrap items-center gap-1 text-xs text-gray-500" aria-label="{{ __('admin.builder.trail') }}">
                        @foreach ($this->trail() as $ancestor)
                            <button type="button" wire:click="select({{ $ancestor['id'] }})" class="hover:underline">
                                {{ __('admin.builder.types.'.$ancestor['type']) }}
                            </button>
                            <span aria-hidden="true">/</span>
                        @endforeach
                    </nav>
                @endif
            </div>

            @if ($this->canvasView === 'preview')

                <div class="p-4">
                    <div class="mx-auto overflow-hidden rounded-lg border border-gray-200 bg-white shadow-sm transition-[width] dark:border-white/10 {{ $devices[$this->device] ?? 'w-full' }}">
                        {{--
                            The draft, rendered by the real public templates.

                            Same-origin, which is what lets the two talk: the
                            frame posts the id of whatever is clicked, and the
                            builder posts back the current selection so the two
                            never disagree about what is selected.

                            `wire:ignore` keeps Livewire's DOM diffing away from
                            it — without it, every re-render would replace the
                            iframe element and reload the page inside, losing
                            the scroll position on every keystroke.
                        --}}
                        <iframe wire:ignore
                                x-ref="frame"
                                src="{{ $previewUrl }}"
                                title="{{ __('admin.builder.views.preview') }}"
                                class="h-[70vh] w-full"
                                loading="lazy"></iframe>
                    </div>

                    <p class="mt-2 text-center text-xs text-gray-400">
                        {{ __('admin.builder.preview_hint') }}
                    </p>
                </div>

            @else

                <div class="p-4">
                    <div class="mx-auto transition-[width] {{ $devices[$this->device] ?? 'w-full' }}">
                        @forelse ($tree as $node)
                            @include('filament.pages.builder.node', ['node' => $node, 'depth' => 0])
                        @empty
                            <div class="rounded-lg border-2 border-dashed border-gray-300 p-8 text-center dark:border-white/10">
                                <p class="text-sm text-gray-500">{{ __('admin.builder.empty') }}</p>
                                <x-filament::button class="mt-3" wire:click="add('section')" icon="heroicon-m-plus">
                                    {{ __('admin.builder.add_section') }}
                                </x-filament::button>
                            </div>
                        @endforelse

                        @if ($tree !== [])
                            <button type="button"
                                    wire:click="add('section')"
                                    class="mt-3 w-full rounded-lg border-2 border-dashed border-gray-300 py-3 text-sm text-gray-500 hover:border-primary-400 hover:text-primary-600 dark:border-white/10">
                                + {{ __('admin.builder.add_section') }}
                            </button>
                        @endif
                    </div>
                </div>

            @endif
        </section>

        {{-- =========================================================== SETTINGS --}}
        <aside class="rounded-xl border border-gray-200 bg-white p-3 dark:border-white/10 dark:bg-gray-900">
            @if ($selected === null)
                <p class="text-sm text-gray-500">{{ __('admin.builder.select_prompt') }}</p>
            @else
                @include('filament.pages.builder.settings', [
                    'node' => $selected,
                    'locales' => $locales,
                ])
            @endif
        </aside>
    </div>


{{--
    The bridge between the builder and the rendered preview.

    Same-origin, so the two can post messages to each other — and the origin is
    checked on every inbound message rather than trusted, because an iframe can
    be addressed by anything that can reach this page and `event.origin` is the
    only part of a message that cannot be forged.

    Two directions:
      · the frame reports what was clicked, and the builder selects it
      · the builder reports what is selected, and the frame highlights it

    The frame is reloaded by changing its `src`, not by re-rendering the element:
    Livewire's DOM diffing would otherwise replace the iframe on every update
    and reload the page inside it, losing the scroll position on each keystroke.
--}}
<script>
    function builderCanvas() {
        return {
            init() {
                var self = this;

                window.addEventListener('message', function (event) {
                    if (event.origin !== window.location.origin) {
                        return;
                    }

                    var data = event.data;

                    if (!data || data.source !== 'wr-builder-preview') {
                        return;
                    }

                    if (data.type === 'select' && data.id) {
                        self.$wire.select(data.id);
                    }

                    // Text edited directly on the canvas (double-click a heading or paragraph).
                    if (data.type === 'inline' && data.id) {
                        self.$wire.inlineEdit(data.id, String(data.value || ''));
                    }

                    // The frame announces itself once it is listening, which is
                    // when the current selection can be pushed to it — sending
                    // earlier would post into a document that is not ready.
                    if (data.type === 'ready') {
                        self.highlight(self.$wire.get('selectedId'));
                    }
                });
            },

            highlight(id) {
                var frame = this.$refs.frame;

                if (!frame || !frame.contentWindow) {
                    return;
                }

                frame.contentWindow.postMessage({
                    source: 'wr-builder',
                    type: 'highlight',
                    id: id || null,
                }, window.location.origin);
            },

            refresh(url) {
                var frame = this.$refs.frame;

                if (frame && url) {
                    // Reassigning src rather than calling reload(): reload()
                    // re-requests the URL the frame already has, which after a
                    // fingerprint change is the previous version of the draft.
                    frame.src = url;
                }
            },
        };
    }
</script>

</x-filament-panels::page>
