@props([
    /** @var array<string, array<int, string>> */
    'filters' => [],
    'categories',
    'varieties',
    'forms',
    'colors' => [],
    'availabilities' => [],
])

@php
    /*
     | One description of every filter group, so the markup below is written
     | once rather than five times. `label_fn` picks how each option's label is
     | read: category translations live in a sibling table, the small lookups
     | keep name_en / name_ar inline, and colour and availability are plain
     | values.
     */
    $groups = array_values(array_filter([
        $categories->isNotEmpty() ? [
            'key' => 'category',
            'label' => __('site.products.category'),
            'options' => $categories->mapWithKeys(fn ($c) => [$c->slug => ($c->parent_id ? '— ' : '').($c->t('name') ?? $c->slug)])->all(),
        ] : null,

        $varieties->isNotEmpty() ? [
            'key' => 'variety',
            'label' => __('site.products.variety'),
            'options' => $varieties->mapWithKeys(fn ($v) => [$v->slug => $v->localized('name')])->all(),
        ] : null,

        $forms->isNotEmpty() ? [
            'key' => 'form',
            'label' => __('site.products.form'),
            'options' => $forms->mapWithKeys(fn ($f) => [$f->slug => $f->localized('name')])->all(),
        ] : null,

        $colors !== [] ? [
            'key' => 'color',
            'label' => __('site.products.color'),
            'options' => collect($colors)->mapWithKeys(fn (string $c) => [$c => $c])->all(),
        ] : null,

        $availabilities !== [] ? [
            'key' => 'availability',
            'label' => __('site.products.availability'),
            'options' => $availabilities,
        ] : null,
    ]));

    // Every active selection, flattened, so the chips can be rendered in one
    // pass and each one can build the URL that removes just itself.
    $active = [];

    foreach ($groups as $group) {
        foreach ((array) ($filters[$group['key']] ?? []) as $value) {
            if (! isset($group['options'][$value])) {
                continue;
            }

            $remaining = array_values(array_diff((array) $filters[$group['key']], [$value]));
            $query = $filters;
            $query[$group['key']] = $remaining;

            $active[] = [
                'label' => $group['options'][$value],
                'group' => $group['label'],
                // The URL with this one value dropped and everything else kept
                // — which is what "remove this chip" has to mean.
                'remove_url' => route('products.index', array_filter($query, fn ($v) => $v !== [])),
            ];
        }
    }
@endphp

{{--
    Product filters.

    Checkboxes, not radios. The previous version used radio inputs with
    `onchange="this.form.submit()"`, which meant choosing a second category
    replaced the first and reloaded the page on every single click — the two
    complaints this partial exists to fix.

    There is no auto-submit now. Selections accumulate and are applied once,
    which is also why this works with JavaScript disabled: it is an ordinary
    GET form, and every chip's remove control is a plain link.
--}}

<form method="GET" action="{{ route('products.index') }}" class="mt-5 lg:mt-0">
    <h2 class="hidden text-h3 text-ink lg:block">{{ __('site.products.filter_by') }}</h2>

    {{-- Active selections --}}
    @if ($active !== [])
        <div class="mt-5 border-b border-line pb-5">
            <p class="spec-label mb-3">{{ __('site.products.active_filters') }}</p>

            <ul class="flex flex-wrap gap-2">
                @foreach ($active as $chip)
                    <li>
                        <a href="{{ $chip['remove_url'] }}"
                           class="group inline-flex items-center gap-1.5 rounded-badge border border-line bg-surface-alt
                                  px-2.5 py-1 text-[0.8125rem] text-ink-muted transition-colors
                                  hover:border-olive-deep/40 hover:text-ink"
                           title="{{ __('site.products.remove_filter', ['value' => $chip['label']]) }}">
                            <span class="text-ink-subtle">{{ $chip['group'] }}:</span>
                            <span class="font-medium">{{ $chip['label'] }}</span>
                            <svg class="size-3 flex-none opacity-50 transition-opacity group-hover:opacity-100"
                                 viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true">
                                <path d="m3 3 6 6M9 3l-6 6" stroke-linecap="round"/>
                            </svg>
                            <span class="sr-only">{{ __('site.products.remove_filter', ['value' => $chip['label']]) }}</span>
                        </a>
                    </li>
                @endforeach
            </ul>

            <a href="{{ route('products.index') }}" class="link-rule mt-4">
                {{ __('site.products.clear_filters') }}
            </a>
        </div>
    @endif

    <div class="mt-6 space-y-6">
        @foreach ($groups as $group)
            @php($selected = (array) ($filters[$group['key']] ?? []))

            <fieldset class="border-t border-line pt-5 first:border-0 first:pt-0">
                <legend class="spec-label mb-3">{{ $group['label'] }}</legend>

                <ul class="space-y-2.5">
                    @foreach ($group['options'] as $value => $label)
                        <li>
                            <label class="flex cursor-pointer items-center gap-2.5 text-[0.9375rem] text-ink-muted
                                          transition-colors hover:text-ink">
                                {{-- `name="category[]"` is what makes the
                                     backend receive every ticked value rather
                                     than only the last one. --}}
                                <input type="checkbox"
                                       name="{{ $group['key'] }}[]"
                                       value="{{ $value }}"
                                       @checked(in_array((string) $value, array_map('strval', $selected), true))
                                       class="size-4 flex-none rounded-sm border-line-strong text-olive-deep
                                              focus:ring-2 focus:ring-olive-deep/30">
                                <span>{{ $label }}</span>
                            </label>
                        </li>
                    @endforeach
                </ul>
            </fieldset>
        @endforeach
    </div>

    <div class="mt-7 flex flex-wrap items-center gap-3">
        <button type="submit" class="btn btn-primary px-5 py-2.5 text-sm">
            {{ __('site.products.apply_filters') }}
        </button>

        @if ($active !== [])
            <a href="{{ route('products.index') }}" class="text-sm text-ink-muted underline-offset-4 hover:underline">
                {{ __('site.products.clear_filters') }}
            </a>
        @endif
    </div>
</form>
