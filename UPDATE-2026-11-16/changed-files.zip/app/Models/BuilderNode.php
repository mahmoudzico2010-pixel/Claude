<?php

declare(strict_types=1);

namespace App\Models;

use App\Models\Concerns\Auditable;
use App\Support\Builder\NodeSettings;
use App\Support\Builder\NodeTypes;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Facades\Cache;

/**
 * One node of the page builder tree.
 *
 * Sections, containers, columns and elements are all this model — they differ
 * only in `type`, and what each may contain is declared once in
 * `config/builder.php`. That is what lets a drag be validated with a single
 * question ("may this parent contain this child?") rather than a rule per
 * direction of movement.
 */
class BuilderNode extends Model
{
    use Auditable;

    /** Bumped whenever the rendered payload changes shape. */
    public const CACHE_VERSION = 1;

    protected $fillable = [
        'page_key', 'parent_id', 'type', 'sort_order', 'is_enabled',
        'settings', 'responsive', 'style',
    ];

    protected function casts(): array
    {
        return [
            'is_enabled' => 'boolean',
            'sort_order' => 'integer',
            'settings' => 'array',
            'responsive' => 'array',
            'style' => 'array',
        ];
    }

    protected static function booted(): void
    {
        /*
         | Saving a node does NOT flush the public cache, and that is the point.
         |
         | The public page renders the newest published revision, not these
         | rows. A draft edit therefore cannot change what a visitor sees, so
         | invalidating their cache on every keystroke-worth of admin work would
         | rebuild the same published payload over and over — real cost on
         | shared hosting, for no change in output.
         |
         | RevisionManager::publish() flushes, because publishing is the only
         | thing that changes what is served.
         */

        /*
         | Nothing reaches the database unvalidated.
         |
         | The admin screen validates too, but this is the gate that matters:
         | it covers a seeder, a console command, an import and any future
         | code path that has not been written yet. A JSON column with no
         | database-level constraint needs its guard at the model, not at one
         | of its callers.
         */
        static::saving(function (self $node): void {
            $node->settings = NodeSettings::clean((string) $node->type, (array) $node->settings);
            $node->style = NodeSettings::clean((string) $node->type, (array) $node->style, style: true);
            $node->responsive = is_array($node->responsive) ? $node->responsive : [];
        });
    }

    // ------------------------------------------------------------- relations

    public function parent(): BelongsTo
    {
        return $this->belongsTo(self::class, 'parent_id');
    }

    public function children(): HasMany
    {
        return $this->hasMany(self::class, 'parent_id')->orderBy('sort_order')->orderBy('id');
    }

    public function translations(): HasMany
    {
        return $this->hasMany(BuilderNodeTranslation::class);
    }

    // ---------------------------------------------------------------- scopes

    public function scopeForPage(Builder $query, string $pageKey): Builder
    {
        return $query->where('page_key', $pageKey);
    }

    public function scopeRoots(Builder $query): Builder
    {
        return $query->whereNull('parent_id');
    }

    public function scopeOrdered(Builder $query): Builder
    {
        return $query->orderBy('sort_order')->orderBy('id');
    }

    // --------------------------------------------------------------- reading

    /**
     * A translated setting for a locale, falling back the way the rest of the
     * site does: requested locale, then fallback locale, then anything present.
     */
    public function t(string $field, ?string $locale = null): ?string
    {
        $locale ??= app()->getLocale();
        $fallback = (string) config('app.fallback_locale', 'en');

        $byLocale = $this->relationLoaded('translations')
            ? $this->translations->keyBy('locale')
            : $this->translations()->get()->keyBy('locale');

        foreach ([$locale, $fallback] as $candidate) {
            $value = $byLocale->get($candidate)?->content[$field] ?? null;

            if (is_string($value) && $value !== '') {
                return $value;
            }
        }

        foreach ($byLocale as $translation) {
            $value = $translation->content[$field] ?? null;

            if (is_string($value) && $value !== '') {
                return $value;
            }
        }

        return null;
    }

    /**
     * A non-translated setting.
     */
    public function setting(string $name, ?string $default = null): ?string
    {
        $value = $this->settings[$name] ?? null;

        return is_string($value) ? $value : $default;
    }

    /**
     * The CSS scope for this node — the selector its custom CSS is confined to
     * and the attribute the renderer emits.
     */
    public function scopeSelector(): string
    {
        return '[data-builder-node="'.(int) $this->id.'"]';
    }

    public function canContain(string $childType): bool
    {
        return NodeTypes::canContain((string) $this->type, $childType);
    }

    // --------------------------------------------------------------- caching

    public static function flushCache(?string $pageKey = null): void
    {
        $pages = $pageKey !== null ? [$pageKey] : array_merge(['home'], static::query()->where('page_key', 'like', 'page:%')->distinct()->pluck('page_key')->all());

        foreach ($pages as $page) {
            foreach (array_keys((array) config('wadi.locales', ['en' => [], 'ar' => []])) as $locale) {
                Cache::forget(static::cacheKey($page, $locale));
            }
        }
    }

    public static function cacheKey(string $pageKey, string $locale): string
    {
        return 'wadi.builder.v'.self::CACHE_VERSION.'.'.$pageKey.'.'.$locale;
    }

    /**
     * Whether a draft tree exists for a page.
     *
     * This is NOT the switch between the builder and the Stage 2 renderer. That
     * switch is whether a *published* revision exists, which
     * RevisionManager::publishedTree() answers — a page can have a complete
     * draft tree and still correctly render the old homepage, because nothing
     * has been published yet.
     *
     * Used by the conversion command to refuse to run twice.
     */
    public static function hasTreeFor(string $pageKey): bool
    {
        return static::query()->forPage($pageKey)->exists();
    }
}
