<?php

declare(strict_types=1);

namespace App\Models;

use App\Enums\Availability;
use App\Enums\ContentStatus;
use App\Models\Concerns\Auditable;
use App\Models\Concerns\HasTranslations;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Collection;

class Product extends Model
{
    use Auditable;
    use HasFactory;
    use HasTranslations;
    use SoftDeletes;

    protected $fillable = [
        'slug', 'category_id', 'variety_id', 'product_form_id',
        'primary_image_id', 'spec_sheet_id', 'seo_image_id',
        'status', 'is_featured', 'display_order',
        'allow_multiple_calibers', 'allow_multiple_forms', 'allow_multiple_packaging',
        'frame_mode', 'frame_id', 'color', 'processing_method', 'stuffing', 'show_in_menu', 'combination_key', 'country_of_origin', 'hs_code', 'shelf_life_months', 'availability',
        'storage_temp_min', 'storage_temp_max',
        'published_at', 'created_by', 'updated_by',
    ];

    /** @var array<int, string> */
    public array $translatedAttributes = [
        'name', 'short_description', 'description', 'ingredients',
        'storage_conditions', 'export_notes', 'seo_title', 'seo_description',
    ];

    protected function casts(): array
    {
        return [
            'status' => ContentStatus::class,
            'availability' => Availability::class,
            'is_featured' => 'boolean',
            'show_in_menu' => 'boolean',
            'allow_multiple_calibers' => 'boolean',
            'allow_multiple_forms' => 'boolean',
            'allow_multiple_packaging' => 'boolean',
            'display_order' => 'integer',
            'shelf_life_months' => 'integer',
            'storage_temp_min' => 'integer',
            'storage_temp_max' => 'integer',
            'published_at' => 'datetime',
        ];
    }

    /**
     * The combination that makes a product materially distinct. Variety, form, colour, processing method and
     * stuffing are separate attributes, so "natural black" and "black oxidized" (or whole and sliced) can never be
     * the same product. Kept on every save so the matrix and imports recognise an existing combination.
     */
    public static function combinationKeyFor(?int $categoryId, ?int $varietyId, ?int $formId, ?string $color, ?string $processing, ?string $stuffing): string
    {
        $norm = fn (?string $v): string => mb_strtolower(trim((string) preg_replace('/\s+/u', ' ', (string) $v)));

        return implode('|', [(int) $categoryId, (int) $varietyId, (int) $formId, $norm($color), $norm($processing), $norm($stuffing)]);
    }

    protected static function booted(): void
    {
        static::saving(function (self $p): void {
            $p->combination_key = self::combinationKeyFor($p->category_id, $p->variety_id, $p->product_form_id, $p->color, $p->processing_method, $p->stuffing);
        });
    }

    public function frame(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(ProductFrame::class, 'frame_id');
    }

    public function nutrition(): \Illuminate\Database\Eloquent\Relations\HasOne
    {
        return $this->hasOne(ProductNutrition::class);
    }

    /**
     * The other available forms of the same variety, colour, processing and stuffing: the sibling child pages.
     *
     * @return Collection<int, self>
     */
    public function siblingForms(): Collection
    {
        if ($this->variety_id === null) {
            return collect();
        }

        return self::query()->published()->withTranslation()->with('form')
            ->where('category_id', $this->category_id)->where('variety_id', $this->variety_id)
            ->where('id', '!=', $this->id)
            ->where('color', $this->color)->where('processing_method', $this->processing_method)->where('stuffing', $this->stuffing)
            ->get()->sortBy(fn (self $p): array => [(int) ($p->form?->display_order ?? 0), $p->display_order, $p->id])->values();
    }

    public function translationModel(): string
    {
        return ProductTranslation::class;
    }

    // -------------------------------------------------------- Relationships

    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class);
    }

    public function variety(): BelongsTo
    {
        return $this->belongsTo(Variety::class);
    }

    public function form(): BelongsTo
    {
        return $this->belongsTo(ProductForm::class, 'product_form_id');
    }

    public function primaryImage(): BelongsTo
    {
        return $this->belongsTo(MediaAsset::class, 'primary_image_id');
    }

    public function specSheet(): BelongsTo
    {
        return $this->belongsTo(MediaAsset::class, 'spec_sheet_id');
    }

    public function seoImage(): BelongsTo
    {
        return $this->belongsTo(MediaAsset::class, 'seo_image_id');
    }

    public function images(): HasMany
    {
        return $this->hasMany(ProductImage::class)->orderBy('display_order');
    }

    public function specifications(): HasMany
    {
        return $this->hasMany(ProductSpecification::class)->orderBy('display_order');
    }

    public function calibers(): BelongsToMany
    {
        return $this->belongsToMany(Caliber::class)
            ->withPivot('display_order')
            ->orderByPivot('display_order');
    }

    public function packagingTypes(): BelongsToMany
    {
        return $this->belongsToMany(PackagingType::class, 'product_packaging')
            ->withPivot(['drained_weight_g', 'net_weight_g', 'gross_weight_g', 'units_per_carton', 'display_order'])
            ->orderByPivot('display_order');
    }

    public function certifications(): BelongsToMany
    {
        return $this->belongsToMany(Certification::class);
    }

    public function relatedProducts(): BelongsToMany
    {
        return $this->belongsToMany(self::class, 'product_related', 'product_id', 'related_product_id')
            ->withPivot('display_order')
            ->orderByPivot('display_order');
    }

    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function editor(): BelongsTo
    {
        return $this->belongsTo(User::class, 'updated_by');
    }

    public function quoteItems(): HasMany
    {
        return $this->hasMany(QuoteRequestItem::class);
    }

    // --------------------------------------------------------------- Scopes

    public function scopePublished(Builder $query): Builder
    {
        return $query->where('status', ContentStatus::Published)
            ->where(function (Builder $q): void {
                $q->whereNull('published_at')->orWhere('published_at', '<=', now());
            });
    }

    public function scopeFeatured(Builder $query): Builder
    {
        return $query->where('is_featured', true);
    }

    public function scopeOrdered(Builder $query): Builder
    {
        return $query->orderBy('display_order')->orderBy('id');
    }

    /**
     * Everything a catalogue card needs, in a fixed number of queries.
     */
    public function scopeForCard(Builder $query): Builder
    {
        return $query->withTranslation()->with([
            'primaryImage',
            // displayImage() falls back to the gallery when no primary image is
            // set, so the gallery must be loaded with the card. Without it the
            // fallback lazy-loads per card — an N+1 in production, and an
            // exception everywhere else, because the models are strict outside
            // production.
            'images.media',
            'category' => fn ($q) => $q->withTranslation(),
        ]);
    }

    /**
     * Everything the detail page needs.
     */
    public function scopeForDetail(Builder $query): Builder
    {
        return $query->withTranslation()->with([
            'primaryImage',
            'specSheet',
            'seoImage',
            'images.media',
            'specifications',
            'calibers',
            'certifications',
            'variety',
            'form',
            'category' => fn ($q) => $q->withTranslation(),
            'packagingTypes' => fn ($q) => $q->withTranslation(),
        ]);
    }

    // -------------------------------------------------------------- Helpers

    public function getRouteKeyName(): string
    {
        return 'slug';
    }

    public function name(?string $locale = null): ?string
    {
        return $this->t('name', $locale);
    }

    public function isPublished(): bool
    {
        return $this->status === ContentStatus::Published
            && ($this->published_at === null || $this->published_at->isPast());
    }

    /**
     * Gallery images with the primary one first. Falls back to the standalone
     * primary image when no gallery rows exist.
     *
     * @return Collection<int, MediaAsset>
     */
    public function galleryImages(): Collection
    {
        $gallery = $this->images
            ->sortByDesc(fn (ProductImage $i): bool => (bool) $i->is_primary)
            ->map(fn (ProductImage $i): ?MediaAsset => $i->media)
            ->filter()
            ->values();

        if ($gallery->isEmpty() && $this->primaryImage) {
            return collect([$this->primaryImage]);
        }

        return $gallery;
    }

    public function displayImage(): ?MediaAsset
    {
        return $this->primaryImage ?? $this->galleryImages()->first();
    }

    /**
     * Storage temperature as a display string, or null when unset so the
     * public page can omit the row entirely.
     */
    public function storageTemperatureRange(): ?string
    {
        if ($this->storage_temp_min === null && $this->storage_temp_max === null) {
            return null;
        }

        if ($this->storage_temp_min !== null && $this->storage_temp_max !== null) {
            return $this->storage_temp_min.'–'.$this->storage_temp_max.' °C';
        }

        return ($this->storage_temp_min ?? $this->storage_temp_max).' °C';
    }

    /**
     * The specification rows the public page should render, already filtered
     * so empty optional fields never appear.
     *
     * @return array<int, array{label: string, value: string}>
     */
    public function publicSpecifications(?string $locale = null): array
    {
        $locale ??= app()->getLocale();

        $rows = [
            ['label' => __('product.spec.category'), 'value' => $this->category?->t('name', $locale)],
            ['label' => __('product.spec.variety'), 'value' => $this->variety?->localized('name', $locale)],
            ['label' => __('product.spec.form'), 'value' => $this->form?->localized('name', $locale)],
            ['label' => __('product.spec.color'), 'value' => $this->color],
            ['label' => __('catalog.spec.processing'), 'value' => $this->processing_method],
            ['label' => __('catalog.spec.stuffing'), 'value' => $this->stuffing],
            ['label' => __('product.spec.ingredients'), 'value' => $this->t('ingredients', $locale)],
            ['label' => __('product.spec.calibers'), 'value' => $this->calibers->map(fn (Caliber $c): string => $c->code)->implode(', ') ?: null],
            ['label' => __('product.spec.shelf_life'), 'value' => $this->shelf_life_months
                ? trans_choice('product.months', $this->shelf_life_months, ['count' => $this->shelf_life_months])
                : null],
            ['label' => __('product.spec.storage'), 'value' => $this->t('storage_conditions', $locale) ?? $this->storageTemperatureRange()],
            ['label' => __('product.spec.origin'), 'value' => $this->country_of_origin],
            ['label' => __('product.spec.hs_code'), 'value' => $this->hs_code],
            ['label' => __('product.spec.availability'), 'value' => $this->availability?->getLabel()],
        ];

        // Administrator-defined extra rows.
        foreach ($this->specifications as $spec) {
            $rows[] = [
                'label' => $spec->localized('label', $locale),
                'value' => $spec->localized('value', $locale),
            ];
        }

        return array_values(array_filter(
            $rows,
            fn (array $row): bool => filled($row['value']) && filled($row['label'])
        ));
    }
}
