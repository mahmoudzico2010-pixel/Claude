<?php

declare(strict_types=1);

namespace App\Services\Homepage;

use App\Models\Category;
use App\Models\Certification;
use App\Models\ContentBlock;
use App\Models\ExportMarket;
use App\Models\HeroSlide;
use App\Models\HeroSlideTranslation;
use App\Models\HomeSection;
use App\Models\HomeSectionTranslation;
use App\Models\MediaAsset;
use App\Models\NewsPost;
use App\Models\Product;
use App\Packaging\Data\Family;
use App\Packaging\PackagingCatalog;
use App\Services\Launch\LaunchReadiness;
use App\Services\Seo\SchemaBuilder;
use App\Services\Seo\SeoData;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Cache;

/**
 * Everything the homepage templates need, from one snapshot, for one locale.
 *
 * The public homepage (published snapshot) and the admin preview (draft
 * snapshot) both come through here, into the same templates — what the
 * preview shows is what publishing produces.
 *
 * Homepage-owned values come from the snapshot. Shared content is read live
 * from its canonical tables, published and active records only; a hand-picked
 * selection stores ids, and an id whose record is gone, inactive or
 * unpublished is simply not shown. "Automatic" sources run exactly the
 * queries the homepage always ran, so adopting changes nothing on screen.
 */
final class HomepageView
{
    /** Core sections the templates know, in their shipped order. */
    public const CORE = [
        'hero', 'statistics', 'categories', 'featured', 'packaging', 'values',
        'production', 'certifications', 'markets', 'news', 'cta',
    ];

    public function __construct(private readonly LaunchReadiness $readiness) {}

    /**
     * @param  int|null  $cacheRevision  the published revision id, to cache the
     *                                   expensive parts; null (preview) = no cache
     * @return array<string, mixed>
     */
    public function data(HomepageSnapshot $snapshot, string $locale, ?int $cacheRevision = null): array
    {
        $now = now();
        [$sections, $slides] = $this->arrangement($snapshot, $locale, $now, $cacheRevision);

        $heroImageId = $snapshot->setting('home.hero_image');

        return [
            'homepage' => $snapshot,
            'seo' => $this->seo($snapshot, $locale),

            'sections' => $sections,
            'heroSlides' => $slides,
            'heroImage' => filled($heroImageId) ? MediaAsset::find((int) $heroImageId) : null,
            // Optional phone image for the settings-driven hero; none = as before.
            'heroImageMobile' => filled($snapshot->setting('home.hero_mobile_image'))
                ? MediaAsset::find((int) $snapshot->setting('home.hero_mobile_image')) : null,
            'heroTitle' => $snapshot->text('hero_title', $locale),
            'heroSubtitle' => $snapshot->text('hero_subtitle', $locale),
            'heroEyebrow' => $snapshot->text('hero_eyebrow', $locale),

            ...$this->sharedContent($snapshot, $sections),
        ];
    }

    // ------------------------------------------------------------ arrangement

    /**
     * Sections and live slides as plain arrays — the expensive part (HTML
     * sanitising, layout CSS), cached per published revision and locale until
     * the next slide schedule boundary.
     *
     * @return array{0: list<array<string, mixed>>, 1: list<array<string, mixed>>}
     */
    private function arrangement(HomepageSnapshot $snapshot, string $locale, Carbon $now, ?int $cacheRevision): array
    {
        if ($cacheRevision !== null) {
            $cached = Cache::get(HomepageRepository::renderKey($cacheRevision, $locale));

            if (is_array($cached) && isset($cached['sections'], $cached['slides'])) {
                return [$cached['sections'], $cached['slides']];
            }
        }

        $sections = $this->sections($snapshot, $locale);
        $slides = $this->slides($snapshot, $locale, $now);

        if ($cacheRevision !== null) {
            $ttl = (int) config('wadi.cache.ttl', 3600);
            $boundary = $this->nextBoundary($snapshot, $now);

            if ($boundary !== null) {
                $ttl = min($ttl, max(60, (int) $now->diffInSeconds($boundary) + 1));
            }

            Cache::put(HomepageRepository::renderKey($cacheRevision, $locale), compact('sections', 'slides'), $ttl);
        }

        return [$sections, $slides];
    }

    /**
     * Active sections, in order, through the same HomeSection code the
     * homepage always used — hydrated from the snapshot instead of queried.
     *
     * @return list<array<string, mixed>>
     */
    public function sections(HomepageSnapshot $snapshot, string $locale): array
    {
        $out = [];

        foreach ($snapshot->sections() as $row) {
            if (! ($row['is_active'] ?? false)) {
                continue;
            }

            $section = new HomeSection;
            $section->forceFill(collect($row)->except(['translations', 'id'])->all());
            $section->id = (int) $row['id'];
            $section->exists = true;
            $section->setRelation('translations', new Collection(array_map(
                fn (string $loc, array $t): HomeSectionTranslation => (new HomeSectionTranslation)->forceFill($t + ['locale' => $loc]),
                array_keys((array) $row['translations']),
                array_values((array) $row['translations']),
            )));

            $out[] = HomeSection::normalise($section->toPublicArray($locale));
        }

        // As before: an empty arrangement renders the shipped default order
        // rather than a blank homepage.
        return $out !== [] ? $out : HomeSection::defaults();
    }

    /**
     * Slides live at `$now`, in order, as HeroSlide::liveFor() built them.
     *
     * @return list<array<string, mixed>>
     */
    public function slides(HomepageSnapshot $snapshot, string $locale, Carbon $now): array
    {
        $live = array_values(array_filter($snapshot->slides(), function (array $row) use ($now): bool {
            $starts = $row['starts_at'] ? Carbon::parse($row['starts_at']) : null;
            $ends = $row['ends_at'] ? Carbon::parse($row['ends_at']) : null;

            return ($row['is_active'] ?? false)
                && ($starts === null || $starts->lte($now))
                && ($ends === null || $ends->gte($now));
        }));

        $mediaIds = [];
        foreach ($live as $row) {
            $mediaIds = array_merge($mediaIds, LocalizedMedia::slideMediaIds($row));
        }
        $media = MediaAsset::query()->whereKey(array_values(array_unique(array_filter($mediaIds))))->get()->keyBy('id');

        // Language scope, per-language mode (inherit / custom / disabled), override media and order, validity.
        $live = LocalizedMedia::slides($live, $locale, $media);

        $out = [];

        foreach ($live as $row) {
            $slide = new HeroSlide;
            $slide->forceFill(collect($row)->except(['translations', 'id'])->all());
            $slide->id = (int) $row['id'];
            $slide->exists = true;
            $slide->setRelation('image', $media->get((int) ($row['image_id'] ?? 0)));
            $slide->setRelation('imageMobile', $media->get((int) ($row['image_mobile_id'] ?? 0)));
            $slide->setRelation('video', $media->get((int) ($row['video_id'] ?? 0)));
            $slide->setRelation('translations', new Collection(array_map(
                fn (string $loc, array $t): HeroSlideTranslation => (new HeroSlideTranslation)->forceFill($t + ['locale' => $loc]),
                array_keys((array) $row['translations']),
                array_values((array) $row['translations']),
            )));

            $out[] = $slide->toPublicArray($locale);
        }

        return array_slice($out, 0, (int) config('wadi.hero.max_slides', 30));
    }

    /** The next moment a slide or the intro video starts or stops. */
    public function nextBoundary(HomepageSnapshot $snapshot, Carbon $now): ?Carbon
    {
        $candidates = [];

        foreach ($snapshot->slides() as $row) {
            foreach (['starts_at', 'ends_at'] as $column) {
                if (! empty($row[$column]) && Carbon::parse($row[$column])->gt($now)) {
                    $candidates[] = Carbon::parse($row[$column]);
                }
            }
        }

        foreach (['home.intro_starts_at', 'home.intro_ends_at'] as $key) {
            $value = $snapshot->setting($key);
            if (filled($value) && Carbon::parse((string) $value)->gt($now)) {
                $candidates[] = Carbon::parse((string) $value);
            }
        }

        return collect($candidates)->sort()->first();
    }

    // ---------------------------------------------------------------- SEO

    private function seo(HomepageSnapshot $snapshot, string $locale): SeoData
    {
        $imageId = $snapshot->setting('home.seo_image');

        return SeoData::make()
            ->title($snapshot->setting('home.seo_title_'.$locale) ?: $snapshot->setting('home.seo_title_en') ?: null)
            ->description($snapshot->setting('home.seo_description_'.$locale) ?: $snapshot->setting('home.seo_description_en') ?: null)
            ->image(filled($imageId) ? MediaAsset::find((int) $imageId) : null)
            ->schema(SchemaBuilder::organisation())
            ->schema([
                '@context' => 'https://schema.org',
                '@type' => 'WebSite',
                'name' => setting('company.name_'.$locale) ?? config('app.name'),
                'url' => url('/'.$locale),
            ]);
    }

    // ------------------------------------------------------- shared content

    /**
     * Live canonical records for the sections that are actually on the page.
     * A section that is switched off costs no query.
     *
     * @param  list<array<string, mixed>>  $sections
     * @return array<string, mixed>
     */
    private function sharedContent(HomepageSnapshot $snapshot, array $sections): array
    {
        $on = array_flip(array_filter(array_map(fn (array $s) => $s['key'] ?? null, $sections)));
        $empty = new Collection;

        $statistics = isset($on['statistics']) ? $this->statistics($snapshot) : $empty;
        $certifications = isset($on['certifications']) ? $this->certifications($snapshot) : $empty;

        return [
            'featuredProducts' => isset($on['featured']) ? $this->featured($snapshot) : $empty,
            'categories' => isset($on['categories']) ? $this->categories($snapshot) : $empty,
            'statistics' => $statistics,
            'showStatistics' => isset($on['statistics']) && ($snapshot->isManual('statistics')
                ? $statistics->filter(fn (ContentBlock $b): bool => filled($b->value_text))->count() >= 2
                : $this->readiness->showStatistics()),
            'values' => isset($on['values']) ? $this->blocks($snapshot, 'values', ContentBlock::SECTION_VALUES, 4) : $empty,
            'productionSteps' => isset($on['production']) ? $this->blocks($snapshot, 'production', ContentBlock::SECTION_PRODUCTION, null) : $empty,
            'certifications' => $certifications,
            'showCertifications' => isset($on['certifications']) && ($snapshot->isManual('certifications')
                ? $certifications->isNotEmpty()
                : $this->readiness->showCertifications()),
            'latestNews' => isset($on['news']) ? $this->news($snapshot) : $empty,
            'markets' => isset($on['markets']) ? $this->markets($snapshot) : $empty,
            'packagingFamilies' => isset($on['packaging']) ? $this->packaging($snapshot) : [],
        ];
    }

    private function limit(HomepageSnapshot $snapshot, string $key, ?int $default, int $max = 24): ?int
    {
        $value = $snapshot->setting('home.'.$key.'_limit');

        if ($value === null || $value === '') {
            return $default;
        }

        return max(1, min((int) $value, $max));
    }

    /**
     * Restrict a query to a hand-picked selection and keep the picked order.
     *
     * @return Collection<int, Model>
     */
    private function picked(Builder $query, array $ids, ?int $limit): Collection
    {
        if ($ids === []) {
            return new Collection;
        }

        $rows = $query->whereIn($query->getModel()->getQualifiedKeyName(), $ids)->get()
            ->sortBy(fn ($m): int => (int) array_search((int) $m->getKey(), $ids, true))
            ->values();

        return new Collection($limit === null ? $rows->all() : $rows->take($limit)->all());
    }

    /** As HomeController::featuredProducts() always selected them. */
    private function featured(HomepageSnapshot $snapshot): Collection
    {
        $limit = max(1, min((int) ($snapshot->setting('home.featured_limit') ?: 6), 12));
        $source = $snapshot->setting('home.featured_source') ?: 'auto';

        if ($source === 'manual') {
            $ids = $snapshot->setting('home.featured_products');
            $ids = is_string($ids) ? json_decode($ids, true) : $ids;
            $ids = array_values(array_filter(array_map('intval', (array) $ids)));

            if ($ids !== []) {
                $products = Product::query()->published()->forCard()->whereIn('id', $ids)->limit($limit)->get();

                return $products->sortBy(fn (Product $p): int => array_search($p->id, $ids, true))->values();
            }
        }

        $featured = Product::query()->published()->featured()->forCard()->ordered()->limit($limit)->get();

        return $featured->isNotEmpty()
            ? $featured
            : Product::query()->published()->forCard()->ordered()->limit($limit)->get();
    }

    private function categories(HomepageSnapshot $snapshot): Collection
    {
        $query = Category::query()->active()->withTranslation()->with('image');
        $limit = $this->limit($snapshot, 'categories', 6);

        return $snapshot->isManual('categories')
            ? $this->picked($query, $snapshot->selection('categories'), $limit)
            : $query->roots()->ordered()->limit($limit)->get();
    }

    private function statistics(HomepageSnapshot $snapshot): Collection
    {
        $query = ContentBlock::query()->section(ContentBlock::SECTION_STATISTICS)->active();

        return $snapshot->isManual('statistics')
            ? $this->picked($query, $snapshot->selection('statistics'), 4)
            : $query->ordered()->get();
    }

    private function blocks(HomepageSnapshot $snapshot, string $key, string $section, ?int $default): Collection
    {
        $query = ContentBlock::query()->section($section)->active();
        $limit = $this->limit($snapshot, $key, $default);

        if ($snapshot->isManual($key)) {
            return $this->picked($query, $snapshot->selection($key), $limit);
        }

        $query->ordered();

        return $limit === null ? $query->get() : $query->limit($limit)->get();
    }

    private function certifications(HomepageSnapshot $snapshot): Collection
    {
        // Evidence is required either way: an unevidenced badge never ships.
        $query = Certification::query()->active()
            ->where(fn ($q) => $q->whereNotNull('logo_id')->orWhereNotNull('document_id'))
            ->with('logo');
        $limit = $this->limit($snapshot, 'certifications', 8);

        return $snapshot->isManual('certifications')
            ? $this->picked($query, $snapshot->selection('certifications'), $limit)
            : $query->ordered()->limit($limit)->get();
    }

    private function news(HomepageSnapshot $snapshot): Collection
    {
        $query = NewsPost::query()->published()->withTranslation()->with('featuredImage');
        $limit = $this->limit($snapshot, 'news', 3, 12);

        return $snapshot->isManual('news')
            ? $this->picked($query, $snapshot->selection('news'), $limit)
            : $query->latestFirst()->limit($limit)->get();
    }

    private function markets(HomepageSnapshot $snapshot): Collection
    {
        $query = ExportMarket::query()->where('is_active', true);
        $limit = $this->limit($snapshot, 'markets', 12, 48);

        return $snapshot->isManual('markets')
            ? $this->picked($query, $snapshot->selection('markets'), $limit)
            : $query->orderBy('display_order')->limit($limit)->get();
    }

    /**
     * Packaging families from the canonical packaging catalogue.
     *
     * @return list<Family>
     */
    private function packaging(HomepageSnapshot $snapshot): array
    {
        $families = app(PackagingCatalog::class)->families();
        $limit = $this->limit($snapshot, 'packaging', 6);

        return array_slice(array_values($families), 0, $limit);
    }
}
