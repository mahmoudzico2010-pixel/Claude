<?php

declare(strict_types=1);

namespace App\Services\Navigation;

use App\Models\Category;
use App\Models\Product;
use App\Services\Catalog\CatalogTree;

/**
 * The generated part of the Products menu, as plain rows for the navigation cache: category → variety → Overview + one
 * link per available form. Labels and destinations are for one language. Nothing here is stored: publishing, archiving
 * or reordering a product, variety or category changes the next build (the navigation cache is flushed by the catalogue
 * observers), and the rows carry no id, so a language sign-off snapshot can never hide or relabel them.
 */
final class CatalogMenu
{
    /** @return list<array<string, mixed>> */
    public function rows(string $locale): array
    {
        $cats = Category::query()->active()->where('show_in_menu', true)->with('translations')->ordered()->get();
        $out = [];
        foreach ($cats->whereNull('parent_id') as $family) {
            $children = $cats->where('parent_id', $family->id)->map(fn (Category $c): array => $this->row($this->name($c, $locale), $this->url($c, $locale), $locale))->values()->all();
            $out[] = $this->row($this->name($family, $locale), $this->url($family, $locale), $locale, $children);
        }

        return $out;
    }

    private function name(Category $c, string $locale): string
    {
        return (string) ($c->t('name', $locale) ?: $c->slug);
    }

    private function url(Category $c, string $locale): string
    {
        return route('products.category', ['locale' => $locale, 'category' => $c->slug]);
    }

    /** "Whole", "Stuffed (pimiento)", … the form name plus the variant that makes it a distinct product. */
    private function productLabel(Product $p, string $locale): string
    {
        $label = (string) ($p->form?->localized('name', $locale) ?: $p->t('name', $locale) ?: $p->slug);
        $extra = array_filter([$p->stuffing, $p->processing_method, $p->color]);

        return $extra === [] ? $label : $label.' ('.implode(', ', $extra).')';
    }

    /** @return array<string, mixed> */
    private function row(string $label, string $url, string $locale, array $children = []): array
    {
        return [
            'id' => null, 'location' => 'header', 'label_en' => $label, 'label_ar' => $label, 'label_'.$locale => $label,
            'route_name' => null, 'page_id' => null, 'page_slug' => null, 'document_id' => null, 'document_slug' => null,
            'url' => $url, 'anchor' => null, 'source' => null, 'open_in_new_tab' => false, 'display_order' => 0,
            'children' => $children,
        ];
    }
}
