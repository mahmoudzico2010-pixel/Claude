<?php

declare(strict_types=1);

namespace App\Services\Catalog;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Support\Collection;

/**
 * The published catalogue as a tree: category → variety → forms (child products). It is the only thing the
 * navigation, the variety pages and the sitemap read, so a product that is published, archived, unpublished or
 * reordered changes all of them at once. Products without a variety hang directly under their category.
 */
final class CatalogTree
{
    /**
     * @return Collection<int, array{category: Category, varieties: Collection<int, array{variety: \App\Models\Variety, products: Collection<int, Product>}>, loose: Collection<int, Product>}>
     */
    public static function build(bool $menuOnly = false): Collection
    {
        $products = Product::query()->published()->withTranslation()
            ->with(['variety', 'form', 'category'])
            ->when($menuOnly, fn ($q) => $q->where('show_in_menu', true))
            ->orderBy('display_order')->orderBy('id')->get();

        $cats = Category::query()->active()->withTranslation()->ordered()
            ->when($menuOnly, fn ($q) => $q->where('show_in_menu', true))->get();
        $families = $cats->whereNull('parent_id')->values();

        return $families->map(function (Category $cat) use ($products, $menuOnly, $cats): ?array {
            // A family shows its own products and those of its subcategories, each once.
            $ids = $cats->where('parent_id', $cat->id)->pluck('id')->push($cat->id)->all();
            $mine = $products->whereIn('category_id', $ids);
            $varieties = $mine->whereNotNull('variety_id')->groupBy('variety_id')->map(function (Collection $group) use ($menuOnly): ?array {
                $variety = $group->first()->variety;
                if ($variety === null || ! $variety->is_active || ($menuOnly && ! $variety->show_in_menu)) {
                    return null;
                }

                return [
                    'variety' => $variety,
                    'products' => $group->sortBy(fn (Product $p): array => [(int) ($p->form?->display_order ?? 0), $p->display_order, $p->id])->values(),
                ];
            })->filter()->sortBy(fn (array $v): array => [(int) $v['variety']->display_order, $v['variety']->id])->values();

            $loose = $mine->filter(fn (Product $p): bool => $p->variety_id === null || ! $varieties->contains(fn (array $v): bool => $v['variety']->id === $p->variety_id))->values();

            return $varieties->isEmpty() && $loose->isEmpty() ? null : ['category' => $cat, 'varieties' => $varieties, 'loose' => $loose];
        })->filter()->values();
    }

    /** All published products of one variety, grouped by category. */
    public static function forVariety(int $varietyId): Collection
    {
        return self::build()->map(function (array $node) use ($varietyId): ?array {
            $v = $node['varieties']->first(fn (array $x): bool => $x['variety']->id === $varietyId);

            return $v === null ? null : ['category' => $node['category'], 'products' => $v['products']];
        })->filter()->values();
    }
}
