<?php

declare(strict_types=1);

namespace App\Support;

/**
 * What the header language picker shows: the published languages in their configured order, each with a representative
 * flag that is set per language in Settings → Header & footer (independent of the locale code: Arabic → Egypt,
 * English → United Kingdom, Greek → Greece …) and a layout mode, horizontal or dropdown.
 */
final class LanguagePicker
{
    public const HORIZONTAL = 'horizontal';

    public const DROPDOWN = 'dropdown';

    /** Sensible starting flags; the owner can change any of them. */
    public const DEFAULT_FLAGS = ['ar' => 'EG', 'en' => 'GB', 'es' => 'ES', 'fr' => 'FR', 'it' => 'IT', 'pt' => 'PT', 'el' => 'GR', 'ru' => 'RU', 'zh' => 'CN', 'ur' => 'PK'];

    public static function mode(): string
    {
        return setting('header.lang_mode') === self::DROPDOWN ? self::DROPDOWN : self::HORIZONTAL;
    }

    public static function flag(string $locale): string
    {
        $code = strtoupper(trim((string) setting('header.flag_'.$locale, '')));

        return Countries::exists($code) ? $code : (self::DEFAULT_FLAGS[$locale] ?? strtoupper($locale));
    }

    /** @return list<array{code: string, native: string, flag: string, url: string, hreflang: string, active: bool, dir: string}> */
    public static function items(): array
    {
        $current = app()->getLocale();
        $out = [];
        foreach (Locales::switcher() as $code => $config) {
            $out[] = [
                'code' => $code, 'native' => (string) ($config['native'] ?? strtoupper($code)), 'flag' => self::flag($code),
                'url' => switch_locale_url($code), 'hreflang' => (string) ($config['hreflang'] ?? $code), 'active' => $code === $current,
                'dir' => Locales::dir($code),
            ];
        }

        return $out;
    }
}
