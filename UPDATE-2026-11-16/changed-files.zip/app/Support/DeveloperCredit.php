<?php

declare(strict_types=1);

namespace App\Support;

use App\Models\MediaAsset;

/**
 * The optional "Developed by" credit shown after the copyright. Nothing here names a developer: the name, link and logo
 * come from Settings → Header & footer. Disabled or nameless means no credit (and no separator); a missing or invalid
 * URL means plain text; a missing logo means the name alone.
 */
final class DeveloperCredit
{
    /** @return array{name: string, url: ?string, logo: ?MediaAsset}|null */
    public static function get(): ?array
    {
        if (! filter_var(setting('footer.dev_enabled', false), FILTER_VALIDATE_BOOLEAN)) {
            return null;
        }
        $name = trim((string) setting('footer.dev_name', ''));
        if ($name === '') {
            return null;
        }

        return ['name' => $name, 'url' => self::safeUrl((string) setting('footer.dev_url', '')), 'logo' => setting_media('footer.dev_logo')];
    }

    /** Only absolute http(s) URLs are ever linked. */
    public static function safeUrl(?string $url): ?string
    {
        $url = trim((string) $url);
        if ($url === '' || ! preg_match('~^https?://[^\s<>"\']+$~i', $url) || filter_var($url, FILTER_VALIDATE_URL) === false) {
            return null;
        }

        return $url;
    }
}
