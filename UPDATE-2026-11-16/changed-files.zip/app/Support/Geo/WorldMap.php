<?php

declare(strict_types=1);

namespace App\Support\Geo;

/**
 * One projection for land, pins and routes: equirectangular over lon -180..180, lat 78..-56, into a 1000 x H viewBox.
 * Land is a bundled grid of dots (database/data/map/world.json, from Natural Earth via world-atlas); country positions
 * come from the same file by ISO 3166-1 alpha-2 code, so no market is placed by hand and none is hard-coded.
 * Egypt is the fixed origin of every route.
 */
final class WorldMap
{
    public const ORIGIN = 'EG';

    public const WIDTH = 1000.0;

    /** @var array{lonMin: float, lonMax: float, latMax: float, latMin: float, dots: list<array{0: float, 1: float}>, countries: array<string, array{0: float, 1: float}>}|null */
    private static ?array $data = null;

    private static function data(): array
    {
        return self::$data ??= (array) json_decode((string) file_get_contents(database_path('data/map/world.json')), true, 512, JSON_THROW_ON_ERROR);
    }

    public static function height(): float
    {
        $d = self::data();

        return round(self::WIDTH * ($d['latMax'] - $d['latMin']) / ($d['lonMax'] - $d['lonMin']), 2);
    }

    /** @return array{0: float, 1: float} x, y in viewBox units */
    public static function project(float $lon, float $lat): array
    {
        $d = self::data();

        return [
            round(($lon - $d['lonMin']) / ($d['lonMax'] - $d['lonMin']) * self::WIDTH, 2),
            round(($d['latMax'] - $lat) / ($d['latMax'] - $d['latMin']) * self::height(), 2),
        ];
    }

    /** Position of a country by ISO code, or null when the code has no known position. @return array{0: float, 1: float}|null */
    public static function point(string $code): ?array
    {
        $c = self::data()['countries'][strtoupper($code)] ?? null;

        return $c === null ? null : self::project((float) $c[0], (float) $c[1]);
    }

    /** All land dots as ONE path of zero-length round-capped segments (tiny, fast to paint). */
    public static function landPath(): string
    {
        $out = [];
        foreach (self::data()['dots'] as [$lon, $lat]) {
            [$x, $y] = self::project((float) $lon, (float) $lat);
            $out[] = 'M'.$x.' '.$y.'h0';
        }

        return implode('', $out);
    }

    /**
     * A quadratic arc from the origin to a destination, bowed upwards in proportion to its length.
     *
     * @param  array{0: float, 1: float}  $from
     * @param  array{0: float, 1: float}  $to
     */
    public static function arc(array $from, array $to): string
    {
        $dx = $to[0] - $from[0];
        $dy = $to[1] - $from[1];
        $len = sqrt($dx * $dx + $dy * $dy);
        $mx = ($from[0] + $to[0]) / 2;
        $my = ($from[1] + $to[1]) / 2 - min(160.0, $len * 0.32);

        return sprintf('M%s %s Q%s %s %s %s', $from[0], $from[1], round($mx, 2), round($my, 2), $to[0], $to[1]);
    }

    /**
     * Everything the view needs for a set of markets, in their given order. Markets whose code has no position are
     * left out of the routes (they still appear in the list).
     *
     * @param  iterable<\App\Models\ExportMarket>  $markets
     * @return array{height: float, origin: array{0: float, 1: float}, routes: list<array{code: string, name: string, to: array{0: float, 1: float}, d: string, i: int}>}
     */
    public static function routes(iterable $markets, string $locale): array
    {
        $origin = self::point(self::ORIGIN) ?? [0.0, 0.0];
        $routes = [];
        foreach ($markets as $m) {
            $code = strtoupper((string) $m->country_code);
            $to = $code === self::ORIGIN ? null : self::point($code);
            if ($to === null) {
                continue;
            }
            $routes[] = ['code' => $code, 'name' => (string) $m->localized('name', $locale), 'to' => $to, 'd' => self::arc($origin, $to), 'i' => count($routes)];
        }

        return ['height' => self::height(), 'origin' => $origin, 'routes' => $routes];
    }
}
