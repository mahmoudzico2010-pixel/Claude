<?php

declare(strict_types=1);

namespace App\Console\Commands;

use App\Services\Catalog\CatalogHierarchy;
use Illuminate\Console\Command;

class CatalogueHierarchy extends Command
{
    protected $signature = 'catalogue:hierarchy';

    protected $description = 'Create/refresh the five product families and thirteen subcategories (fill-only, repeatable) and report items needing review';

    public function handle(): int
    {
        $r = CatalogHierarchy::apply();
        $this->info("created {$r['created']}, names filled {$r['filled']}, products moved {$r['moved']}");
        foreach ($r['review'] as $line) {
            $this->warn('REVIEW  '.$line);
        }
        $this->line('Header image missing (brand panel shown until one is chosen): '.implode(', ', $r['no_image']));

        return self::SUCCESS;
    }
}
