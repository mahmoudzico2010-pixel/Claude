<?php

declare(strict_types=1);

namespace App\Filament\Pages;

use App\Models\BuilderNode;
use App\Models\BuilderRevision;
use App\Services\Builder\LegacyRebuilder;
use App\Services\Builder\RevisionManager;
use App\Services\Builder\TreeManager;
use App\Support\Builder\NodeSettings;
use App\Support\Builder\NodeTypes;
use App\Support\Builder\TreeOperations;
use App\Support\Permissions;
use BackedEnum;
use Filament\Notifications\Notification;
use Filament\Pages\Page;
use Filament\Support\Icons\Heroicon;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;
use RuntimeException;

/**
 * The visual page builder.
 *
 * Four panes: the element library on the left, the canvas in the middle, the
 * selected node's settings on the right, and the toolbar across the top.
 *
 * ---------------------------------------------------------------------------
 * Why the canvas is server-rendered
 * ---------------------------------------------------------------------------
 *
 * Every structural change round-trips to the server and the canvas re-renders
 * from the database. That is slower per interaction than keeping a copy of the
 * tree in JavaScript, and it is the right trade here: a client-side copy is a
 * second source of truth, and the moment it disagrees with the database the
 * administrator is editing a page that does not exist. Re-reading after every
 * change means what is on screen is what is stored, always.
 *
 * ---------------------------------------------------------------------------
 * Why nothing here decides what is legal
 * ---------------------------------------------------------------------------
 *
 * Every move goes through TreeManager, which asks TreeOperations. This page
 * asks the same question to decide which drop targets to light up, so an
 * illegal drop is never offered — but it is not the gate. A Livewire action is
 * a public endpoint: the checks that matter run in the service, on the server,
 * for every call including ones this page never makes.
 */
class PageBuilder extends Page
{
    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedSquares2x2;

    protected static ?int $navigationSort = 1;

    protected static bool $shouldRegisterNavigation = false;

    protected string $view = 'filament.pages.page-builder';

    /** The page being edited. Only the homepage for now; the column exists. */
    public string $pageKey = 'home';

    /** The selected node, whose settings fill the right-hand pane. */
    public ?int $selectedId = null;

    /** Canvas width: desktop, tablet or mobile. */
    public string $device = 'desktop';

    /**
     * Which view of the tree the centre pane shows.
     *
     * `preview` is the draft rendered by the real public templates; `outline`
     * is the structural tree. The outline is not a fallback — it is the only
     * way to see and reach a node the preview cannot show: an empty column, a
     * hidden section, a node sitting behind an overlay.
     */
    public string $canvasView = 'preview';

    /** Which breakpoint the responsive controls are editing. */
    public string $breakpoint = 'mobile';

    /** The settings form state for the selected node. */
    public array $form = [];

    /** Translated values, keyed by locale then field. */
    public array $translations = [];

    public static function getNavigationLabel(): string
    {
        return __('admin.builder.title');
    }

    public function getTitle(): string
    {
        return __('admin.builder.title');
    }

    public static function canAccess(): bool
    {
        return Auth::user()?->can(Permissions::CONTENT_VIEW) ?? false;
    }

    protected function canEdit(): bool
    {
        return Auth::user()?->can(Permissions::CONTENT_MANAGE) ?? false;
    }

    /**
     * Whether the current user may use the types that write code.
     *
     * `html` and `custom_css` put markup and stylesheets on the company's own
     * origin, which is a different power from editing copy — so they are
     * withheld from the library and refused on the server, not merely hidden.
     */
    protected function canUseCode(): bool
    {
        return Auth::user()?->can(Permissions::SETTINGS_SENSITIVE) ?? false;
    }

    /** Draft fingerprint as of the end of this editor's last request; a different value at the next edit means somebody else saved in between. */
    public string $loadedFingerprint = '';

    /** URL of the visual editor for a CMS page. */
    public static function urlForPage(\App\Models\Page $page): string
    {
        return static::getUrl(['page' => $page->slug]);
    }

    public function dehydrate(): void
    {
        $this->loadedFingerprint = app(RevisionManager::class)->draftFingerprint($this->pageKey);
    }

    public function mount(): void
    {
        abort_unless(static::canAccess(), 403);

        $slug = request()->query('page');
        if (is_string($slug) && $slug !== '' && $slug !== 'home') {
            $page = \App\Models\Page::query()->where('slug', $slug)->firstOrFail();
            $this->pageKey = \App\Services\Builder\PageConverter::key($page);
            if ($this->canEdit()) {
                app(\App\Services\Builder\PageConverter::class)->ensureDraft($page);
            }
            $this->selectFirst();

            return;
        }

        // The homepage is edited in the Homepage Manager; a Page Builder tree
        // no longer renders on an adopted homepage. Builder blocks for new
        // optional sections need separate design approval (Decision 4), so
        // this editor is parked: hidden, redirecting, its data kept.
        $this->redirect(HomepageManager::getUrl());
    }

    /*
    |--------------------------------------------------------------------------
    | Reads
    |--------------------------------------------------------------------------
    |
    | Plain methods, called explicitly from the view, rather than Livewire's
    | `getXProperty()` computed properties.
    |
    | Those are magic that changed behaviour across Livewire versions — they
    | were superseded by the #[Computed] attribute — and Livewire is not a
    | direct dependency here; it arrives through Filament, so which version
    | resolves is not pinned by this application. A method call works the same
    | in all of them, and a typo in a method name is a fatal error rather than
    | a silently null property.
    |
    */

    /**
     * The tree, as nested arrays for the canvas.
     *
     * Arrays rather than models: the canvas only needs id, type, enabled state
     * and a label, and passing models into a Livewire view would serialise far
     * more than that into the page on every render.
     *
     * @return array<int, array<string, mixed>>
     */
    public function tree(): array
    {
        return $this->present(app(TreeManager::class)->tree($this->pageKey));
    }

    /**
     * @param  array<int, BuilderNode>  $nodes
     * @return array<int, array<string, mixed>>
     */
    private function present(array $nodes): array
    {
        return array_map(fn (BuilderNode $node): array => [
            'id' => (int) $node->id,
            'type' => (string) $node->type,
            'enabled' => (bool) $node->is_enabled,
            'label' => $this->label($node),
            'accepts' => NodeTypes::accepts((string) $node->type),
            'children' => $this->present($node->children->all()),
        ], $nodes);
    }

    /**
     * A human label for a node in the canvas.
     *
     * The node's own text where it has some, so a list of six headings is
     * distinguishable at a glance rather than six rows reading "Heading".
     */
    private function label(BuilderNode $node): string
    {
        foreach (NodeTypes::translatable((string) $node->type) as $field) {
            $value = $node->t($field);

            if (is_string($value) && $value !== '') {
                return mb_substr($value, 0, 60);
            }
        }

        return __('admin.builder.types.'.$node->type);
    }

    /**
     * The element library, grouped, with restricted types removed.
     *
     * @return array<string, array<int, string>>
     */
    public function library(): array
    {
        $groups = [];

        foreach (NodeTypes::library() as $group => $types) {
            $allowed = array_values(array_filter(
                $types,
                fn (string $type): bool => NodeTypes::requiredPermission($type) === null || $this->canUseCode(),
            ));

            if ($allowed !== []) {
                $groups[$group] = $allowed;
            }
        }

        return $groups;
    }

    public function selectedNode(): ?BuilderNode
    {
        return $this->selectedId === null
            ? null
            : BuilderNode::query()->with('translations')->find($this->selectedId);
    }

    /**
     * The breadcrumb above the canvas.
     *
     * Four nested levels are impossible to navigate without one — "which of
     * these three columns am I in?" has no answer from the canvas alone.
     *
     * @return array<int, array{id: int, type: string}>
     */
    public function trail(): array
    {
        if ($this->selectedId === null) {
            return [];
        }

        $map = app(TreeManager::class)->map($this->pageKey);

        return array_map(
            fn (int $id): array => ['id' => $id, 'type' => $map[$id]['type'] ?? ''],
            TreeOperations::ancestors($map, $this->selectedId),
        );
    }

    public function canUndo(): bool
    {
        return app(RevisionManager::class)->count($this->pageKey, RevisionManager::UNDO) > 0;
    }

    public function canRedo(): bool
    {
        return app(RevisionManager::class)->count($this->pageKey, RevisionManager::REDO) > 0;
    }

    /**
     * Does the draft differ from what visitors are currently seeing?
     *
     * Drives the "unpublished changes" indicator. Without it the builder looks
     * identical whether or not the work has been made live, which is precisely
     * the confusion that separating draft from published exists to remove.
     */
    public function isDirty(): bool
    {
        return app(RevisionManager::class)->isDirty($this->pageKey);
    }

    /**
     * A token that changes when the draft does.
     *
     * The preview frame's URL carries it, so the frame reloads after a real
     * change and not merely because the component re-rendered — which it does
     * on every keystroke in the settings panel.
     */
    public function previewToken(): string
    {
        return app(RevisionManager::class)->draftFingerprint($this->pageKey);
    }

    /**
     * The preview frame's URL, carrying the draft's fingerprint.
     *
     * The token changes only when the tree actually changed, so the frame
     * reloads after a real edit rather than on every re-render — and the
     * settings panel re-renders on every field blur.
     */
    public function previewUrl(): string
    {
        return route('admin.builder.preview', ['pageKey' => $this->pageKey])
            .'?locale='.app()->getLocale()
            .'&v='.$this->previewToken();
    }

    /**
     * Tell the preview frame to reload.
     *
     * Called after anything that changes the tree. The frame is a separate
     * document, so Livewire re-rendering this component does not update it.
     */
    private function refreshPreview(): void
    {
        // The URL travels with the event.
        //
        // The iframe carries wire:ignore — without it Livewire would replace
        // the element on every update and reload the page inside, losing the
        // scroll position on each keystroke. But that also means the rendered
        // src attribute is never updated, so the browser must be handed the
        // new URL explicitly. Baking it into the Alpine component at render
        // time would not do: that function is defined once and would keep
        // reloading whichever version of the draft was current when the page
        // was first opened.
        $this->dispatch('builder-refresh', url: $this->previewUrl());
    }

    /**
     * The version number currently live, or null if never published.
     */
    public function publishedVersion(): ?int
    {
        $revision = app(RevisionManager::class)->latestPublished($this->pageKey);

        return $revision === null ? null : (int) $revision->version;
    }

    /**
     * Published versions, newest first, for the history list.
     *
     * @return Collection<int, BuilderRevision>
     */
    public function history(): Collection
    {
        return app(RevisionManager::class)->history($this->pageKey);
    }

    // --------------------------------------------------------------- commands

    public function select(int $id): void
    {
        $node = BuilderNode::query()->with('translations')->find($id);

        if ($node === null || $node->page_key !== $this->pageKey) {
            return;
        }

        $this->selectedId = $id;

        // Told to the frame explicitly rather than inferred from a Livewire
        // lifecycle hook: those hooks are named differently across Livewire
        // versions, and Livewire is not a direct dependency here.
        $this->dispatch('builder-selected', id: $id);

        $this->form = ((array) $node->settings) + ((array) $node->style);
        $this->translations = [];

        foreach (array_keys((array) config('wadi.locales', [])) as $locale) {
            foreach (NodeTypes::translatable((string) $node->type) as $field) {
                $this->translations[$locale][$field] = $node->t($field, $locale) ?? '';
            }
        }
    }

    public function add(string $type, ?int $parentId = null, ?int $position = null): void
    {
        $this->authorizeEdit();
        $this->authorizeType($type);

        $this->snapshot();

        try {
            $node = app(TreeManager::class)->add($this->pageKey, $parentId, $type, $position);
        } catch (RuntimeException $e) {
            $this->refuse($e->getMessage());

            return;
        }

        // Selecting the new node puts its settings in the right-hand pane
        // immediately, which is the point of adding it.
        $this->select((int) $node->id);

        $this->refreshPreview();
    }

    public function move(int $id, ?int $parentId, int $position): void
    {
        $this->authorizeEdit();
        $this->snapshot();

        try {
            app(TreeManager::class)->move($id, $parentId, $position);
        } catch (RuntimeException $e) {
            $this->refuse($e->getMessage());
        }

        $this->refreshPreview();
    }

    /**
     * @param  array<int, int>  $ids
     */
    public function reorder(?int $parentId, array $ids): void
    {
        $this->authorizeEdit();
        $this->snapshot();

        app(TreeManager::class)->reorder($this->pageKey, $parentId, $ids);

        $this->refreshPreview();
    }

    public function duplicate(int $id): void
    {
        $this->authorizeEdit();
        $this->snapshot();

        try {
            $copy = app(TreeManager::class)->duplicate($id);
            $this->select((int) $copy->id);
        } catch (RuntimeException $e) {
            $this->refuse($e->getMessage());
        }

        $this->refreshPreview();
    }

    public function remove(int $id): void
    {
        $this->authorizeEdit();
        $this->snapshot();

        app(TreeManager::class)->delete($id);

        if ($this->selectedId === $id) {
            $this->selectedId = null;
            $this->selectFirst();
        }

        $this->refreshPreview();
    }

    /**
     * Whether the selected node is a legacy band that can be rebuilt.
     */
    public function canRebuildLegacy(): bool
    {
        $node = $this->selectedNode();

        return $node !== null && app(LegacyRebuilder::class)->canRebuild($node);
    }

    /**
     * Scaffold native elements beside a legacy band and switch the band off.
     *
     * This does not convert the band's content — a Stage 2 partial's inner
     * content has no general mapping to builder nodes, and inventing one would
     * produce a homepage that is subtly wrong in ways nobody asked for. It
     * creates the elements the band is made of, carries across the heading and
     * subheading it could read, and leaves the rest to be filled in.
     *
     * The legacy node is disabled, never deleted, so abandoning a half-finished
     * rebuild costs nothing.
     */
    public function rebuildLegacy(int $id): void
    {
        $this->authorizeEdit();

        $node = BuilderNode::query()->with('translations')->find($id);

        if ($node === null || $node->page_key !== $this->pageKey) {
            return;
        }

        $this->snapshot();

        try {
            $created = app(LegacyRebuilder::class)->rebuild($node);
        } catch (RuntimeException $e) {
            $this->refuse($e->getMessage());

            return;
        }

        if ($created !== []) {
            $this->select((int) $created[0]->id);
        }

        $this->refreshPreview();

        Notification::make()
            ->title(__('admin.builder.rebuilt'))
            ->body(__('admin.builder.rebuilt_body'))
            ->success()
            ->send();
    }

    public function toggleEnabled(int $id): void
    {
        $this->authorizeEdit();

        $node = BuilderNode::query()->find($id);

        if ($node === null || $node->page_key !== $this->pageKey) {
            return;
        }

        $this->snapshot();

        $node->is_enabled = ! $node->is_enabled;
        $node->save();

        $this->refreshPreview();
    }

    /**
     * Save the selected node's settings and translations.
     */
    public function save(): void
    {
        $this->authorizeEdit();

        $node = $this->selectedNode();

        if ($node === null) {
            return;
        }

        $this->snapshot();

        $type = (string) $node->type;

        /*
         | Settings and style are split back apart by which registry they belong
         | to, then cleaned.
         |
         | The form merges them for editing, so an unknown key could otherwise
         | land in whichever column it was written to last. NodeSettings::clean
         | iterates the declared settings rather than the submitted values, so
         | anything not in the registry is dropped rather than stored.
         */
        $node->settings = NodeSettings::clean($type, $this->form);
        $node->style = NodeSettings::clean($type, $this->form, style: true);
        $node->save();

        $this->saveTranslations($node, $type);

        // No cache flush: this is a draft edit, and the public page renders the
        // newest published revision rather than these rows.
        $this->refreshPreview();

        Notification::make()
            ->title(__('admin.builder.saved'))
            ->body(__('admin.builder.saved_draft'))
            ->success()
            ->send();
    }

    private function saveTranslations(BuilderNode $node, string $type): void
    {
        $fields = NodeTypes::translatable($type);

        if ($fields === []) {
            return;
        }

        foreach ((array) $this->translations as $locale => $values) {
            if (! array_key_exists((string) $locale, (array) config('wadi.locales', []))) {
                continue;
            }

            $content = [];

            foreach ($fields as $field) {
                $definition = NodeTypes::settings($type)[$field] ?? [];

                $value = NodeSettings::value(
                    $values[$field] ?? null,
                    (string) ($definition['type'] ?? 'text'),
                    $definition,
                );

                if (is_string($value) && $value !== '') {
                    $content[$field] = $value;
                }
            }

            $node->translations()->updateOrCreate(
                ['locale' => (string) $locale],
                ['content' => $content],
            );
        }
    }

    /**
     * Make the current draft live.
     *
     * This writes a published revision, and that revision is what the public
     * page renders. It is the only action in this class that changes what a
     * visitor sees — saving, undoing, redoing and reverting all act on the
     * draft alone.
     */
    public function publish(): void
    {
        $this->authorizeEdit();

        $revision = app(RevisionManager::class)->publish($this->pageKey);

        if ($revision === null) {
            Notification::make()->title(__('admin.builder.nothing_to_publish'))->warning()->send();

            return;
        }

        Notification::make()
            ->title(__('admin.builder.published', ['version' => (int) $revision->version]))
            ->success()
            ->send();
    }

    /**
     * Put a published version back into the draft.
     *
     * Deliberately into the draft, not straight onto the public site: reverting
     * lets you look at the old content in the builder first, and publishing it
     * is a second, separate decision. An accidental revert is therefore not
     * immediately visible to visitors, and is itself undoable.
     */
    public function revertTo(int $revisionId): void
    {
        $this->authorizeEdit();

        if (! app(RevisionManager::class)->revertTo($this->pageKey, $revisionId)) {
            Notification::make()->title(__('admin.builder.revert_failed'))->warning()->send();

            return;
        }

        $this->selectedId = null;
        $this->selectFirst();
        $this->refreshPreview();

        Notification::make()
            ->title(__('admin.builder.reverted'))
            ->body(__('admin.builder.reverted_body'))
            ->success()
            ->send();
    }

    public function undo(): void
    {
        $this->authorizeEdit();

        if (! app(RevisionManager::class)->undo($this->pageKey)) {
            Notification::make()->title(__('admin.builder.nothing_to_undo'))->warning()->send();

            return;
        }

        $this->selectedId = null;
        $this->selectFirst();
        $this->refreshPreview();

        Notification::make()->title(__('admin.builder.undone'))->success()->send();
    }

    /**
     * Step forward again, to a state an undo stepped away from.
     *
     * The redo stack is cleared by the next edit, because once you change
     * something after stepping back, the future you stepped away from was
     * never built on this state and reinstating it would lose the change.
     */
    public function redo(): void
    {
        $this->authorizeEdit();

        if (! app(RevisionManager::class)->redo($this->pageKey)) {
            Notification::make()->title(__('admin.builder.nothing_to_redo'))->warning()->send();

            return;
        }

        $this->selectedId = null;
        $this->selectFirst();
        $this->refreshPreview();

        Notification::make()->title(__('admin.builder.redone'))->success()->send();
    }

    // --------------------------------------------------------------- internals

    /**
     * Record the tree before a change, so undo has something to return to.
     *
     * Taken before every structural change rather than on a timer: an undo that
     * restores "some point in the last thirty seconds" is not an undo.
     */
    private function snapshot(): void
    {
        app(RevisionManager::class)->snapshot($this->pageKey);
    }

    private function selectFirst(): void
    {
        $first = BuilderNode::query()
            ->forPage($this->pageKey)
            ->roots()
            ->ordered()
            ->first();

        if ($first !== null) {
            $this->select((int) $first->id);
        }
    }

    private function authorizeEdit(): void
    {
        abort_unless($this->canEdit(), 403);

        // Stale-save protection: the draft changed since this editor last saw it (another tab or person saved).
        abort_if(
            $this->loadedFingerprint !== '' && $this->loadedFingerprint !== app(RevisionManager::class)->draftFingerprint($this->pageKey),
            409,
            __('admin.builder.stale'),
        );
    }

    /** Inline canvas edit: new text for a heading / text / rich-text block in the language being previewed. */
    public function inlineEdit(int $id, string $value): void
    {
        $this->authorizeEdit();

        $node = BuilderNode::query()->find($id);
        $fields = ['heading' => 'text', 'text' => 'body', 'rich_text' => 'body'];

        if ($node === null || $node->page_key !== $this->pageKey || ! isset($fields[$node->type])) {
            return;
        }

        $field = $fields[$node->type];
        $definition = NodeTypes::settings((string) $node->type)[$field] ?? [];
        $clean = NodeSettings::value($value, (string) ($definition['type'] ?? 'text'), $definition);

        $this->snapshot();
        $existing = (array) ($node->translations()->where('locale', app()->getLocale())->first()?->content ?? []);
        $node->translations()->updateOrCreate(['locale' => app()->getLocale()], ['content' => array_merge($existing, [$field => is_string($clean) ? $clean : ''])]);
        $this->refreshPreview();
    }

    /**
     * Refuse a type this user may not place.
     *
     * The library hides these, but a Livewire action is a public endpoint and
     * hiding a button is not a permission check.
     */
    private function authorizeType(string $type): void
    {
        abort_if(
            NodeTypes::requiredPermission($type) !== null && ! $this->canUseCode(),
            403,
        );
    }

    /**
     * Show why a move was refused.
     *
     * The reason comes from TreeOperations — "a column cannot contain a
     * section" — which is a far better answer than a drop target that silently
     * does nothing.
     */
    private function refuse(string $reason): void
    {
        Notification::make()->title($reason)->warning()->send();
    }
}
