<?php

declare(strict_types=1);

namespace App\Filament\Resources\ProductFrames\Pages;

use App\Filament\Resources\ProductFrames\ProductFramesResource;
use Filament\Actions\CreateAction;
use Filament\Resources\Pages\ManageRecords;

class ManageProductFrames extends ManageRecords
{
    protected static string $resource = ProductFramesResource::class;

    protected function getHeaderActions(): array
    {
        return [CreateAction::make()->mutateDataUsing(fn (array $d): array => ProductFramesResource::prepare($d))];
    }
}
