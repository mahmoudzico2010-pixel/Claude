<?php

declare(strict_types=1);

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Services\Builder\PageRenderer;
use App\Support\Permissions;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

/**
 * Renders the builder's draft through the real public templates.
 *
 * This is what the builder shows in its preview pane, and it is deliberately
 * the *same* renderer, the same Blade partials and the same compiled CSS that
 * publishing would produce — not a stylised approximation drawn by the admin
 * panel. An approximation is a second implementation of the page, and the two
 * drift: the preview keeps looking right while the real page breaks.
 *
 * Two things make it safe to expose:
 *
 *   · It is behind the panel's auth guard and the content permission, so it is
 *     not a public route that renders unpublished work.
 *   · It renders `draftPayload()`, which never writes and never touches the
 *     published cache. Looking at a preview cannot change what visitors see.
 */
class BuilderPreviewController extends Controller
{
    public function __invoke(Request $request, string $pageKey = 'home'): View
    {
        abort_unless(Auth::check(), 403);
        abort_unless(Auth::user()?->can(Permissions::CONTENT_VIEW) ?? false, 403);

        // The page key comes from the URL, so it is matched against the pages
        // the builder actually serves rather than trusted. It is only ever used
        // as a database value, but a value that reaches a query from a route
        // segment deserves the check regardless.
        abort_unless($pageKey === 'home' || (str_starts_with($pageKey, 'page:') && \App\Models\Page::query()->where('slug', substr($pageKey, 5))->exists()), 404);

        $locale = $request->query('locale');
        $locale = is_string($locale) && array_key_exists($locale, (array) config('wadi.locales', []))
            ? $locale
            : app()->getLocale();

        app()->setLocale($locale);

        return view('builder.preview', [
            'payload' => app(PageRenderer::class)->draftPayload($pageKey, $locale),
            'pageKey' => $pageKey,
            'locale' => $locale,
        ]);
    }
}
