<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Models\MediaAsset;
use App\Models\User;
use App\Services\Media\MediaManager;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use PHPUnit\Framework\Attributes\Test;
use RuntimeException;
use Tests\TestCase;

/** iPhone videos are QuickTime (.mov / video/quicktime). They must be accepted — without opening the door to fake files. */
final class IphoneVideoUploadTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        Storage::fake('public');
        $this->seed();
        $u = User::factory()->create(['is_active' => true]);
        $u->assignRole(User::ROLE_SUPER_ADMIN);
        $this->actingAs($u);
    }

    /** A minimal QuickTime header (what finfo recognises as video/quicktime) followed by padding. */
    private function mov(int $bytes = 4000): string
    {
        $head = "\x00\x00\x00\x14ftypqt  \x00\x00\x00\x00qt  ";

        return $head.str_repeat('A', max(0, $bytes - strlen($head)));
    }

    /** @return array<string, array{0: string, 1: string}> extension => [bytes-start, expected mime family] */
    private function containers(): array
    {
        return [
            'mov' => [$this->mov(), 'video/quicktime'],
            'mp4' => ["\x00\x00\x00\x18ftypisom\x00\x00\x02\x00isomiso2".str_repeat('A', 3000), 'video/mp4'],
            '3gp' => ["\x00\x00\x00\x14ftyp3gp4\x00\x00\x00\x00isom".str_repeat('A', 3000), 'video/3gpp'],
            'avi' => ['RIFF'."\x00\x10\x00\x00".'AVI LIST'.str_repeat('A', 3000), 'video/x-msvideo'],
        ];
    }

    private function file(string $name, string $bytes): UploadedFile
    {
        $p = sys_get_temp_dir().'/'.uniqid('mov').'-'.$name;
        file_put_contents($p, $bytes);

        return new UploadedFile($p, $name, null, null, true);
    }

    #[Test]
    public function a_quicktime_movie_from_an_iphone_is_accepted_and_announced_as_mp4(): void
    {
        $asset = app(MediaManager::class)->store($this->file('copy_ED50D79A-1234.mov', $this->mov()), 'news');
        $this->assertSame('video/quicktime', $asset->mime_type);
        $this->assertSame('mov', $asset->extension);
        $this->assertTrue($asset->isVideo());
        $this->assertSame('video/mp4', $asset->playbackType(), 'browsers decode the H.264 inside, but refuse the quicktime type');
        Storage::disk('public')->assertExists($asset->path);
    }

    #[Test]
    public function mp4_and_webm_still_play_as_themselves(): void
    {
        $m = new MediaAsset(['mime_type' => 'video/mp4']);
        $w = new MediaAsset(['mime_type' => 'video/webm']);
        $this->assertSame('video/mp4', $m->playbackType());
        $this->assertSame('video/webm', $w->playbackType());
    }

    #[Test]
    public function every_common_video_container_is_stored_as_a_video(): void
    {
        foreach ($this->containers() as $ext => [$bytes, $mime]) {
            $asset = app(MediaManager::class)->store($this->file("clip.$ext", $bytes), 'news');
            $this->assertTrue($asset->isVideo(), "$ext is a video ($asset->mime_type)");
            $this->assertSame($ext, $asset->extension);
        }
    }

    #[Test]
    public function the_video_allowlist_covers_the_usual_phone_camera_and_editor_formats(): void
    {
        $ext = (array) config('wadi.media.video.extensions');
        foreach (['mp4', 'm4v', 'mov', 'webm', 'mkv', 'avi', 'wmv', 'flv', 'mpg', 'mpeg', '3gp', 'mts', 'm2ts', 'ogv'] as $e) {
            $this->assertContains($e, $ext, $e);
        }
        foreach (['php', 'phtml', 'exe', 'js', 'html', 'svg', 'sh', 'jar'] as $bad) {
            $this->assertNotContains($bad, $ext, "$bad must never be a video extension");
        }
        $this->assertSame(['video/*'], (array) config('wadi.media.video.mimes'));
    }

    #[Test]
    public function the_upload_control_offers_quicktime_to_the_browser(): void
    {
        $this->assertContains('video/*', (array) config('wadi.media.video.mimes'));
        $this->assertContains('mov', (array) config('wadi.media.video.extensions'));
    }

    #[Test]
    public function the_large_file_uploader_accepts_a_mov_by_its_real_content_and_refuses_a_disguised_file(): void
    {
        $admin = auth()->user();
        $data = $this->mov(5000);
        $id = $this->postJson('/admin/large-uploads', ['name' => 'iphone.mov', 'size' => 5000, 'type' => 'video/quicktime', 'category' => 'video', 'folder' => 'news'])->assertCreated()->json('id');
        $this->call('PUT', "/admin/large-uploads/{$id}/chunk", [], [], [], ['HTTP_X-Upload-Offset' => '0', 'CONTENT_LENGTH' => (string) strlen($data), 'CONTENT_TYPE' => 'application/octet-stream', 'HTTP_ACCEPT' => 'application/json'], $data)->assertOk();
        $done = $this->postJson("/admin/large-uploads/{$id}/complete");
        $this->assertSame(200, $done->getStatusCode(), $done->getContent());
        $this->assertSame('video/quicktime', MediaAsset::firstOrFail()->mime_type);

        $bad = 'This is not a movie at all, only text pretending to be one.'.str_repeat('x', 4940);
        $id2 = $this->postJson('/admin/large-uploads', ['name' => 'fake.mov', 'size' => 5000, 'type' => 'video/quicktime', 'category' => 'video', 'folder' => 'news'])->assertCreated()->json('id');
        $this->call('PUT', "/admin/large-uploads/{$id2}/chunk", [], [], [], ['HTTP_X-Upload-Offset' => '0', 'CONTENT_LENGTH' => (string) strlen($bad), 'CONTENT_TYPE' => 'application/octet-stream', 'HTTP_ACCEPT' => 'application/json'], $bad);
        $this->postJson("/admin/large-uploads/{$id2}/complete")->assertStatus(422);
        $this->assertSame(1, MediaAsset::count(), 'only the genuine movie is in the library');
        $this->assertNotNull($admin);
    }
}
