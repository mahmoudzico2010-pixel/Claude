<?php

declare(strict_types=1);

use App\Support\Http\TrustedProxyList;

return [

    /*
    |--------------------------------------------------------------------------
    | Locales: supported versus published
    |--------------------------------------------------------------------------
    |
    | Two separate ideas, deliberately not one list.
    |
    | SUPPORTED (`locales`): every language the application can store, edit,
    | preview and test. All ten exist everywhere internal: translation forms,
    | the Packaging Manager, previews, cache keys, the locale route prefix.
    | `dir` drives document direction so the layout mirrors rather than merely
    | right-aligning; Arabic and Urdu are right-to-left.
    |
    | PUBLISHED (`published`): the subset shown to the public. Only published
    | locales appear in the language switcher, the sitemap, canonical/hreflang
    | output and normal navigation. The default comes from PUBLISHED_LOCALES;
    | the Languages tab of the Launch Checklist overrides it once an administrator
    | publishes a locale (stored as the setting `locales.published`).
    |
    | A supported locale that is not published is NEVER treated as production
    | ready, even though English fallback text lets its pages render: it is
    | served only to signed-in administrators (preview) or, for testing on
    | staging, to everyone when EXPOSE_UNPUBLISHED_LOCALES=true — always
    | noindex and never listed. Publishing in production additionally requires
    | the essential areas to be translated and reviewed (see LocaleReadiness).
    |
    | Fallback chain for every locale: the requested locale, then
    | app.fallback_locale (English), then any translation that exists.
    |
    */

    'locales' => [
        'ar' => ['name' => 'Arabic', 'native' => 'العربية', 'dir' => 'rtl', 'hreflang' => 'ar', 'og_locale' => 'ar_EG'],
        'en' => ['name' => 'English', 'native' => 'English', 'dir' => 'ltr', 'hreflang' => 'en', 'og_locale' => 'en_GB'],
        'es' => ['name' => 'Spanish', 'native' => 'Español', 'dir' => 'ltr', 'hreflang' => 'es', 'og_locale' => 'es_ES'],
        'fr' => ['name' => 'French', 'native' => 'Français', 'dir' => 'ltr', 'hreflang' => 'fr', 'og_locale' => 'fr_FR'],
        'it' => ['name' => 'Italian', 'native' => 'Italiano', 'dir' => 'ltr', 'hreflang' => 'it', 'og_locale' => 'it_IT'],
        'pt' => ['name' => 'Portuguese', 'native' => 'Português', 'dir' => 'ltr', 'hreflang' => 'pt', 'og_locale' => 'pt_PT'],
        'el' => ['name' => 'Greek', 'native' => 'Ελληνικά', 'dir' => 'ltr', 'hreflang' => 'el', 'og_locale' => 'el_GR'],
        'ru' => ['name' => 'Russian', 'native' => 'Русский', 'dir' => 'ltr', 'hreflang' => 'ru', 'og_locale' => 'ru_RU'],
        'zh' => ['name' => 'Chinese', 'native' => '中文', 'dir' => 'ltr', 'hreflang' => 'zh', 'og_locale' => 'zh_CN'],
        'ur' => ['name' => 'Urdu', 'native' => 'اردو', 'dir' => 'rtl', 'hreflang' => 'ur', 'og_locale' => 'ur_PK'],
    ],

    /**
     * The site's default language, fixed at boot. `app.locale` cannot serve: the
     * locale middleware overwrites it with the visitor's language on every request.
     */
    'default_locale' => env('APP_LOCALE', 'en'),

    /** Written by the installer when it finishes (WADI_INSTALLED=true in .env): the installer never reopens on a site that carries it. */
    'installed' => (bool) env('WADI_INSTALLED', false),

    /** Locales shown to the public (a subset of `locales`); see above. */
    'published' => array_values(array_filter(array_map('trim', explode(',', (string) env('PUBLISHED_LOCALES', 'en,ar'))))),

    /**
     * Is "a language must be translated and reviewed to be public" enforced on every request,
     * not only when publishing? null (default) = yes in production only; true/false force it.
     * A published language that is not ready is suspended: out of the switcher, sitemap, hreflang
     * and navigation, and a 404 for visitors (administrators still preview it).
     */
    'enforce_locale_readiness' => env('ENFORCE_LOCALE_READINESS') === null ? null : filter_var(env('ENFORCE_LOCALE_READINESS'), FILTER_VALIDATE_BOOLEAN),

    /** Seconds a computed "which published languages are ready" answer is reused (0 = never). */
    'locale_eligibility_ttl' => (int) env('LOCALE_ELIGIBILITY_TTL', 60),

    /** Serve supported-but-unpublished locales to everyone (noindex). Staging only. */
    'expose_unpublished_locales' => (bool) env('EXPOSE_UNPUBLISHED_LOCALES', false),

    /*
    |--------------------------------------------------------------------------
    | Media library
    |--------------------------------------------------------------------------
    */

    /*
    |--------------------------------------------------------------------------
    | Upload limits (defaults; an authorised administrator changes them in System -> Upload limits)
    |--------------------------------------------------------------------------
    | One limit per file category: a video allowance is never granted to images, avatars or plugin packages.
    | `ceiling_kb` is the hard upper bound an administrator setting can never exceed.
    */
    'uploads' => [
        'defaults_kb' => [
            'image' => (int) env('MEDIA_MAX_UPLOAD_KB', 8192),
            'video' => (int) env('MEDIA_VIDEO_MAX_UPLOAD_KB', 204800),      // 200 MiB = 209715200 bytes
            'document' => (int) env('MEDIA_DOCUMENT_MAX_UPLOAD_KB', 16384),
            'avatar' => 2048,
            'plugin' => (int) env('PLUGIN_MAX_UPLOAD_KB', 102400),
        ],
        'ceiling_kb' => ['image' => 51200, 'video' => 1048576, 'document' => 102400, 'avatar' => 5120, 'plugin' => 204800],
        'slow_upload_seconds' => (int) env('UPLOAD_SLOW_SECONDS', 1800),   // 30 minutes
        'chunk_kb' => (int) env('UPLOAD_CHUNK_KB', 4096),                  // 4 MiB per request in the large-file uploader
        'session_ttl_hours' => 24,
        'max_open_sessions_per_user' => 3,
    ],

    'media' => [
        'max_upload_kb' => (int) env('MEDIA_MAX_UPLOAD_KB', 8192),
        'optimize' => (bool) env('MEDIA_OPTIMIZE', true),
        'public_fallback' => (bool) env('MEDIA_PUBLIC_FALLBACK', false),

        'disk' => 'public',

        // Extensions accepted from an ordinary administrator. SVG is NOT in
        // this list: it is a scripting-capable format and is restricted to
        // Super Admins (see `svg` below).
        'allowed_extensions' => ['jpg', 'jpeg', 'png', 'webp', 'pdf'],

        'allowed_mimes' => [
            'image/jpeg',
            'image/png',
            'image/webp',
            'application/pdf',
        ],

        /*
         * Video.
         *
         * Kept deliberately narrow and deliberately small.
         *
         * MP4 (H.264/AAC) and WebM are the only two formats every current
         * browser plays without a plugin, and neither can carry script. There
         * is no transcoding on shared hosting — no ffmpeg — so whatever is
         * uploaded is exactly what every visitor downloads, at full size, on
         * every uncached view. A hero video is therefore a bandwidth decision
         * before it is a design one.
         *
         * `max_upload_kb` is the hard ceiling and is bounded by PHP's own
         * upload_max_filesize (16M on this plan), so a larger value here would
         * only produce a confusing silent failure at the web-server layer.
         *
         * A poster image is required rather than optional: without one the
         * slide is blank until enough of the video has buffered, which on a
         * mobile connection is the whole first impression.
         */
        // Magnification for the product detail magnifier. 2.5x reveals label
        // text on a typical 2000px product photograph without turning it to
        // mush; above about 3x the source runs out of detail first.
        'zoom_factor' => (float) env('MEDIA_ZOOM_FACTOR', 2.5),

        'video' => [
            'enabled' => true,
            'max_upload_kb' => (int) env('MEDIA_VIDEO_MAX_UPLOAD_KB', 204800),
            // Any video container is accepted for STORAGE (iPhone .mov, Android .3gp, camera .avi/.mts, .mkv …): the real content type must be video/*
            // (checked on the bytes, not the name) and the extension must be one of these. Playback depends on the visitor's browser: MP4 (H.264) / WebM play everywhere.
            'extensions' => ['mp4', 'm4v', 'mov', 'qt', 'webm', 'mkv', 'avi', 'wmv', 'asf', 'flv', 'f4v', 'mpg', 'mpeg', 'mpe', 'm2v', 'mts', 'm2ts', 'ts', '3gp', '3g2', 'ogv', 'ogm', 'mxf', 'vob', 'divx', 'dv'],
            'mimes' => ['video/*'],
            'require_poster' => true,
        ],

        /*
         * SVG upload.
         *
         * Restricted to Super Admins because an SVG can carry script, CSS and
         * remote references, and the media library serves uploads from the
         * same origin as the control panel. Accepted files are rebuilt from a
         * strict allowlist before they touch disk.
         *
         * PNG and WebP are the intended formats for ordinary content.
         */
        'svg' => [
            'super_admin_only' => true,
            'mime' => 'image/svg+xml',
            'extension' => 'svg',
        ],

        /*
         * Decompression-bomb and memory guards.
         *
         * Dimensions are read from the file header before anything is
         * decoded; see App\Support\ResourceLimits for the reasoning.
         */
        'max_image_pixels' => 40_000_000,
        'max_image_dimension' => 12_000,

        // Responsive widths generated for raster images, largest first.
        // Anything wider than the source is skipped.
        'responsive_widths' => [1920, 1280, 960, 640, 400],

        'webp_quality' => 82,
    ],

    /*
    |--------------------------------------------------------------------------
    | Quote requests
    |--------------------------------------------------------------------------
    |
    | `reference_prefix` is combined with the year and a zero-padded sequence,
    | e.g. RFQ-2026-000184.
    |
    */

    'rfq' => [
        'reference_prefix' => 'RFQ',
        'max_items' => 20,

        // Upper bound on how many values one attribute of one line may carry.
        // Generous for a real inquiry, cheap to reject for a crafted one.
        'max_options_per_attribute' => 12,
        'max_attachments' => 5,
        'attachment_max_kb' => 5120,
        'attachment_extensions' => ['pdf', 'jpg', 'jpeg', 'png', 'doc', 'docx', 'xls', 'xlsx'],
    ],

    /*
    |--------------------------------------------------------------------------
    | Throttling
    |--------------------------------------------------------------------------
    */

    'throttle' => [
        // Admin sign-in failures: per account + IP a minute, per account an hour.
        'login' => (int) env('THROTTLE_LOGIN', 5),
        'login_account' => (int) env('THROTTLE_LOGIN_ACCOUNT', 20),
        'rfq' => (int) env('THROTTLE_RFQ', 5),
        'contact' => (int) env('THROTTLE_CONTACT', 5),
    ],

    /*
    |--------------------------------------------------------------------------
    | Trusted proxies
    |--------------------------------------------------------------------------
    |
    | Peers allowed to tell the application the real client address and the
    | original scheme (X-Forwarded-For / -Proto / -Host). Empty = trust no
    | proxy, which is correct for a site served directly by Apache. Only
    | explicit IP addresses and CIDR ranges are accepted; wildcards, hostnames
    | and /0 ranges are rejected. One invalid entry discards the whole list
    | (fail closed) and is reported by scripts/preflight.php. See
    | App\Support\Http\TrustedProxyList and .env.production.example.
    |
    */

    /*
    |--------------------------------------------------------------------------
    | Search-engine facing host
    |--------------------------------------------------------------------------
    | The preferred public origin for canonical, hreflang, Open Graph, sitemap and structured data, e.g. https://wadielrayan.net.
    | Empty = use APP_URL when it is https, otherwise the request's own origin (local development).
    */
    'seo' => [
        'public_url' => env('SEO_PUBLIC_URL'),
    ],

    'proxies' => (function (): array {
        $parsed = TrustedProxyList::parse(env('TRUSTED_PROXIES'));

        return [
            'trusted' => $parsed['errors'] === [] ? $parsed['entries'] : [],
            'errors' => $parsed['errors'],
            'warnings' => $parsed['warnings'],
        ];
    })(),

    /*
    |--------------------------------------------------------------------------
    | Admin access
    |--------------------------------------------------------------------------
    */

    'admin' => [
        'path' => 'admin',
        'ip_allowlist' => array_values(array_filter(
            array_map('trim', explode(',', (string) env('ADMIN_IP_ALLOWLIST', '')))
        )),
    ],

    /*
    |--------------------------------------------------------------------------
    | Cache keys and TTLs
    |--------------------------------------------------------------------------
    |
    | Public pages read settings and navigation from cache. Both are flushed
    | automatically whenever the underlying records are saved.
    |
    */

    /*
    |--------------------------------------------------------------------------
    | Homepage hero
    |--------------------------------------------------------------------------
    |
    | Auto-advance interval, in milliseconds. Seven seconds is deliberately
    | unhurried: a buyer reading a sub-heading in their second language needs
    | longer than the three or four seconds a marketing carousel usually gets.
    | Rotation is disabled entirely for visitors who prefer reduced motion.
    |
    */

    /*
    |--------------------------------------------------------------------------
    | Homepage composition
    |--------------------------------------------------------------------------
    |
    | The order the homepage ships in. Each key names a partial under
    | resources/views/home/sections/. This is the fallback used when the
    | home_sections table is empty, so a fresh install or an upgrade applied
    | before seeding still renders a complete page.
    |
    | Only keys listed here can be rendered as built-in sections: the render
    | loop checks membership before including anything, so a row naming an
    | arbitrary path cannot reach the filesystem.
    |
    */

    /*
    |--------------------------------------------------------------------------
    | Colour themes
    |--------------------------------------------------------------------------
    |
    | Each preset is a set of overrides for the design tokens declared in
    | resources/css/app.css. Tailwind 4 compiles those tokens to CSS custom
    | properties on :root, so re-declaring one later in the document re-colours
    | every utility that references it — no rebuild, no extra stylesheet, and
    | the change is one <style> block of a few hundred bytes.
    |
    | Only the colour tokens are themeable. Type scale, spacing and shadows stay
    | fixed: they are what make the site feel like one product, and letting them
    | drift is how a considered design becomes a template.
    |
    | 'estate' is the brand and the default. The others exist so a seasonal or
    | campaign look can be tried without a developer.
    |
    */

    'themes' => [
        'default' => 'estate',

        'presets' => [

            // The brand: deep olive, soft gold, warm ivory.
            'estate' => [
                'label_en' => 'Estate — deep olive and gold',
                'label_ar' => 'إستيت — زيتوني غامق وذهبي',
                'tokens' => [],
            ],

            // Warmer and lighter; olive held, gold pushed towards amber.
            'orchard' => [
                'label_en' => 'Orchard — warm olive and amber',
                'label_ar' => 'البستان — زيتوني دافئ وكهرماني',
                'tokens' => [
                    '--color-olive-deep' => '#1f4a36',
                    '--color-forest' => '#143528',
                    '--color-gold' => '#cf9a45',
                    '--color-gold-hover' => '#b8862f',
                    '--color-gold-soft' => '#efdcb8',
                    '--color-ivory' => '#faf6ec',
                    '--color-surface-alt' => '#faf6ec',
                    '--color-olive-deep-hover' => '#275c44',
                ],
            ],

            // Cooler, export and shipping: deep marine with brass.
            'harbour' => [
                'label_en' => 'Harbour — deep marine and brass',
                'label_ar' => 'المرفأ — أزرق بحري غامق ونحاسي',
                'tokens' => [
                    '--color-olive-deep' => '#123c46',
                    '--color-forest' => '#0b2a31',
                    '--color-olive-muted' => '#46707a',
                    '--color-gold' => '#c39b5f',
                    '--color-gold-hover' => '#ab8650',
                    '--color-gold-soft' => '#e6d6bb',
                    '--color-ivory' => '#f4f6f5',
                    '--color-surface-alt' => '#f4f6f5',
                    '--color-line' => '#dde3e2',
                    '--color-line-strong' => '#c5cecd',
                    '--color-olive-deep-hover' => '#1a4f5b',
                ],
            ],

            // Near-black olive for a restrained, high-contrast look.
            'obsidian' => [
                'label_en' => 'Obsidian — near-black and gold',
                'label_ar' => 'أوبسيديان — أسود قريب وذهبي',
                'tokens' => [
                    '--color-olive-deep' => '#14241e',
                    '--color-forest' => '#0a1512',
                    '--color-olive-muted' => '#5d6b54',
                    '--color-gold' => '#d0ad6c',
                    '--color-gold-hover' => '#b9975a',
                    '--color-ivory' => '#f5f4f0',
                    '--color-surface-alt' => '#f5f4f0',
                    '--color-olive-deep-hover' => '#1d322a',
                ],
            ],
        ],
    ],

    'home' => [
        'sections' => [
            'hero',
            // Its own band rather than a strip welded to the bottom of the
            // hero. It can now be switched off, moved, or placed below the
            // featured products without touching a template.
            'statistics',
            'categories',
            'featured',
            'values',
            'production',
            'certifications',
            'news',
            'cta',
        ],

        // Added with the Homepage Manager; seeded switched off.
        'optional_sections' => ['packaging', 'markets'],
    ],

    // Release identifier: the VERSION file written by the build script ("dev" in a source checkout).
    'version' => is_file(base_path('VERSION')) ? trim((string) file_get_contents(base_path('VERSION'))) : 'dev',

    /*
    |--------------------------------------------------------------------------
    | Automatic language selection (the unlocalized entry point only)
    |--------------------------------------------------------------------------
    |
    | Precedence: explicit URL > the visitor's saved manual choice > browser/country (policy) > English.
    | Everything below is only the DEFAULT; administrators change it in System -> Automatic language.
    */
    'locale_detection' => [
        'enabled' => true,
        // browser_first (default) | country_first
        'policy' => 'browser_first',
        'country_enabled' => false,
        // Name of a country header set by YOUR trusted CDN/proxy (e.g. CF-IPCountry). Honoured ONLY when the request comes from a proxy listed in TRUSTED_PROXIES.
        'country_header' => '',
        // Manual-choice cookie (a functional preference, set only when the visitor picks a language).
        'cookie' => 'wr_locale',
        'cookie_days' => 365,
        // Optional local IP->country database (see docs: geo:import). Plain files, no service, no network.
        'geo_dir' => storage_path('app/geo'),
    ],

    // Country (ISO 3166-1 alpha-2) -> language candidates in order of preference; the first PUBLIC language wins. Editable in the admin.
    'country_locales' => [
        'es' => ['ES', 'MX', 'AR', 'CO', 'CL', 'PE', 'VE', 'EC', 'GT', 'CU', 'BO', 'DO', 'HN', 'PY', 'SV', 'NI', 'CR', 'PA', 'UY', 'PR', 'GQ'],
        'fr' => ['FR', 'BE', 'LU', 'MC', 'SN', 'CI', 'ML', 'BF', 'NE', 'TG', 'BJ', 'GA', 'CG', 'CD', 'CM', 'MG', 'HT'],
        'it' => ['IT', 'SM', 'VA'],
        'pt' => ['PT', 'BR', 'AO', 'MZ', 'CV', 'GW', 'ST', 'TL'],
        'el' => ['GR', 'CY'],
        'ru' => ['RU', 'BY', 'KZ', 'KG'],
        'zh' => ['CN', 'TW', 'HK', 'MO', 'SG'],
        'ur' => ['PK'],
        'ar' => ['SA', 'EG', 'AE', 'KW', 'QA', 'BH', 'OM', 'JO', 'LB', 'SY', 'IQ', 'YE', 'LY', 'TN', 'DZ', 'MA', 'SD', 'PS', 'MR', 'SO', 'DJ'],
    ],

    'navigation' => [
        // Levels in a menu: 1 = top row only. Deeper nesting is refused by the model, not only hidden in a form.
        'max_depth' => (int) env('NAVIGATION_MAX_DEPTH', 3),
    ],

    'hero' => [
        // Default time an IMAGE slide stays on screen (seconds); each slide can set its own. Video slides default to
        // "automatic": they advance when the video (or its start-end segment) ends.
        'image_seconds' => (int) env('HERO_IMAGE_SECONDS', 5),
        // Legacy site-wide interval (no longer used by the carousel; kept so an existing HERO_INTERVAL_MS stays valid).
        'interval' => (int) env('HERO_INTERVAL_MS', 7000),
        // How many slides the homepage hero may hold (editor limit and public cap). Raise with HERO_MAX_SLIDES; never below 1.
        'max_slides' => max(1, (int) env('HERO_MAX_SLIDES', 30)),
    ],

    'cache' => [
        'settings_key' => 'wadi.settings',
        'navigation_key' => 'wadi.navigation',
        'ttl' => 60 * 60 * 24,
    ],

    /*
    |--------------------------------------------------------------------------
    | Analytics
    |--------------------------------------------------------------------------
    */

    'analytics' => [
        'ga_id' => env('GOOGLE_ANALYTICS_ID'),
        'gtm_id' => env('GOOGLE_TAG_MANAGER_ID'),
    ],

    /*
    |--------------------------------------------------------------------------
    | Notification recipients
    |--------------------------------------------------------------------------
    |
    | Falls back to the address held in Settings when left empty.
    |
    */

    // Date/time shown in customer e-mails carries this zone's label.
    'business_timezone' => env('WADI_BUSINESS_TIMEZONE', 'Africa/Cairo'),

    'mail' => [
        // Seconds the SMTP connection may stay silent before a send is abandoned (shared hosts can hang on a blocked port).
        'timeout' => (int) env('MAIL_TIMEOUT', 15),
        // Read here (not with env() elsewhere) so they survive `config:cache`.
        'env_host' => (string) env('MAIL_HOST', ''),
        'env_from' => (string) env('MAIL_FROM_ADDRESS', ''),
        // Automatic retries of a failed e-mail (run by the scheduler, if cron is configured): attempts and minutes between them.
        'max_attempts' => 5,
        'retry_minutes' => [5, 15, 60, 240],
    ],

    'notifications' => [
        'sales_inbox' => array_values(array_filter(
            array_map('trim', explode(',', (string) env('MAIL_SALES_INBOX', '')))
        )),
        'contact_inbox' => array_values(array_filter(
            array_map('trim', explode(',', (string) env('MAIL_CONTACT_INBOX', '')))
        )),
    ],

    /*
    |--------------------------------------------------------------------------
    | Company locations
    |--------------------------------------------------------------------------
    |
    | The permitted values for a location's `type` column. Kept here rather than
    | in a MySQL enum so that adding one is a config edit rather than an ALTER
    | on a live table — the brief asks for the list to be extensible.
    |
    | Each key needs a matching entry under `locations.types` in both language
    | files; a type with no translation falls back to showing its own key.
    |
    */

    'locations' => [
        'types' => [
            'head_office',
            'factory',
            'warehouse',
            'branch',
            'sales_office',
            'export_office',
            'farm',
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Google Maps
    |--------------------------------------------------------------------------
    |
    | The embed is generated from each location's coordinates rather than from
    | a URL pasted into a settings field. See CompanyLocation::embedUrl() for
    | why that matters — briefly, a pasted embed URL is ~800 characters of
    | nested parameters that has to survive a POST through whatever web
    | application firewall the host runs, and coordinates are two numbers.
    |
    | No API key is required. `maps.google.com/maps?…&output=embed` is the
    | keyless endpoint and is what most WordPress map plugins emit. Setting
    | GOOGLE_MAPS_EMBED_API_KEY switches to the official Embed API instead;
    | leave it empty unless you have a reason.
    |
    */

    'maps' => [
        'enabled' => (bool) env('GOOGLE_MAPS_EMBED_ENABLED', true),
        'api_key' => env('GOOGLE_MAPS_EMBED_API_KEY', ''),
        'zoom' => (int) env('GOOGLE_MAPS_EMBED_ZOOM', 15),
    ],

    /*
    |--------------------------------------------------------------------------
    | Diagnostics
    |--------------------------------------------------------------------------
    |
    | Setting a token registers the temporary diagnostics routes; leaving it
    | empty means they do not exist. Clear it once a problem is solved.
    |
    */

    'diagnostics' => [
        'token' => env('MAP_DIAGNOSTICS_TOKEN', ''),
        // STAGING ONLY: exposes /_diagnostics/network to a signed-in Super
        // Admin. Production preflight fails while this is on.
        'network' => filter_var(env('NETWORK_DIAGNOSTIC_ENABLED', false), FILTER_VALIDATE_BOOLEAN),
    ],
];
