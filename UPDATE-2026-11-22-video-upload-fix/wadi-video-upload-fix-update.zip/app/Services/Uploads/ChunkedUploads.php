<?php

declare(strict_types=1);

namespace App\Services\Uploads;

use App\Models\AuditLog;
use App\Models\MediaAsset;
use App\Models\UploadSession;
use App\Models\User;
use App\Rules\SafeRasterImage;
use App\Services\Media\MediaManager;
use App\Support\Uploads\UploadLimits;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use RuntimeException;
use Throwable;

/**
 * Authenticated, resumable, chunked uploads for files too big for one request on shared hosting.
 *
 * The client sends the file in small sequential chunks; the server appends each one to a private temporary file at the exact
 * offset it expects (so a retry never corrupts it), and only when every byte has arrived is the assembled file validated (size,
 * real content type, image dimensions) and handed to MediaManager. A failed, cancelled or expired upload deletes its bytes and never
 * creates a media record.
 */
final class ChunkedUploads
{
    private const EXTENSIONS = [
        'video' => ['mp4', 'm4v', 'mov', 'qt', 'webm', 'mkv', 'avi', 'wmv', 'asf', 'flv', 'f4v', 'mpg', 'mpeg', 'mpe', 'm2v', 'mts', 'm2ts', 'ts', '3gp', '3g2', 'ogv', 'ogm', 'mxf', 'vob', 'divx', 'dv'],
        'image' => ['jpg', 'jpeg', 'png', 'webp'],
        'document' => ['pdf'],
    ];

    private const MIMES = [
        'video' => ['video/*'],
        'image' => ['image/jpeg', 'image/png', 'image/webp'],
        'document' => ['application/pdf'],
    ];

    /** @param array{name: string, size: int, type?: ?string, category: string, folder?: ?string, alt_en?: ?string, alt_ar?: ?string, sha256?: ?string} $meta */
    public function start(User $user, array $meta): UploadSession
    {
        $this->cleanup();

        $category = (string) $meta['category'];
        if (! isset(self::EXTENSIONS[$category])) {
            throw new RuntimeException('This kind of file cannot be sent with the large-file uploader.');
        }

        $name = $this->cleanName((string) $meta['name']);
        $size = (int) $meta['size'];
        $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));

        if ($size <= 0) {
            throw new RuntimeException('The file is empty.');
        }
        if ($size > UploadLimits::bytes($category)) {
            throw new RuntimeException('The file is '.UploadLimits::human($size).', above the '.UploadLimits::human(UploadLimits::bytes($category)).' limit for this kind of file.');
        }
        if (! in_array($ext, self::EXTENSIONS[$category], true)) {
            throw new RuntimeException('Only '.strtoupper(implode(', ', self::EXTENSIONS[$category])).' files are accepted here.');
        }
        $declared = (string) ($meta['type'] ?? '');
        $declaredOk = in_array($declared, self::MIMES[$category], true) || (in_array('video/*', self::MIMES[$category], true) && str_starts_with($declared, 'video/'));
        // Some systems send no type, or application/octet-stream, for rarer containers: the bytes are judged at the end, not this label.
        if ($category === 'video' && ($declared === '' || $declared === 'application/octet-stream')) {
            $declaredOk = true;
        }
        if (filled($declared) && ! $declaredOk) {
            throw new RuntimeException('The file type '.e((string) $meta['type']).' is not accepted here.');
        }

        $open = UploadSession::query()->where('user_id', $user->getKey())->where('status', 'open')->where('expires_at', '>', now())->count();
        if ($open >= (int) config('wadi.uploads.max_open_sessions_per_user', 3)) {
            throw new RuntimeException('You already have '.$open.' uploads in progress. Finish or cancel one first.');
        }

        $dir = UploadSession::directory();
        if (! is_dir($dir) && ! @mkdir($dir, 0750, true) && ! is_dir($dir)) {
            throw new RuntimeException('The private upload folder cannot be created. Check that storage/app/private is writable.');
        }
        $free = @disk_free_space($dir);
        if ($free !== false && $free < $size * 2.5) {
            throw new RuntimeException('Not enough free disk space on the server for this upload ('.UploadLimits::human((int) $free).' free).');
        }

        $session = UploadSession::create([
            'user_id' => $user->getKey(), 'category' => $category, 'original_name' => $name, 'declared_mime' => $meta['type'] ?? null,
            'size' => $size, 'received' => 0, 'chunk_size' => UploadLimits::chunkKb() * 1024, 'folder' => $this->folder($meta['folder'] ?? null),
            'alt_en' => $meta['alt_en'] ?? null, 'alt_ar' => $meta['alt_ar'] ?? null,
            'sha256' => ($h = strtolower((string) ($meta['sha256'] ?? ''))) !== '' && preg_match('/^[a-f0-9]{64}$/', $h) ? $h : null,
            'status' => 'open', 'expires_at' => now()->addHours((int) config('wadi.uploads.session_ttl_hours', 24)),
        ]);

        touch($session->partPath());
        @chmod($session->partPath(), 0640);

        return $session;
    }

    /**
     * Append one chunk at $offset. Idempotent: a retried chunk that was already stored is acknowledged without being written twice.
     *
     * @param  resource  $stream
     */
    public function append(UploadSession $session, int $offset, $stream, int $declaredLength): UploadSession
    {
        if (! $session->isOpen()) {
            throw new RuntimeException('This upload is no longer open ('.$session->status.').');
        }
        if ($offset < $session->received) {
            return $session;   // already have these bytes
        }
        if ($offset !== $session->received) {
            throw new OffsetMismatch($session->received);
        }
        if ($declaredLength <= 0 || $declaredLength > $session->chunk_size || $offset + $declaredLength > $session->size) {
            throw new RuntimeException('The chunk size is not valid for this upload.');
        }

        $fh = fopen($session->partPath(), 'c+b');
        if ($fh === false || ! flock($fh, LOCK_EX | LOCK_NB)) {
            $fh && fclose($fh);
            throw new RuntimeException('This upload is busy. Try again in a moment.');
        }

        try {
            if ($offset !== (int) fstat($fh)['size']) {
                // The file and the database disagree (an interrupted write): trust the file, and truncate to what is recorded.
                ftruncate($fh, $session->received);
            }
            fseek($fh, $offset);
            $written = 0;
            while ($written < $declaredLength && ! feof($stream)) {
                $buf = fread($stream, min(65536, $declaredLength - $written));
                if ($buf === false || $buf === '') {
                    break;
                }
                fwrite($fh, $buf);
                $written += strlen($buf);
            }
            fflush($fh);

            if ($written !== $declaredLength) {
                ftruncate($fh, $offset);   // a cut-off request leaves no partial chunk behind
                throw new RuntimeException('The chunk arrived incomplete ('.$written.' of '.$declaredLength.' bytes). Retry it.');
            }
        } finally {
            flock($fh, LOCK_UN);
            fclose($fh);
        }

        $session->update(['received' => $offset + $declaredLength, 'last_chunk_at' => now()]);

        return $session;
    }

    /** Verify the assembled file and register it in the Media Library. */
    public function complete(UploadSession $session, User $user): MediaAsset
    {
        if ($session->status === 'complete' && $session->media_id !== null && ($asset = MediaAsset::find($session->media_id)) !== null) {
            return $asset;   // idempotent
        }
        if (! $session->isOpen()) {
            throw new RuntimeException('This upload is no longer open ('.$session->status.').');
        }
        if ($session->received !== $session->size) {
            throw new RuntimeException('The upload is not complete: '.UploadLimits::human($session->received).' of '.UploadLimits::human($session->size).' received.');
        }

        $path = $session->partPath();
        try {
            if (! is_file($path) || filesize($path) !== $session->size) {
                throw new RuntimeException('The assembled file does not have the expected size. Start the upload again.');
            }
            if ($session->sha256 !== null && ! hash_equals($session->sha256, (string) hash_file('sha256', $path))) {
                throw new RuntimeException('The file was damaged in transit (checksum mismatch). Start the upload again.');
            }

            $mime = (string) (new \finfo(FILEINFO_MIME_TYPE))->file($path);
            $allowed = self::MIMES[$session->category];
            if (! in_array($mime, $allowed, true) && ! (in_array('video/*', $allowed, true) && str_starts_with($mime, 'video/'))) {
                throw new RuntimeException('The file content is not a valid '.$session->category.' ('.($mime ?: 'unknown').').');
            }
            $this->assertMagic($path, $session->category, $mime);

            $upload = new UploadedFile($path, $session->original_name, $mime, null, true);
            if ($session->category === 'image') {
                $v = Validator::make(['f' => $upload], ['f' => [new SafeRasterImage]]);
                if ($v->fails()) {
                    throw new RuntimeException((string) $v->errors()->first());
                }
            }

            $asset = DB::transaction(fn (): MediaAsset => app(MediaManager::class)->store($upload, $session->folder, array_filter([
                'alt_en' => $session->alt_en, 'alt_ar' => $session->alt_ar, 'uploaded_by' => $user->getKey(),
            ])));

            @unlink($path);
            $session->update(['status' => 'complete', 'media_id' => $asset->getKey(), 'error' => null]);
            $this->audit($user, 'media.chunked_upload_completed', $session, ['media_id' => $asset->getKey(), 'bytes' => $session->size]);

            return $asset;
        } catch (Throwable $e) {
            @unlink($path);
            $session->update(['status' => 'failed', 'error' => mb_substr($e->getMessage(), 0, 480)]);
            $this->audit($user, 'media.chunked_upload_failed', $session, ['reason' => mb_substr($e->getMessage(), 0, 200)]);

            throw $e instanceof RuntimeException ? $e : new RuntimeException('The upload could not be completed. Details are in the server log.', 0, $e);
        }
    }

    public function cancel(UploadSession $session, User $user): void
    {
        if ($session->status === 'open') {
            @unlink($session->partPath());
            $session->update(['status' => 'cancelled']);
            $this->audit($user, 'media.chunked_upload_cancelled', $session, []);
        }
    }

    /** Remove expired and finished sessions' leftovers and orphaned part files. @return int files removed */
    public function cleanup(): int
    {
        $removed = 0;

        foreach (UploadSession::query()->where('status', 'open')->where('expires_at', '<=', now())->get() as $s) {
            @unlink($s->partPath()) && $removed++;
            $s->update(['status' => 'expired']);
        }

        $dir = UploadSession::directory();
        if (is_dir($dir)) {
            $known = UploadSession::query()->where('status', 'open')->pluck('id')->flip();
            foreach (glob($dir.'/*.part') ?: [] as $file) {
                $id = basename($file, '.part');
                if (! $known->has($id) && filemtime($file) < time() - 3600) {
                    @unlink($file) && $removed++;
                }
            }
        }

        UploadSession::query()->whereIn('status', ['complete', 'failed', 'cancelled', 'expired'])->where('updated_at', '<', now()->subDays(7))->delete();

        return $removed;
    }

    private function assertMagic(string $path, string $category, string $mime): void
    {
        $head = (string) file_get_contents($path, false, null, 0, 16);
        $ok = match (true) {
            $category === 'video' && in_array($mime, ['video/mp4', 'video/x-m4v'], true) => substr($head, 4, 4) === 'ftyp',
            // QuickTime (.mov) files start with an ftyp box or an older-style atom.
            $category === 'video' && $mime === 'video/quicktime' => in_array(substr($head, 4, 4), ['ftyp', 'moov', 'mdat', 'wide', 'free', 'skip', 'pnot'], true),
            // Every other video container: the content type was already established from the bytes (finfo says video/*); here the known
            // signatures are checked where one exists, and anything else video/* is accepted as stored.
            $category === 'video' && $mime === 'video/webm' => str_starts_with($head, "\x1A\x45\xDF\xA3"),
            $category === 'video' => true,
            $category === 'document' => str_starts_with($head, '%PDF-'),
            default => true,
        };

        if (! $ok) {
            throw new RuntimeException('The file content does not match its type.');
        }
    }

    private function cleanName(string $name): string
    {
        $name = trim(preg_replace('/[\x00-\x1F\x7F\/\\\\]+/', '', basename($name)) ?? '');

        return $name === '' ? 'upload' : mb_substr($name, 0, 200);
    }

    private function folder(?string $folder): string
    {
        $folder = strtolower((string) $folder);

        return preg_match('/^[a-z0-9][a-z0-9_-]{0,40}$/', $folder) ? $folder : 'general';
    }

    /** @param array<string, mixed> $values */
    private function audit(User $user, string $action, UploadSession $s, array $values): void
    {
        try {
            AuditLog::create([
                'user_id' => $user->getKey(), 'user_name' => $user->name, 'action' => $action, 'auditable_type' => 'upload_session',
                'auditable_id' => 0, 'auditable_label' => mb_substr($s->original_name, 0, 100), 'new_values' => $values, 'created_at' => now(),
            ]);
        } catch (Throwable $e) {
            report($e);
        }
    }
}
