<x-filament-panels::page>
    @php($lim = $this->limits())
    <div x-data="largeUploader(@js($lim))" class="space-y-4" data-testid="large-uploader">
        <div class="rounded-xl bg-white p-4 text-sm shadow-sm ring-1 ring-gray-950/5 dark:bg-gray-900 dark:ring-white/10">
            <p>Send big files in small resumable pieces. Videos up to <strong x-text="fmt(limits.video)"></strong>, images up to <strong x-text="fmt(limits.image)"></strong>, PDFs up to <strong x-text="fmt(limits.document)"></strong>.
                If the connection drops, choose the same file again and it continues where it stopped. The file is checked (type, size, image dimensions) only when every piece has arrived; nothing appears in the Media Library until then.</p>
            <p class="mt-2 text-gray-500">Allowed: MP4 / WebM video, JPEG / PNG / WebP images, PDF. Pieces of <span x-text="fmt(limits.chunk)"></span>.</p>
        </div>

        <div class="grid gap-3 rounded-xl bg-white p-4 shadow-sm ring-1 ring-gray-950/5 dark:bg-gray-900 dark:ring-white/10 sm:grid-cols-2">
            <label class="text-sm sm:col-span-2">File
                <input type="file" x-ref="file" @change="pick($event)" accept="video/*,.mp4,.m4v,.mov,.mkv,.avi,.wmv,.flv,.mpg,.mpeg,.3gp,.webm,.jpg,.jpeg,.png,.webp,.pdf,image/jpeg,image/png,image/webp,application/pdf" class="mt-1 block w-full text-sm" data-testid="file">
            </label>
            <label class="text-sm">Alt text / description (English)<input type="text" maxlength="255" x-model="alt_en" class="mt-1 block w-full rounded-lg border-gray-300 text-sm"></label>
            <label class="text-sm">النص البديل / الوصف (العربية)<input type="text" dir="rtl" maxlength="255" x-model="alt_ar" class="mt-1 block w-full rounded-lg border-gray-300 text-sm"></label>
            <label class="text-sm">Folder
                <select x-model="folder" class="mt-1 block w-full rounded-lg border-gray-300 text-sm">
                    <option value="branding">Branding (hero / intro)</option><option value="products">Products</option><option value="general">General</option><option value="documents">Documents</option>
                </select>
            </label>
            <div class="flex items-end gap-2">
                <button type="button" @click="start()" :disabled="!file || busy" class="rounded-lg bg-primary-600 px-4 py-2 text-sm text-white disabled:opacity-50" data-testid="start">Upload</button>
                <button type="button" @click="cancel()" x-show="busy || sessionId" class="rounded-lg border px-4 py-2 text-sm" data-testid="cancel">Cancel upload</button>
            </div>
        </div>

        <div x-show="state !== 'idle'" class="rounded-xl bg-white p-4 shadow-sm ring-1 ring-gray-950/5 dark:bg-gray-900 dark:ring-white/10" aria-live="polite" data-testid="progress">
            <div class="h-3 w-full overflow-hidden rounded bg-gray-100"><div class="h-3 bg-primary-600 transition-all" :style="'width:' + pct + '%'"></div></div>
            <p class="mt-2 text-sm"><span x-text="message"></span> <span class="text-gray-500" x-show="busy" x-text="'— ' + pct + '% · ' + speed + ' · ' + eta"></span></p>
            <p x-show="error" class="mt-1 text-sm text-danger-600" x-text="error" role="alert"></p>
            <p x-show="mediaId" class="mt-1 text-sm">Added to the Media Library (ID <strong x-text="mediaId"></strong>). To use it: open the field (Homepage Manager → Intro video, Hero slides → Video, or a page block), click “Choose a file” and pick it from the library — no second upload is needed.</p>
        </div>

        @if ($this->recent()->isNotEmpty())
            <div class="rounded-xl bg-white p-4 text-sm shadow-sm ring-1 ring-gray-950/5 dark:bg-gray-900 dark:ring-white/10">
                <h3 class="mb-2 font-semibold">Your recent uploads</h3>
                @foreach ($this->recent() as $s)
                    <div class="flex flex-wrap justify-between gap-2 border-t py-1"><span>{{ $s->original_name }}</span><span class="text-gray-500">{{ $s->status }}{{ $s->media_id ? ' · media #'.$s->media_id : '' }}{{ $s->error ? ' · '.$s->error : '' }}</span></div>
                @endforeach
            </div>
        @endif
    </div>

    <script>
        document.addEventListener('alpine:init', () => {
            Alpine.data('largeUploader', (limits) => ({
                limits, file: null, alt_en: '', alt_ar: '', folder: 'branding', busy: false, state: 'idle', pct: 0, message: '', error: '', mediaId: null,
                sessionId: null, speed: '', eta: '', aborter: null, cancelled: false,
                fmt(b) { return b >= 1073741824 ? (b / 1073741824).toFixed(2) + ' GiB' : b >= 1048576 ? (b / 1048576).toFixed(1) + ' MiB' : Math.round(b / 1024) + ' KiB'; },
                csrf() { return document.querySelector('meta[name="csrf-token"]')?.content || ''; },
                headers(extra = {}) { return Object.assign({ 'X-CSRF-TOKEN': this.csrf(), 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' }, extra); },
                pick(e) { this.file = e.target.files[0] || null; this.error = ''; this.mediaId = null; this.state = 'idle'; this.pct = 0; },
                category() { const n = (this.file?.name || '').toLowerCase(); return /\.(mp4|webm)$/.test(n) ? 'video' : /\.pdf$/.test(n) ? 'document' : 'image'; },
                async json(res) { let body = {}; try { body = await res.json(); } catch (_) {} return { ok: res.ok, status: res.status, body }; },
                async start() {
                    if (!this.file) return;
                    this.busy = true; this.cancelled = false; this.error = ''; this.mediaId = null; this.state = 'working'; this.message = 'Preparing…';
                    try {
                        const cat = this.category();
                        if (this.file.size > this.limits[cat]) throw new Error('This file is ' + this.fmt(this.file.size) + ', above the ' + this.fmt(this.limits[cat]) + ' limit for this kind of file.');
                        let s = await (await fetch(this.limits.urls.find + '?' + new URLSearchParams({ name: this.file.name, size: this.file.size }), { headers: this.headers(), credentials: 'same-origin' })).json();
                        if (!s.id) {
                            const r = await this.json(await fetch(this.limits.urls.start, { method: 'POST', credentials: 'same-origin', headers: this.headers({ 'Content-Type': 'application/json' }),
                                body: JSON.stringify({ name: this.file.name, size: this.file.size, type: this.file.type || null, category: cat, folder: this.folder, alt_en: this.alt_en, alt_ar: this.alt_ar }) }));
                            if (!r.ok) throw new Error(r.body.error || (r.body.message ?? 'The server refused this upload.'));
                            s = r.body;
                        } else { this.message = 'Resuming an interrupted upload…'; }
                        this.sessionId = s.id; let offset = s.received; const size = this.file.size; const chunk = s.chunk_size; const t0 = Date.now(); const start0 = offset; let retries = 0;
                        while (offset < size) {
                            if (this.cancelled) throw new Error('Upload cancelled.');
                            const end = Math.min(offset + chunk, size); const blob = this.file.slice(offset, end);
                            try {
                                const res = await this.json(await fetch(this.limits.urls.base + '/' + this.sessionId + '/chunk', { method: 'PUT', credentials: 'same-origin', body: blob,
                                    headers: this.headers({ 'X-Upload-Offset': String(offset), 'Content-Type': 'application/octet-stream' }) }));
                                if (res.status === 409) { offset = res.body.received; continue; }
                                if (!res.ok) { if (res.status === 419 || res.status === 401 || res.status === 403) throw new Error('Your session expired. Reload the page, sign in, and choose the file again to resume.'); if (res.status >= 500 || res.status === 429) throw new Error('retry'); throw new Error(res.body.error || 'The server rejected a piece.'); }
                                offset = res.body.received; retries = 0;
                            } catch (e) {
                                if (this.cancelled) throw new Error('Upload cancelled.');
                                if (e.message === 'retry' || e instanceof TypeError) { if (++retries > 8) throw new Error('The connection keeps failing. Choose the same file later to resume from ' + this.pct + '%.'); this.message = 'Connection problem, retrying (' + retries + ')…'; await new Promise(r => setTimeout(r, Math.min(30000, 1000 * 2 ** retries))); continue; }
                                throw e;
                            }
                            this.pct = Math.floor(offset / size * 100); this.message = 'Uploading ' + this.file.name;
                            const el = (Date.now() - t0) / 1000, rate = (offset - start0) / Math.max(el, 1); this.speed = this.fmt(rate) + '/s'; const left = (size - offset) / Math.max(rate, 1); this.eta = left > 90 ? Math.round(left / 60) + ' min left' : Math.round(left) + ' s left';
                        }
                        this.message = 'Checking and adding to the Media Library…'; this.pct = 100;
                        const done = await this.json(await fetch(this.limits.urls.base + '/' + this.sessionId + '/complete', { method: 'POST', credentials: 'same-origin', headers: this.headers() }));
                        if (!done.ok) throw new Error(done.body.error || 'The file could not be completed.');
                        this.mediaId = done.body.media_id; this.message = 'Done: ' + done.body.filename; this.state = 'done'; this.sessionId = null;
                    } catch (e) { this.error = e.message; this.state = 'error'; this.message = 'Stopped.'; }
                    finally { this.busy = false; }
                },
                async cancel() {
                    this.cancelled = true;
                    if (this.sessionId) { await fetch(this.limits.urls.base + '/' + this.sessionId, { method: 'DELETE', credentials: 'same-origin', headers: this.headers() }); this.sessionId = null; }
                    this.busy = false; this.state = 'error'; this.error = 'Upload cancelled.'; this.message = 'Stopped.';
                },
            }));
        });
    </script>
</x-filament-panels::page>
