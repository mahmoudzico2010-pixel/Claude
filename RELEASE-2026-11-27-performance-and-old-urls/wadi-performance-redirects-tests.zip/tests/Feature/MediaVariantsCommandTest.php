<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Models\MediaAsset;
use App\Services\Media\MediaManager;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;

final class MediaVariantsCommandTest extends TestCase
{
    use RefreshDatabase;

    #[Test]
    public function it_adds_smaller_copies_without_touching_the_original_and_is_idempotent(): void
    {
        Storage::fake('public');
        $asset = app(MediaManager::class)->store(UploadedFile::fake()->image('big.jpg', 1600, 1200)->size(300), 'general');
        // simulate an image imported without copies
        foreach ((array) $asset->variants as $v) {
            Storage::disk('public')->delete($v['path']);
        }
        $asset->forceFill(['variants' => null])->save();
        $before = Storage::disk('public')->get($asset->path);

        $this->artisan('media:variants', ['--min-kb' => 0])->assertSuccessful();
        $asset->refresh();
        $this->assertNotEmpty($asset->variants);
        foreach ($asset->variants as $v) {
            Storage::disk('public')->assertExists($v['path']);
            $this->assertLessThanOrEqual(1600, $v['width']);
        }
        $this->assertSame($before, Storage::disk('public')->get($asset->path), 'the original file is never rewritten');

        $paths = collect($asset->variants)->pluck('path')->all();
        $this->artisan('media:variants', ['--min-kb' => 0])->expectsOutputToContain('0 image(s) without smaller copies')->assertSuccessful();
        $this->assertSame($paths, collect($asset->refresh()->variants)->pluck('path')->all());
    }
}
