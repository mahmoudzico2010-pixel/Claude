<?php

declare(strict_types=1);

namespace App\Console\Commands;

use App\Models\MediaAsset;
use App\Services\Media\MediaManager;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Storage;

/**
 * Creates the smaller WebP copies (400/640/960/1280/1920 px wide, never larger than the original) for images that have none,
 * so product cards, thumbnails and slides stop downloading the full-size original. Only ADDS new files beside the original; the
 * original file and its address never change; running it again does nothing for images that already have copies.
 * Works in small batches so it is safe on shared hosting: run it again until it says 0 remaining.
 */
class MediaVariantsCommand extends Command
{
    protected $signature = 'media:variants {--limit=20 : images per run} {--dry-run : only count} {--min-kb=40 : skip originals smaller than this}';

    protected $description = 'Generate missing responsive image copies (adds files, never changes originals)';

    public function handle(MediaManager $media): int
    {
        $minBytes = max(0, (int) $this->option('min-kb')) * 1024;
        $query = MediaAsset::query()->where('mime_type', 'like', 'image/%')
            ->where(fn ($q) => $q->whereNull('variants')->orWhere('variants', '[]')->orWhere('variants', ''))
            ->orderBy('id');

        $todo = $query->get()->filter(fn (MediaAsset $a): bool => $a->isRaster()
            && ($a->width === null || $a->width > 400)
            && Storage::disk($a->disk)->exists($a->path)
            && Storage::disk($a->disk)->size($a->path) >= $minBytes)->values();

        $this->line($todo->count().' image(s) without smaller copies.');
        if ($this->option('dry-run') || $todo->isEmpty()) {
            return self::SUCCESS;
        }

        $done = 0;
        foreach ($todo->take(max(1, (int) $this->option('limit'))) as $asset) {
            $media->generateVariants($asset);
            $asset->refresh();
            $ok = ! empty($asset->variants);
            $done += $ok ? 1 : 0;
            $this->line(($ok ? '  ok   ' : '  skip ').$asset->path.($ok ? ' ('.count($asset->variants).' sizes)' : ''));
        }
        $this->info("$done done, ".max(0, $todo->count() - $done).' remaining (run again until 0).');

        return self::SUCCESS;
    }
}
