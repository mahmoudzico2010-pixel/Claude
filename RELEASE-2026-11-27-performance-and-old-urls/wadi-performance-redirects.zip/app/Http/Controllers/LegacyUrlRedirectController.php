<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Page;
use App\Models\Product;
use App\Models\Variety;
use App\Support\Locales;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

/**
 * 301 from the OLD website's addresses (still shown by Google) to the same page on the new site.
 *
 * Evidence for the patterns (owner's own screenshots): /contact-us, /cookie-policy, /public/product/<slug>, and Google listing a
 * product under "Shop > Green Olives" with the same product slug the new catalogue uses. The usual shop layouts (/product/<slug>,
 * /shop/<category>/<slug>, /product-category/<slug>) are handled the same way. A redirect happens ONLY when the target really
 * exists (a published product, an active category/variety, a public page); anything else is a plain 404 — never the homepage,
 * and never a redirect to a host or path taken from the request, so it cannot be used as an open redirect.
 */
class LegacyUrlRedirectController extends Controller
{
    public function __invoke(Request $request, ?string $path = null): RedirectResponse
    {
        $target = $this->resolve($this->clean((string) $request->path()));

        abort_if($target === null, 404);

        return redirect()->to($target, 301);
    }

    private bool $hadPublicPrefix = false;

    private function clean(string $path): string
    {
        $path = strtolower(trim(rawurldecode($path), '/'));
        $this->hadPublicPrefix = str_starts_with($path, 'public/');
        $path = preg_replace('#^public/#', '', $path) ?? $path;

        return preg_replace('/\.(html?|php)$/', '', $path) ?? $path;
    }

    private function resolve(string $path): ?string
    {
        $locale = Locales::default();
        $segments = $path === '' ? [] : explode('/', $path);
        $first = $segments[0] ?? '';
        // /public/en/products/x (the application folder showing in the address) -> /en/products/x
        if (Locales::isSupported($first) && count($segments) > 1 && $this->hadPublicPrefix) {
            return '/'.$path;
        }
        $last = end($segments) ?: '';
        $slug = preg_match('/^[a-z0-9]+(?:-[a-z0-9]+)*$/', $last) === 1 ? $last : null;

        $fixed = [
            'contact-us' => fn () => route('contact.show', ['locale' => $locale]),
            'contact' => fn () => route('contact.show', ['locale' => $locale]),
            'about-us' => fn () => route('about', ['locale' => $locale]),
            'shop' => fn () => route('products.index', ['locale' => $locale]),
            'products' => fn () => route('products.index', ['locale' => $locale]),
            'privacy-policy' => fn () => $this->legal('privacy', $locale),
            'cookie-policy' => fn () => $this->legal('privacy', $locale),   // the privacy policy is where cookies are described
            'terms' => fn () => $this->legal('terms', $locale),
        ];
        if (count($segments) === 1 && isset($fixed[$first])) {
            return $fixed[$first]();
        }

        if ($slug === null) {
            return null;
        }

        if (in_array($first, ['product', 'shop', 'products'], true) && count($segments) >= 2) {
            if (Product::query()->published()->where('slug', $slug)->exists()) {
                return route('products.show', ['locale' => $locale, 'product' => $slug]);
            }
            if (Category::query()->active()->where('slug', $slug)->exists()) {
                return route('products.category', ['locale' => $locale, 'category' => $slug]);
            }
            if (Variety::query()->active()->where('slug', $slug)->exists()) {
                return route('products.variety', ['locale' => $locale, 'variety' => $slug]);
            }

            return null;
        }

        if (in_array($first, ['product-category', 'category', 'product_cat'], true) && count($segments) >= 2
            && Category::query()->active()->where('slug', $slug)->exists()) {
            return route('products.category', ['locale' => $locale, 'category' => $slug]);
        }

        return null;
    }

    private function legal(string $key, string $locale): ?string
    {
        $public = Page::query()->published()->where('key', $key)->exists() && Page::publiclyLinkableLegalPages()->contains(fn ($p) => ($p['key'] ?? null) === $key);

        return $public ? route($key === 'terms' ? 'terms' : 'privacy', ['locale' => $locale]) : null;
    }
}
