<?php

declare(strict_types=1);

namespace App\Http\Middleware;

use App\Support\PublicHost;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * One permanent redirect (301, no chain) from the www/non-www twin of the preferred host, and from plain HTTP on that host, to
 * the preferred https origin, keeping path and query string. Only GET/HEAD are redirected so a form post, API call, webhook or
 * signed callback is never bounced. Hosts that are neither the preferred host nor its www twin (IP address, staging domain,
 * localhost) are left alone. It is a safety net: the cleanest place for the same redirect is the host's .htaccess (see the guide).
 */
class RedirectToPreferredHost
{
    private const SKIP = ['livewire*', '_wr/*', 'up', 'install*', 'plugins/*', 'api/*'];

    public function handle(Request $request, Closure $next): Response
    {
        // Opt-in: only when the owner has set SEO_PUBLIC_URL. A host guessed from APP_URL must never move visitors to another address.
        $base = filled(config('wadi.seo.public_url')) ? PublicHost::base() : null;
        if ($base === null || ! in_array($request->getMethod(), ['GET', 'HEAD'], true) || $request->is(...self::SKIP) || $request->is(trim((string) config('wadi.admin.path', 'admin'), '/').'*')) {
            return $next($request);
        }

        $preferred = (string) PublicHost::host();
        $twin = str_starts_with($preferred, 'www.') ? substr($preferred, 4) : 'www.'.$preferred;
        $host = strtolower($request->getHost());
        $needsHost = $host === $twin;
        $needsHttps = str_starts_with($base, 'https://') && ! $request->isSecure() && ($host === $preferred || $host === $twin);

        if ($needsHost || $needsHttps) {
            return redirect()->to($base.$request->getRequestUri(), 301);
        }

        return $next($request);
    }
}
