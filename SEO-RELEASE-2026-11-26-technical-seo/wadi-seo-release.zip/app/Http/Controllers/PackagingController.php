<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\Page;
use App\Packaging\Links;
use App\Packaging\PackagingCatalog;
use App\Packaging\PackagingImages;
use App\Services\Seo\SeoData;
use Illuminate\Contracts\View\View;

/**
 * The approved packaging pages.
 *
 *   /{locale}/packaging           overview          (URL unchanged)
 *   /{locale}/packaging/{slug}    family, pack or the olive-oil page
 *
 * One resolver route: a slug is unique across families, packs and the oil
 * page (enforced where they are stored, and by PackagingRoutesTest), so the
 * URI pattern is never registered twice.
 */
class PackagingController extends Controller
{
    /*
     * Resolved per use, never held: Laravel keeps one controller instance per route for the
     * life of the process, so a catalog captured in the constructor would keep serving the
     * revision that was live when the first request arrived (a long-running worker, or a
     * test that publishes between requests).
     */
    private function catalog(): PackagingCatalog
    {
        return app(PackagingCatalog::class);
    }

    public function index(): View
    {
        $this->ensurePublished();

        $page = Page::byKey('packaging');
        $title = $this->catalog()->copy('collection.index_title');

        return $this->render('packaging.collection', [
            'family' => null,
            'title' => $title,
        ], $this->seo(
            $page?->t('seo_title') ?: $title,
            $page?->t('seo_description') ?: $this->catalog()->copy('meta_description'),
        ));
    }

    public function show(string $locale, string $slug): View
    {
        $this->ensurePublished();

        if ($pack = $this->catalog()->pack($slug)) {
            return $this->render('packaging.pack', ['pack' => $pack],
                $this->seo($pack->name, $this->catalog()->copy('meta_description'), $pack->name));
        }

        if ($family = $this->catalog()->familyPage($slug)) {
            return $this->render('packaging.collection', ['family' => $family, 'title' => $family->title],
                $this->seo((string) $family->title, $this->catalog()->copy('meta_description'), $family->name));
        }

        if ($slug === $this->catalog()->oilPageSlug()) {
            $title = $this->catalog()->copy('oil.page_title');

            return $this->render('packaging.olive-oil', [],
                $this->seo($title, $this->catalog()->copy('meta_description'), $title));
        }

        abort(404);
    }

    /**
     * Before the first publish (a fresh install that has not run `packaging:import`) there is
     * nothing to show; a plain 404 is honest, an empty page or an exception is not.
     */
    private function ensurePublished(): void
    {
        abort_if($this->catalog()->isEmpty(), 404);
    }

    private function render(string $view, array $data, SeoData $seo): View
    {
        return view($view, $data + [
            'seo' => $seo,
            'catalog' => $this->catalog(),
            'images' => app(PackagingImages::class),
            'links' => app(Links::class),
        ]);
    }

    private function seo(string $title, ?string $description, ?string $crumb = null): SeoData
    {
        $breadcrumbs = [['label' => __('site.home'), 'url' => route('home')]];
        $breadcrumbs[] = ['label' => __('site.packaging.title'), 'url' => $crumb ? route('packaging.index') : null];
        if ($crumb) {
            $breadcrumbs[] = ['label' => $crumb, 'url' => null];
        }

        return SeoData::make()->title($title)->description($description)->defaultDescription($crumb ? 'pack' : 'packaging', [':name' => (string) ($crumb ?? $title)])->breadcrumbs($breadcrumbs);
    }
}
