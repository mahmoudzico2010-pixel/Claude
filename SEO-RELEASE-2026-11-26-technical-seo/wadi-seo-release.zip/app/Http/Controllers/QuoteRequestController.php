<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Enums\CompanyType;
use App\Enums\QuantityUnit;
use App\Http\Requests\StoreQuoteRequest;
use App\Models\Caliber;
use App\Models\ExportMarket;
use App\Models\PackagingType;
use App\Models\Product;
use App\Models\ProductForm;
use App\Models\QuoteRequest;
use App\Packaging\QuotePrefill;
use App\Services\Seo\SeoData;
use App\Services\Submissions\QuoteSubmissionService;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class QuoteRequestController extends Controller
{
    public function create(Request $request, QuotePrefill $prefill): View
    {
        $seo = SeoData::make()
            ->title(__('forms.rfq.title'))
            ->description(mb_strlen((string) __('forms.rfq.intro')) >= 70 ? __('forms.rfq.intro') : null)
            ->defaultDescription('quote')
            ->breadcrumbs([
                ['label' => __('site.home'), 'url' => route('home')],
                ['label' => __('forms.rfq.title'), 'url' => null],
            ]);

        return view('pages.quote', array_merge(
            ['seo' => $seo],
            $this->formOptions(),
            // Deep link from a product page pre-selects that product.
            ['preselected' => $request->query('product'), 'prefill' => $prefill->resolve($this->text($request, 'pack'), $this->text($request, 'variant'), $this->text($request, 'model'))]
        ));
    }

    private function text(Request $request, string $key): ?string
    {
        $v = $request->query($key);

        return is_string($v) ? mb_substr($v, 0, 120) : null;
    }

    public function store(StoreQuoteRequest $request, QuoteSubmissionService $service): RedirectResponse
    {
        $quote = $service->store($request->validated(), $request);

        return redirect()
            ->route('quote.thanks', ['locale' => app()->getLocale(), 'reference' => $quote->reference]);
    }

    public function thanks(string $locale, string $reference): View
    {
        // Only confirms that a reference exists; no inquiry detail is exposed
        // on this public page.
        $exists = QuoteRequest::query()->where('reference', $reference)->exists();

        abort_unless($exists, 404);

        return view('pages.quote-thanks', [
            'seo' => SeoData::make()->title(__('forms.rfq.success_title'))->noindex(),
            'reference' => $reference,
        ]);
    }

    /**
     * @return array<string, mixed>
     */
    private function formOptions(): array
    {
        return [
            'products' => Product::query()->published()->withTranslation()->ordered()->get(),
            'forms' => ProductForm::query()->active()->ordered()->get(),
            'calibers' => Caliber::query()->active()->ordered()->get(),
            'packaging' => PackagingType::query()->selectable()->withTranslation()->ordered()->get(),
            'markets' => ExportMarket::query()->active()->ordered()->get(),
            'companyTypes' => CompanyType::cases(),
            'units' => QuantityUnit::cases(),
            // Which packaging is valid for which product, and which model each packaging offers (live catalogue only).
            'quoteOptions' => app(\App\Packaging\QuoteOptions::class),
        ];
    }
}
