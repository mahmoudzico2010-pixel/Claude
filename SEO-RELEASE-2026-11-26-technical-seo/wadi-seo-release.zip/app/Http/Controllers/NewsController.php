<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Enums\NewsType;
use App\Models\NewsPost;
use App\Services\Seo\SchemaBuilder;
use App\Services\Seo\SeoData;
use Illuminate\Contracts\View\View;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Validation\Rules\Enum;

class NewsController extends Controller
{
    public function index(Request $request): View
    {
        $filters = $request->validate([
            'type' => ['nullable', new Enum(NewsType::class)],
        ]);

        $posts = NewsPost::query()
            ->published()
            ->withTranslation()
            ->with(['featuredImage', 'category'])
            ->when($filters['type'] ?? null, fn (Builder $q, string $type) => $q->ofType($type))
            ->latestFirst()
            ->paginate(9)
            ->withQueryString();

        $seo = SeoData::make()
            ->title(__('site.news.title'))
            ->defaultDescription('news')
            ->breadcrumbs([
                ['label' => __('site.home'), 'url' => route('home')],
                ['label' => __('site.news.title'), 'url' => null],
            ]);

        return view('pages.news.index', [
            'seo' => $seo,
            'posts' => $posts,
            'filters' => $filters,
            'types' => NewsType::cases(),
        ]);
    }

    public function show(string $locale, NewsPost $post): View
    {
        abort_unless(
            $post->status->value === 'published'
            && ($post->published_at === null || $post->published_at->isPast()),
            404
        );

        $post->load(['translations', 'featuredImage', 'seoImage', 'category', 'tags']);

        $seo = SeoData::make()
            ->title($post->t('seo_title') ?: $post->title())
            ->description($post->t('seo_description') ?: $post->t('excerpt'))
            ->locales(\App\Services\Seo\LocaleAvailability::for($post, ['title']))
            ->image($post->seoImage ?? $post->featuredImage)
            ->type('article')
            ->schema(SchemaBuilder::article($post))
            ->breadcrumbs([
                ['label' => __('site.home'), 'url' => route('home')],
                ['label' => __('site.news.title'), 'url' => route('news.index')],
                ['label' => (string) $post->title(), 'url' => null],
            ]);

        return view('pages.news.show', [
            'seo' => $seo,
            'post' => $post,
            'related' => NewsPost::query()
                ->published()
                ->whereKeyNot($post->getKey())
                ->withTranslation()
                ->with('featuredImage')
                ->latestFirst()
                ->limit(3)
                ->get(),
        ]);
    }
}
