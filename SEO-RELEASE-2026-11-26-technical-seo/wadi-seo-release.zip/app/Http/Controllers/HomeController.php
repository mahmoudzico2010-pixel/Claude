<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Enums\NewsType;
use App\Models\Category;
use App\Models\Certification;
use App\Models\ContentBlock;
use App\Models\NewsPost;
use App\Models\Product;
use App\Services\Homepage\HomepageRepository;
use App\Services\Homepage\HomepageView;
use App\Services\Launch\LaunchReadiness;
use App\Services\Locales\ApprovedContent;
use App\Services\Seo\SchemaBuilder;
use App\Services\Seo\SeoData;
use Illuminate\Contracts\View\View;
use Illuminate\Database\Eloquent\Collection;

class HomeController extends Controller
{
    /**
     * The products shown in the Featured band.
     *
     * Three sources in order of precedence, all configured from the Homepage
     * Manager rather than in code:
     *
     *   manual  — an explicit, ordered list the administrator chose
     *   auto    — whatever is flagged as featured in the catalogue
     *   neither — the newest published products, so a fresh install is not
     *             an empty band
     *
     * Bounded in every case: the homepage never loads the whole catalogue.
     *
     * @return Collection<int, Product>
     */
    private function featuredProducts(): Collection
    {
        $limit = max(1, min((int) (setting('home.featured_limit') ?: 6), 12));
        $source = setting('home.featured_source') ?: 'auto';

        if ($source === 'manual') {
            $ids = setting('home.featured_products');
            $ids = is_string($ids) ? json_decode($ids, true) : $ids;
            $ids = array_values(array_filter(array_map('intval', (array) $ids)));

            if ($ids !== []) {
                $products = Product::query()
                    ->published()
                    ->forCard()
                    ->whereIn('id', $ids)
                    ->limit($limit)
                    ->get();

                // Restore the administrator's order, which whereIn does not
                // preserve — the point of choosing manually is choosing the
                // sequence too.
                return $products->sortBy(fn (Product $p): int => array_search($p->id, $ids, true))->values();
            }
        }

        $featured = Product::query()
            ->published()
            ->featured()
            ->forCard()
            ->ordered()
            ->limit($limit)
            ->get();

        if ($featured->isNotEmpty()) {
            return $featured;
        }

        return Product::query()->published()->forCard()->ordered()->limit($limit)->get();
    }

    public function index(LaunchReadiness $readiness, HomepageRepository $homepage, HomepageView $view): View
    {
        // Adopted: render the published Homepage Manager version — never the
        // draft records, which the Manager edits.
        $published = $homepage->published();

        if ($published !== null) {
            // Reviewed texts stay public while a newer translation awaits sign-off.
            $published = ApprovedContent::homepage($published, app()->getLocale());

            return view('pages.home', $view->data($published, app()->getLocale(), $homepage->liveRevisionId()));
        }

        // Before `homepage:adopt`: the original renderer, unchanged.
        $featured = $this->featuredProducts();

        $categories = Category::query()
            ->active()
            ->roots()
            ->withTranslation()
            ->with('image')
            ->ordered()
            ->limit(6)
            ->get();

        $locale = app()->getLocale();

        // Homepage SEO, editable from the Homepage Manager. Falls back to the
        // company name and tagline so a site that has not filled these in is
        // still described sensibly rather than left blank.
        $seo = SeoData::make()
            ->title(setting('home.seo_title_'.$locale) ?: setting('home.seo_title_en') ?: setting('seo.title_'.$locale) ?: setting('seo.title_en') ?: __('seo.home_title'))
            ->description(setting('home.seo_description_'.$locale) ?: setting('home.seo_description_en') ?: setting('seo.description_'.$locale) ?: setting('seo.description_en') ?: null)
            ->defaultDescription('home')
            ->image(setting_media('home.seo_image'))
            ->schema(SchemaBuilder::organisation())
            ->schema([
                '@context' => 'https://schema.org',
                '@type' => 'WebSite',
                'name' => setting('company.name_'.$locale) ?? config('app.name'),
                'url' => url('/'.$locale),
            ]);

        return view('pages.home', [
            'seo' => $seo,
            // Incomplete sections are hidden rather than rendered empty.
            'showStatistics' => $readiness->showStatistics(),
            'showCertifications' => $readiness->showCertifications(),
            'featuredProducts' => $featured,
            'categories' => $categories,
            'statistics' => ContentBlock::query()
                ->section(ContentBlock::SECTION_STATISTICS)->active()->ordered()->get(),
            'values' => ContentBlock::query()
                ->section(ContentBlock::SECTION_VALUES)->active()->ordered()->limit(4)->get(),
            'productionSteps' => ContentBlock::query()
                ->section(ContentBlock::SECTION_PRODUCTION)->active()->ordered()->get(),
            'certifications' => Certification::query()
                ->active()
                ->where(function ($q): void {
                    $q->whereNotNull('logo_id')->orWhereNotNull('document_id');
                })
                ->ordered()->with('logo')->limit(8)->get(),
            'latestNews' => NewsPost::query()
                ->published()
                ->withTranslation()
                ->with('featuredImage')
                ->latestFirst()
                ->limit(3)
                ->get(),
            'upcomingExhibitions' => NewsPost::query()
                ->published()
                ->ofType(NewsType::Exhibition)
                ->whereDate('event_start_date', '>=', now())
                ->withTranslation()
                ->orderBy('event_start_date')
                ->limit(2)
                ->get(),
        ]);
    }
}
