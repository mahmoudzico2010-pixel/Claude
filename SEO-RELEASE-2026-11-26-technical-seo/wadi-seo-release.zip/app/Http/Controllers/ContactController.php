<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Http\Requests\StoreContactMessage;
use App\Models\ExportMarket;
use App\Models\Page;
use App\Services\Seo\SchemaBuilder;
use App\Services\Seo\SeoData;
use App\Services\Submissions\ContactSubmissionService;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;

class ContactController extends Controller
{
    public function show(): View
    {
        $page = Page::byKey('contact');

        $seo = SeoData::make()
            ->title($page?->t('seo_title') ?: __('site.contact.title'))
            ->description($page?->t('seo_description'))
            ->defaultDescription('contact')
            ->schema(SchemaBuilder::organisation())
            ->breadcrumbs([
                ['label' => __('site.home'), 'url' => route('home')],
                ['label' => __('site.contact.title'), 'url' => null],
            ]);

        return view('pages.contact', [
            'seo' => $seo,
            'page' => $page,
            'markets' => ExportMarket::query()->active()->ordered()->get(),
        ]);
    }

    public function store(StoreContactMessage $request, ContactSubmissionService $service): RedirectResponse
    {
        $service->store($request->validated(), $request);

        return redirect()
            ->route('contact.show', ['locale' => app()->getLocale()])
            ->with('contact_sent', true);
    }
}
