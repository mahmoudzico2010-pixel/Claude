<?php

declare(strict_types=1);

namespace App\Models;

use App\Models\Concerns\Auditable;
use App\Models\Concerns\HasTranslations;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Route;

/**
 * A single slide in the homepage hero.
 *
 * Public reads are cached as plain arrays, never as models; `liveFor()`
 * explains why that distinction is load-bearing on this platform.
 */
class HeroSlide extends Model
{
    use Auditable;
    use HasTranslations;

    public const TYPE_IMAGE = 'image';

    public const TYPE_VIDEO = 'video';

    public const ALIGNMENTS = ['start', 'center'];

    protected $fillable = [
        'media_type', 'image_id', 'image_mobile_id', 'video_id',
        'video_start', 'video_end', 'video_loop', 'video_sound', 'video_sound_button', 'slide_seconds',
        'locales', 'locale_overrides',
        'button_route_name', 'button_url', 'button_new_tab',
        'overlay_opacity', 'text_alignment',
        'is_active', 'display_order', 'starts_at', 'ends_at',
    ];

    /** @var array<int, string> */
    public array $translatedAttributes = ['eyebrow', 'title', 'subtitle', 'button_text', 'image_alt'];

    protected function casts(): array
    {
        return [
            'button_new_tab' => 'boolean',
            'locales' => 'array',
            'locale_overrides' => 'array',
            'video_loop' => 'boolean',
            'video_sound' => 'boolean',
            'video_sound_button' => 'boolean',
            'video_start' => 'float',
            'video_end' => 'float',
            'slide_seconds' => 'integer',
            'is_active' => 'boolean',
            'display_order' => 'integer',
            'overlay_opacity' => 'integer',
            'starts_at' => 'datetime',
            'ends_at' => 'datetime',
        ];
    }

    public function translationModel(): string
    {
        return HeroSlideTranslation::class;
    }

    protected static function booted(): void
    {
        static::saved(fn () => static::flushCache());
        static::deleted(fn () => static::flushCache());
    }

    public static function flushCache(): void
    {
        foreach (array_keys(config('wadi.locales', [])) as $locale) {
            Cache::forget('wadi.hero_slides.'.$locale);
        }
    }

    // ---------------------------------------------------------- Relations

    public function image(): BelongsTo
    {
        return $this->belongsTo(MediaAsset::class, 'image_id');
    }

    public function imageMobile(): BelongsTo
    {
        return $this->belongsTo(MediaAsset::class, 'image_mobile_id');
    }

    public function video(): BelongsTo
    {
        return $this->belongsTo(MediaAsset::class, 'video_id');
    }

    // ------------------------------------------------------------- Scopes

    /**
     * Slides that should be on the site right now.
     *
     * Scheduling is evaluated in SQL rather than in PHP so an expired slide
     * never reaches the view layer at all.
     */
    public function scopeLive(Builder $query, ?Carbon $at = null): Builder
    {
        $at ??= now();

        return $query
            ->where('is_active', true)
            ->where(fn (Builder $q) => $q->whereNull('starts_at')->orWhere('starts_at', '<=', $at))
            ->where(fn (Builder $q) => $q->whereNull('ends_at')->orWhere('ends_at', '>=', $at))
            ->orderBy('display_order')
            ->orderBy('id');
    }

    // ------------------------------------------------------------ Helpers

    public function isVideo(): bool
    {
        return $this->media_type === self::TYPE_VIDEO;
    }

    /**
     * Resolve the call-to-action target for a locale.
     *
     * A named route wins over a literal URL, so the same slide links to the
     * right language on both /en and /ar. Route::has() is checked because a
     * route can be renamed after a slide was saved, and a missing route would
     * otherwise throw on the homepage rather than simply hiding a button.
     */
    public function buttonHref(?string $locale = null): ?string
    {
        $locale ??= app()->getLocale();

        if ($this->button_route_name && Route::has($this->button_route_name)) {
            return route($this->button_route_name, ['locale' => $locale]);
        }

        return $this->button_url ?: null;
    }

    /**
     * @return array<string, string> field => language code of the text actually shown, for fields that fell back
     */
    public function fallbackLanguages(string $locale): array
    {
        $default = (string) config('app.fallback_locale', 'en');
        if ($locale === $default) {
            return [];
        }
        $own = $this->relationLoaded('translations') ? $this->translations->firstWhere('locale', $locale) : null;
        $out = [];
        foreach (['eyebrow', 'title', 'subtitle', 'button_text'] as $field) {
            if (blank($own?->{$field}) && filled($this->t($field, $locale))) {
                $out[$field] = $default;
            }
        }

        return $out;
    }

    /**
     * The public payload for one slide, as scalars only.
     *
     * @return array<string, mixed>
     */
    public function toPublicArray(string $locale): array
    {
        $image = $this->relationLoaded('image') ? $this->image : null;
        $video = $this->relationLoaded('video') ? $this->video : null;
        $mobile = $this->relationLoaded('imageMobile') ? $this->imageMobile : null;

        $label = $this->t('button_text', $locale);
        $href = $this->buttonHref($locale);

        return [
            'id' => $this->id,
            'is_video' => $this->isVideo() && $video !== null,

            'poster' => $image?->urlFor(1920),
            'poster_srcset' => $image?->srcset(),
            'poster_width' => $image?->width,
            'poster_height' => $image?->height,
            // Optional portrait image for narrow screens. Null renders exactly
            // as before: the desktop image at every width.
            'poster_mobile' => $mobile?->urlFor(1080),
            'poster_mobile_srcset' => $mobile?->srcset(),
            'alt' => $this->t('image_alt', $locale) ?? $image?->alt($locale) ?? '',

            'video_url' => $video?->url(),
            'video_mime' => $video?->mime_type,
            'video_start' => $this->video_start === null ? null : (float) $this->video_start,
            'video_end' => $this->video_end === null ? null : (float) $this->video_end,
            'video_loop' => $this->video_loop === null ? true : (bool) $this->video_loop,
            'video_sound' => (bool) $this->video_sound,
            'video_sound_button' => (bool) $this->video_sound_button,
            'slide_ms' => $this->slide_seconds ? (int) $this->slide_seconds * 1000 : null,

            'eyebrow' => $this->t('eyebrow', $locale),
            'title' => $this->t('title', $locale),
            'subtitle' => $this->t('subtitle', $locale),
            // When a language has no text of its own for a field, the default-language text is shown. Say so in the markup
            // (lang attribute) so assistive technology and search engines know that piece is not in the page language.
            'fallback_lang' => $this->fallbackLanguages($locale),

            // A button is rendered only when it has both a label and a
            // destination; half a button is worse than none.
            'button_text' => ($label && $href) ? $label : null,
            'button_href' => ($label && $href) ? $href : null,
            'button_new_tab' => (bool) $this->button_new_tab,

            'overlay' => max(0, min(95, (int) $this->overlay_opacity)) / 100,
            'alignment' => in_array($this->text_alignment, self::ALIGNMENTS, true)
                ? $this->text_alignment
                : 'start',
        ];
    }

    /**
     * Every live slide for a locale, cached as plain arrays.
     *
     * Arrays, not models, and deliberately so. Caching an Eloquent collection
     * makes the payload depend on every class in the object graph being
     * reconstructible at read time; where that fails, `unserialize()` returns
     * `__PHP_Incomplete_Class` silently rather than throwing, and the failure
     * surfaces much later as a "member function on string" error inside a
     * template. That exact failure took the public site down on this platform
     * once already.
     *
     * @return array<int, array<string, mixed>>
     */
    public static function liveFor(?string $locale = null): array
    {
        $locale ??= app()->getLocale();
        $key = 'wadi.hero_slides.'.$locale;

        $cached = Cache::get($key);

        if (is_array($cached) && array_key_exists('slides', $cached) && is_array($cached['slides'])) {
            return $cached['slides'];
        }

        [$slides, $ttl] = static::buildPayload($locale);

        Cache::put($key, ['slides' => $slides], $ttl);

        return $slides;
    }

    /**
     * Build the payload and work out how long it may safely be cached.
     *
     * A scheduled slide is the reason this is not a plain `Cache::remember`.
     * With a flat 24-hour TTL, a slide set to go live at 09:00 would appear
     * whenever the cache happened to expire — possibly the next day — and an
     * expired one would linger just as long. The cache therefore lives only
     * until the next schedule boundary, and no longer.
     *
     * @return array{0: array<int, array<string, mixed>>, 1: int}
     */
    private static function buildPayload(string $locale): array
    {
        $now = now();

        $slides = static::query()
            ->live($now)
            ->with(['image', 'video', 'translations'])
            ->get()
            ->map(fn (self $slide): array => $slide->toPublicArray($locale))
            ->all();

        $default = (int) config('wadi.cache.ttl', 3600);
        $boundary = static::nextScheduleBoundary($now);

        if ($boundary === null) {
            return [$slides, $default];
        }

        // One second past the boundary, so the rebuild sees the new state.
        $seconds = max(60, $now->diffInSeconds($boundary) + 1);

        return [$slides, min($default, $seconds)];
    }

    /**
     * The soonest moment at which the set of live slides could change.
     */
    private static function nextScheduleBoundary(Carbon $now): ?Carbon
    {
        // Two plain aggregates rather than one clever UNION subquery: the
        // saving is a single round trip, and hand-rolled subquery SQL is
        // exactly the kind of thing that works on MySQL and quietly differs
        // on SQLite, where the test suite runs.
        $candidates = [
            static::query()->whereNotNull('starts_at')->where('starts_at', '>', $now)->min('starts_at'),
            static::query()->whereNotNull('ends_at')->where('ends_at', '>', $now)->min('ends_at'),
        ];

        $candidates = array_filter($candidates);

        if ($candidates === []) {
            return null;
        }

        return collect($candidates)
            ->map(fn ($value): Carbon => Carbon::parse($value))
            ->sort()
            ->first();
    }
}
