<?php

declare(strict_types=1);

namespace App\Console\Commands;

use App\Models\Category;
use App\Models\HeroSlide;
use App\Models\Page;
use App\Models\Product;
use App\Support\Locales;
use Illuminate\Console\Command;

/**
 * Read-only report: which public texts are shown in a language only because the default-language text is used as a fallback
 * (for example the English slide headings that still appear on the Arabic homepage). It changes nothing: copy is corrected by a
 * person in the admin; the CSV includes a PROPOSED translation for known strings so it can be reviewed first.
 */
class SeoLocaleGapsCommand extends Command
{
    protected $signature = 'seo:locale-gaps {--locale=* : only these languages (default: every published language)} {--no-csv : print only}';

    protected $description = 'List texts that fall back to the default language in a published language (read-only; proposes nothing automatically)';

    /** Reviewed-by-nobody proposals for strings known to be affected. Never applied automatically. */
    private const PROPOSED = [
        'ar' => [
            'What a single olive can tell us' => 'ماذا يمكن أن تخبرنا زيتونة واحدة',
            'Start with the volume you need' => 'ابدأ بالكمية التي تحتاجها',
        ],
    ];

    public function handle(): int
    {
        $default = Locales::default();
        $locales = array_values(array_filter($this->option('locale') ?: Locales::publishedCodes(), fn ($l) => $l !== $default));
        $rows = [];

        $scan = function (string $entity, $models, array $fields, \Closure $label) use ($locales, $default, &$rows): void {
            foreach ($models as $m) {
                $by = $m->translations->keyBy('locale');
                $base = $by->get($default);
                foreach ($locales as $l) {
                    foreach ($fields as $f) {
                        $en = trim((string) ($base?->{$f} ?? ''));
                        if ($en === '' || filled($by->get($l)?->{$f})) {
                            continue;
                        }
                        $rows[] = [$entity, $m->id, $label($m), $f, $l, $en, self::PROPOSED[$l][$en] ?? ''];
                    }
                }
            }
        };

        $scan('hero_slide', HeroSlide::query()->with('translations')->get(), ['eyebrow', 'title', 'subtitle', 'button_text'], fn ($m) => 'slide #'.$m->id);
        $scan('page', Page::query()->with('translations')->get(), ['title', 'seo_title', 'seo_description'], fn ($m) => (string) ($m->key ?: $m->slug));
        $scan('category', Category::query()->with('translations')->get(), ['name'], fn ($m) => (string) $m->slug);
        Product::query()->with('translations')->chunk(200, fn ($chunk) => $scan('product', $chunk, ['name', 'seo_title', 'seo_description'], fn ($m) => (string) $m->slug));

        $summary = [];
        foreach ($rows as $r) {
            $summary[$r[4]][$r[0]] = ($summary[$r[4]][$r[0]] ?? 0) + 1;
        }
        foreach ($summary as $l => $by) {
            $this->line(sprintf('%s: %s', $l, collect($by)->map(fn ($n, $e) => $n.' '.$e)->implode(', ')));
        }
        $this->info(count($rows).' fallback text(s) in '.count($locales).' language(s).');

        if (! $this->option('no-csv') && $rows !== []) {
            $dir = storage_path('app/seo');
            @mkdir($dir, 0775, true);
            $file = $dir.'/locale-gaps-'.now()->format('Ymd-His').'.csv';
            $h = fopen($file, 'w');
            fwrite($h, "\xEF\xBB\xBF");
            fputcsv($h, ['entity', 'id', 'record', 'field', 'language', 'text_shown_(default_language)', 'proposed_translation_(review_first)']);
            foreach ($rows as $r) {
                fputcsv($h, $r);
            }
            fclose($h);
            $this->line('CSV: '.$file);
        }

        return self::SUCCESS;
    }
}
