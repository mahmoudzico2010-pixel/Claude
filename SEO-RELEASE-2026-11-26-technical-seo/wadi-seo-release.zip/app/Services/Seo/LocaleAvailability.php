<?php

declare(strict_types=1);

namespace App\Services\Seo;

use App\Models\ContentTranslation;
use App\Support\Locales;
use Illuminate\Database\Eloquent\Model;

/**
 * In which published languages does a record GENUINELY exist (its own text, not the English fallback)? Used so hreflang and the
 * sitemap advertise only real translations. The default language is always included.
 */
final class LocaleAvailability
{
    /**
     * @param  list<string>  $fields  at least one of these must be non-empty in a language for it to count
     * @return list<string>
     */
    public static function for(Model $model, array $fields): array
    {
        $published = array_keys(Locales::published());
        $default = Locales::default();
        $have = [$default => true];

        foreach ($published as $locale) {
            if ($locale === $default) {
                continue;
            }
            if (self::has($model, $fields, $locale)) {
                $have[$locale] = true;
            }
        }

        return array_values(array_intersect($published, array_keys($have)));
    }

    private static function has(Model $model, array $fields, string $locale): bool
    {
        if (method_exists($model, 'translations')) {
            $rows = $model->relationLoaded('translations') ? $model->translations : $model->translations()->get();
            $row = $rows->firstWhere('locale', $locale);
            if ($row !== null) {
                foreach ($fields as $f) {
                    if (filled($row->{$f} ?? null)) {
                        return true;
                    }
                }
            }

            return false;
        }

        // Bilingual-column models: en/ar columns, other languages in content_translations.
        foreach ($fields as $f) {
            if (array_key_exists($f.'_'.$locale, $model->getAttributes()) && filled($model->getAttribute($f.'_'.$locale))) {
                return true;
            }
            if (! in_array($locale, ['en', 'ar'], true) && $model->getKey() !== null && filled(ContentTranslation::lookup($model->getTable(), (int) $model->getKey(), $locale, $f))) {
                return true;
            }
        }

        return false;
    }
}
