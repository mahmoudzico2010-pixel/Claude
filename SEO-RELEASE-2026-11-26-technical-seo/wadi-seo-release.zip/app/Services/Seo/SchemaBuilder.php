<?php

declare(strict_types=1);

namespace App\Services\Seo;

use App\Models\NewsPost;
use App\Models\Product;

/**
 * Structured data. Only fields the company can actually substantiate are
 * emitted — no invented ratings, prices or review counts.
 */
class SchemaBuilder
{
    /**
     * @return array<string, mixed>
     */
    public static function organisation(): array
    {
        $locale = app()->getLocale();

        $schema = array_filter([
            '@context' => 'https://schema.org',
            '@type' => 'Organization',
            'name' => setting('company.name_'.$locale) ?? setting('company.name_en') ?? config('app.name'),
            'url' => url('/'.$locale),
            'logo' => setting_media('company.logo_light')?->url(),
            'description' => setting('seo.description_'.$locale) ?? setting('seo.description_en'),
            'email' => setting('contact.email'),
            'telephone' => setting('contact.phone'),
        ]);

        $address = setting('contact.address_'.$locale) ?? setting('contact.address_en');

        if (filled($address)) {
            $schema['address'] = [
                '@type' => 'PostalAddress',
                'streetAddress' => $address,
                'addressCountry' => 'EG',
            ];
        }

        $social = collect([
            setting('social.facebook'),
            setting('social.instagram'),
            setting('social.linkedin'),
            setting('social.youtube'),
            setting('social.x'),
        ])->filter()->values();

        if ($social->isNotEmpty()) {
            $schema['sameAs'] = $social->all();
        }

        return $schema;
    }

    /**
     * @return array<string, mixed>
     */
    public static function product(Product $product): array
    {
        $images = $product->galleryImages()
            ->map(fn ($m) => $m->urlFor(1200))
            ->filter()
            ->values();

        return array_filter([
            '@context' => 'https://schema.org',
            '@type' => 'Product',
            'name' => $product->name(),
            'url' => route('products.show', ['locale' => app()->getLocale(), 'product' => $product->slug]),
            'description' => $product->t('short_description') ?: strip_tags((string) $product->t('description')) ?: null,
            'image' => $images->isNotEmpty() ? $images->all() : null,
            'category' => $product->category?->t('name'),
            'countryOfOrigin' => $product->country_of_origin,
            'brand' => [
                '@type' => 'Brand',
                'name' => Brand::name(),
            ],
            // No offers block: this is a B2B catalogue with quoted pricing,
            // so publishing a price would be inaccurate.
        ], fn ($v): bool => $v !== null && $v !== '');
    }

    /**
     * @return array<string, mixed>
     */
    public static function article(NewsPost $post): array
    {
        return array_filter([
            '@context' => 'https://schema.org',
            '@type' => $post->type->value === 'exhibition' ? 'Event' : 'Article',
            'headline' => $post->title(),
            'url' => route('news.show', ['locale' => app()->getLocale(), 'post' => $post->slug]),
            'mainEntityOfPage' => route('news.show', ['locale' => app()->getLocale(), 'post' => $post->slug]),
            'description' => $post->t('excerpt'),
            'image' => $post->featuredImage?->urlFor(1200),
            'datePublished' => $post->published_at?->toIso8601String(),
            'dateModified' => $post->updated_at?->toIso8601String(),
            'publisher' => [
                '@type' => 'Organization',
                'name' => setting('company.name_en') ?? config('app.name'),
            ],
            'startDate' => $post->event_start_date?->toDateString(),
            'endDate' => $post->event_end_date?->toDateString(),
            'location' => $post->location ? [
                '@type' => 'Place',
                'name' => $post->location,
            ] : null,
        ], fn ($v): bool => $v !== null && $v !== '');
    }
}
