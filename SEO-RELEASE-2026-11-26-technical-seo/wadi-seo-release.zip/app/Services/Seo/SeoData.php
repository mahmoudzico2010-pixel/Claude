<?php

declare(strict_types=1);

namespace App\Services\Seo;

use App\Models\MediaAsset;
use Illuminate\Contracts\Support\Arrayable;

/**
 * Everything the <head> needs for one page, resolved once in the controller
 * and passed to the layout. Falls back to the site defaults from Settings so
 * a page with no SEO fields still emits a complete, sensible head.
 *
 * @implements Arrayable<string, mixed>
 */
class SeoData implements Arrayable
{
    /** @var array<int, array<string, mixed>> */
    public array $schemas = [];

    /** @var array<int, array{label: string, url: ?string}> */
    public array $breadcrumbs = [];

    /** Languages in which THIS page genuinely exists (null = every published language). Used for hreflang and the sitemap. */
    public ?array $availableLocales = null;

    /** Key into lang seo.desc.* used when the page has no description of its own (page-specific wording, never the site-wide blurb). */
    public ?string $descriptionKey = null;

    /** @var array<string, string> replacements for the default description, e.g. [':name' => 'Green Olives'] */
    public array $descriptionVars = [];

    public function __construct(
        public ?string $title = null,
        public ?string $description = null,
        public ?MediaAsset $image = null,
        public ?string $canonical = null,
        public bool $noindex = false,
        public string $type = 'website',
    ) {}

    public static function make(): self
    {
        return new self;
    }

    public function title(?string $title): self
    {
        $this->title = $title;

        return $this;
    }

    public function description(?string $description): self
    {
        $this->description = $description;

        return $this;
    }

    public function image(?MediaAsset $image): self
    {
        $this->image = $image;

        return $this;
    }

    public function canonical(?string $url): self
    {
        $this->canonical = $url;

        return $this;
    }

    public function type(string $type): self
    {
        $this->type = $type;

        return $this;
    }

    /** @param  list<string>|null  $codes */
    public function locales(?array $codes): self
    {
        $this->availableLocales = $codes;

        return $this;
    }

    /** @param  array<string, string>  $vars */
    public function defaultDescription(string $key, array $vars = []): self
    {
        $this->descriptionKey = $key;
        $this->descriptionVars = $vars;

        return $this;
    }

    public function noindex(bool $noindex = true): self
    {
        $this->noindex = $noindex;

        return $this;
    }

    /**
     * @param  array<string, mixed>  $schema
     */
    public function schema(array $schema): self
    {
        $this->schemas[] = $schema;

        return $this;
    }

    /**
     * @param  array<int, array{label: string, url: ?string}>  $items
     */
    public function breadcrumbs(array $items): self
    {
        $this->breadcrumbs = $items;

        // Breadcrumb structured data mirrors the visible trail exactly.
        $listItems = [];
        $position = 1;

        foreach ($items as $item) {
            $entry = [
                '@type' => 'ListItem',
                'position' => $position++,
                'name' => $item['label'],
            ];

            if (! empty($item['url'])) {
                $entry['item'] = $item['url'];
            }

            $listItems[] = $entry;
        }

        if ($listItems !== []) {
            $this->schema([
                '@context' => 'https://schema.org',
                '@type' => 'BreadcrumbList',
                'itemListElement' => $listItems,
            ]);
        }

        return $this;
    }

    // ------------------------------------------------------------ Resolvers

    /** Brand exactly once, never duplicated, human-written titles untouched. */
    public function resolvedTitle(): string
    {
        $locale = app()->getLocale();

        if (blank($this->title)) {
            $default = setting('seo.title_'.$locale) ?: setting('seo.title_en');

            return trim((string) $default) !== '' ? (string) $default : Brand::name($locale);
        }

        return Brand::compose((string) $this->title);
    }

    public function resolvedDescription(): ?string
    {
        $locale = app()->getLocale();

        if (filled($this->description)) {
            return trim(strip_tags((string) $this->description));
        }
        if ($this->descriptionKey !== null && \Illuminate\Support\Facades\Lang::has('seo.desc.'.$this->descriptionKey)) {
            return __('seo.desc.'.$this->descriptionKey, $this->descriptionVars + ['brand' => Brand::name($locale)]);
        }

        return setting('seo.description_'.$locale) ?: setting('seo.description_en');
    }

    public function resolvedImageUrl(): ?string
    {
        $image = $this->image ?? setting_media('seo.share_image');

        $url = $image?->urlFor(1200);

        return $url === null ? null : \App\Support\PublicHost::rewrite($url);
    }

    /** This page in one language on the preferred host: no tracking/filter/sort parameters; only a real page number is kept. */
    public function urlFor(string $locale): string
    {
        $request = request();
        $segments = $request->segments();
        if ($segments === []) {
            $path = '/'.$locale;
        } else {
            \App\Support\Locales::isSupported($segments[0]) ? $segments[0] = $locale : array_unshift($segments, $locale);
            $path = '/'.implode('/', $segments);
        }
        $page = (int) $request->query('page', 1);
        if ($page > 1) {
            $path .= '?page='.$page;
        }

        return \App\Support\PublicHost::base() === null ? url($path) : \App\Support\PublicHost::rewrite($path);
    }

    public function resolvedCanonical(): string
    {
        if ($this->canonical !== null) {
            return \App\Support\PublicHost::rewrite($this->canonical);
        }
        $locale = app()->getLocale();
        // A language version that is only the fallback text (no real translation) is not a version of its own: it points at the default language.
        if ($this->availableLocales !== null && ! in_array($locale, $this->availableLocales, true)) {
            return $this->urlFor(\App\Support\Locales::default());
        }

        return $this->urlFor($locale);
    }

    /** @return array<string, string> hreflang => URL, reciprocal by construction (every page lists the same set, itself included) */
    public function resolvedAlternates(): array
    {
        $published = \App\Support\Locales::published();
        $codes = array_keys($published);
        if ($this->availableLocales !== null) {
            $codes = array_values(array_intersect($codes, array_unique(array_merge($this->availableLocales, [\App\Support\Locales::default()]))));
        }
        $out = [];
        foreach ($codes as $code) {
            $out[(string) ($published[$code]['hreflang'] ?? config('wadi.locales.'.$code.'.hreflang', $code))] = $this->urlFor($code);
        }
        $out['x-default'] = $this->urlFor(\App\Support\Locales::default());

        return $out;
    }

    /**
     * @return array<string, mixed>
     */
    public function toArray(): array
    {
        return [
            'title' => $this->resolvedTitle(),
            'description' => $this->resolvedDescription(),
            'image' => $this->resolvedImageUrl(),
            'canonical' => $this->resolvedCanonical(),
            'alternates' => $this->resolvedAlternates(),
            'noindex' => $this->noindex,
            'type' => $this->type,
            'schemas' => \App\Support\PublicHost::rewriteDeep($this->schemas),
            'breadcrumbs' => $this->breadcrumbs,
        ];
    }
}
