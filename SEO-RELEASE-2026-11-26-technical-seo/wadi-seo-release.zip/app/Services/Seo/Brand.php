<?php

declare(strict_types=1);

namespace App\Services\Seo;

/**
 * The short brand shown once in a page title ("Whole Manzanilla Green Olives | Wadi El Rayan"). An explicit setting wins
 * (seo.brand_<locale>); otherwise it is derived from the company short name by dropping the descriptor
 * ("WADI EL RAYAN FOR FOOD INDUSTRIES" -> "Wadi El Rayan"). A title that already carries the brand is never suffixed again.
 */
final class Brand
{
    public static function name(?string $locale = null): string
    {
        $locale ??= app()->getLocale();
        $explicit = trim((string) (setting('seo.brand_'.$locale) ?? setting('seo.brand_en') ?? ''));
        if ($explicit !== '' && ($locale === 'en' || setting('seo.brand_'.$locale) !== null)) {
            return $explicit;
        }
        $short = trim((string) (setting('company.short_name_'.$locale) ?? setting('company.short_name_en') ?? config('app.name')));

        return self::strip($short, $locale);
    }

    public static function strip(string $short, string $locale = 'en'): string
    {
        $cut = $short;
        if (preg_match('/^(.+?)\s+(?:for\s+food|for\s+industries|food\s+industries)\b/iu', $short, $m) === 1) {
            $cut = $m[1];
        } elseif (preg_match('/^(.+?)\s+(?:للصناعات|لصناعة)/u', $short, $m) === 1) {
            $cut = $m[1];
        }
        $cut = trim($cut);
        if ($cut !== '' && $cut === mb_strtoupper($cut) && preg_match('/[A-Z]/', $cut) === 1) {
            $cut = mb_convert_case(mb_strtolower($cut), MB_CASE_TITLE);   // ALL CAPS Latin -> Title Case
        }

        return $cut !== '' ? $cut : $short;
    }

    /** @return list<string> lower-cased strings whose presence means "the brand is already in this title" */
    public static function needles(): array
    {
        $locale = app()->getLocale();
        $out = [];
        foreach ([self::name($locale), setting('company.short_name_'.$locale), setting('company.short_name_en'), setting('company.name_'.$locale), config('app.name')] as $n) {
            $n = mb_strtolower(trim((string) $n));
            if (mb_strlen($n) >= 3) {
                $out[$n] = true;
            }
        }

        return array_keys($out);
    }

    public static function in(string $title): bool
    {
        $t = mb_strtolower($title);
        foreach (self::needles() as $n) {
            if (str_contains($t, $n)) {
                return true;
            }
        }

        return false;
    }

    /** Compose "<title> | <brand>" with the brand exactly once. */
    public static function compose(string $title): string
    {
        $title = trim($title);

        return self::in($title) ? $title : $title.' | '.self::name();
    }
}
