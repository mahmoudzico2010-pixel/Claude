<?php

declare(strict_types=1);

namespace App\Support;

/**
 * The ONE preferred public origin (scheme + host) used for everything a search engine reads: canonical, hreflang, Open Graph,
 * sitemap, robots and structured-data URLs. It comes from configuration, never from the incoming Host header, so a request to
 * www., an IP address or any other alias cannot put its own host into the page.
 *
 * Source: SEO_PUBLIC_URL (e.g. https://wadielrayan.net) or, when that is empty, APP_URL if it is an https address. With neither
 * (local development, tests) the request's own origin is used, exactly as before.
 */
final class PublicHost
{
    /** @return ?string e.g. "https://wadielrayan.net" (no trailing slash), or null when no preferred origin is configured */
    public static function base(): ?string
    {
        $candidate = trim((string) config('wadi.seo.public_url', ''));
        if ($candidate === '') {
            $app = trim((string) config('app.url', ''));
            $candidate = str_starts_with(strtolower($app), 'https://') ? $app : '';
        }
        if ($candidate === '') {
            return null;
        }
        $p = parse_url($candidate);
        if (! is_array($p) || ! in_array($p['scheme'] ?? '', ['http', 'https'], true) || ($p['host'] ?? '') === '') {
            return null;
        }

        return strtolower($p['scheme']).'://'.strtolower($p['host']).(isset($p['port']) ? ':'.$p['port'] : '');
    }

    public static function host(): ?string
    {
        $b = self::base();

        return $b === null ? null : strtolower((string) parse_url($b, PHP_URL_HOST));
    }

    /** Hosts that are "this site" (so their URLs may be moved to the preferred origin); anything else is an external link. */
    private static function internalHosts(): array
    {
        $hosts = [];
        $add = function (?string $h) use (&$hosts): void {
            $h = strtolower(trim((string) $h));
            if ($h !== '') {
                $hosts[$h] = true;
                $hosts[str_starts_with($h, 'www.') ? substr($h, 4) : 'www.'.$h] = true;
            }
        };
        $add(self::host());
        $add((string) parse_url((string) config('app.url'), PHP_URL_HOST));
        try {
            $add(request()->getHost());
        } catch (\Throwable) {
        }

        return $hosts;
    }

    /** Move one URL (absolute or site-relative) onto the preferred origin. External URLs are returned unchanged. */
    public static function rewrite(string $url): string
    {
        $base = self::base();
        if ($base === null || $url === '') {
            return $url;
        }
        if (str_starts_with($url, '/') && ! str_starts_with($url, '//')) {
            return $base.$url;
        }
        $p = parse_url($url);
        if (! is_array($p) || ! isset($p['host']) || ! in_array($p['scheme'] ?? '', ['http', 'https'], true)) {
            return $url;
        }
        if (! isset(self::internalHosts()[strtolower($p['host'])])) {
            return $url;
        }

        return $base.($p['path'] ?? '/').(isset($p['query']) ? '?'.$p['query'] : '').(isset($p['fragment']) ? '#'.$p['fragment'] : '');
    }

    /** Apply rewrite() to every URL-looking string inside structured data. */
    public static function rewriteDeep(mixed $value): mixed
    {
        if (is_array($value)) {
            return array_map(fn ($v) => self::rewriteDeep($v), $value);
        }
        if (is_string($value) && preg_match('#^https?://#i', $value) === 1) {
            return self::rewrite($value);
        }

        return $value;
    }
}
