@php
    $image = $node['media'][(int) ($settings['image'] ?? 0)] ?? null;
    $mobile = $node['media'][(int) ($settings['image_mobile'] ?? 0)] ?? null;

    $x = ['start' => 'items-start text-start', 'center' => 'items-center text-center', 'end' => 'items-end text-end'];
    $y = ['start' => 'justify-start', 'center' => 'justify-center', 'end' => 'justify-end'];
@endphp

<div data-builder-node="{{ $node['id'] }}"
     @class(['wr-node wr-hero relative isolate flex flex-col overflow-hidden',
             $x[$settings['content_x'] ?? 'start'] ?? $x['start'],
             $y[$settings['content_y'] ?? 'center'] ?? $y['center']])>

    @if ($image)
        {{-- A separate mobile crop where one is set. A wide hero scaled down to
             phone width puts the subject off-centre or crops the message out
             entirely, and there is no CSS that recovers a composition. --}}
        <picture class="absolute inset-0 -z-[1]">
            @if ($mobile)
                <source media="(max-width: 767px)" srcset="{{ $mobile }}">
            @endif
            <img src="{{ $image }}" alt="" aria-hidden="true"
                 class="size-full object-cover" fetchpriority="high" decoding="async">
        </picture>

        {{-- No overlay div: NodeStyle writes the overlay straight onto this
             node's own ::before, scoped by its id, and emits nothing at all
             when none is configured. An element here would be a layer that
             exists on every hero whether or not it paints anything. --}}
    @endif

    <div class="container-wr relative flex flex-col gap-5 py-20">
        @if (filled($content['eyebrow'] ?? null))
            <p class="text-sm font-semibold uppercase tracking-[0.2em]">{{ $content['eyebrow'] }}</p>
        @endif

        @if (filled($content['heading'] ?? null))
            {{-- The homepage already has its own main heading (a visually hidden <h1>), so a hero element there is an <h2>. --}}
            @php($heroTag = request()->routeIs('home') ? 'h2' : 'h1')
            <{{ $heroTag }} class="text-display font-semibold">{{ $content['heading'] }}</{{ $heroTag }}>
        @endif

        @if (filled($content['body'] ?? null))
            <p class="max-w-2xl text-lead">{{ $content['body'] }}</p>
        @endif

        @if (filled($content['primary_label'] ?? null) || filled($content['secondary_label'] ?? null))
            <div class="mt-3 flex flex-wrap gap-4">
                @if (filled($content['primary_label'] ?? null))
                    <a href="{{ \App\Support\Builder\Destination::url(['destination' => 'url', 'url' => $settings['primary_url'] ?? '']) }}"
                       class="btn btn-primary">{{ $content['primary_label'] }}</a>
                @endif
                @if (filled($content['secondary_label'] ?? null))
                    <a href="{{ \App\Support\Builder\Destination::url(['destination' => 'url', 'url' => $settings['secondary_url'] ?? '']) }}"
                       class="btn btn-secondary">{{ $content['secondary_label'] }}</a>
                @endif
            </div>
        @endif
    </div>
</div>
