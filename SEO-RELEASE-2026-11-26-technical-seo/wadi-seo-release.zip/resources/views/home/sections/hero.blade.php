    {{-- ============================ Hero ============================ --}}
    @if ($heroSlides !== [])

        @include('partials.hero-slider', ['slides' => $heroSlides])

    @else

    {{-- No slides configured: the original single hero, driven by Settings.
         Kept intact so an existing site is unaffected until someone adds a
         slide, and so there is always a working hero to fall back to. --}}
    <section class="relative isolate overflow-hidden bg-forest">
        @if ($heroImage)
            @if ($heroImageMobile ?? null)
                <picture class="contents">
                    <source media="(max-width: 767px)" srcset="{{ $heroImageMobile->srcset() ?? $heroImageMobile->urlFor(1080) }}" sizes="100vw">
            @endif
            <img src="{{ $heroImage->urlFor(1920) }}"
                 @if ($heroImage->srcset()) srcset="{{ $heroImage->srcset() }}" sizes="100vw" @endif
                 alt="{{ $heroImage->alt() }}"
                 class="absolute inset-0 -z-10 size-full object-cover"
                 fetchpriority="high" decoding="async"
                 width="{{ $heroImage->width }}" height="{{ $heroImage->height }}">
            @if ($heroImageMobile ?? null)
                </picture>
            @endif
            <div class="absolute inset-0 -z-10 bg-gradient-to-b from-forest/90 via-forest/75 to-forest/95" aria-hidden="true"></div>
        @else
            {{-- Restrained fallback: no stock imagery invented. --}}
            <div class="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_30%_0%,#1d4d41,transparent_60%)]" aria-hidden="true"></div>
        @endif

        <div class="container-wr">
            <div class="flex min-h-[var(--wr-hero-min-height)] flex-col justify-center py-20">
                <div class="max-w-3xl">
                    @if ($heroEyebrow)
                        <p class="eyebrow eyebrow-light">{{ $heroEyebrow }}</p>
                    @endif

                    <h2 class="mt-5 text-balance text-h1 font-bold text-white lg:text-display">
                        {{ $heroTitle ?? (setting('company.name_'.$locale) ?? config('app.name')) }}
                    </h2>

                    @if ($heroSubtitle)
                        <p class="mt-6 max-w-2xl text-lead text-white/75">{{ $heroSubtitle }}</p>
                    @endif

                    <div class="mt-9 flex flex-wrap items-center gap-4">
                        <a href="{{ route('quote.create') }}" class="btn btn-gold">{{ __('site.cta.request_quote') }}</a>
                        <a href="{{ route('products.index') }}" class="btn btn-outline-light">{{ __('site.cta.view_products') }}</a>
                    </div>
                </div>
            </div>
        </div>

    </section>

    @endif
