    {{-- ======================== Certifications =====================
         Shown only when a certification carries a logo or an uploaded
         certificate. An unevidenced badge on an export site is exactly the
         claim that must not ship. --}}
    @if ($showCertifications && $certifications->isNotEmpty())
        <section class="reveal-ready section bg-surface-alt"
                 x-data="reveal"
                 x-bind:class="{ 'reveal-ready': ! shown, 'reveal-in': shown }">
            <div class="container-wr">
                <x-certifications-grid
                    :certifications="$certifications"
                    :heading="home_setting('home.quality_title_'.$locale) ?? home_setting('home.quality_title_en') ?? __('site.certifications.title')"
                    :intro="home_setting('home.quality_intro_'.$locale) ?? home_setting('home.quality_intro_en')"
                />

                <div class="mt-12 text-center">
                    <a href="{{ route('quality') }}" class="link-rule">
                        {{ __('site.read_more') }}<span class="sr-only">: {{ home_setting('home.quality_title_'.$locale) ?? home_setting('home.quality_title_en') ?? __('site.certifications.title') }}</span>
                        <svg class="rtl-flip size-3.5" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><path fill-rule="evenodd" d="M3 10a.75.75 0 0 1 .75-.75h10.638L10.23 5.29a.75.75 0 1 1 1.04-1.08l5.5 5.25a.75.75 0 0 1 0 1.08l-5.5 5.25a.75.75 0 1 1-1.04-1.08l4.158-3.96H3.75A.75.75 0 0 1 3 10Z" clip-rule="evenodd"/></svg>
                    </a>
                </div>
            </div>
        </section>
    @endif
