{{--
    Homepage hero slider.

    Expects $slides: an array of plain arrays from HeroSlide::liveFor().

    Design constraints this is written around:

    - The first slide is the page's Largest Contentful Paint. It loads eagerly
      at high priority; every other slide is lazy, so a five-slide hero costs
      one image on first paint rather than five.
    - Video never autoplays on the first slide alone — it plays only when its
      slide is showing, and pauses when it is not, so a background video on
      slide four never downloads for a visitor who leaves after three seconds.
    - Reduced motion is honoured: no auto-advance, no video autoplay. The
      slider becomes a manually operated carousel.
    - Everything renders without JavaScript. Alpine adds rotation and controls;
      without it the first slide is a complete, readable hero.
--}}

@php
    $locale = app()->getLocale();
    $total = count($slides);
    // ONE timing mechanism (resources/js/app.js, heroSlider) drives every slide from this description:
    //   image          -> its own display time, default config('wadi.hero.image_seconds') = 5 s: the time the slide is FULLY SHOWN (the ~1.2 s of fade-out/fade-in is added on top, not taken out of it), counted once the image is loaded
    //   video, ms = 0  -> AUTOMATIC: the video (or its start-end segment) plays to its end, then the slide advances
    //   video, ms > 0  -> custom display time, counted only while the video is really playing; moves on earlier if it ends
    $timing = [
        'imageMs' => max(2, (int) config('wadi.hero.image_seconds', 5)) * 1000,
        'slides' => array_map(fn (array $s): array => [
            'kind' => ! empty($s['is_video']) ? 'video' : 'image',
            'ms' => (int) ($s['slide_ms'] ?? 0),
            'start' => (float) ($s['video_start'] ?? 0),
            'end' => (float) ($s['video_end'] ?? 0),
            'loop' => (bool) ($s['video_loop'] ?? true),
            'sound' => (bool) ($s['video_sound'] ?? false),
        ], array_values($slides)),
    ];
@endphp

{{-- Slides never show together: the outgoing slide (image AND text) fades out in 500 ms, and only then the incoming one fades
     in (550 ms delay, 650 ms fade). A plain cross-dissolve laid both texts and both pictures on top of each other.
     ROOT CAUSE of the old overlap: slide 1 carried a static `opacity-100` (so it shows without JavaScript) that out-ranked the
     `opacity-0` Alpine added when it became inactive, so slide 1 never faded out and stayed under every later slide. The
     active/inactive classes below are `!important` for that reason.
     The slides are stacked in ONE grid cell, so the section is always as tall as its tallest slide and never collapses
     while a slide is hidden (the previous layout kept slide 1 in flow and the rest absolute: once slide 1 faded out the
     hero lost its height and disappeared). Inactive slides are invisible + inert, not display:none. --}}
<section
    class="relative isolate grid overflow-hidden bg-forest min-h-[var(--wr-hero-min-height)]"
    x-data="heroSlider(@js($timing))"
    :data-hero-current="current"
    :data-hero-blocked="blocked ? '1' : '0'"
    x-on:keydown.left.window="previous()"
    x-on:keydown.right.window="next()"
    role="region"
    aria-roledescription="carousel"
    aria-label="{{ __('hero.controls.region') }}"
>
    @foreach ($slides as $index => $slide)
        <div
            data-hero-slide="{{ $index }}"
            @if ($total > 1)
                :class="current === {{ $index }} ? 'visible! opacity-100! delay-[550ms] duration-[650ms]' : 'invisible! opacity-0! delay-0 duration-[500ms]'"
                :inert="current !== {{ $index }}"
                :aria-hidden="current !== {{ $index }}"
            @endif
            class="relative col-start-1 row-start-1 transition-[opacity,visibility] ease-[cubic-bezier(.4,0,.2,1)] motion-reduce:transition-none motion-reduce:delay-0 {{ $index === 0 ? 'visible opacity-100' : 'invisible opacity-0' }}"
            role="group"
            aria-roledescription="slide"
            aria-label="{{ $index + 1 }} / {{ $total }}"
        >
            {{-- Background ------------------------------------------------ --}}
            @if ($slide['poster'])
                {{-- Optional portrait image for phones. Only when one is set — a
                     slide without it renders exactly as before. `contents` keeps
                     the absolutely positioned image laid out as if unwrapped. --}}
                @if ($slide['poster_mobile'] ?? null)
                    <picture class="contents">
                        <source media="(max-width: 767px)" srcset="{{ $slide['poster_mobile_srcset'] ?? $slide['poster_mobile'] }}" sizes="100vw">
                @endif
                <img
                    x-ref="poster{{ $index }}"
                    src="{{ $slide['poster'] }}"
                    @if ($slide['poster_srcset']) srcset="{{ $slide['poster_srcset'] }}" sizes="100vw" @endif
                    alt="{{ $slide['alt'] }}"
                    {{-- A very slow scale while the slide is showing. Large
                         enough to keep a still photograph from feeling frozen,
                         small enough that nobody consciously notices it — and
                         cancelled outright under prefers-reduced-motion. --}}
                    @if (count($slides) > 1)
                        :class="current === {{ $index }} ? 'scale-100' : 'scale-[1.06]'"
                    @endif
                    class="absolute inset-0 -z-10 size-full object-cover will-change-transform
                           transition-transform duration-[9000ms] ease-out
                           motion-reduce:transition-none motion-reduce:scale-100"
                    @if ($index === 0)
                        fetchpriority="high" decoding="async"
                    @elseif ($index === 1)
                        decoding="async"
                    @else
                        loading="lazy" decoding="async"
                    @endif
                    @if ($slide['poster_width']) width="{{ $slide['poster_width'] }}" @endif
                    @if ($slide['poster_height']) height="{{ $slide['poster_height'] }}" @endif
                >
                @if ($slide['poster_mobile'] ?? null)
                    </picture>
                @endif
            @else
                <div class="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_30%_0%,#1d4d41,transparent_60%)]" aria-hidden="true"></div>
            @endif

            @if ($slide['is_video'])
                {{--
                    The poster above stays underneath as the fallback. The video
                    starts muted (sound is opt-in per slide, see data-sound) and
                    carries no native controls: it is decoration, so it is hidden
                    from assistive technology and never becomes the only way to
                    receive the message. The optional sound button is separate.

                    preload="none" on purpose — the browser fetches it when
                    the slide is played, not on page load.
                --}}
                <video
                    x-ref="video{{ $index }}"
                    class="absolute inset-0 -z-10 size-full object-cover"
                    muted
                    {{-- A native loop would stop 'ended' from ever firing and block the carousel; with several slides the
                         single timing loop rewinds only when the slide is in custom-time mode. Alone, the video may loop. --}}
                    @if ($total === 1 && ($slide['video_loop'] ?? true) && empty($slide['video_start']) && empty($slide['video_end'])) loop @endif
                    data-start="{{ $slide['video_start'] ?? 0 }}"
                    data-end="{{ $slide['video_end'] ?? 0 }}"
                    data-loop="{{ ($slide['video_loop'] ?? true) ? '1' : '0' }}"
                    data-sound="{{ ($slide['video_sound'] ?? false) ? '1' : '0' }}"
                    playsinline
                    preload="{{ $slide['poster'] ? 'none' : 'metadata' }}"
                    aria-hidden="true"
                    tabindex="-1"
                    @if ($slide['poster']) poster="{{ $slide['poster'] }}" @endif
                >
                    <source src="{{ $slide['video_url'] }}" type="{{ $slide['video_mime'] }}">
                </video>
            @endif

            @if ($slide['is_video'] && (($slide['video_sound'] ?? false) || ($slide['video_sound_button'] ?? false)))
                <button type="button"
                        x-on:click="toggleSound()"
                        x-show="current === {{ $index }}"
                        x-cloak
                        class="absolute end-4 top-4 z-10 rounded-sm bg-forest/60 px-3 py-2 text-sm font-semibold text-white backdrop-blur hover:bg-forest/80 focus-visible:outline focus-visible:outline-2 focus-visible:outline-gold"
                        :aria-pressed="soundOn ? 'true' : 'false'"
                        :aria-label="soundOn ? @js(__('hero.controls.mute')) : @js(__('hero.controls.unmute'))"
                        x-text="soundOn ? @js(__('hero.controls.mute')) : @js(__('hero.controls.unmute'))"></button>
            @endif

            @if ($slide['is_video'])
                {{-- Shown only when the browser refused autoplay: nothing counts down until the visitor presses it. --}}
                <button type="button"
                        x-on:click="playBlocked()"
                        x-show="blocked && current === {{ $index }}"
                        x-cloak
                        class="absolute start-1/2 top-1/2 z-10 -translate-x-1/2 -translate-y-1/2 rounded-full bg-forest/70 px-5 py-3 text-sm font-semibold text-white backdrop-blur hover:bg-forest/90 focus-visible:outline focus-visible:outline-2 focus-visible:outline-gold rtl:translate-x-1/2"
                        aria-label="{{ __('hero.controls.play_video') }}">
                    <span aria-hidden="true">▶</span> {{ __('hero.controls.play_video') }}
                </button>
            @endif

            {{-- Overlay. Inline style because the value is per-slide and
                 continuous; a Tailwind class cannot express it. --}}
            <div
                class="absolute inset-0 -z-10"
                style="background: linear-gradient(to bottom, rgb(14 46 39 / {{ $slide['overlay'] }}), rgb(14 46 39 / {{ min(0.95, $slide['overlay'] + 0.12) }}));"
                aria-hidden="true"
            ></div>

            {{-- Copy ------------------------------------------------------ --}}
            <div class="container-wr">
                <div @class([
                    'flex min-h-[var(--wr-hero-min-height)] flex-col justify-center py-20',
                    'items-center text-center' => $slide['alignment'] === 'center',
                ])>
                    <div @class(['max-w-3xl', 'mx-auto' => $slide['alignment'] === 'center'])>
                        @if ($slide['eyebrow'])
                            <p class="eyebrow eyebrow-light" @if (isset($slide['fallback_lang']['eyebrow'])) lang="{{ $slide['fallback_lang']['eyebrow'] }}" dir="{{ \App\Support\Locales::dir($slide['fallback_lang']['eyebrow']) }}" @endif>{{ $slide['eyebrow'] }}</p>
                        @endif

                        @if ($slide['title'])
                            <h2 class="mt-5 text-balance text-h1 font-bold text-white lg:text-display" @if (isset($slide['fallback_lang']['title'])) lang="{{ $slide['fallback_lang']['title'] }}" dir="{{ \App\Support\Locales::dir($slide['fallback_lang']['title']) }}" @endif>
                                {{ $slide['title'] }}
                            </h2>
                        @endif

                        @if ($slide['subtitle'])
                            <p @if (isset($slide['fallback_lang']['subtitle'])) lang="{{ $slide['fallback_lang']['subtitle'] }}" dir="{{ \App\Support\Locales::dir($slide['fallback_lang']['subtitle']) }}" @endif @class([
                                'mt-6 max-w-2xl text-lead text-white/75',
                                'mx-auto' => $slide['alignment'] === 'center',
                            ])>{{ $slide['subtitle'] }}</p>
                        @endif

                        <div @class([
                            'mt-9 flex flex-wrap items-center gap-4',
                            'justify-center' => $slide['alignment'] === 'center',
                        ])>
                            @if ($slide['button_text'])
                                <a href="{{ $slide['button_href'] }}"
                                   @if ($slide['button_new_tab']) target="_blank" rel="noopener" @endif
                                   class="btn btn-gold">{{ $slide['button_text'] }}</a>
                            @endif

                            <a href="{{ route('quote.create') }}" class="btn btn-outline-light">
                                {{ __('site.cta.request_quote') }}
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @endforeach

    {{-- Thin progress line along the bottom edge (gold accent, no numbers). Driven by the one timing loop:
         elapsed time for images, real playback position for automatic video, played time for custom-time video. --}}
    @if ($total > 1)
        <div class="pointer-events-none absolute inset-x-0 bottom-0 z-20 h-0.5 bg-white/10" x-cloak x-show="! reducedMotion" aria-hidden="true">
            <div x-ref="bar" data-hero-progress class="h-full w-full origin-left bg-gold rtl:origin-right" style="transform: scaleX(0)"></div>
        </div>
    @endif

    {{-- Controls. Only rendered when there is more than one slide. --}}
    @if (count($slides) > 1)
        <div class="pointer-events-none absolute inset-x-0 bottom-0 z-10" x-cloak>
            <div class="container-wr pointer-events-auto flex items-center gap-4 pb-6">
                <button type="button"
                        x-on:click="previous()"
                        class="rtl-flip rounded-sm p-2 text-white/70 transition-colors hover:text-white focus-visible:outline focus-visible:outline-2 focus-visible:outline-gold"
                        aria-label="{{ __('hero.controls.previous') }}">
                    <svg class="size-5" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><path d="M12.5 4 6.5 10l6 6" stroke-linecap="round" stroke-linejoin="round"/></svg>
                </button>

                <ul class="flex items-center gap-2">
                    @foreach ($slides as $index => $slide)
                        <li>
                            <button type="button"
                                    x-on:click="goTo({{ $index }})"
                                    class="block h-1 rounded-full transition-all duration-300"
                                    :class="current === {{ $index }} ? 'w-8 bg-gold' : 'w-4 bg-white/35 hover:bg-white/60'"
                                    :aria-current="current === {{ $index }} ? 'true' : 'false'"
                                    aria-label="{{ __('hero.controls.goto', ['number' => $index + 1]) }}"></button>
                        </li>
                    @endforeach
                </ul>

                <button type="button"
                        x-on:click="next()"
                        class="rtl-flip rounded-sm p-2 text-white/70 transition-colors hover:text-white focus-visible:outline focus-visible:outline-2 focus-visible:outline-gold"
                        aria-label="{{ __('hero.controls.next') }}">
                    <svg class="size-5" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><path d="m7.5 4 6 6-6 6" stroke-linecap="round" stroke-linejoin="round"/></svg>
                </button>

                <button type="button"
                        x-on:click="toggle()"
                        class="ms-auto rounded-sm p-2 text-white/70 transition-colors hover:text-white focus-visible:outline focus-visible:outline-2 focus-visible:outline-gold"
                        :aria-label="playing ? @js(__('hero.controls.pause')) : @js(__('hero.controls.play'))">
                    <svg x-show="playing" class="size-4" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true"><rect x="3" y="2" width="3.5" height="12" rx="1"/><rect x="9.5" y="2" width="3.5" height="12" rx="1"/></svg>
                    <svg x-show="!playing" class="size-4 rtl-flip" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true"><path d="M4 2.5 13 8l-9 5.5Z"/></svg>
                </button>
            </div>
        </div>
    @endif
</section>
