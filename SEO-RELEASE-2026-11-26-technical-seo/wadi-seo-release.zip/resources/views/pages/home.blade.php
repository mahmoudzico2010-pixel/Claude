@extends('layouts.public')

@php
    $locale = app()->getLocale();

    /*
     | Adopted homepage: the controller passes everything below from the
     | published snapshot (or, in the admin preview, from the draft) — see
     | App\Services\Homepage\HomepageView. The block that follows is the
     | pre-adoption renderer, used only until `homepage:adopt` has run.
     */
    $adopted = isset($homepage);

    if (! $adopted) {
        // The slider supersedes the single settings-driven hero when slides
        // exist. Falling back rather than replacing means an existing site
        // keeps working untouched until someone adds a slide.
        $heroSlides = array_slice(
            \App\Models\HeroSlide::liveFor($locale),
            0,
            (int) config('wadi.hero.max_slides', 6)
        );

        $heroImage = setting_media('home.hero_image');
        $heroTitle = setting('home.hero_title_'.$locale) ?? setting('home.hero_title_en');
        $heroSubtitle = setting('home.hero_subtitle_'.$locale) ?? setting('home.hero_subtitle_en');
        $heroEyebrow = setting('home.hero_eyebrow_'.$locale) ?? setting('home.hero_eyebrow_en');

        $sections = \App\Models\HomeSection::liveFor($locale);
    }

    // Only these keys may be rendered as a built-in section. The check happens
    // before @include so a row cannot name an arbitrary template path.
    $allowedSections = $adopted
        ? \App\Services\Homepage\HomepageView::CORE
        : (array) config('wadi.home.sections', []);

    $backgrounds = [
        'default' => '',
        'surface' => 'bg-surface-alt',
        'ivory' => 'bg-ivory',
        'forest' => 'bg-forest text-white',
    ];

    /*
     | Section padding, expressed as a multiplier of the themed section
     | spacing rather than as fixed utilities.
     |
     | These used to be Tailwind classes — `py-16 lg:py-24` — which sat on the
     | same element as `.home-section`'s `padding-block: var(--section-pt)`.
     | Utilities are emitted after components, so the class always won and the
     | Stage 1 spacing token silently did nothing on a custom section. Two
     | systems setting one property, one of them invisible.
     |
     | Now there is one system: these map onto the same `.section-*` classes
     | the built-in sections use, so spacing stays on the token scale and a
     | change to the global section spacing moves every band together.
     */
    $paddings = [
        'none' => 'section-flush',
        'compact' => 'section-tight',
        'default' => '',
        'roomy' => 'section-loose',
    ];
@endphp

{{-- The intro video pushes itself to the layout's `body-start` stack. Included
     outside the content section, where a child view's own output is discarded,
     so it adds no whitespace to the page. --}}
@if ($adopted)
    @include('home.intro')
@endif

@section('content')

    {{-- The page's one main heading: what the company does. Visually hidden so the slides keep the design; the slide
         headings below it are <h2>. An administrator can override the wording per language with setting home.h1_<locale>. --}}
    <h1 class="sr-only" data-testid="home-h1">{{ setting('home.h1_'.$locale) ?: __('seo.home_h1') }}</h1>

    @php($renderedKeys = [])
    <x-module-slot target="homepage" place="top" />

    {{--
        The builder supersedes the Stage 2 sections when a tree exists for this
        page.

        The decision is made from the cached payload rather than a separate
        `hasTreeFor` query, so the common case costs nothing extra. An empty
        tree and an absent tree fall the same way — back to the Stage 2
        renderer below — which is what makes `builder:convert-homepage
        --rollback` a complete undo: delete the nodes and the previous homepage
        returns on the next request, with home_sections never having been
        touched.
    --}}
    {{-- Pre-adoption only. Once adopted, the Homepage Manager's published
         version is the homepage and a Page Builder tree no longer overrides
         it (its data is kept). --}}
    @php($builder = $adopted ? ['nodes' => []] : app(\App\Services\Builder\PageRenderer::class)->payload('home', $locale))

    @if (! empty($builder['nodes']))

        @include('builder.page', ['payload' => $builder])

    @else

    @foreach ($sections as $section)

        @if ($section['type'] === \App\Models\HomeSection::TYPE_BUILTIN)

            {{-- Built-in sections bring their own <section> wrapper, so the
                 layout settings reach them as scoped custom properties and a
                 wrapper class rather than by replacing their markup. That is
                 what lets an existing section become configurable without its
                 partial being rewritten.

                 `layout_css` was built and validated when the cache was
                 written: every value matched against config/design.php, and
                 the selector built from this row's integer id. --}}
            @if (in_array($section['key'], $allowedSections, true))
                @if (filled($section['layout_css']))
                    <style>{!! $section['layout_css'] !!}</style>
                @endif

                <div id="home-section-{{ $section['id'] }}"
                     @class(array_filter([
                         $section['classes']['cards'],
                         $section['classes']['cta'],
                         $section['classes']['image'],
                     ]))>
                    @include('home.sections.'.$section['key'])
                </div>
                @php($renderedKeys[] = $section['key'])
                <x-module-slot target="homepage" :place="'after:'.$section['key']" />
            @endif

        @elseif (filled($section['html']))

            {{-- Administrator-authored block.

                 The HTML was rebuilt from an allowlist and the CSS confined to
                 this element's id when the cache was built — see
                 HtmlBlockSanitizer. Both are therefore safe to print
                 unescaped, and there is nowhere else in the public templates
                 where that is true. --}}
            @if (filled($section['css']))
                <style>{!! $section['css'] !!}</style>
            @endif

            @if (filled($section['layout_css']))
                <style>{!! $section['layout_css'] !!}</style>
            @endif

            <section id="home-section-{{ $section['id'] }}"
                     @class(array_filter([
                         'home-section',
                         $backgrounds[$section['background']] ?? '',
                         $paddings[$section['padding']] ?? '',
                         $section['classes']['cards'],
                         $section['classes']['cta'],
                         $section['background_image'] && ($section['layout']['overlay']['mobile'] ?? '0%') !== '0%'
                             ? 'section-overlay' : '',
                     ]))
                     @if ($section['background_image'])
                         {{-- Inline because the URL is per-section data, not
                              style: there is no stylesheet that could know it.
                              url() is single-quoted and the value comes from
                              MediaAsset, not from free text. --}}
                         style="background-image:url('{{ $section['background_image'] }}');background-size:cover;background-position:center;"
                     @endif>
                <div @class(array_filter([
                        $section['classes']['width'] ?: ($section['constrain'] ? 'container-wr' : ''),
                        $section['classes']['text_align'],
                        'relative',
                     ]))>
                    @if (filled($section['heading']))
                        <x-section-heading
                            :title="$section['heading']"
                            :description="$section['subheading']"
                        />
                    @endif

                    <div class="prose-wr max-w-none">
                        {!! $section['html'] !!}
                    </div>
                </div>
            </section>

        @endif

    @endforeach

    @endif

    {{-- Declared by active modules; an anchor that was not rendered falls back to here. --}}
    <x-module-slot target="homepage" place="bottom" :rendered="$renderedKeys" />

@endsection
