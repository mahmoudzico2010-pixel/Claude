<?php

// Search-engine wording: page-specific default descriptions (used only when a page has no description of its own),
// the homepage main heading and a default homepage title. Proposed wording, reviewable and overridable in the admin.
return [
    'home_title' => 'Exportateur égyptien d\'olives et de cornichons',
    'home_h1' => 'Olives de table et légumes marinés d\'Égypte pour les marchés mondiaux',
    'desc' => [
        'home' => 'Wadi El Rayan est un fabricant et exportateur égyptien d\'olives de table et de légumes marinés. Découvrez la gamme et les options de conditionnement, puis demandez un devis.',
        'products' => 'Découvrez les olives de table et légumes marinés de Wadi El Rayan, en Égypte : variétés, coupes et formats de conditionnement pour importateurs, distributeurs et marques de distributeur.',
        'category' => ':name par Wadi El Rayan : consultez la gamme, les spécifications et les formats de conditionnement, puis demandez un devis.',
        'variety' => ':name par Wadi El Rayan : produits disponibles, coupes et formats de conditionnement, avec demande de devis pour les importateurs.',
        'product' => ':name par Wadi El Rayan, Égypte. Consultez les spécifications et les formats de conditionnement, puis demandez un devis.',
        'contact' => 'Contactez l\'équipe export de Wadi El Rayan en Égypte pour des informations produits, des options de conditionnement et des demandes de devis.',
        'about' => 'À propos de Wadi El Rayan : producteur égyptien d\'olives de table et de légumes marinés, notre histoire, nos opérations et nos équipes.',
        'team' => 'Rencontrez l\'équipe de Wadi El Rayan, fabricant égyptien d\'olives de table et de légumes marinés.',
        'quality' => 'La démarche de Wadi El Rayan en matière de qualité, de sécurité alimentaire et de traçabilité pour ses olives de table et légumes marinés fabriqués en Égypte.',
        'export' => 'Informations export pour importateurs et distributeurs : marchés servis et comment demander un devis pour les olives et les conserves de Wadi El Rayan.',
        'private_label' => 'Olives et légumes marinés en marque de distributeur par Wadi El Rayan, en Égypte. Découvrez les options de conditionnement et demandez un devis pour votre marque.',
        'news' => 'Actualités, salons et nouveautés de Wadi El Rayan, fabricant égyptien d\'olives de table et de légumes marinés.',
        'quote' => 'Demandez un devis à Wadi El Rayan : indiquez-nous les produits, formats et volumes souhaités et notre équipe export vous répondra.',
        'packaging' => 'Options de conditionnement de Wadi El Rayan pour olives de table et légumes marinés : formats et tailles pour la distribution, la restauration et la marque de distributeur.',
        'pack' => ':name : un format de conditionnement de Wadi El Rayan pour olives de table et légumes marinés. Consultez les détails et demandez un devis.',
    ],
];
