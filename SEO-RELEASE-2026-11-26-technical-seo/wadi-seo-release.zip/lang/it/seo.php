<?php

// Search-engine wording: page-specific default descriptions (used only when a page has no description of its own),
// the homepage main heading and a default homepage title. Proposed wording, reviewable and overridable in the admin.
return [
    'home_title' => 'Esportatore egiziano di olive e sottaceti',
    'home_h1' => 'Olive da tavola e verdure sott\'aceto dall\'Egitto per i mercati globali',
    'desc' => [
        'home' => 'Wadi El Rayan è un produttore ed esportatore egiziano di olive da tavola e verdure sott\'aceto. Scopri la gamma e le opzioni di confezionamento e richiedi un preventivo.',
        'products' => 'Scopri le olive da tavola e le verdure sott\'aceto di Wadi El Rayan, in Egitto: varietà, tagli e formati di confezione per importatori, distributori e marchi privati.',
        'category' => ':name di Wadi El Rayan: consulta la gamma, le specifiche e i formati di confezione e richiedi un preventivo.',
        'variety' => ':name di Wadi El Rayan: prodotti disponibili, tagli e formati di confezione, con richiesta di preventivo per gli importatori.',
        'product' => ':name di Wadi El Rayan, Egitto. Consulta le specifiche e i formati di confezione e richiedi un preventivo.',
        'contact' => 'Contatta il team export di Wadi El Rayan in Egitto per informazioni sui prodotti, opzioni di confezionamento e richieste di preventivo.',
        'about' => 'Chi è Wadi El Rayan: produttore egiziano di olive da tavola e verdure sott\'aceto, la nostra storia, le nostre attività e il nostro team.',
        'team' => 'Conosci le persone di Wadi El Rayan, produttore egiziano di olive da tavola e verdure sott\'aceto.',
        'quality' => 'Come Wadi El Rayan affronta qualità, sicurezza alimentare e tracciabilità per le olive da tavola e le verdure sott\'aceto prodotte in Egitto.',
        'export' => 'Informazioni per l\'export destinate a importatori e distributori: mercati serviti e come richiedere un preventivo per olive e sottaceti di Wadi El Rayan.',
        'private_label' => 'Olive e verdure sott\'aceto a marchio privato di Wadi El Rayan, in Egitto. Scopri le opzioni di confezionamento e richiedi un preventivo per il tuo marchio.',
        'news' => 'Notizie, fiere e aggiornamenti di Wadi El Rayan, produttore egiziano di olive da tavola e verdure sott\'aceto.',
        'quote' => 'Richiedi un preventivo a Wadi El Rayan: indicaci prodotti, formati e quantità di cui hai bisogno e il nostro team export ti risponderà.',
        'packaging' => 'Opzioni di confezionamento di Wadi El Rayan per olive da tavola e verdure sott\'aceto: formati e dimensioni per retail, ristorazione e marchio privato.',
        'pack' => ':name: un formato di confezione di Wadi El Rayan per olive da tavola e verdure sott\'aceto. Consulta i dettagli e richiedi un preventivo.',
    ],
];
