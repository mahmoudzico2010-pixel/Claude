<?php

// Search-engine wording: page-specific default descriptions (used only when a page has no description of its own),
// the homepage main heading and a default homepage title. Proposed wording, reviewable and overridable in the admin.
return [
    'home_title' => '埃及橄榄与腌制蔬菜出口商',
    'home_h1' => '面向全球市场的埃及餐桌橄榄与腌制蔬菜',
    'desc' => [
        'home' => 'Wadi El Rayan 是埃及餐桌橄榄和腌制蔬菜的生产商与出口商。了解产品系列和包装选择，并索取报价。',
        'products' => '浏览 Wadi El Rayan（埃及）的餐桌橄榄与腌制蔬菜：适合进口商、分销商和自有品牌的品种、切法与包装规格。',
        'category' => 'Wadi El Rayan 的:name：查看产品系列、规格和包装规格，并索取报价。',
        'variety' => 'Wadi El Rayan 的:name：可供产品、切法和包装规格，进口商可索取报价。',
        'product' => 'Wadi El Rayan（埃及）的:name。查看规格和包装规格，并索取报价。',
        'contact' => '联系埃及 Wadi El Rayan 出口团队，了解产品信息、包装选择并提交报价请求。',
        'about' => '关于 Wadi El Rayan：埃及餐桌橄榄与腌制蔬菜生产商，我们的故事、生产运营和团队。',
        'team' => '认识 Wadi El Rayan 的团队——埃及餐桌橄榄与腌制蔬菜制造商。',
        'quality' => 'Wadi El Rayan 如何对待在埃及生产的餐桌橄榄和腌制蔬菜的质量、食品安全与可追溯性。',
        'export' => '面向进口商和分销商的出口信息：服务的市场，以及如何向 Wadi El Rayan 索取橄榄和腌菜报价。',
        'private_label' => 'Wadi El Rayan（埃及）的自有品牌橄榄与腌制蔬菜。了解包装选择，并为您的品牌索取报价。',
        'news' => 'Wadi El Rayan（埃及餐桌橄榄与腌制蔬菜制造商）的新闻、展会与公司动态。',
        'quote' => '向 Wadi El Rayan 索取报价：告诉我们您需要的产品、包装规格和数量，出口团队将回复您。',
        'packaging' => 'Wadi El Rayan 为餐桌橄榄和腌制蔬菜提供的包装选择：适用于零售、餐饮和自有品牌的规格与尺寸。',
        'pack' => ':name：Wadi El Rayan 为餐桌橄榄和腌制蔬菜提供的包装规格。查看详情并索取报价。',
    ],
];
