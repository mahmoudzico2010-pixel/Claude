<?php

// Search-engine wording: page-specific default descriptions (used only when a page has no description of its own),
// the homepage main heading and a default homepage title. Proposed wording, reviewable and overridable in the admin.
return [
    'home_title' => 'Exportador egípcio de azeitonas e conservas',
    'home_h1' => 'Azeitonas de mesa e legumes em conserva do Egito para os mercados globais',
    'desc' => [
        'home' => 'A Wadi El Rayan é uma fabricante e exportadora egípcia de azeitonas de mesa e legumes em conserva. Conheça a gama e as opções de embalagem e peça um orçamento.',
        'products' => 'Conheça as azeitonas de mesa e os legumes em conserva da Wadi El Rayan, no Egito: variedades, cortes e formatos de embalagem para importadores, distribuidores e marcas próprias.',
        'category' => ':name da Wadi El Rayan: veja a gama, as especificações e os formatos de embalagem e peça um orçamento.',
        'variety' => ':name da Wadi El Rayan: produtos disponíveis, cortes e formatos de embalagem, com pedido de orçamento para importadores.',
        'product' => ':name da Wadi El Rayan, Egito. Veja as especificações e os formatos de embalagem e peça um orçamento.',
        'contact' => 'Contacte a equipa de exportação da Wadi El Rayan no Egito para informações sobre produtos, opções de embalagem e pedidos de orçamento.',
        'about' => 'Sobre a Wadi El Rayan: produtora egípcia de azeitonas de mesa e legumes em conserva, a nossa história, as nossas operações e a nossa equipa.',
        'team' => 'Conheça as pessoas da Wadi El Rayan, fabricante egípcia de azeitonas de mesa e legumes em conserva.',
        'quality' => 'Como a Wadi El Rayan encara a qualidade, a segurança alimentar e a rastreabilidade das azeitonas de mesa e dos legumes em conserva fabricados no Egito.',
        'export' => 'Informação de exportação para importadores e distribuidores: mercados servidos e como pedir um orçamento de azeitonas e conservas da Wadi El Rayan.',
        'private_label' => 'Azeitonas e legumes em conserva de marca própria da Wadi El Rayan, no Egito. Conheça as opções de embalagem e peça um orçamento para a sua marca.',
        'news' => 'Notícias, feiras e novidades da Wadi El Rayan, fabricante egípcia de azeitonas de mesa e legumes em conserva.',
        'quote' => 'Peça um orçamento à Wadi El Rayan: indique os produtos, formatos de embalagem e volumes de que precisa e a nossa equipa de exportação responderá.',
        'packaging' => 'Opções de embalagem da Wadi El Rayan para azeitonas de mesa e legumes em conserva: formatos e tamanhos para retalho, restauração e marca própria.',
        'pack' => ':name: um formato de embalagem da Wadi El Rayan para azeitonas de mesa e legumes em conserva. Veja os detalhes e peça um orçamento.',
    ],
];
