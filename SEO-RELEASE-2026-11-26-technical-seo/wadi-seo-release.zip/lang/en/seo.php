<?php

// Search-engine wording: page-specific default descriptions (used only when a page has no description of its own),
// the homepage main heading and a default homepage title. Proposed wording, reviewable and overridable in the admin.
return [
    'home_title' => 'Egyptian Olive & Pickle Exporter',
    'home_h1' => 'Egyptian Table Olives & Pickled Vegetables for Global Markets',
    'desc' => [
        'home' => 'Wadi El Rayan is an Egyptian manufacturer and exporter of table olives and pickled vegetables. Explore the range and packaging options, then request a quotation.',
        'products' => 'Browse table olives and pickled vegetables from Wadi El Rayan in Egypt: varieties, cuts and pack formats for importers, distributors and private-label brands.',
        'category' => ':name from Wadi El Rayan: browse the range, specifications and pack formats, then request a quotation.',
        'variety' => ':name from Wadi El Rayan: available products, cuts and pack formats, with quotation requests for importers.',
        'product' => ':name from Wadi El Rayan, Egypt. See specifications and pack formats, then request a quotation.',
        'contact' => 'Contact the Wadi El Rayan export team in Egypt for product information, packaging options and quotation requests.',
        'about' => 'About Wadi El Rayan: an Egyptian producer of table olives and pickled vegetables, our story, our operations and our people.',
        'team' => 'Meet the people behind Wadi El Rayan, the Egyptian manufacturer of table olives and pickled vegetables.',
        'quality' => 'How Wadi El Rayan approaches quality, food safety and traceability for table olives and pickled vegetables made in Egypt.',
        'export' => 'Export information for importers and distributors: markets served and how to request a quotation for olives and pickles from Wadi El Rayan.',
        'private_label' => 'Private label olives and pickled vegetables from Wadi El Rayan in Egypt. Explore packaging options and request a quotation for your brand.',
        'news' => 'News, exhibitions and company updates from Wadi El Rayan, the Egyptian manufacturer of table olives and pickled vegetables.',
        'quote' => 'Request a quotation from Wadi El Rayan: tell us the products, pack formats and volumes you need and our export team will reply.',
        'packaging' => 'Packaging options from Wadi El Rayan for table olives and pickled vegetables: formats and sizes for retail, food service and private label.',
        'pack' => ':name: a packaging format from Wadi El Rayan for table olives and pickled vegetables. See the details and request a quotation.',
    ],
];
