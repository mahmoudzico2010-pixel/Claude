<?php

// Search-engine wording: page-specific default descriptions (used only when a page has no description of its own),
// the homepage main heading and a default homepage title. Proposed wording, reviewable and overridable in the admin.
return [
    'home_title' => 'Exportador egipcio de aceitunas y encurtidos',
    'home_h1' => 'Aceitunas de mesa y verduras en conserva de Egipto para mercados globales',
    'desc' => [
        'home' => 'Wadi El Rayan es un fabricante y exportador egipcio de aceitunas de mesa y verduras encurtidas. Descubra la gama y las opciones de envasado y solicite un presupuesto.',
        'products' => 'Explore las aceitunas de mesa y verduras encurtidas de Wadi El Rayan, en Egipto: variedades, cortes y formatos de envase para importadores, distribuidores y marcas blancas.',
        'category' => ':name de Wadi El Rayan: consulte la gama, las especificaciones y los formatos de envase y solicite un presupuesto.',
        'variety' => ':name de Wadi El Rayan: productos disponibles, cortes y formatos de envase, con solicitud de presupuesto para importadores.',
        'product' => ':name de Wadi El Rayan, Egipto. Consulte las especificaciones y los formatos de envase y solicite un presupuesto.',
        'contact' => 'Contacte con el equipo de exportación de Wadi El Rayan en Egipto para información de producto, opciones de envasado y solicitudes de presupuesto.',
        'about' => 'Sobre Wadi El Rayan: productor egipcio de aceitunas de mesa y verduras encurtidas, nuestra historia, nuestras operaciones y nuestro equipo.',
        'team' => 'Conozca al equipo de Wadi El Rayan, fabricante egipcio de aceitunas de mesa y verduras encurtidas.',
        'quality' => 'Cómo aborda Wadi El Rayan la calidad, la seguridad alimentaria y la trazabilidad de sus aceitunas de mesa y verduras encurtidas elaboradas en Egipto.',
        'export' => 'Información de exportación para importadores y distribuidores: mercados atendidos y cómo solicitar un presupuesto de aceitunas y encurtidos de Wadi El Rayan.',
        'private_label' => 'Aceitunas y verduras encurtidas de marca blanca de Wadi El Rayan, en Egipto. Explore las opciones de envasado y solicite un presupuesto para su marca.',
        'news' => 'Noticias, ferias y novedades de Wadi El Rayan, fabricante egipcio de aceitunas de mesa y verduras encurtidas.',
        'quote' => 'Solicite un presupuesto a Wadi El Rayan: indíquenos los productos, formatos de envase y volúmenes que necesita y nuestro equipo de exportación le responderá.',
        'packaging' => 'Opciones de envasado de Wadi El Rayan para aceitunas de mesa y verduras encurtidas: formatos y tamaños para retail, hostelería y marca blanca.',
        'pack' => ':name: formato de envase de Wadi El Rayan para aceitunas de mesa y verduras encurtidas. Consulte los detalles y solicite un presupuesto.',
    ],
];
