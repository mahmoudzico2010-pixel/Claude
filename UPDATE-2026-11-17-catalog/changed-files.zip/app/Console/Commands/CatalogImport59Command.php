<?php

declare(strict_types=1);

namespace App\Console\Commands;

use App\Services\Catalog\CatalogImport59;
use Illuminate\Console\Command;

class CatalogImport59Command extends Command
{
    protected $signature = 'catalog:import-59 {--apply : Write changes (default is a dry run)} {--photos= : Folder holding the supplied WebP photographs} {--mapping= : Write the photo mapping CSV to this path}';

    protected $description = 'Create/reconcile the 59 catalogue entries with ten-language copy and photo matches (dry run by default; repeatable)';

    public function handle(): int
    {
        $svc = new CatalogImport59;
        $r = $svc->run((bool) $this->option('apply'), $this->option('photos') ?: null);
        $this->info(($r['applied'] ? 'APPLIED' : 'DRY RUN (nothing written)').': '.json_encode($r['stats']));
        foreach ($r['notes'] as $n) {
            $this->warn($n);
        }
        if ($path = $this->option('mapping')) {
            $fh = fopen($path, 'w');
            fputcsv($fh, ['product_key', 'source_filename', 'role', 'status']);
            foreach ($svc->mapping as $m) {
                fputcsv($fh, [$m['key'], $m['source_filename'], $m['role'], $m['status']]);
            }
            fclose($fh);
            $this->line("Mapping written to $path");
        }

        return self::SUCCESS;
    }
}
