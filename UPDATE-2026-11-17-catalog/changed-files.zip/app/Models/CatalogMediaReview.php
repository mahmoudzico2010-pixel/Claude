<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class CatalogMediaReview extends Model
{
    protected $fillable = ['media_id', 'original_filename', 'candidates', 'reason', 'status', 'product_id'];

    protected function casts(): array
    {
        return ['candidates' => 'array'];
    }

    public function media(): BelongsTo
    {
        return $this->belongsTo(MediaAsset::class, 'media_id');
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }
}
