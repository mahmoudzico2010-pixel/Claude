<?php

declare(strict_types=1);

// Every icon name the editor accepts (core set + Lucide). Parsed once per config load.
$builderIconNames = array_keys(array_merge(require __DIR__.'/builder_icons.php', (array) json_decode((string) file_get_contents(dirname(__DIR__).'/database/data/icons-lucide.json'), true)));

/*
|--------------------------------------------------------------------------
| Page builder — node type registry
|--------------------------------------------------------------------------
|
| Every node type the builder knows, and everything true about it: which group
| it appears under in the element library, what it may contain, what settings it
| accepts, which of those are translatable, and which vary by breakpoint.
|
| This is the single source. The element library, the drag-and-drop validity
| rules, the contextual settings panel, the server-side validator and the
| renderer all read it. Adding an element type is an entry here plus a Blade
| partial — no migration, and nothing to keep in sync by hand.
|
| ---------------------------------------------------------------------------
| `accepts` is the hierarchy
| ---------------------------------------------------------------------------
|
|     page → section → container → column → element
|
| Expressed as "which child types may I contain", so a drag is valid when the
| target's `accepts` list contains the dragged node's type. That one rule covers
| dropping into a column, moving between columns, moving between containers and
| reordering sections — without a special case per direction.
|
| An element's `accepts` is empty, which is what stops a heading being dropped
| inside a button.
|
| ---------------------------------------------------------------------------
| Setting types
| ---------------------------------------------------------------------------
|
| The `type` of each setting names a validator in App\Support\Theme::validate()
| — the same one the theme system uses, already covered by tests — plus a few
| builder-specific ones handled in App\Support\Builder\NodeSettings:
|
|   text, textarea, html   free text, sanitised on the way out
|   media                  a MediaAsset id
|   product, document      a record id
|   select                 one of `options`
|   toggle                 'on' | 'off'
|   integer, length,       validated by Theme::validate()
|   color, percentage,
|   spacing, radius,
|   shadow, font, weight
|
| `responsive => true` means the setting accepts a per-breakpoint map.
| `translatable => true` moves it into builder_node_translations.
|
*/

return [

    /*
    |--------------------------------------------------------------------------
    | Element library groups
    |--------------------------------------------------------------------------
    |
    | Order here is the order in the left-hand panel.
    |
    */

    'groups' => ['layout', 'content', 'graphic', 'business', 'media', 'advanced'],

    /*
    |--------------------------------------------------------------------------
    | Stage 2 section key → native builder element
    |--------------------------------------------------------------------------
    |
    | Used by `builder:convert-homepage`. A key listed here converts into the
    | native element named; a key absent from this map converts into a
    | `legacy_section` node that renders the Stage 2 partial unchanged.
    |
    | Absence therefore means "no native equivalent yet", never "drop it" —
    | `values`, `production` and `cta` are bespoke bands with nothing matching
    | them in the registry, and losing three sections of a live homepage because
    | the builder had no element for them is precisely the failure this map
    | exists to make impossible. scripts/test-builder-tree.php asserts every
    | configured key resolves one way or the other.
    |
    */

    'legacy_map' => [
        'hero' => 'hero',
        'statistics' => 'counters',
        'categories' => 'categories',
        'featured' => 'featured_products',
        'certifications' => 'certifications',
        'news' => 'news',
    ],

    /*
    |--------------------------------------------------------------------------
    | Style settings shared by every node
    |--------------------------------------------------------------------------
    |
    | Merged into each type's own settings rather than repeated in every entry.
    | These live in the `style` column.
    |
    */

    'shared_style' => [
        'margin_top' => ['type' => 'spacing', 'responsive' => true, 'default' => ''],
        'margin_bottom' => ['type' => 'spacing', 'responsive' => true, 'default' => ''],
        'padding_top' => ['type' => 'spacing', 'responsive' => true, 'default' => ''],
        'padding_bottom' => ['type' => 'spacing', 'responsive' => true, 'default' => ''],
        'align' => [
            'type' => 'select', 'responsive' => true, 'default' => '',
            'options' => ['start', 'center', 'end'],
        ],
        // Hide at a breakpoint without deleting or duplicating the element —
        // the alternative is two elements and a maintenance problem.
        'visible' => ['type' => 'toggle', 'responsive' => true, 'default' => 'on'],
        'animation' => [
            'type' => 'select', 'default' => '',
            'options' => ['fade', 'fade-up', 'fade-down', 'fade-left', 'fade-right', 'zoom'],
        ],
        'animation_delay' => ['type' => 'integer', 'default' => '0'],
    ],

    /*
    |--------------------------------------------------------------------------
    | Node types
    |--------------------------------------------------------------------------
    */

    'types' => [

        // ============================================================ LAYOUT

        'section' => [
            'group' => 'layout',
            'icon' => 'rectangle-group',
            'accepts' => ['container'],
            'settings' => [
                'background_color' => ['type' => 'color', 'default' => ''],
                'background_image' => ['type' => 'media', 'default' => ''],
                'background_size' => [
                    'type' => 'select', 'default' => 'cover',
                    'options' => ['cover', 'contain', 'auto'],
                ],
                'background_position' => [
                    'type' => 'select', 'default' => 'center',
                    'options' => ['center', 'top', 'bottom', 'left', 'right'],
                ],
                'background_repeat' => [
                    'type' => 'select', 'default' => 'no-repeat',
                    'options' => ['no-repeat', 'repeat'],
                ],
                'overlay_color' => ['type' => 'color', 'default' => ''],
                'overlay_opacity' => ['type' => 'percentage', 'responsive' => true, 'default' => '0%'],
                // No default min-height. A section that reserves space it does
                // not need is the "giant empty area" this stage exists to fix,
                // so height is opt-in rather than inherited.
                'min_height' => ['type' => 'length', 'responsive' => true, 'default' => ''],
                'full_width' => ['type' => 'toggle', 'default' => 'off'],
            ],
        ],

        'container' => [
            'group' => 'layout',
            'icon' => 'square-3-stack-3d',
            'accepts' => ['column'],
            'settings' => [
                'width' => [
                    'type' => 'select', 'responsive' => true, 'default' => 'standard',
                    'options' => ['narrow', 'standard', 'wide', 'full'],
                ],
                'gap' => ['type' => 'spacing', 'responsive' => true, 'default' => ''],
                'vertical_align' => [
                    'type' => 'select', 'responsive' => true, 'default' => 'stretch',
                    'options' => ['start', 'center', 'end', 'stretch'],
                ],
                // How the columns inside divide the row. Per breakpoint, so a
                // three-column row becomes one column on a phone without a
                // second container existing.
                'columns' => ['type' => 'integer', 'responsive' => true, 'default' => '1'],
            ],
        ],

        'column' => [
            'group' => 'layout',
            'icon' => 'view-columns',
            // The only type that accepts elements. Everything in `content`,
            // `business`, `media` and `advanced` is listed by NodeTypes::
            // elementTypes() rather than repeated here.
            'accepts' => '*elements',
            'settings' => [
                'span' => ['type' => 'integer', 'responsive' => true, 'default' => '1'],
                'background_color' => ['type' => 'color', 'default' => ''],
                'vertical_align' => [
                    'type' => 'select', 'responsive' => true, 'default' => 'start',
                    'options' => ['start', 'center', 'end'],
                ],
            ],
        ],

        'spacer' => [
            'group' => 'layout',
            'icon' => 'arrows-up-down',
            'accepts' => [],
            'settings' => [
                'height' => ['type' => 'length', 'responsive' => true, 'default' => '2rem'],
            ],
        ],

        'divider' => [
            'group' => 'layout',
            'icon' => 'minus',
            'accepts' => [],
            'settings' => [
                'color' => ['type' => 'color', 'default' => ''],
                'thickness' => ['type' => 'length', 'default' => '1px'],
                'width' => ['type' => 'percentage', 'default' => '100%'],
            ],
        ],

        // =========================================================== CONTENT

        'heading' => [
            'group' => 'content',
            'icon' => 'h1',
            'accepts' => [],
            'translatable' => ['text'],
            'settings' => [
                'text' => ['type' => 'text', 'translatable' => true, 'default' => ''],
                // Semantic level, chosen separately from visual size — so a
                // section heading can look large without becoming a second H1
                // and breaking the document outline.
                'level' => [
                    'type' => 'select', 'default' => 'h2',
                    'options' => ['h1', 'h2', 'h3', 'h4'],
                ],
                'size' => [
                    'type' => 'select', 'responsive' => true, 'default' => 'h2',
                    'options' => ['display', 'h1', 'h2', 'h3', 'body'],
                ],
                'color' => ['type' => 'color', 'default' => ''],
                'weight' => ['type' => 'weight', 'default' => ''],
                'line_height' => ['type' => 'ratio', 'default' => ''],
                'letter_spacing' => ['type' => 'length', 'default' => ''],
            ],
        ],

        'text' => [
            'group' => 'content',
            'icon' => 'bars-3-bottom-left',
            'accepts' => [],
            'translatable' => ['body'],
            'settings' => [
                'body' => ['type' => 'textarea', 'translatable' => true, 'default' => ''],
                'size' => [
                    'type' => 'select', 'responsive' => true, 'default' => 'body',
                    'options' => ['small', 'body', 'lead'],
                ],
                'color' => ['type' => 'color', 'default' => ''],
                'max_width' => ['type' => 'length', 'default' => ''],
            ],
        ],

        'rich_text' => [
            'group' => 'content',
            'icon' => 'document-text',
            'accepts' => [],
            'translatable' => ['body'],
            'settings' => [
                'body' => ['type' => 'html', 'translatable' => true, 'default' => ''],
            ],
        ],

        'button' => [
            'group' => 'content',
            'icon' => 'cursor-arrow-rays',
            'accepts' => [],
            'translatable' => ['label'],
            'settings' => [
                'label' => ['type' => 'text', 'translatable' => true, 'default' => ''],
                'destination' => [
                    'type' => 'select', 'default' => 'url',
                    'options' => ['url', 'page', 'document', 'anchor', 'route'],
                ],
                'url' => ['type' => 'text', 'default' => ''],
                'page_id' => ['type' => 'integer', 'default' => ''],
                'document_id' => ['type' => 'document', 'default' => ''],
                'anchor' => ['type' => 'text', 'default' => ''],
                'route_name' => ['type' => 'text', 'default' => ''],
                'new_tab' => ['type' => 'toggle', 'default' => 'off'],
                'style' => [
                    'type' => 'select', 'default' => 'primary',
                    'options' => ['primary', 'outline', 'ghost', 'link'],
                ],
                'size' => [
                    'type' => 'select', 'responsive' => true, 'default' => 'default',
                    'options' => ['small', 'default', 'large'],
                ],
                'full_width' => ['type' => 'toggle', 'responsive' => true, 'default' => 'off'],
            ],
        ],

        'buttons' => [
            'group' => 'content',
            'icon' => 'rectangle-stack',
            'accepts' => ['button'],
            'settings' => [
                'layout' => [
                    'type' => 'select', 'responsive' => true, 'default' => 'inline',
                    'options' => ['inline', 'stacked'],
                ],
                'gap' => ['type' => 'spacing', 'default' => ''],
            ],
        ],

        // ========================================================== BUSINESS

        'hero' => [
            'group' => 'business',
            'icon' => 'photo',
            'accepts' => [],
            'translatable' => ['eyebrow', 'heading', 'body', 'primary_label', 'secondary_label'],
            'settings' => [
                'eyebrow' => ['type' => 'text', 'translatable' => true, 'default' => ''],
                'heading' => ['type' => 'text', 'translatable' => true, 'default' => ''],
                'body' => ['type' => 'textarea', 'translatable' => true, 'default' => ''],
                'image' => ['type' => 'media', 'default' => ''],
                'image_mobile' => ['type' => 'media', 'default' => ''],
                'overlay_opacity' => ['type' => 'percentage', 'responsive' => true, 'default' => '55%'],
                'height' => ['type' => 'length', 'responsive' => true, 'default' => ''],
                'content_x' => [
                    'type' => 'select', 'responsive' => true, 'default' => 'start',
                    'options' => ['start', 'center', 'end'],
                ],
                'content_y' => [
                    'type' => 'select', 'responsive' => true, 'default' => 'center',
                    'options' => ['start', 'center', 'end'],
                ],
                'primary_label' => ['type' => 'text', 'translatable' => true, 'default' => ''],
                'primary_url' => ['type' => 'text', 'default' => ''],
                'secondary_label' => ['type' => 'text', 'translatable' => true, 'default' => ''],
                'secondary_url' => ['type' => 'text', 'default' => ''],
            ],
        ],

        'counters' => [
            'group' => 'business',
            'icon' => 'chart-bar',
            'accepts' => ['counter'],
            'settings' => [
                'columns' => ['type' => 'integer', 'responsive' => true, 'default' => '4'],
                'animate' => ['type' => 'toggle', 'default' => 'on'],
                'repeat' => ['type' => 'toggle', 'default' => 'off'],
                'duration' => ['type' => 'integer', 'default' => '2000'],
            ],
        ],

        'counter' => [
            'group' => 'business',
            'icon' => 'hashtag',
            'accepts' => [],
            'translatable' => ['label', 'prefix', 'suffix'],
            'settings' => [
                'start' => ['type' => 'integer', 'default' => '0'],
                'end' => ['type' => 'integer', 'default' => '0'],
                'decimals' => ['type' => 'integer', 'default' => '0'],
                'separator' => ['type' => 'toggle', 'default' => 'on'],
                'prefix' => ['type' => 'text', 'translatable' => true, 'default' => ''],
                'suffix' => ['type' => 'text', 'translatable' => true, 'default' => ''],
                'label' => ['type' => 'text', 'translatable' => true, 'default' => ''],
                'icon' => ['type' => 'media', 'default' => ''],
                'color' => ['type' => 'color', 'default' => ''],
            ],
        ],

        'featured_products' => [
            'group' => 'business',
            'icon' => 'star',
            'accepts' => [],
            'settings' => [
                'source' => [
                    'type' => 'select', 'default' => 'auto',
                    'options' => ['auto', 'manual'],
                ],
                'products' => ['type' => 'product_list', 'default' => ''],
                'limit' => ['type' => 'integer', 'default' => '6'],
                'columns' => ['type' => 'integer', 'responsive' => true, 'default' => '3'],
                'card_style' => [
                    'type' => 'select', 'default' => 'card',
                    'options' => ['card', 'bordered', 'plain'],
                ],
                'image_ratio' => [
                    'type' => 'select', 'default' => '4-3',
                    'options' => ['1-1', '4-3', '3-2', '16-9', '3-4'],
                ],
                'show_category' => ['type' => 'toggle', 'default' => 'on'],
                'show_description' => ['type' => 'toggle', 'default' => 'on'],
                'show_link' => ['type' => 'toggle', 'default' => 'on'],
                'hover_zoom' => ['type' => 'toggle', 'default' => 'on'],
            ],
        ],

        'product_grid' => [
            'group' => 'business',
            'icon' => 'squares-2x2',
            'accepts' => [],
            'settings' => [
                'category_id' => ['type' => 'integer', 'default' => ''],
                'limit' => ['type' => 'integer', 'default' => '9'],
                'columns' => ['type' => 'integer', 'responsive' => true, 'default' => '3'],
                'card_style' => [
                    'type' => 'select', 'default' => 'card',
                    'options' => ['card', 'bordered', 'plain'],
                ],
                'image_ratio' => [
                    'type' => 'select', 'default' => '4-3',
                    'options' => ['1-1', '4-3', '3-2', '16-9', '3-4'],
                ],
            ],
        ],

        'product_carousel' => [
            'group' => 'business',
            'icon' => 'arrows-right-left',
            'accepts' => [],
            'settings' => [
                'source' => ['type' => 'select', 'default' => 'auto', 'options' => ['auto', 'manual']],
                'products' => ['type' => 'product_list', 'default' => ''],
                'limit' => ['type' => 'integer', 'default' => '12'],
                'visible' => ['type' => 'integer', 'responsive' => true, 'default' => '3'],
                'autoplay' => ['type' => 'toggle', 'default' => 'off'],
            ],
        ],

        'categories' => [
            'group' => 'business',
            'icon' => 'rectangle-group',
            'accepts' => [],
            'settings' => [
                'limit' => ['type' => 'integer', 'default' => '6'],
                'columns' => ['type' => 'integer', 'responsive' => true, 'default' => '3'],
            ],
        ],

        'content_blocks' => [
            'group' => 'business',
            'icon' => 'rectangle-stack',
            'accepts' => [],
            'settings' => [
                'section' => ['type' => 'select', 'default' => 'values', 'options' => ['values', 'statistics', 'production_steps', 'quality_points', 'export_services', 'private_label_benefits']],
                'layout' => ['type' => 'select', 'default' => 'cards', 'options' => ['cards', 'list', 'numbers']],
                'columns' => ['type' => 'integer', 'responsive' => true, 'default' => '3'],
                'show_icon' => ['type' => 'toggle', 'default' => 'on'],
                'icon_size' => ['type' => 'integer', 'default' => '56'],
                'limit' => ['type' => 'integer', 'default' => '12'],
            ],
        ],

        'certifications' => [
            'group' => 'business',
            'icon' => 'check-badge',
            'accepts' => [],
            'settings' => [
                'show_banner' => ['type' => 'toggle', 'default' => 'on'],
                'columns' => ['type' => 'integer', 'responsive' => true, 'default' => '4'],
            ],
        ],

        'markets' => [
            'group' => 'business',
            'icon' => 'globe-alt',
            'accepts' => [],
            'settings' => [
                'columns' => ['type' => 'integer', 'responsive' => true, 'default' => '4'],
            ],
        ],

        'export_map' => [
            'group' => 'business',
            'icon' => 'globe-alt',
            'accepts' => [],
            'settings' => [],
        ],

        'country_flags' => [
            'group' => 'business',
            'icon' => 'flag',
            'accepts' => [],
            'settings' => [
                'columns' => ['type' => 'integer', 'responsive' => true, 'default' => '4'],
                'show_names' => ['type' => 'toggle', 'default' => 'on'],
            ],
        ],

        'rfq' => [
            'group' => 'business',
            'icon' => 'envelope',
            'accepts' => [],
            'translatable' => ['heading', 'text', 'button_label'],
            'settings' => [
                'heading' => ['type' => 'text', 'translatable' => true, 'default' => ''],
                'text' => ['type' => 'textarea', 'translatable' => true, 'default' => ''],
                'button_label' => ['type' => 'text', 'translatable' => true, 'default' => ''],
            ],
        ],

        'chart' => [
            'group' => 'content',
            'icon' => 'chart-bar',
            'accepts' => [],
            'translatable' => ['title', 'data'],
            'settings' => [
                'chart_type' => ['type' => 'select', 'default' => 'bar', 'options' => ['bar', 'donut']],
                'title' => ['type' => 'text', 'translatable' => true, 'default' => ''],
                // One "Label | value" per line.
                'data' => ['type' => 'textarea', 'translatable' => true, 'default' => ''],
                'color' => ['type' => 'color', 'default' => ''],
            ],
        ],

        // ------------------------------------------------------------------ graphic elements
        'icon' => [
            'group' => 'graphic', 'icon' => 'star', 'accepts' => [], 'translatable' => ['label'],
            'settings' => [
                'name' => ['type' => 'select', 'picker' => 'icon', 'default' => 'check', 'options' => $builderIconNames],
                'style' => ['type' => 'select', 'default' => 'plain', 'options' => ['plain', 'circle', 'square', 'outline']],
                'size' => ['type' => 'integer', 'default' => '48'],
                'color' => ['type' => 'color', 'default' => ''],
                'background' => ['type' => 'color', 'default' => ''],
                'label' => ['type' => 'text', 'translatable' => true, 'default' => ''],
            ],
        ],

        'icon_box' => [
            'group' => 'graphic', 'icon' => 'squares-2x2', 'accepts' => [], 'translatable' => ['title', 'text', 'link_label'],
            'settings' => [
                'name' => ['type' => 'select', 'picker' => 'icon', 'default' => 'leaf', 'options' => $builderIconNames],
                'style' => ['type' => 'select', 'default' => 'circle', 'options' => ['plain', 'circle', 'square', 'outline']],
                'layout' => ['type' => 'select', 'default' => 'top', 'options' => ['top', 'side']],
                'align' => ['type' => 'select', 'default' => 'start', 'options' => ['start', 'center', 'end']],
                'size' => ['type' => 'integer', 'default' => '28'],
                'color' => ['type' => 'color', 'default' => ''],
                'background' => ['type' => 'color', 'default' => ''],
                'card' => ['type' => 'toggle', 'default' => 'on'],
                'title' => ['type' => 'text', 'translatable' => true, 'default' => ''],
                'text' => ['type' => 'textarea', 'translatable' => true, 'default' => ''],
                'link_label' => ['type' => 'text', 'translatable' => true, 'default' => ''],
                'link_url' => ['type' => 'text', 'default' => ''],
            ],
        ],

        'icon_list' => [
            'group' => 'graphic', 'icon' => 'list-bullet', 'accepts' => ['icon_list_item'],
            'settings' => [
                'name' => ['type' => 'select', 'picker' => 'icon', 'default' => 'check', 'options' => $builderIconNames],
                'color' => ['type' => 'color', 'default' => ''],
                'gap' => ['type' => 'integer', 'default' => '12'],
            ],
        ],
        'icon_list_item' => [
            'group' => 'graphic', 'icon' => 'minus', 'accepts' => [], 'translatable' => ['text'], 'hidden' => true,
            'settings' => [
                'name' => ['type' => 'select', 'picker' => 'icon', 'default' => '', 'options' => $builderIconNames],
                'text' => ['type' => 'text', 'translatable' => true, 'default' => ''],
            ],
        ],

        'shape_divider' => [
            'group' => 'graphic', 'icon' => 'minus', 'accepts' => [],
            'settings' => [
                'shape' => ['type' => 'select', 'default' => 'wave', 'options' => ['wave', 'curve', 'tilt', 'triangle', 'zigzag', 'arc']],
                'color' => ['type' => 'color', 'default' => '#ffffff'],
                'background' => ['type' => 'color', 'default' => ''],
                'height' => ['type' => 'integer', 'responsive' => true, 'default' => '80'],
                'flip' => ['type' => 'toggle', 'default' => 'off'],
                'invert' => ['type' => 'toggle', 'default' => 'off'],
            ],
        ],

        'cta_banner' => [
            'group' => 'graphic', 'icon' => 'megaphone', 'accepts' => [], 'translatable' => ['heading', 'text', 'button_label'],
            'settings' => [
                'heading' => ['type' => 'text', 'translatable' => true, 'default' => ''],
                'text' => ['type' => 'textarea', 'translatable' => true, 'default' => ''],
                'button_label' => ['type' => 'text', 'translatable' => true, 'default' => ''],
                'button_url' => ['type' => 'text', 'default' => ''],
                'gradient_from' => ['type' => 'color', 'default' => '#14382a'],
                'gradient_to' => ['type' => 'color', 'default' => '#1f6b4f'],
                'angle' => ['type' => 'integer', 'default' => '135'],
                'text_color' => ['type' => 'color', 'default' => '#ffffff'],
                'align' => ['type' => 'select', 'default' => 'start', 'options' => ['start', 'center', 'end']],
                'radius' => ['type' => 'integer', 'default' => '24'],
                'pattern' => ['type' => 'toggle', 'default' => 'on'],
            ],
        ],

        'testimonial' => [
            'group' => 'graphic', 'icon' => 'chat-bubble-left-right', 'accepts' => [], 'translatable' => ['quote', 'name', 'role'],
            'settings' => [
                'quote' => ['type' => 'textarea', 'translatable' => true, 'default' => ''],
                'name' => ['type' => 'text', 'translatable' => true, 'default' => ''],
                'role' => ['type' => 'text', 'translatable' => true, 'default' => ''],
                'photo' => ['type' => 'media', 'default' => ''],
                'rating' => ['type' => 'integer', 'default' => '5'],
                'card' => ['type' => 'toggle', 'default' => 'on'],
                'align' => ['type' => 'select', 'default' => 'start', 'options' => ['start', 'center']],
            ],
        ],

        'accordion' => [
            'group' => 'graphic', 'icon' => 'bars-3-bottom-left', 'accepts' => ['accordion_item'],
            'settings' => [
                'first_open' => ['type' => 'toggle', 'default' => 'on'],
                'allow_multiple' => ['type' => 'toggle', 'default' => 'off'],
                'accent' => ['type' => 'color', 'default' => ''],
            ],
        ],
        'accordion_item' => [
            'group' => 'graphic', 'icon' => 'minus', 'accepts' => [], 'translatable' => ['title', 'body'], 'hidden' => true,
            'settings' => [
                'title' => ['type' => 'text', 'translatable' => true, 'default' => ''],
                'body' => ['type' => 'textarea', 'translatable' => true, 'default' => ''],
            ],
        ],

        'timeline' => [
            'group' => 'graphic', 'icon' => 'queue-list', 'accepts' => ['timeline_item'],
            'settings' => [
                'line_color' => ['type' => 'color', 'default' => '#b8903a'],
                'dot_color' => ['type' => 'color', 'default' => '#14382a'],
            ],
        ],
        'timeline_item' => [
            'group' => 'graphic', 'icon' => 'minus', 'accepts' => [], 'translatable' => ['date', 'title', 'text'], 'hidden' => true,
            'settings' => [
                'date' => ['type' => 'text', 'translatable' => true, 'default' => ''],
                'title' => ['type' => 'text', 'translatable' => true, 'default' => ''],
                'text' => ['type' => 'textarea', 'translatable' => true, 'default' => ''],
            ],
        ],

        'progress_bar' => [
            'group' => 'graphic', 'icon' => 'chart-bar', 'accepts' => [], 'translatable' => ['label'],
            'settings' => [
                'label' => ['type' => 'text', 'translatable' => true, 'default' => ''],
                'value' => ['type' => 'integer', 'default' => '80'],
                'color' => ['type' => 'color', 'default' => ''],
                'height' => ['type' => 'integer', 'default' => '10'],
                'show_value' => ['type' => 'toggle', 'default' => 'on'],
            ],
        ],

        'badge' => [
            'group' => 'graphic', 'icon' => 'tag', 'accepts' => [], 'translatable' => ['text'],
            'settings' => [
                'text' => ['type' => 'text', 'translatable' => true, 'default' => ''],
                'style' => ['type' => 'select', 'default' => 'solid', 'options' => ['solid', 'soft', 'outline']],
                'color' => ['type' => 'color', 'default' => '#14382a'],
                'name' => ['type' => 'select', 'picker' => 'icon', 'default' => '', 'options' => $builderIconNames],
            ],
        ],

        'image_box' => [
            'group' => 'graphic', 'icon' => 'photo', 'accepts' => [], 'translatable' => ['title', 'text'],
            'settings' => [
                'image' => ['type' => 'media', 'default' => ''],
                'title' => ['type' => 'text', 'translatable' => true, 'default' => ''],
                'text' => ['type' => 'textarea', 'translatable' => true, 'default' => ''],
                'link_url' => ['type' => 'text', 'default' => ''],
                'height' => ['type' => 'integer', 'responsive' => true, 'default' => '320'],
                'overlay_color' => ['type' => 'color', 'default' => '#0b2a1f'],
                'overlay_opacity' => ['type' => 'integer', 'default' => '45'],
                'radius' => ['type' => 'integer', 'default' => '20'],
                'align' => ['type' => 'select', 'default' => 'start', 'options' => ['start', 'center', 'end']],
            ],
        ],

        'star_rating' => [
            'group' => 'graphic', 'icon' => 'star', 'accepts' => [], 'translatable' => ['label'],
            'settings' => [
                'rating' => ['type' => 'integer', 'default' => '5'],
                'label' => ['type' => 'text', 'translatable' => true, 'default' => ''],
                'color' => ['type' => 'color', 'default' => '#b8903a'],
                'size' => ['type' => 'integer', 'default' => '24'],
            ],
        ],

        'social_icons' => [
            'group' => 'graphic', 'icon' => 'share', 'accepts' => [],
            'settings' => [
                'facebook' => ['type' => 'text', 'default' => ''], 'instagram' => ['type' => 'text', 'default' => ''], 'linkedin' => ['type' => 'text', 'default' => ''],
                'x' => ['type' => 'text', 'default' => ''], 'youtube' => ['type' => 'text', 'default' => ''], 'whatsapp' => ['type' => 'text', 'default' => ''],
                'style' => ['type' => 'select', 'default' => 'circle', 'options' => ['plain', 'circle', 'square']],
                'size' => ['type' => 'integer', 'default' => '40'],
                'color' => ['type' => 'color', 'default' => ''],
                'align' => ['type' => 'select', 'default' => 'start', 'options' => ['start', 'center', 'end']],
            ],
        ],

        'locations' => [
            'group' => 'business',
            'icon' => 'map-pin',
            'accepts' => [],
            'settings' => [
                'show_map' => ['type' => 'toggle', 'default' => 'on'],
                'columns' => ['type' => 'integer', 'responsive' => true, 'default' => '2'],
            ],
        ],

        'news' => [
            'group' => 'business',
            'icon' => 'newspaper',
            'accepts' => [],
            'settings' => [
                'limit' => ['type' => 'integer', 'default' => '3'],
                'columns' => ['type' => 'integer', 'responsive' => true, 'default' => '3'],
            ],
        ],

        // ============================================================= MEDIA

        'image' => [
            'group' => 'media',
            'icon' => 'photo',
            'accepts' => [],
            'translatable' => ['caption'],
            'settings' => [
                'media' => ['type' => 'media', 'default' => ''],
                'caption' => ['type' => 'text', 'translatable' => true, 'default' => ''],
                'ratio' => [
                    'type' => 'select', 'responsive' => true, 'default' => 'auto',
                    'options' => ['auto', '1-1', '4-3', '3-2', '16-9', '3-4'],
                ],
                // `contain` by default: an image the administrator chose should
                // be shown whole unless cropping is asked for.
                'fit' => ['type' => 'select', 'default' => 'contain', 'options' => ['contain', 'cover']],
                'radius' => ['type' => 'radius', 'default' => ''],
                'link_url' => ['type' => 'text', 'default' => ''],
            ],
        ],

        'gallery' => [
            'group' => 'media',
            'icon' => 'rectangle-stack',
            'accepts' => [],
            'settings' => [
                'media' => ['type' => 'media_list', 'default' => ''],
                'columns' => ['type' => 'integer', 'responsive' => true, 'default' => '3'],
                'ratio' => [
                    'type' => 'select', 'default' => '1-1',
                    'options' => ['1-1', '4-3', '3-2', '16-9'],
                ],
            ],
        ],

        'video' => [
            'group' => 'media',
            'icon' => 'play-circle',
            'accepts' => [],
            'settings' => [
                'media' => ['type' => 'media', 'default' => ''],
                'poster' => ['type' => 'media', 'default' => ''],
                'autoplay' => ['type' => 'toggle', 'default' => 'off'],
                'loop' => ['type' => 'toggle', 'default' => 'off'],
                'controls' => ['type' => 'toggle', 'default' => 'on'],
            ],
        ],

        'document' => [
            'group' => 'media',
            'icon' => 'document',
            'accepts' => [],
            'settings' => [
                'document_id' => ['type' => 'document', 'default' => ''],
                'mode' => [
                    'type' => 'select', 'default' => 'viewer',
                    'options' => ['viewer', 'card'],
                ],
                'ratio' => [
                    'type' => 'select', 'responsive' => true, 'default' => '4-3',
                    'options' => ['3-4', '1-1', '4-3', '16-9'],
                ],
            ],
        ],

        // ========================================================== ADVANCED

        'html' => [
            'group' => 'advanced',
            'icon' => 'code-bracket',
            'accepts' => [],
            'translatable' => ['markup'],
            'settings' => [
                // Rebuilt from an allowlist by HtmlBlockSanitizer before it
                // reaches a page. Never executed as PHP or Blade.
                'markup' => ['type' => 'html', 'translatable' => true, 'default' => ''],
            ],
            // Writing markup is writing code on the company's own origin.
            'permission' => 'super_admin',
        ],

        'custom_css' => [
            'group' => 'advanced',
            'icon' => 'paint-brush',
            'accepts' => [],
            'settings' => [
                // Every selector is prefixed with this node's own scope, so a
                // block cannot reach the header, the navigation or another
                // section.
                'css' => ['type' => 'css', 'default' => ''],
            ],
            'permission' => 'super_admin',
        ],

        /*
         | A Stage 2 built-in band, rendered by its shipped Blade partial.
         |
         | This type exists so converting the old homepage into the builder
         | cannot lose anything. Most built-in keys have a native element here —
         | `hero`, `statistics`, `categories`, `featured`, `certifications`,
         | `news` — and convert into it. But `values`, `production` and `cta` are
         | bespoke bands with no equivalent, and dropping them because the
         | builder has no matching element would silently delete three sections
         | of a live homepage.
         |
         | So they convert into this instead: same partial, same markup, now
         | movable and switchable like everything else. It is a bridge, not a
         | permanent parallel renderer — the partials it calls are the ones
         | already shipped, and an administrator can replace any of these with
         | native elements whenever they like.
         */
        'legacy_section' => [
            'group' => 'advanced',
            'icon' => 'archive-box',
            'accepts' => [],

            /*
             | A transitional compatibility layer, not a destination.
             |
             | This type renders a Stage 2 Blade partial, which means the band's
             | internal content — its cards, images and copy — cannot be edited
             | in the builder at all; only its heading and subheading are
             | reachable. It exists so that converting the old homepage loses
             | nothing, and the intended end state is that each of these is
             | rebuilt from native elements.
             |
             | The flag drives the notice in the settings panel and the
             | "rebuild" action beside it. Rebuilding disables the legacy node
             | rather than deleting it, so the original band is always one click
             | from coming back.
             */
            'transitional' => true,
            'settings' => [
                // Constrained to the shipped list, so this cannot be turned
                // into a way to include an arbitrary view.
                'key' => [
                    'type' => 'select',
                    'default' => '',
                    'options' => ['values', 'production', 'cta', 'hero', 'statistics',
                        'categories', 'featured', 'certifications', 'news'],
                ],
                'heading' => ['type' => 'text', 'translatable' => true, 'default' => ''],
                'subheading' => ['type' => 'textarea', 'translatable' => true, 'default' => ''],
            ],
        ],
    ],
];
