<?php

declare(strict_types=1);

namespace App\Support\Builder;

/**
 * Reads the node type registry.
 *
 * Everything that needs to know what a node type is — the element library, the
 * drag-and-drop validity check, the settings panel, the validator, the renderer
 * — asks here rather than reading `config/builder.php` directly. One place to
 * resolve `*elements`, one place that knows the hierarchy.
 *
 * Framework-free on purpose: no Eloquent, no facades, nothing but `config()`.
 * That makes the hierarchy rules testable from a plain PHP script, which is the
 * only kind of test this project can currently run.
 */
final class NodeTypes
{
    /** The levels above elements, in order. */
    public const STRUCTURE = ['section', 'container', 'column'];

    /**
     * Every type, keyed by name.
     *
     * @return array<string, array<string, mixed>>
     */
    public static function all(): array
    {
        return (array) config('builder.types', []);
    }

    /**
     * @return array<string, mixed>|null
     */
    public static function get(string $type): ?array
    {
        $definition = self::all()[$type] ?? null;

        return is_array($definition) ? $definition : null;
    }

    public static function exists(string $type): bool
    {
        return self::get($type) !== null;
    }

    /**
     * Types that can live inside a column — everything that is not structure.
     *
     * Derived rather than listed, so adding an element type to the registry
     * makes it placeable without a second edit. A list that has to be updated
     * in two places is a list that will disagree with itself.
     *
     * @return array<int, string>
     */
    public static function elementTypes(): array
    {
        return array_values(array_filter(
            array_keys(self::all()),
            static fn (string $type): bool => ! in_array($type, self::STRUCTURE, true) && ! (self::get($type)['hidden'] ?? false),   // items that only live inside a parent (accordion item, timeline item…) are not free-standing elements
        ));
    }

    /**
     * Which child types this type may contain.
     *
     * `*elements` expands here rather than in the config, so the registry stays
     * declarative and the expansion happens once.
     *
     * @return array<int, string>
     */
    public static function accepts(string $type): array
    {
        $accepts = self::get($type)['accepts'] ?? [];

        if ($accepts === '*elements') {
            return self::elementTypes();
        }

        return is_array($accepts) ? $accepts : [];
    }

    /**
     * Whether a node of `$childType` may be placed inside `$parentType`.
     *
     * The whole hierarchy reduces to this one question, which is why dropping
     * into a column, moving between columns, moving between containers and
     * reordering sections need no separate rules.
     *
     * A null parent means the page root, which accepts sections only — that is
     * what stops a heading being dragged to the top level where nothing would
     * render it.
     */
    public static function canContain(?string $parentType, string $childType): bool
    {
        if (! self::exists($childType)) {
            return false;
        }

        if ($parentType === null) {
            return $childType === 'section';
        }

        return in_array($childType, self::accepts($parentType), true);
    }

    /**
     * Can this type hold children at all? Drives whether the canvas draws a
     * drop target inside it.
     */
    public static function isContainer(string $type): bool
    {
        return self::accepts($type) !== [];
    }

    /**
     * The settings for a type, with the shared style settings merged in.
     *
     * @return array<string, array<string, mixed>>
     */
    public static function settings(string $type): array
    {
        $own = (array) (self::get($type)['settings'] ?? []);

        return $own;
    }

    /**
     * @return array<string, array<string, mixed>>
     */
    public static function styleSettings(): array
    {
        return (array) config('builder.shared_style', []);
    }

    /**
     * Setting names that are stored per locale rather than on the node.
     *
     * @return array<int, string>
     */
    public static function translatable(string $type): array
    {
        $fields = [];

        foreach (self::settings($type) as $name => $definition) {
            if (($definition['translatable'] ?? false) === true) {
                $fields[] = $name;
            }
        }

        return $fields;
    }

    /**
     * Setting names that accept a per-breakpoint map, including shared style.
     *
     * @return array<int, string>
     */
    public static function responsive(string $type): array
    {
        $fields = [];

        foreach (self::settings($type) + self::styleSettings() as $name => $definition) {
            if (($definition['responsive'] ?? false) === true) {
                $fields[] = $name;
            }
        }

        return $fields;
    }

    /**
     * Whether this type is a compatibility layer rather than a destination.
     *
     * Only `legacy_section` is. It renders a Stage 2 partial, so its inner
     * content is not editable in the builder — which is worth saying on the
     * screen rather than leaving someone to discover by looking for settings
     * that are not there.
     */
    public static function isTransitional(string $type): bool
    {
        return (self::get($type)['transitional'] ?? false) === true;
    }

    /**
     * Types whose use is restricted, and to whom.
     *
     * Only `html` and `custom_css` carry one: both write code onto the
     * company's own origin, which is a different power from editing copy.
     */
    public static function requiredPermission(string $type): ?string
    {
        $permission = self::get($type)['permission'] ?? null;

        return is_string($permission) ? $permission : null;
    }

    /**
     * The element library, grouped for the left-hand panel.
     *
     * Structure types are excluded: a section, container and column are added
     * by the canvas itself, not dragged from the library.
     *
     * @return array<string, array<int, string>>
     */
    public static function library(): array
    {
        $groups = [];

        foreach ((array) config('builder.groups', []) as $group) {
            $groups[$group] = [];
        }

        foreach (self::all() as $type => $definition) {
            if ($definition['hidden'] ?? false) {
                continue;
            }
            $group = (string) ($definition['group'] ?? 'content');

            if (! array_key_exists($group, $groups)) {
                continue;
            }

            $groups[$group][] = $type;
        }

        return array_filter($groups, static fn (array $types): bool => $types !== []);
    }

    /**
     * The default settings for a new node of this type.
     *
     * @return array<string, string>
     */
    public static function defaults(string $type): array
    {
        $defaults = [];

        foreach (self::settings($type) as $name => $definition) {
            $default = $definition['default'] ?? '';

            if (is_string($default) && $default !== '') {
                $defaults[$name] = $default;
            }
        }

        return $defaults;
    }
}
