<?php

declare(strict_types=1);

namespace App\Support\Builder;

use Illuminate\Support\HtmlString;

/** The shared icon set (config/builder_icons.php) rendered as classic outline icons; also the name/keyword search behind the pickers. */
final class Icons3D
{
    /** Search words besides the name itself. */
    private const ALIASES = [
        'truck' => 'delivery shipping transport lorry logistics', 'ship' => 'sea freight export vessel boat container', 'globe' => 'world international export global',
        'shield' => 'safety security protection quality', 'leaf' => 'natural organic green eco plant', 'star' => 'favourite rating premium',
        'clock' => 'time hours schedule fast', 'award' => 'medal certificate prize quality', 'heart' => 'love care health', 'phone' => 'call contact telephone',
        'mail' => 'email message contact', 'map-pin' => 'location address place', 'factory' => 'plant production industry manufacturing', 'box' => 'package packaging carton',
        'flask' => 'lab laboratory test chemistry', 'sun' => 'sunshine day', 'droplet' => 'water oil liquid brine', 'users' => 'team people customers staff',
        'lock' => 'secure private', 'snowflake' => 'cold frozen cooling', 'thermometer' => 'temperature heat cold', 'cart' => 'shop order buy basket',
        'tag' => 'price label brand', 'calendar' => 'date schedule', 'chart' => 'statistics growth graph analytics', 'document' => 'paper file documentation papers',
        'building' => 'company office', 'flag' => 'country market', 'eye' => 'view vision', 'recycle' => 'sustainable eco reuse', 'scale' => 'weight balance',
        'sparkles' => 'new special shine', 'check' => 'ok done approved tick', 'clipboard' => 'checklist inspection audit', 'jar' => 'pickles glass bottle packaging',
        'wheat' => 'grain farm agriculture', 'cube' => 'pack unit pallet', 'handshake' => 'partnership deal agreement', 'target' => 'goal aim', 'trophy' => 'winner best',
        'bolt' => 'energy fast power', 'home' => 'house', 'gift' => 'present bonus', 'search' => 'find look', 'pin' => 'location place', 'microscope' => 'quality analysis lab',
        'tools' => 'service maintenance', 'wrench' => 'service repair', 'bell' => 'notification alert', 'bookmark' => 'save favourite', 'percent' => 'discount offer',
        'link' => 'connection', 'clock-check' => 'on time punctual',
    ];

    /** Icon used when a content block has none chosen, by section. */
    public static function defaultForSection(?string $section): string
    {
        return ['values' => 'leaf', 'statistics' => 'chart', 'production_steps' => 'factory', 'quality_points' => 'shield', 'export_services' => 'ship', 'private_label_benefits' => 'tag'][(string) $section] ?? 'sparkles';
    }

    /** @return list<string> */
    public static function names(): array
    {
        return array_keys(self::glyphs());
    }

    /** @return array<string, string> */
    private static function glyphs(): array
    {
        static $g = null;

        return $g ??= array_merge(require config_path('builder_icons.php'), array_map(fn ($v) => $v[0], self::lucide()));
    }

    /** Lucide icon set (ISC licence, see database/data/icons-lucide-LICENSE.txt): name => [svg inner, search tags]. @return array<string, array{0: string, 1: string}> */
    private static function lucide(): array
    {
        static $l = null;

        return $l ??= (array) json_decode((string) file_get_contents(database_path('data/icons-lucide.json')), true);
    }

    /** Accepts a stored value ("truck", or a legacy "heroicon-o-truck") and returns a known icon name or null. */
    public static function resolve(?string $value): ?string
    {
        $v = strtolower(trim((string) $value));
        $v = preg_replace('/^heroicon-[a-z]-/', '', $v) ?? $v;

        return isset(self::glyphs()[$v]) ? $v : null;
    }

    /** @return list<string> names matching the query by name or keyword */
    public static function search(string $q): array
    {
        $q = strtolower(trim($q));

        return array_values(array_filter(self::names(), fn (string $n): bool => $q === '' || str_contains($n, $q) || str_contains(self::ALIASES[$n] ?? '', $q) || str_contains(self::lucide()[$n][1] ?? '', $q)));
    }

    public static function label(string $name): string
    {
        return ucwords(str_replace('-', ' ', $name));
    }

    /** Classic outline icon (24px line glyph, single colour). Name kept for the existing callers. */
    /** Raw inner SVG markup of an icon (check, if unknown). */
    public static function inner(string $name): string
    {
        $g = self::glyphs();

        return $g[$name] ?? $g['check'];
    }

    public static function svg(string $name, int $size = 48): HtmlString
    {
        $name = self::resolve($name) ?? 'sparkles';
        $size = max(16, min(160, $size));
        $glyph = self::glyphs()[$name];

        return new HtmlString('<svg xmlns="http://www.w3.org/2000/svg" width="'.$size.'" height="'.$size.'" viewBox="0 0 24 24" fill="none" stroke="#166534" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" role="img" aria-hidden="true" style="display:inline-block;flex:none">'.$glyph.'</svg>');
    }

    /** Icon + name, as one option of a searchable picker. */
    public static function option(string $name, int $size = 28): string
    {
        return '<span style="display:flex;align-items:center;gap:.6rem">'.self::svg($name, $size).'<span>'.e(self::label($name)).'</span></span>';
    }
}
