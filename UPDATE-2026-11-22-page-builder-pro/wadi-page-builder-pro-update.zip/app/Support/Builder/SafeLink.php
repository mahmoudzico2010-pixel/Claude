<?php

declare(strict_types=1);

namespace App\Support\Builder;

/** Links typed into builder elements: only http(s), mailto, tel, in-page anchors and site-relative paths are ever output. */
final class SafeLink
{
    public static function href(?string $url): ?string
    {
        $url = trim((string) $url);
        if ($url === '' || preg_match('/[\x00-\x1F\x7F]/', $url)) {
            return null;
        }
        if (preg_match('#^(https?://|mailto:|tel:|/(?!/)|\#)#i', $url) !== 1) {
            return null;
        }

        return $url;
    }
}
