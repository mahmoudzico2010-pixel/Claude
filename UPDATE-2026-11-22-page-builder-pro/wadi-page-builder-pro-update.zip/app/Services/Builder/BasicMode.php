<?php

declare(strict_types=1);

namespace App\Services\Builder;

use App\Models\SiteSetting;

/** Per-page switch: show the page's original ("basic") content instead of its builder layout. The layout is never touched. */
final class BasicMode
{
    public static function isBasic(string $slug): bool
    {
        return (string) SiteSetting::get('builder.basic.'.$slug, '0') === '1';
    }

    public static function set(string $slug, bool $basic): void
    {
        SiteSetting::set('builder.basic.'.$slug, $basic ? '1' : '0', SiteSetting::TYPE_STRING, false);
    }
}
