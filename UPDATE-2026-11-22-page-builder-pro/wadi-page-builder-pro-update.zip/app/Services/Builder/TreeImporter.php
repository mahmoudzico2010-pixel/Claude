<?php

declare(strict_types=1);

namespace App\Services\Builder;

use App\Models\BuilderNode;
use App\Support\Builder\NodeSettings;
use App\Support\Builder\NodeTypes;
use Illuminate\Support\Facades\DB;
use RuntimeException;

/**
 * Builds nodes from the same array shape RevisionManager::export() writes (templates, copy/paste, saved blocks). Every setting passes
 * through the registry cleaner, every parent/child pair through the hierarchy rule, so imported content can never be something the
 * editor could not have made by hand. Media are referenced, never copied.
 */
final class TreeImporter
{
    public function __construct(private readonly TreeManager $tree) {}

    /**
     * @param  array<int, array<string, mixed>>  $items
     * @return list<int> ids of the created top-level nodes
     */
    public function import(string $pageKey, ?int $parentId, array $items, ?int $position = null): array
    {
        $parentType = $parentId ? (string) BuilderNode::query()->findOrFail($parentId)->type : null;
        $ids = [];
        DB::transaction(function () use ($pageKey, $parentId, $parentType, $items, $position, &$ids): void {
            foreach ($items as $i => $item) {
                $type = (string) ($item['type'] ?? '');
                if (! NodeTypes::exists($type)) {
                    throw new RuntimeException("Unknown element type '$type'.");
                }
                if (! NodeTypes::canContain($parentType, $type)) {
                    throw new RuntimeException("A $parentType cannot contain a $type.");
                }
                $node = $this->create($pageKey, $parentId, $item);
                $ids[] = (int) $node->id;
                if ($position !== null) {
                    $this->tree->move((int) $node->id, $parentId, $position + $i);
                }
            }
        });

        return $ids;
    }

    /** @param  array<string, mixed>  $item */
    private function create(string $pageKey, ?int $parentId, array $item): BuilderNode
    {
        $type = (string) $item['type'];
        $settings = array_merge(NodeTypes::defaults($type), (array) ($item['settings'] ?? []));
        $node = BuilderNode::create([
            'page_key' => $pageKey, 'parent_id' => $parentId, 'type' => $type,
            'sort_order' => (int) BuilderNode::query()->forPage($pageKey)->where('parent_id', $parentId)->max('sort_order') + 1,
            'is_enabled' => (bool) ($item['enabled'] ?? true),
            'settings' => NodeSettings::clean($type, $settings),
            'style' => NodeSettings::clean($type, (array) ($item['style'] ?? []), style: true),
            'responsive' => (array) ($item['responsive'] ?? []),
        ]);
        foreach ((array) ($item['translations'] ?? []) as $locale => $content) {
            if (is_array($content) && array_key_exists((string) $locale, (array) config('wadi.locales', []))) {
                $node->translations()->updateOrCreate(['locale' => (string) $locale], ['content' => $this->cleanContent($type, $content)]);
            }
        }
        foreach ((array) ($item['children'] ?? []) as $child) {
            $childType = (string) ($child['type'] ?? '');
            if (! NodeTypes::exists($childType) || ! NodeTypes::canContain($type, $childType)) {
                throw new RuntimeException("A $type cannot contain a $childType.");
            }
            $this->create($pageKey, (int) $node->id, $child);
        }

        return $node;
    }

    /** Only translatable fields, as plain strings (HTML fields are cleaned again by the renderer). @param array<string, mixed> $content */
    private function cleanContent(string $type, array $content): array
    {
        $allowed = NodeTypes::translatable($type);

        return collect($content)->only($allowed)->map(fn ($v) => is_string($v) ? mb_substr($v, 0, 20000) : '')->all();
    }
}
