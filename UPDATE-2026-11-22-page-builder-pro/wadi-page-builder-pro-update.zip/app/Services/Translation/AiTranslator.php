<?php

declare(strict_types=1);

namespace App\Services\Translation;

use Illuminate\Support\Facades\Http;
use RuntimeException;

/**
 * Machine translation of editable website texts with the Anthropic Messages API.
 *
 * Only the texts being translated leave the server (no user data, no keys). HTML tags, {placeholders}, :tokens, URLs and
 * numbers are kept as written. The result is always a draft for the editor to read before saving.
 */
final class AiTranslator
{
    public function configured(): bool
    {
        return filled(config('services.anthropic.key'));
    }

    /**
     * @param  array<string, string>  $fields  field => text in $from
     * @param  list<string>  $targets  locale codes
     * @return array<string, array<string, string>> locale => field => text
     */
    public function translate(array $fields, string $from, array $targets): array
    {
        if (! $this->configured()) {
            throw new RuntimeException(__('admin.ai.not_configured'));
        }

        $known = (array) config('wadi.locales', []);
        $targets = array_values(array_filter(array_unique($targets), fn ($l) => isset($known[$l]) && $l !== $from));
        $fields = array_filter(array_map(fn ($v) => is_string($v) ? $v : '', $fields), fn ($v) => trim(strip_tags($v)) !== '');

        if ($fields === [] || $targets === [] || ! isset($known[$from])) {
            return [];
        }
        if (count($fields) > 60 || array_sum(array_map('mb_strlen', $fields)) > 60000) {
            throw new RuntimeException(__('admin.ai.too_long'));
        }

        $names = implode(', ', array_map(fn ($l) => $l.' ('.$known[$l]['name'].')', $targets));
        $system = 'You are a professional translator for a food-export company website (olives, pickles, peppers). '
            .'Translate each value of the given JSON object from '.$known[$from]['name'].' into every requested language. '
            .'Keep HTML tags and attributes, {placeholders}, :tokens, URLs, e-mail addresses, numbers, units and brand names (e.g. "Wadi El Rayan") exactly as written. '
            .'Use natural, professional marketing language; do not add or remove information. '
            .'Reply with ONLY one JSON object: {"<locale>": {"<field>": "<translation>"}} for exactly these locales: '.$names.'.';

        $response = Http::withHeaders(['x-api-key' => (string) config('services.anthropic.key'), 'anthropic-version' => '2023-06-01'])
            ->timeout(120)->acceptJson()
            ->post('https://api.anthropic.com/v1/messages', [
                'model' => (string) config('services.anthropic.model'),
                'max_tokens' => 16000,
                'system' => $system,
                'messages' => [['role' => 'user', 'content' => json_encode($fields, JSON_UNESCAPED_UNICODE)]],
            ]);

        if (! $response->successful()) {
            throw new RuntimeException(__('admin.ai.failed', ['status' => $response->status()]));
        }

        $text = (string) data_get($response->json(), 'content.0.text', '');
        if (! preg_match('/\{.*\}/s', $text, $m)) {
            throw new RuntimeException(__('admin.ai.bad_reply'));
        }
        $decoded = json_decode($m[0], true);
        if (! is_array($decoded)) {
            throw new RuntimeException(__('admin.ai.bad_reply'));
        }

        $out = [];
        foreach ($targets as $locale) {
            foreach ($fields as $field => $_) {
                $value = $decoded[$locale][$field] ?? null;
                if (is_string($value) && trim($value) !== '') {
                    $out[$locale][$field] = mb_substr($value, 0, 20000);
                }
            }
        }

        return $out;
    }
}
