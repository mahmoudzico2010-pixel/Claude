<?php

declare(strict_types=1);

namespace App\Services\Translation;

use Illuminate\Support\Facades\Http;
use RuntimeException;

/**
 * Machine translation of editable website texts with the Anthropic Messages API.
 *
 * Only the texts being translated leave the server (no user data, no keys). HTML tags, {placeholders}, :tokens, URLs and
 * numbers are kept as written. The result is always a draft for the editor to read before saving.
 */
final class AiTranslator
{
    /** Translation always works: with an Anthropic key it uses that, otherwise the free keyless service (MyMemory). */
    public function configured(): bool
    {
        return true;
    }

    public function usesAnthropic(): bool
    {
        return filled(config('services.anthropic.key'));
    }

    /**
     * @param  array<string, string>  $fields  field => text in $from
     * @param  list<string>  $targets  locale codes
     * @return array<string, array<string, string>> locale => field => text
     */
    public function translate(array $fields, string $from, array $targets): array
    {
        $known = (array) config('wadi.locales', []);
        $targets = array_values(array_filter(array_unique($targets), fn ($l) => isset($known[$l]) && $l !== $from));
        $fields = array_filter(array_map(fn ($v) => is_string($v) ? $v : '', $fields), fn ($v) => trim(strip_tags($v)) !== '');

        if ($fields === [] || $targets === [] || ! isset($known[$from])) {
            return [];
        }
        if (count($fields) > 60 || array_sum(array_map('mb_strlen', $fields)) > 60000) {
            throw new RuntimeException(__('admin.ai.too_long'));
        }

        if (! $this->usesAnthropic()) {
            return $this->translateFree($fields, $from, $targets);
        }

        $names = implode(', ', array_map(fn ($l) => $l.' ('.$known[$l]['name'].')', $targets));
        $system = 'You are a professional translator for a food-export company website (olives, pickles, peppers). '
            .'Translate each value of the given JSON object from '.$known[$from]['name'].' into every requested language. '
            .'Keep HTML tags and attributes, {placeholders}, :tokens, URLs, e-mail addresses, numbers, units and brand names (e.g. "Wadi El Rayan") exactly as written. '
            .'Use natural, professional marketing language; do not add or remove information. '
            .'Reply with ONLY one JSON object: {"<locale>": {"<field>": "<translation>"}} for exactly these locales: '.$names.'.';

        $response = Http::withHeaders(['x-api-key' => (string) config('services.anthropic.key'), 'anthropic-version' => '2023-06-01'])
            ->timeout(120)->acceptJson()
            ->post('https://api.anthropic.com/v1/messages', [
                'model' => (string) config('services.anthropic.model'),
                'max_tokens' => 16000,
                'system' => $system,
                'messages' => [['role' => 'user', 'content' => json_encode($fields, JSON_UNESCAPED_UNICODE)]],
            ]);

        if (! $response->successful()) {
            throw new RuntimeException(__('admin.ai.failed', ['status' => $response->status()]));
        }

        $text = (string) data_get($response->json(), 'content.0.text', '');
        if (! preg_match('/\{.*\}/s', $text, $m)) {
            throw new RuntimeException(__('admin.ai.bad_reply'));
        }
        $decoded = json_decode($m[0], true);
        if (! is_array($decoded)) {
            throw new RuntimeException(__('admin.ai.bad_reply'));
        }

        $out = [];
        foreach ($targets as $locale) {
            foreach ($fields as $field => $_) {
                $value = $decoded[$locale][$field] ?? null;
                if (is_string($value) && trim($value) !== '') {
                    $out[$locale][$field] = mb_substr($value, 0, 20000);
                }
            }
        }

        return $out;
    }

    /* ------------------------------------------------------------------ free, keyless service (MyMemory) */

    private const FREE_CODES = ['zh' => 'zh-CN'];

    /**
     * @param  array<string, string>  $fields
     * @param  list<string>  $targets
     * @return array<string, array<string, string>>
     */
    private function translateFree(array $fields, string $from, array $targets): array
    {
        @set_time_limit(180);
        $calls = 0;
        $out = [];
        $cache = [];
        foreach ($targets as $locale) {
            foreach ($fields as $field => $html) {
                $parts = preg_split('/(<[^>]*>)/', $html, -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY) ?: [];
                $built = '';
                foreach ($parts as $part) {
                    if (str_starts_with($part, '<') || ! preg_match('/\p{L}/u', $part)) {
                        $built .= $part;

                        continue;
                    }
                    $key = $locale.'|'.$part;
                    $cache[$key] ??= $this->freeText($part, $from, $locale, $calls);
                    $built .= $cache[$key];
                }
                if (trim($built) !== '') {
                    $out[$locale][$field] = mb_substr($built, 0, 20000);
                }
            }
        }

        return $out;
    }

    /** One text node: protect {placeholders}/:tokens, split into <=450-char sentences, translate each. */
    private function freeText(string $text, string $from, string $to, int &$calls): string
    {
        $lead = preg_match('/^\s*/u', $text, $m) ? $m[0] : '';
        $trail = preg_match('/\s*$/u', $text, $m) ? $m[0] : '';
        $text = trim($text);
        $tokens = [];
        $text = preg_replace_callback('/\{[^}]*\}|:[a-z_]+|https?:\/\/\S+|[\w.+-]+@[\w-]+\.[\w.]+/iu', function ($m) use (&$tokens) {
            $tokens[] = $m[0];

            return 'ZX'.(count($tokens) - 1).'XZ';
        }, $text) ?? $text;

        $chunks = [];
        $cur = '';
        foreach (preg_split('/(?<=[.!?؟。])\s+/u', $text) ?: [$text] as $sentence) {
            while (mb_strlen($sentence) > 450) {
                $chunks[] = mb_substr($sentence, 0, 450);
                $sentence = mb_substr($sentence, 450);
            }
            if (mb_strlen($cur) + mb_strlen($sentence) + 1 > 450) {
                $chunks[] = $cur;
                $cur = $sentence;
            } else {
                $cur = trim($cur.' '.$sentence);
            }
        }
        if ($cur !== '') {
            $chunks[] = $cur;
        }

        $done = [];
        foreach ($chunks as $chunk) {
            if (++$calls > 400) {
                throw new RuntimeException(__('admin.ai.too_long'));
            }
            $response = Http::timeout(30)->acceptJson()->get((string) config('services.translate_free.url'), array_filter([
                'q' => $chunk,
                'langpair' => (self::FREE_CODES[$from] ?? $from).'|'.(self::FREE_CODES[$to] ?? $to),
                'de' => config('services.translate_free.email'),
            ]));
            $status = (int) $response->json('responseStatus', $response->status());
            $translated = (string) $response->json('responseData.translatedText', '');
            if ($status === 429 || ($status !== 200 && stripos((string) $response->json('responseDetails'), 'QUOTA') !== false)) {
                throw new RuntimeException(__('admin.ai.free_quota'));
            }
            if ($status !== 200 || $translated === '' || stripos($translated, 'MYMEMORY WARNING') !== false) {
                throw new RuntimeException(__('admin.ai.failed', ['status' => $status]));
            }
            $done[] = html_entity_decode($translated, ENT_QUOTES | ENT_HTML5);
        }

        $result = implode(' ', $done);
        foreach ($tokens as $i => $t) {
            $result = preg_replace('/Z\s*X\s*'.$i.'\s*X\s*Z/iu', str_replace('\\', '\\\\', $t), $result) ?? $result;
        }

        return $lead.$result.$trail;
    }
}
