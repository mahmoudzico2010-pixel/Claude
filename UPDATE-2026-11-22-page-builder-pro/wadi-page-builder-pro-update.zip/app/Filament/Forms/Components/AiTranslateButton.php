<?php

declare(strict_types=1);

namespace App\Filament\Forms\Components;

use App\Services\Translation\AiTranslator;
use Closure;
use Filament\Actions\Action;
use Filament\Forms\Components\Toggle;
use Filament\Notifications\Notification;
use Filament\Schemas\Components\Actions;
use Filament\Schemas\Components\Utilities\Get;
use Filament\Schemas\Components\Utilities\Set;
use Throwable;

/**
 * "Translate to all 10 languages" for any form. Source text = English, else the first language with text. A language box is
 * (re)filled when it is empty OR still holds an untranslated copy of the source; "replace existing" overwrites all.
 * Nothing is saved until the editor saves the form (pages with autosave pass $after to persist).
 *
 * Modes (how a language box is named):
 *  pair    `<base>_en` / `<base>_ar` columns + `extra.<locale>.<base>` for the other eight (lookup tables)
 *  dotted  `translations.<locale>.<base>`
 *  suffix  `<prefix><base>_<locale>` for every locale
 *  after   `<base>.<locale>` (page header)
 */
final class AiTranslateButton
{
    /** @param list<string> $bases */
    public static function make(array $bases, string $mode = 'pair', string $prefix = '', ?Closure $after = null): Actions
    {
        return Actions::make([
            Action::make('aiTranslate'.ucfirst($mode))
                ->label(__('admin.ai.button_all'))
                ->icon('heroicon-m-language')
                ->color('info')
                ->modalHeading(__('admin.ai.button_all'))
                ->modalDescription(__('admin.ai.confirm'))
                ->schema([Toggle::make('overwrite')->label(__('admin.ai.overwrite'))->default(false)])
                ->action(function (array $data, Get $get, Set $set, $livewire) use ($bases, $mode, $prefix, $after): void {
                    try {
                        $n = self::run($bases, $mode, $prefix, (bool) ($data['overwrite'] ?? false), fn (string $path) => $get($path), fn (string $path, string $v) => $set($path, $v));
                    } catch (Throwable $e) {
                        Notification::make()->title($e->getMessage())->danger()->send();

                        return;
                    }
                    if ($n === null) {
                        Notification::make()->title(__('admin.ai.nothing'))->warning()->send();

                        return;
                    }
                    if ($after) {
                        $after($livewire);
                    }
                    Notification::make()->title(__('admin.ai.done', ['count' => $n]))->body(__('admin.ai.review'))->success()->send();
                }),
        ])->columnSpanFull();
    }

    public static function cell(string $mode, string $prefix, string $loc, string $base): string
    {
        return match ($mode) {
            'dotted' => "translations.$loc.$base",
            'suffix' => $prefix.$base.'_'.$loc,
            'after' => "$base.$loc",
            default => in_array($loc, ['en', 'ar'], true) ? $base.'_'.$loc : "extra.$loc.$base",
        };
    }

    /** @return int|null number of cells written; null when there was nothing to translate */
    public static function run(array $bases, string $mode, string $prefix, bool $overwrite, Closure $get, Closure $set): ?int
    {
        $locales = array_keys((array) config('wadi.locales', []));
        $has = fn ($v): bool => is_string($v) && trim(strip_tags($v)) !== '';
        $translator = app(AiTranslator::class);
        $n = 0;
        $any = false;

        foreach ($bases as $b) {
            $src = in_array('en', $locales, true) && $has($get(self::cell($mode, $prefix, 'en', $b))) ? 'en'
                : collect($locales)->first(fn ($l) => $has($get(self::cell($mode, $prefix, $l, $b))));
            if ($src === null) {
                continue;
            }
            $any = true;
            $text = (string) $get(self::cell($mode, $prefix, $src, $b));
            $targets = array_values(array_filter($locales, fn ($l) => $l !== $src && ($overwrite || AiTranslator::needs($get(self::cell($mode, $prefix, $l, $b)), $text))));
            if ($targets === []) {
                continue;
            }
            foreach ($translator->translate([$b => $text], $src, $targets) as $loc => $fields) {
                if (isset($fields[$b])) {
                    $set(self::cell($mode, $prefix, $loc, $b), $fields[$b]);
                    $n++;
                }
            }
        }

        return $any ? $n : null;
    }
}
