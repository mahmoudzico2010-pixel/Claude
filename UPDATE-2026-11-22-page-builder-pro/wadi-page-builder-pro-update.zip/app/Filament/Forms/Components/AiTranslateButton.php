<?php

declare(strict_types=1);

namespace App\Filament\Forms\Components;

use App\Services\Translation\AiTranslator;
use Filament\Actions\Action;
use Filament\Notifications\Notification;
use Filament\Schemas\Components\Actions;
use Filament\Schemas\Components\Utilities\Get;
use Filament\Schemas\Components\Utilities\Set;
use Throwable;

/**
 * A "Translate with AI" button for forms with paired `<field>_en` / `<field>_ar` inputs (works inside modals as well as pages).
 * Fills only the EMPTY side from the filled one; nothing is saved until the editor saves the form.
 */
final class AiTranslateButton
{
    /** @param list<string> $bases e.g. ['title', 'body'] for title_en/title_ar and body_en/body_ar */
    public static function make(array $bases): Actions
    {
        return Actions::make([
            Action::make('aiTranslatePair')
                ->label(__('admin.ai.button'))
                ->icon('heroicon-m-language')
                ->color('info')
                ->action(function (Get $get, Set $set) use ($bases): void {
                    $translator = app(AiTranslator::class);
                    $jobs = ['en' => [], 'ar' => []];
                    foreach ($bases as $b) {
                        $en = (string) ($get($b.'_en') ?? '');
                        $ar = (string) ($get($b.'_ar') ?? '');
                        if (trim(strip_tags($en)) !== '' && trim(strip_tags($ar)) === '') {
                            $jobs['en'][$b] = $en;
                        } elseif (trim(strip_tags($ar)) !== '' && trim(strip_tags($en)) === '') {
                            $jobs['ar'][$b] = $ar;
                        }
                    }
                    if ($jobs['en'] === [] && $jobs['ar'] === []) {
                        Notification::make()->title(__('admin.ai.nothing'))->warning()->send();

                        return;
                    }
                    $n = 0;
                    try {
                        foreach (['en' => 'ar', 'ar' => 'en'] as $from => $to) {
                            foreach ($translator->translate($jobs[$from], $from, [$to])[$to] ?? [] as $field => $value) {
                                $set($field.'_'.$to, $value);
                                $n++;
                            }
                        }
                    } catch (Throwable $e) {
                        Notification::make()->title($e->getMessage())->danger()->send();

                        return;
                    }
                    Notification::make()->title(__('admin.ai.done', ['count' => $n]))->body(__('admin.ai.review'))->success()->send();
                }),
        ])->columnSpanFull();
    }
}
