<?php

declare(strict_types=1);

namespace App\Filament\Forms\Components;

use App\Services\Translation\AiTranslator;
use Filament\Actions\Action;
use Filament\Forms\Components\Toggle;
use Filament\Notifications\Notification;
use Filament\Schemas\Components\Actions;
use Filament\Schemas\Components\Utilities\Get;
use Filament\Schemas\Components\Utilities\Set;
use Throwable;

/**
 * "Translate with AI" for forms with `<field>_en` / `<field>_ar` inputs plus the extra-language boxes (`extra.<locale>.<field>`):
 * translates the source text (English, else Arabic) into ALL ten languages. Empty boxes are filled; "overwrite" replaces
 * the other languages too. Nothing is saved until the editor saves the form.
 */
final class AiTranslateButton
{
    /** @param list<string> $bases e.g. ['title', 'body'] */
    public static function make(array $bases): Actions
    {
        return Actions::make([
            Action::make('aiTranslatePair')
                ->label(__('admin.ai.button_all'))
                ->icon('heroicon-m-language')
                ->color('info')
                ->modalHeading(__('admin.ai.button_all'))
                ->modalDescription(__('admin.ai.confirm'))
                ->schema([Toggle::make('overwrite')->label(__('admin.ai.overwrite'))->default(false)])
                ->action(function (array $data, Get $get, Set $set) use ($bases): void {
                    $overwrite = (bool) ($data['overwrite'] ?? false);
                    $locales = array_keys((array) config('wadi.locales', []));
                    $cell = fn (string $loc, string $b): string => in_array($loc, ['en', 'ar'], true) ? $b.'_'.$loc : "extra.$loc.$b";
                    $has = fn ($v): bool => is_string($v) && trim(strip_tags($v)) !== '';
                    $translator = app(AiTranslator::class);
                    $n = 0;
                    $any = false;
                    try {
                        foreach ($bases as $b) {
                            $src = collect(['en', 'ar'])->first(fn ($l) => $has($get($cell($l, $b))));
                            if ($src === null) {
                                continue;
                            }
                            $any = true;
                            $targets = array_values(array_filter($locales, fn ($l) => $l !== $src && ($overwrite || ! $has($get($cell($l, $b))))));
                            foreach ($translator->translate([$b => (string) $get($cell($src, $b))], $src, $targets) as $loc => $fields) {
                                if (isset($fields[$b])) {
                                    $set($cell($loc, $b), $fields[$b]);
                                    $n++;
                                }
                            }
                        }
                    } catch (Throwable $e) {
                        Notification::make()->title($e->getMessage())->danger()->send();

                        return;
                    }
                    if (! $any) {
                        Notification::make()->title(__('admin.ai.nothing'))->warning()->send();

                        return;
                    }
                    Notification::make()->title(__('admin.ai.done', ['count' => $n]))->body(__('admin.ai.review'))->success()->send();
                }),
        ])->columnSpanFull();
    }
}
