<?php

declare(strict_types=1);

namespace App\Filament\Forms\Components;

use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Tabs;
use Filament\Schemas\Components\Tabs\Tab;

/** Edit boxes for the languages beyond English/Arabic (stored in content_translations) right inside the record's own form. */
final class ExtraLanguageFields
{
    private const LONG = ['body', 'description', 'intro', 'characteristics', 'culinary_uses', 'address'];

    /** @param list<string> $bases */
    public static function section(array $bases): Section
    {
        $locales = (array) config('wadi.locales', []);
        $tabs = [];
        foreach ($locales as $code => $meta) {
            if (in_array($code, ['en', 'ar'], true)) {
                continue;
            }
            $fields = [];
            foreach ($bases as $base) {
                $class = in_array($base, self::LONG, true) ? Textarea::class : TextInput::class;
                $field = $class::make("extra.$code.$base")
                    ->label(ucfirst(str_replace('_', ' ', $base)).' ('.($meta['native'] ?? $code).')')
                    ->afterStateHydrated(fn ($component, $record) => $component->state($record?->extraValue($code, $base)))
                    ->extraInputAttributes(['dir' => $meta['dir'] ?? 'ltr']);
                if ($class === Textarea::class) {
                    $field->rows(3);
                }
                $fields[] = $field;
            }
            $tabs[] = Tab::make(strtoupper($code))->label(($meta['native'] ?? $code))->schema($fields);
        }

        return Section::make(__('admin.ai.other_languages'))->collapsible()->collapsed()->columnSpanFull()->schema([Tabs::make('extra_languages')->tabs($tabs)]);
    }
}
