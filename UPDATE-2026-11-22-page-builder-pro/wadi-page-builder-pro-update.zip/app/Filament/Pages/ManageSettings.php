<?php

declare(strict_types=1);

namespace App\Filament\Pages;

use App\Filament\Forms\Components\MediaPicker;
use App\Models\SiteSetting;
use App\Support\Locales;
use App\Support\Permissions;
use App\Support\Theme;
use BackedEnum;
use App\Support\MaintenanceState;
use Carbon\CarbonImmutable;
use Filament\Actions\Action;
use Filament\Forms\Components\DateTimePicker;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Notifications\Notification;
use Filament\Pages\Page;
use Filament\Schemas\Components\Actions;
use Filament\Schemas\Components\EmbeddedSchema;
use Filament\Schemas\Components\Form;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Tabs;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\HtmlString;

/**
 * Single screen for every editable site-wide value.
 *
 * Groups map to the `group` column on site_settings. The sensitive groups
 * (SMTP, security, uploads) are gated on their own permission, so a Content
 * Editor can change the company address without ever seeing mail credentials.
 *
 * @property-read Schema $form
 */
class ManageSettings extends Page
{
    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedCog6Tooth;

    protected static ?int $navigationSort = 1;

    protected string $view = 'filament-panels::pages.page';

    /** @var array<string, mixed> */
    public ?array $data = [];

    public static function getNavigationGroup(): ?string
    {
        return __('nav.groups.settings');
    }

    public static function getNavigationLabel(): string
    {
        return __('admin.settings.title');
    }

    public function getTitle(): string
    {
        return __('admin.settings.title');
    }

    public static function canAccess(): bool
    {
        return Auth::user()?->can(Permissions::SETTINGS_VIEW) ?? false;
    }

    public function mount(): void
    {
        $this->form->fill($this->currentValues());
    }

    protected function canEdit(): bool
    {
        return Auth::user()?->can(Permissions::SETTINGS_UPDATE) ?? false;
    }

    protected function canEditSensitive(): bool
    {
        return Auth::user()?->can(Permissions::SETTINGS_SENSITIVE) ?? false;
    }

    /**
     * @return array<string, mixed>
     */
    protected function currentValues(): array
    {
        // Every group this form has fields for. A group missing here opened
        // empty and was written back as '' on save — which blanked the
        // homepage copy and switched the preloader off.
        $groups = ['company', 'contact', 'social', 'seo', 'analytics', 'mail', 'security', 'uploads', 'site', 'theme', 'header', 'footer'];

        $values = [];

        foreach ($groups as $group) {
            foreach (SiteSetting::group($group) as $key => $value) {
                $values[$group.'__'.$key] = $value;
            }
        }

        // A setting that has never been saved must open at its documented default, not as 'off' (the first save would store false).
        $values['site__maintenance_countdown'] ??= true;

        // Launch deadline: stored as ONE UTC instant, edited as wall-clock time in the chosen launch time zone (default Africa/Cairo).
        $values['site__maintenance_timezone'] = MaintenanceState::timezone();
        $values['site__maintenance_auto_launch'] = MaintenanceState::autoLaunch();
        $values['site__maintenance_launch_local'] = MaintenanceState::launchAt()?->setTimezone(MaintenanceState::timezone())->format('Y-m-d H:i:s');

        return $values;
    }

    public function form(Schema $schema): Schema
    {
        return $schema
            ->statePath('data')
            ->disabled(! $this->canEdit())
            ->components([
                Tabs::make()->columnSpanFull()->persistTabInQueryString()->tabs([

                    Tabs\Tab::make(__('admin.settings.company'))->schema([
                        Section::make()->columns(2)->schema([
                            TextInput::make('company__name_en')->label('Company name (English)')->maxLength(255),
                            TextInput::make('company__name_ar')->label('Company name (Arabic)')->maxLength(255),
                            TextInput::make('company__short_name_en')->label('Short name (English)')->maxLength(60),
                            TextInput::make('company__short_name_ar')->label('Short name (Arabic)')->maxLength(60),
                            Textarea::make('company__tagline_en')->label('Tagline (English)')->rows(2),
                            Textarea::make('company__tagline_ar')->label('Tagline (Arabic)')->rows(2),
                            \App\Filament\Forms\Components\AiTranslateButton::make(['tagline'], 'suffix', 'company__'),
                            Section::make('Tagline in other languages')->columnSpanFull()->columns(2)->collapsible()->collapsed()
                                ->description('Shown in the footer. Optional: a language without one shows the English tagline. Changing it means that language needs review again (System → Languages).')
                                ->schema(collect(Locales::supported())->except(['en', 'ar'])->map(
                                    fn (array $cfg, string $code) => Textarea::make('company__tagline_'.$code)->label($cfg['name'].' — '.$cfg['native'])->rows(2)
                                        ->extraInputAttributes(['dir' => $cfg['dir'], 'lang' => $code])
                                )->values()->all()),
                            MediaPicker::make('company__logo_light', 'Logo (light background)', 'branding'),
                            MediaPicker::make('company__logo_dark', 'Logo (dark background)', 'branding'),
                            MediaPicker::make('company__favicon', 'Favicon', 'branding'),
                        ]),
                    ]),

                    // The Homepage tab moved to the Homepage Manager — the one
                    // place homepage content is edited (draft → publish).

                    Tabs\Tab::make(__('admin.settings.contact'))->schema([
                        Section::make()->columns(2)->schema([
                            Textarea::make('contact__address_en')->label('Address (English)')->rows(3),
                            Textarea::make('contact__address_ar')->label('Address (Arabic)')->rows(3),
                            TextInput::make('contact__phone')->label(__('site.contact.phone'))->maxLength(60),
                            TextInput::make('contact__phone_secondary')->label('Second phone')->maxLength(60),
                            TextInput::make('contact__whatsapp')->label('WhatsApp')->maxLength(60)
                                ->helperText('International format without spaces, e.g. 201001234567.'),
                            TextInput::make('contact__email')->label(__('site.contact.email'))->email()->maxLength(255),
                            TextInput::make('contact__email_sales')->label('Sales email')->email()->maxLength(255),
                            TextInput::make('contact__working_hours_en')->label('Working hours (English)')->maxLength(255),
                            TextInput::make('contact__working_hours_ar')->label('Working hours (Arabic)')->maxLength(255),
                            Section::make('Working hours in other languages')->columnSpanFull()->columns(2)->collapsible()->collapsed()
                                ->description('Optional: a language without them shows the English hours. Changing them means that language needs review again (System → Languages).')
                                ->schema(collect(Locales::supported())->except(['en', 'ar'])->map(
                                    fn (array $cfg, string $code) => TextInput::make('contact__working_hours_'.$code)->label($cfg['name'].' — '.$cfg['native'])->maxLength(255)
                                        ->extraInputAttributes(['dir' => $cfg['dir'], 'lang' => $code])
                                )->values()->all()),
                            /*
                             | Legacy. Maps are now generated from each
                             | location's coordinates under Content →
                             | Locations, which is both easier to fill in and
                             | avoids sending an 800-character URL through a
                             | POST that a web application firewall is liable
                             | to reject.
                             |
                             | Kept because an installation may already have a
                             | value here, and the contact page still falls
                             | back to it when no location has coordinates.
                             |
                             | maxLength was 500, which is shorter than a real
                             | Google embed URL — those run 600–900 characters
                             | — so a genuine one failed validation before it
                             | ever reached the database.
                             */
                            TextInput::make('contact__map_embed')
                                ->label('Google Maps embed URL (legacy)')
                                ->maxLength(1200)
                                ->helperText('Optional. Prefer setting latitude and longitude on each location under Content → Locations.'),
                        ]),
                    ]),

                    Tabs\Tab::make(__('admin.settings.social'))->schema([
                        Section::make()->columns(2)->schema([
                            TextInput::make('social__facebook')->label('Facebook')->url()->maxLength(255),
                            TextInput::make('social__instagram')->label('Instagram')->url()->maxLength(255),
                            TextInput::make('social__linkedin')->label('LinkedIn')->url()->maxLength(255),
                            TextInput::make('social__youtube')->label('YouTube')->url()->maxLength(255),
                            TextInput::make('social__x')->label('X (Twitter)')->url()->maxLength(255),
                        ]),
                    ]),

                    Tabs\Tab::make(__('chrome.admin.header_footer'))->schema([
                        Section::make(__('chrome.admin.lang_section'))->description(__('chrome.admin.lang_help'))->columns(2)->schema([
                            Select::make('header__lang_mode')->label(__('chrome.admin.lang_mode'))->native(false)->default('horizontal')
                                ->options(['horizontal' => __('chrome.admin.mode_horizontal'), 'dropdown' => __('chrome.admin.mode_dropdown')]),
                            Section::make(__('chrome.admin.flags'))->columnSpanFull()->columns(3)->schema(
                                collect(Locales::supported())->map(fn (array $meta, string $code) => Select::make('header__flag_'.$code)
                                    ->label(($meta['native'] ?? strtoupper($code)).' ('.$code.')')
                                    ->options(fn (): array => \App\Support\Countries::options('en'))
                                    ->searchable()->native(false)->default(\App\Support\LanguagePicker::DEFAULT_FLAGS[$code] ?? null))->values()->all()
                            ),
                        ]),
                        Section::make(__('chrome.admin.dev_section'))->description(__('chrome.admin.dev_help'))->columns(2)->schema([
                            Toggle::make('footer__dev_enabled')->label(__('chrome.admin.dev_enabled'))->inline(false),
                            TextInput::make('footer__dev_name')->label(__('chrome.admin.dev_name'))->maxLength(120),
                            TextInput::make('footer__dev_url')->label(__('chrome.admin.dev_url'))->url()->maxLength(500)->placeholder('https://')
                                ->rule(fn (): \Closure => function (string $attribute, mixed $value, \Closure $fail): void {
                                    if (filled($value) && \App\Support\DeveloperCredit::safeUrl((string) $value) === null) {
                                        $fail(__('chrome.admin.dev_url_invalid'));
                                    }
                                }),
                            MediaPicker::make('footer__dev_logo', __('chrome.admin.dev_logo'), 'branding'),
                        ]),
                    ]),

                    Tabs\Tab::make(__('admin.settings.seo'))->schema([
                        Section::make()->columns(2)->schema([
                            TextInput::make('seo__title_en')->label('Default title (English)')->maxLength(255),
                            TextInput::make('seo__title_ar')->label('Default title (Arabic)')->maxLength(255),
                            Textarea::make('seo__description_en')->label('Default description (English)')->rows(3)->maxLength(500),
                            Textarea::make('seo__description_ar')->label('Default description (Arabic)')->rows(3)->maxLength(500),
                            MediaPicker::make('seo__share_image', 'Default social share image', 'branding'),
                        ]),
                        Section::make(__('admin.settings.analytics'))->columns(2)->schema([
                            TextInput::make('analytics__ga_id')->label('Google Analytics ID')->maxLength(60)
                                ->placeholder('G-XXXXXXXXXX'),
                            TextInput::make('analytics__gtm_id')->label('Google Tag Manager ID')->maxLength(60)
                                ->placeholder('GTM-XXXXXXX'),
                        ]),
                    ]),

                    // ----- Sensitive groups -------------------------------
                    Tabs\Tab::make(__('admin.settings.mail'))
                        ->visible(fn (): bool => $this->canEditSensitive())
                        ->schema([
                            Section::make()
                                ->description(__('admin.settings.mail_env_hint'))
                                ->columns(2)
                                ->schema([
                                    TextInput::make('mail__host')->label('SMTP host')->maxLength(255),
                                    TextInput::make('mail__port')->label('Port')->numeric()->default(465),
                                    TextInput::make('mail__username')->label('Username')->maxLength(255),
                                    TextInput::make('mail__password')->label('Password')->password()->revealable()
                                        ->maxLength(255)->dehydrated(fn (?string $state): bool => filled($state)),
                                    TextInput::make('mail__scheme')->label('Scheme')->placeholder('smtps')->maxLength(20),
                                    TextInput::make('mail__from_address')->label('From address')->email()->maxLength(255),
                                    TextInput::make('mail__from_name')->label('From name')->maxLength(255),
                                    TextInput::make('mail__sales_inbox')->label('Sales notification inbox')
                                        ->maxLength(500)->helperText('Comma-separated.'),
                                    TextInput::make('mail__contact_inbox')->label('Contact notification inbox')
                                        ->maxLength(500)->helperText('Comma-separated.'),
                                ]),
                        ]),

                    Tabs\Tab::make(__('admin.settings.appearance'))->schema([
                        Section::make()->schema([
                            Select::make('theme__preset')
                                ->label(__('admin.settings.theme'))
                                ->options(fn (): array => Theme::options())
                                ->default(config('wadi.themes.default', 'estate'))
                                ->native(false)
                                ->required()
                                ->helperText(__('admin.settings.theme_hint')),
                        ]),
                    ]),

                    Tabs\Tab::make(__('admin.settings.security'))
                        ->visible(fn (): bool => $this->canEditSensitive())
                        ->schema([
                            Section::make()
                                ->description(__('admin.settings.sensitive_hint'))
                                ->columns(2)
                                ->schema([
                                    TextInput::make('security__login_throttle')->label('Login attempts per minute')
                                        ->numeric()->minValue(1)->maxValue(60)->default(5),
                                    TextInput::make('security__form_throttle')->label('Form submissions per minute')
                                        ->numeric()->minValue(1)->maxValue(60)->default(5),
                                    TextInput::make('uploads__max_kb')->label('Maximum upload size (KB)')
                                        ->numeric()->minValue(256)->maxValue(102400)->default(8192)
                                        ->helperText('Cannot exceed the server upload_max_filesize.'),
                                ]),

                            // The loading animation moved to the Homepage Manager
                            // (Intro & loading), published with the homepage.

                            Section::make(__('admin.settings.maintenance'))
                                ->description(__('admin.settings.maintenance_hint'))
                                ->schema([
                                    Toggle::make('site__maintenance_mode')
                                        ->label(__('admin.settings.maintenance'))
                                        ->inline(false),
                                    MediaPicker::make('site__maintenance_logo', 'Maintenance page logo (optional — the company logo is used when empty)', 'branding'),
                                    MediaPicker::make('site__maintenance_image', 'Maintenance page image (optional — a built-in maintenance illustration is shown when empty)', 'branding'),
                                    Select::make('site__maintenance_timezone')
                                        ->label('Launch time zone')
                                        ->options(array_combine(\DateTimeZone::listIdentifiers(), \DateTimeZone::listIdentifiers()))
                                        ->searchable()->default(MaintenanceState::DEFAULT_TIMEZONE)->required()->live(),
                                    DateTimePicker::make('site__maintenance_launch_local')
                                        ->label('Launch date and time (in the zone above)')
                                        ->seconds(false)->native(false)->format('Y-m-d H:i:s')
                                        ->helperText('Optional. Drives the countdown on the maintenance page. Reaching it does NOT open the site by itself: unless you switch on the automatic launch below, the page keeps the site closed and shows the "final preparations" message. Stored as one exact moment (UTC).'),
                                    Toggle::make('site__maintenance_auto_launch')
                                        ->label('Open the site automatically when the countdown ends (Super Admin only, off by default)')
                                        ->helperText('Only a Super Admin can change this. If the automatic opening cannot be saved, the site stays closed.')
                                        ->disabled(fn (): bool => ! (Auth::user()?->isSuperAdmin() ?? false))
                                        ->default(false)->inline(false),
                                    Toggle::make('site__maintenance_countdown')
                                        ->label('Show a countdown to that moment on the maintenance page')
                                        ->default(true)->inline(false),
                                    // One tab per supported language: the notice a visitor sees is in THEIR language
                                    // (the site language of the page they asked for); a language left empty falls back to English,
                                    // then to the built-in wording.
                                    Tabs::make('maintenance_languages')->tabs(array_map(
                                        fn (string $code, array $meta): Tabs\Tab => Tabs\Tab::make($meta['native'] ?? strtoupper($code))->schema([
                                            TextInput::make("site__maintenance_title_{$code}")
                                                ->label('Heading')->maxLength(120)
                                                ->placeholder(__('site.errors.maintenance_title', [], $code)),
                                            Textarea::make("site__maintenance_message_{$code}")
                                                ->label('Notice')->rows(3)->maxLength(1000)
                                                ->placeholder(__('site.errors.maintenance_body', [], $code))
                                                ->helperText(new HtmlString('Preview the visitor page: <a href="'.e(route('maintenance.preview', ['locale' => $code, 'state' => 'countdown'])).'" target="_blank" rel="noopener" class="underline">countdown</a> · <a href="'.e(route('maintenance.preview', ['locale' => $code, 'state' => 'final'])).'" target="_blank" rel="noopener" class="underline">final preparations</a> (save first)')),
                                            Textarea::make("site__maintenance_final_{$code}")
                                                ->label('Final-preparations notice (shown when the countdown has ended but the site is still closed)')->rows(2)->maxLength(600)
                                                ->placeholder(__('site.errors.maintenance_final_body', [], $code)),
                                            TextInput::make("site__maintenance_contact_{$code}")
                                                ->label('Contact line (before the e-mail address)')->maxLength(160)
                                                ->placeholder(__('site.errors.maintenance_contact', [], $code)),
                                        ]),
                                        array_keys(Locales::supported()),
                                        array_values(Locales::supported()),
                                    ))->columnSpanFull(),
                                ]),
                        ]),
                ]),
            ]);
    }

    public function content(Schema $schema): Schema
    {
        return $schema->components([
            Form::make([EmbeddedSchema::make('form')])
                ->id('settings-form')
                ->livewireSubmitHandler('save')
                ->footer([
                    Actions::make($this->getFormActions()),
                ]),
        ]);
    }

    /** @return array<int, Action> */
    public function getFormActions(): array
    {
        return [
            Action::make('save')
                ->label(__('admin.actions.save'))
                ->submit('settings-form')
                ->keyBindings(['mod+s'])
                ->visible($this->canEdit()),
        ];
    }

    public function save(): void
    {
        if (! $this->canEdit()) {
            return;
        }

        $state = $this->form->getState();

        // Split `group__key` back into its group, and refuse to write a
        // sensitive group unless the actor holds that permission.
        $sensitiveGroups = ['mail', 'security', 'uploads', 'site'];
        $byGroup = [];

        foreach ($state as $compound => $value) {
            if (! str_contains($compound, '__')) {
                continue;
            }

            [$group, $key] = explode('__', $compound, 2);

            if (in_array($group, $sensitiveGroups, true) && ! $this->canEditSensitive()) {
                continue;
            }

            $byGroup[$group][$key] = $value;
        }

        // Virtual launch fields -> one unambiguous UTC deadline; the auto-launch opt-in belongs to Super Admins only.
        if (isset($byGroup['site'])) {
            $site = &$byGroup['site'];
            $tz = (string) ($site['maintenance_timezone'] ?? '');
            $site['maintenance_timezone'] = in_array($tz, \DateTimeZone::listIdentifiers(), true) ? $tz : MaintenanceState::DEFAULT_TIMEZONE;
            $local = trim((string) ($site['maintenance_launch_local'] ?? ''));
            $site['maintenance_launch_at'] = $local === '' ? '' : CarbonImmutable::parse($local, $site['maintenance_timezone'])->utc()->format('Y-m-d\TH:i:s\Z');
            $site['maintenance_until'] = '';        // the legacy field is superseded
            unset($site['maintenance_launch_local']);
            if (! (Auth::user()?->isSuperAdmin() ?? false)) {
                unset($site['maintenance_auto_launch']);
            }
            unset($site);
        }

        foreach ($byGroup as $group => $values) {
            SiteSetting::setMany($values, $group);
        }

        // Private groups must never be exposed through the public helper.
        SiteSetting::query()
            ->whereIn('group', ['mail', 'security'])
            ->update(['is_public' => false]);

        SiteSetting::flushCache();

        Notification::make()->success()->title(__('admin.settings.saved'))->send();
    }
}
