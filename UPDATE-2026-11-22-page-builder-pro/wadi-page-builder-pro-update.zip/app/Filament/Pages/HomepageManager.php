<?php

declare(strict_types=1);

namespace App\Filament\Pages;

use App\Filament\Forms\Components\MediaPicker;
use App\Filament\Pages\Concerns\LocalizedMediaFields;
use App\Filament\Resources\Classifications\CategoriesResource;
use App\Filament\Resources\Classifications\CertificationsResource;
use App\Filament\Resources\Classifications\ExportMarketsResource;
use App\Filament\Resources\Content\ContentBlockResource;
use App\Filament\Resources\Content\HeroSlideResource;
use App\Filament\Resources\Content\HomeSectionResource;
use App\Filament\Resources\News\NewsPostResource;
use App\Filament\Resources\Products\ProductResource;
use App\Models\BuilderRevision;
use App\Models\Category;
use App\Models\Certification;
use App\Models\ContentBlock;
use App\Models\ExportMarket;
use App\Models\HomeSection;
use App\Models\NewsPost;
use App\Models\Product;
use App\Services\Homepage\HomepageConflictException;
use App\Services\Homepage\HomepageDraft;
use App\Services\Homepage\HomepageEditor;
use App\Services\Homepage\HomepagePublisher;
use App\Services\Homepage\HomepageRepository;
use App\Services\Homepage\HomepageStatus;
use App\Services\Homepage\HomepageValidationException;
use App\Support\ContentLocales;
use App\Support\Permissions;
use BackedEnum;
use Filament\Actions\Action;
use Filament\Forms\Components\DateTimePicker;
use Filament\Forms\Components\Hidden;
use Filament\Forms\Components\Repeater;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Notifications\Notification;
use Filament\Pages\Page;
use Filament\Schemas\Components\Actions;
use Filament\Schemas\Components\EmbeddedSchema;
use Filament\Schemas\Components\Fieldset;
use Filament\Schemas\Components\Form;
use Filament\Schemas\Components\Grid;
use Filament\Schemas\Components\Html;
use Illuminate\Support\HtmlString;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Tabs;
use Filament\Schemas\Components\Tabs\Tab;
use Filament\Schemas\Components\Utilities\Get;
use Filament\Schemas\Components\View;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;
use RuntimeException;

/**
 * Homepage Manager — the one place the public homepage is edited.
 *
 * Edits the homepage DRAFT (see HomepageDraft). Nothing here changes the live
 * homepage until it is published (now or on a schedule). Shared content —
 * statistics, values, production steps, certifications, products, categories,
 * news, markets, packaging — is referenced by id; "Quick edit" edits the
 * original record (under that record's own permissions), never a copy.
 *
 * Permissions: homepage.view (open), .edit (save drafts), .media (change
 * images and videos), .preview, .schedule, .publish, .rollback.
 *
 * @property-read Schema $form
 */
class HomepageManager extends Page
{
    use LocalizedMediaFields;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedHome;

    protected static ?int $navigationSort = 1;

    protected static ?string $slug = 'homepage-manager';

    protected string $view = 'filament-panels::pages.page';

    /** @var array<string, mixed> */
    public ?array $data = [];

    public static function getNavigationGroup(): ?string
    {
        return __('nav.groups.content');
    }

    public static function getNavigationLabel(): string
    {
        return __('homepage.manager.title');
    }

    public function getTitle(): string
    {
        return __('homepage.manager.title');
    }

    public function getSubheading(): ?string
    {
        return __('homepage.manager.subtitle');
    }

    public static function canAccess(): bool
    {
        return self::may(Permissions::HOMEPAGE_VIEW);
    }

    private static function may(string $permission): bool
    {
        return Auth::user()?->can($permission) ?? false;
    }

    public function mount(): void
    {
        $this->form->fill(app(HomepageEditor::class)->load());
    }

    // ================================================================ form

    public function form(Schema $schema): Schema
    {
        $edit = self::may(Permissions::HOMEPAGE_EDIT);

        return $schema
            ->statePath('data')
            ->disabled(! $edit)
            ->components([
                Hidden::make('draft_version'),
                Tabs::make('homepage')->columnSpanFull()->persistTabInQueryString()->tabs([
                    $this->sectionsTab(),
                    $this->heroTab(),
                    $this->contentTab(),
                    $this->ctaTab(),
                    $this->introTab(),
                    $this->seoTab(),
                ]),
            ]);
    }

    /**
     * Per-locale fields in one tab per content locale (ten), each input with
     * its own text direction.
     *
     * @param  callable(string): array<int, mixed>  $fields
     */
    private function localeTabs(string $id, callable $fields): \Filament\Schemas\Components\Group
    {
        $tabs = Tabs::make($id)->tabs(
            collect(ContentLocales::all())
                ->map(fn (array $cfg, string $locale): Tab => Tab::make($id.'_'.$locale)
                    ->label($cfg['native'].' · '.strtoupper($locale))
                    ->schema(array_map(
                        fn ($field) => method_exists($field, 'extraInputAttributes')
                            ? $field->extraInputAttributes(['dir' => ContentLocales::dir($locale), 'lang' => $locale])
                            : $field,
                        $fields($locale),
                    )))
                ->values()->all()
        );

        // One "Translate to all 10 languages" button per group of fields, derived from the field names (prefix__base_locale).
        $byPrefix = [];
        $first = array_key_first(ContentLocales::all());
        foreach ($fields((string) $first) as $field) {
            if (method_exists($field, 'getName') && preg_match('/^(?:(.*__))?([a-z0-9_]+?)_'.preg_quote((string) $first, '/').'$/', (string) $field->getName(), $m)) {
                $byPrefix[(string) $m[1]][] = $m[2];
            }
        }
        $buttons = [];
        foreach ($byPrefix as $prefix => $bases) {
            $buttons[] = \App\Filament\Forms\Components\AiTranslateButton::make($bases, 'suffix', (string) $prefix);
        }

        return \Filament\Schemas\Components\Group::make([...$buttons, $tabs])->columnSpanFull();
    }

    private function text(string $base, string $locale, string $label, int $max, bool $area = false): TextInput|Textarea
    {
        $field = $area
            ? Textarea::make("home__{$base}_{$locale}")->rows(3)
            : TextInput::make("home__{$base}_{$locale}");

        return $field->label($label)->maxLength($max)
            ->helperText($locale === config('app.fallback_locale') ? null : __('homepage.manager.fallback_hint'));
    }

    private function sectionsTab(): Tab
    {
        $markup = HomeSectionResource::mayEditMarkup();
        $status = fn (): array => app(HomepageStatus::class)->sections();

        return Tab::make('sections')->id('sections')->label(__('homepage.manager.tabs.sections'))
            ->icon(Heroicon::OutlinedBars3BottomLeft)
            ->schema([
                Section::make(__('homepage.manager.sections.title'))
                    ->description(__('homepage.manager.sections.hint'))
                    ->schema([
                        Repeater::make('sections')
                            ->hiddenLabel()
                            ->reorderable()
                            ->reorderableWithDragAndDrop()
                            ->collapsible()
                            ->collapsed()
                            ->addable($markup)
                            ->addActionLabel(__('homepage.manager.sections.add_custom'))
                            // Only custom blocks can be removed (by a Super Admin);
                            // built-in sections are switched off, never deleted.
                            ->deletable($markup)
                            ->deleteAction(fn (Action $action) => $action->requiresConfirmation()
                                ->visible(fn (array $arguments, Repeater $component): bool => ($component->getState()[$arguments['item'] ?? '']['type'] ?? null) === 'html'))
                            ->itemLabel(function (array $state) use ($status): string {
                                $label = ($state['type'] ?? 'builtin') === 'html'
                                    ? (($state['t_en_heading'] ?? null) ?: __('home.untitled_block'))
                                    : __('homepage.manager.section_names.'.($state['key'] ?? ''));
                                $info = $status()[(string) ($state['id'] ?? '')] ?? null;

                                return $label.($info ? '  ·  '.__('homepage.manager.status.'.$info['status']) : '');
                            })
                            ->schema([
                                Hidden::make('id'),
                                Hidden::make('type'),
                                Hidden::make('key'),
                                Grid::make(['default' => 1, 'md' => 4])->schema([
                                    Toggle::make('is_active')->label(__('homepage.manager.sections.enabled'))->inline(false),
                                    Select::make('background')->label(__('home.fields.background'))
                                        ->options(collect(HomeSection::BACKGROUNDS)->mapWithKeys(fn ($b) => [$b => __('home.backgrounds.'.$b)])->all())
                                        ->selectablePlaceholder(false),
                                    Select::make('padding')->label(__('home.fields.padding'))
                                        ->options(collect(HomeSection::PADDINGS)->mapWithKeys(fn ($p) => [$p => __('home.paddings.'.$p)])->all())
                                        ->selectablePlaceholder(false),
                                    Toggle::make('constrain_width')->label(__('home.fields.constrain'))->inline(false),
                                ]),
                                MediaPicker::make('background_media_id', __('home.fields.background_image'), 'homepage')
                                    ->disabled(! self::may(Permissions::HOMEPAGE_MEDIA)),
                                Fieldset::make(__('homepage.manager.sections.custom_content'))
                                    ->visible(fn (Get $get): bool => $get('type') === 'html')
                                    ->disabled(! $markup)
                                    ->schema([
                                        $this->localeTabs('block', fn (string $l) => [
                                            TextInput::make("t_{$l}_heading")->label(__('home.fields.heading'))->maxLength(200),
                                            TextInput::make("t_{$l}_subheading")->label(__('home.fields.subheading'))->maxLength(400),
                                            Textarea::make("t_{$l}_html")->label(__('home.fields.html'))->rows(6),
                                        ])->columnSpanFull(),
                                        Textarea::make('css')->label(__('home.fields.css'))->rows(4)->columnSpanFull(),
                                    ]),
                                Section::make(__('home.sections.layout'))->collapsed()->compact()
                                    ->schema(HomeSectionResource::layoutFields()),
                            ]),
                    ]),
            ]);
    }

    private function heroTab(): Tab
    {
        $media = self::may(Permissions::HOMEPAGE_MEDIA);

        return Tab::make('hero')->id('hero')->label(__('homepage.manager.tabs.hero'))
            ->icon(Heroicon::OutlinedPhoto)
            ->schema([
                Section::make(__('homepage.manager.locales.hero_overview'))
                    ->description(__('homepage.manager.locales.hero_overview_hint'))
                    ->collapsible()
                    ->schema([Html::make(fn (Get $get): HtmlString => $this->heroOverview((array) $get('slides')))]),
                Section::make(__('homepage.manager.hero.slides'))
                    ->description(__('homepage.manager.hero.slides_hint'))
                    ->schema([
                        Repeater::make('slides')
                            ->hiddenLabel()
                            ->reorderable()->reorderableWithDragAndDrop()
                            ->collapsible()->collapsed()
                            ->maxItems((int) config('wadi.hero.max_slides', 30))
                            ->addActionLabel(__('homepage.manager.hero.add_slide'))
                            ->deleteAction(fn (Action $action) => $action->requiresConfirmation())
                            ->itemLabel(fn (array $state): string => ($state['t_en_title'] ?? null) ?: __('homepage.manager.hero.untitled_slide'))
                            ->schema([
                                Hidden::make('id'),
                                Grid::make(['default' => 1, 'md' => 3])->schema([
                                    Select::make('media_type')->label(__('homepage.manager.hero.media_type'))
                                        ->options(['image' => __('homepage.manager.hero.image'), 'video' => __('homepage.manager.hero.video')])
                                        ->default('image')->selectablePlaceholder(false)->live(),
                                    Toggle::make('is_active')->label(__('homepage.manager.sections.enabled'))->default(true)->inline(false),
                                    Select::make('text_alignment')->label(__('homepage.manager.hero.alignment'))
                                        ->options(['start' => __('homepage.manager.hero.align_start'), 'center' => __('homepage.manager.hero.align_center')])
                                        ->default('start')->selectablePlaceholder(false),
                                ]),
                                Grid::make(['default' => 1, 'md' => 3])->schema([
                                    MediaPicker::make('image_id', __('homepage.manager.hero.image_desktop'), 'homepage')->disabled(! $media),
                                    MediaPicker::make('image_mobile_id', __('homepage.manager.hero.image_mobile'), 'homepage')->disabled(! $media),
                                    MediaPicker::video('video_id', __('homepage.manager.hero.video'), 'homepage')->disabled(! $media)
                                        ->visible(fn (Get $get): bool => $get('media_type') === 'video'),
                                ]),
                                Grid::make(['default' => 1, 'md' => 3])->schema([
                                    TextInput::make('slide_seconds')->label(__('hero.fields.slide_seconds'))->numeric()->nullable()->minValue(2)->maxValue(600)->suffix('s')
                                        ->placeholder(fn (Get $get): string => $get('media_type') === 'video' ? __('hero.hints.slide_seconds_ph_video') : __('hero.hints.slide_seconds_ph_image'))
                                        ->helperText(fn (Get $get): string => $get('media_type') === 'video' ? __('hero.hints.slide_seconds_video') : __('hero.hints.slide_seconds_image')),
                                ]),
                                Grid::make(['default' => 1, 'md' => 3])->schema([
                                    TextInput::make('video_start')->label(__('homepage.manager.intro.start'))->numeric()->nullable()->minValue(0)->maxValue(86400)->suffix('s'),
                                    TextInput::make('video_end')->label(__('homepage.manager.intro.end'))->numeric()->nullable()->minValue(0)->maxValue(86400)->suffix('s'),
                                    Toggle::make('video_loop')->label(__('homepage.manager.intro.loop'))->default(true)->inline(false),
                                    Toggle::make('video_sound')->label(__('homepage.manager.intro.sound'))->inline(false),
                                    Toggle::make('video_sound_button')->label(__('homepage.manager.intro.sound_button'))->inline(false),
                                ])->visible(fn (Get $get): bool => $get('media_type') === 'video'),
                                $this->slideLanguageSection($media),
                                $this->localeTabs('slide', fn (string $l) => [
                                    TextInput::make("t_{$l}_eyebrow")->label(__('homepage.hero.eyebrow'))->maxLength(120),
                                    TextInput::make("t_{$l}_title")->label(__('homepage.hero.title'))->maxLength(180),
                                    Textarea::make("t_{$l}_subtitle")->label(__('homepage.hero.subtitle'))->rows(2)->maxLength(400),
                                    TextInput::make("t_{$l}_button_text")->label(__('homepage.manager.hero.button_text'))->maxLength(60),
                                    TextInput::make("t_{$l}_image_alt")->label(__('homepage.manager.hero.image_alt'))->maxLength(200),
                                ]),
                                Grid::make(['default' => 1, 'md' => 3])->schema([
                                    Select::make('button_route_name')->label(__('homepage.manager.hero.button_page'))
                                        ->options(HeroSlideResource::routeOptions())->placeholder(__('homepage.manager.hero.button_url_instead')),
                                    TextInput::make('button_url')->label(__('homepage.manager.hero.button_url'))->url()->maxLength(500),
                                    Toggle::make('button_new_tab')->label(__('homepage.manager.hero.new_tab'))->inline(false),
                                ]),
                                Grid::make(['default' => 1, 'md' => 3])->schema([
                                    TextInput::make('overlay_opacity')->label(__('homepage.manager.hero.overlay'))
                                        ->numeric()->nullable()->minValue(0)->maxValue(95)->suffix('%')->default(55),
                                    DateTimePicker::make('starts_at')->label(__('homepage.manager.schedule.starts'))->seconds(false),
                                    DateTimePicker::make('ends_at')->label(__('homepage.manager.schedule.ends'))->seconds(false)
                                        ->after('starts_at'),
                                ]),
                            ]),
                    ]),
                Section::make(__('homepage.manager.hero.fallback'))
                    ->description(__('homepage.hero.hint'))
                    ->collapsed()
                    ->schema([
                        $this->localeTabs('hero', fn (string $l) => [
                            $this->text('hero_eyebrow', $l, __('homepage.hero.eyebrow'), 120),
                            $this->text('hero_title', $l, __('homepage.hero.title'), 180),
                            $this->text('hero_subtitle', $l, __('homepage.hero.subtitle'), 400, area: true),
                        ]),
                        Grid::make(2)->schema([
                            MediaPicker::make('home__hero_image', __('homepage.hero.image'), 'homepage')->disabled(! $media),
                            MediaPicker::make('home__hero_mobile_image', __('homepage.hero.image_mobile'), 'homepage')->disabled(! $media)
                                ->helperText(__('homepage.hero.image_mobile_hint')),
                        ]),
                    ]),
            ]);
    }

    /** Headings, selection, order and limits for the shared-content sections. */
    private function contentTab(): Tab
    {
        return Tab::make('content')->id('content')->label(__('homepage.manager.tabs.content'))
            ->icon(Heroicon::OutlinedSquares2x2)
            ->schema([
                $this->sharedSection('statistics', null, ContentBlockResource::getUrl(), fn () => ContentBlock::query()->section(ContentBlock::SECTION_STATISTICS)->orderBy('display_order')->get()->mapWithKeys(fn ($b) => [$b->id => trim(($b->value_text ?? '—').' · '.($b->title_en ?? '')).($b->is_active ? '' : ' ('.__('homepage.manager.inactive').')')])->all(), ContentBlock::class),
                $this->sharedSection('categories', 'categories', CategoriesResource::getUrl(), fn () => Category::query()->withTranslation('en')->orderBy('display_order')->get()->mapWithKeys(fn ($c) => [$c->id => ($c->t('name', 'en') ?? $c->slug).($c->is_active ? '' : ' ('.__('homepage.manager.inactive').')')])->all(), Category::class),
                $this->featuredSection(),
                $this->packagingSection(),
                $this->sharedSection('values', 'values', ContentBlockResource::getUrl(), fn () => ContentBlock::query()->section(ContentBlock::SECTION_VALUES)->orderBy('display_order')->get()->mapWithKeys(fn ($b) => [$b->id => ($b->title_en ?? '#'.$b->id).($b->is_active ? '' : ' ('.__('homepage.manager.inactive').')')])->all(), ContentBlock::class),
                $this->sharedSection('production', 'production', ContentBlockResource::getUrl(), fn () => ContentBlock::query()->section(ContentBlock::SECTION_PRODUCTION)->orderBy('display_order')->get()->mapWithKeys(fn ($b) => [$b->id => ($b->title_en ?? '#'.$b->id).($b->is_active ? '' : ' ('.__('homepage.manager.inactive').')')])->all(), ContentBlock::class),
                $this->sharedSection('certifications', 'quality', CertificationsResource::getUrl(), fn () => Certification::query()->orderBy('display_order')->get()->mapWithKeys(fn ($c) => [$c->id => $c->name_en.($c->is_active ? '' : ' ('.__('homepage.manager.inactive').')').($c->logo_id || $c->document_id ? '' : ' ('.__('homepage.manager.no_evidence').')')])->all(), Certification::class),
                $this->sharedSection('markets', 'markets', ExportMarketsResource::getUrl(), fn () => ExportMarket::query()->orderBy('display_order')->get()->mapWithKeys(fn ($m) => [$m->id => $m->name_en.($m->is_active ? '' : ' ('.__('homepage.manager.inactive').')')])->all(), ExportMarket::class),
                $this->sharedSection('news', null, NewsPostResource::getUrl(), fn () => NewsPost::query()->withTranslation('en')->latest('published_at')->limit(200)->get()->mapWithKeys(fn ($n) => [$n->id => ($n->t('title', 'en') ?? $n->slug).' · '.$n->status?->value])->all(), NewsPost::class),
            ]);
    }

    /**
     * One shared-content section: optional heading/intro per locale, source
     * (automatic | hand-picked, ordered), limit, quick edit + full editor.
     *
     * @param  string|null  $textBase  settings base for title/intro (null = none)
     * @param  callable(): array<int|string, string>  $options
     * @param  class-string<Model>  $model
     */
    private function sharedSection(string $key, ?string $textBase, string $fullEditorUrl, callable $options, string $model): Section
    {
        $schema = [];

        if ($textBase !== null) {
            $schema[] = $this->localeTabs($key.'_text', fn (string $l) => [
                $this->text($textBase.'_title', $l, __('homepage.manager.content.heading'), 200),
                $this->text($textBase.'_intro', $l, __('homepage.manager.content.intro'), 600, area: true),
            ]);
        }

        if (in_array($key, HomepageEditor::PICKABLE, true)) {
            $schema[] = Grid::make(['default' => 1, 'md' => 2])->schema([
                Select::make("home__{$key}_source")->label(__('homepage.featured.source'))
                    ->options(['auto' => __('homepage.manager.content.auto'), 'manual' => __('homepage.manager.content.manual')])
                    ->default('auto')->selectablePlaceholder(false)->live(),
                array_key_exists($key, HomepageEditor::LIMITS)
                    ? TextInput::make("home__{$key}_limit")->label(__('homepage.featured.limit'))->numeric()->nullable()->minValue(1)->maxValue(48)
                        ->placeholder((string) (HomepageEditor::LIMITS[$key] ?? __('homepage.manager.content.all')))
                    : Hidden::make("home__{$key}_limit_none"),
            ]);

            $schema[] = Repeater::make("home__{$key}_items")
                ->label(__('homepage.manager.content.picked'))
                ->helperText(__('homepage.manager.content.picked_hint'))
                ->simple(Select::make('id')->options($options)->searchable()->required()->distinct())
                ->reorderable()->reorderableWithDragAndDrop()
                ->addActionLabel(__('homepage.manager.content.add_item'))
                ->extraItemActions([$this->quickEditAction($model)])
                ->visible(fn (Get $get): bool => $get("home__{$key}_source") === 'manual');
        }

        $schema[] = Actions::make([
            Action::make("full_{$key}")->label(__('homepage.manager.content.full_editor'))
                ->icon(Heroicon::OutlinedArrowTopRightOnSquare)->color('gray')->url($fullEditorUrl)->openUrlInNewTab(),
        ]);

        return Section::make(__('homepage.manager.section_names.'.$key))
            ->collapsed()
            ->schema($schema);
    }

    private function featuredSection(): Section
    {
        return Section::make(__('homepage.manager.section_names.featured'))->collapsed()->schema([
            $this->localeTabs('featured_text', fn (string $l) => [
                $this->text('featured_title', $l, __('homepage.manager.content.heading'), 200),
            ]),
            Grid::make(['default' => 1, 'md' => 2])->schema([
                Select::make('home__featured_source')->label(__('homepage.featured.source'))
                    ->options(['auto' => __('homepage.featured.source_auto'), 'manual' => __('homepage.featured.source_manual')])
                    ->default('auto')->selectablePlaceholder(false)->live(),
                TextInput::make('home__featured_limit')->label(__('homepage.featured.limit'))->numeric()->nullable()->minValue(1)->maxValue(12),
            ]),
            Repeater::make('home__featured_products')
                ->label(__('homepage.featured.products'))
                ->helperText(__('homepage.featured.products_hint'))
                ->simple(Select::make('id')->searchable()->required()->distinct()->options(fn () => Product::query()->withTranslation('en')->orderBy('display_order')->get()->mapWithKeys(fn ($p) => [$p->id => ($p->t('name', 'en') ?? $p->slug).' · '.$p->status?->value])->all()))
                ->reorderable()->reorderableWithDragAndDrop()
                ->addActionLabel(__('homepage.manager.content.add_item'))
                ->visible(fn (Get $get): bool => $get('home__featured_source') === 'manual'),
            MediaPicker::make('home__product_fallback_image', __('homepage.featured.fallback'), 'homepage')
                ->helperText(__('homepage.featured.fallback_hint'))
                ->disabled(! self::may(Permissions::HOMEPAGE_MEDIA)),
            Actions::make([
                Action::make('full_products')->label(__('homepage.manager.content.full_editor'))
                    ->icon(Heroicon::OutlinedArrowTopRightOnSquare)->color('gray')->url(ProductResource::getUrl())->openUrlInNewTab(),
            ]),
        ]);
    }

    private function packagingSection(): Section
    {
        return Section::make(__('homepage.manager.section_names.packaging'))->collapsed()
            ->description(__('homepage.manager.content.packaging_hint'))
            ->schema([
                $this->localeTabs('packaging_text', fn (string $l) => [
                    $this->text('packaging_title', $l, __('homepage.manager.content.heading'), 200),
                    $this->text('packaging_intro', $l, __('homepage.manager.content.intro'), 600, area: true),
                ]),
                TextInput::make('home__packaging_limit')->label(__('homepage.featured.limit'))->numeric()->nullable()->minValue(1)->maxValue(12)->placeholder('6'),
            ]);
    }

    /**
     * Edit the ORIGINAL record behind a picked id, under its own policy.
     *
     * @param  class-string<Model>  $model
     */
    private function quickEditAction(string $model): Action
    {
        return Action::make('quickEdit')
            ->label(__('homepage.manager.content.quick_edit'))
            ->icon(Heroicon::OutlinedPencilSquare)
            ->modalHeading(__('homepage.manager.content.quick_edit'))
            ->modalDescription(__('homepage.manager.content.quick_edit_hint'))
            ->visible(fn (array $arguments, Repeater $component): bool => ($record = $this->pickedRecord($model, $arguments, $component)) !== null && Gate::allows('update', $record))
            ->fillForm(fn (array $arguments, Repeater $component): array => $this->pickedRecord($model, $arguments, $component)?->only($this->quickEditFields($model)) ?? [])
            ->schema(fn (): array => $this->quickEditSchema($model))
            ->action(function (array $data, array $arguments, Repeater $component) use ($model): void {
                $record = $this->pickedRecord($model, $arguments, $component);
                abort_unless($record !== null && Gate::allows('update', $record), 403);
                $record->update(array_intersect_key($data, array_flip($this->quickEditFields($model))));
                Notification::make()->success()->title(__('homepage.manager.content.quick_saved'))->send();
            });
    }

    /** @param  class-string<Model>  $model */
    private function pickedRecord(string $model, array $arguments, Repeater $component): ?Model
    {
        $id = $component->getState()[$arguments['item'] ?? ''] ?? null;
        $id = is_array($id) ? ($id['id'] ?? null) : $id;

        return filled($id) ? $model::query()->find((int) $id) : null;
    }

    /** @return list<string> */
    private function quickEditFields(string $model): array
    {
        return match ($model) {
            ContentBlock::class => ['value_text', 'value_suffix_en', 'value_suffix_ar', 'title_en', 'title_ar', 'body_en', 'body_ar', 'is_active'],
            Certification::class => ['name_en', 'name_ar', 'is_active'],
            ExportMarket::class => ['name_en', 'name_ar', 'is_active'],
            Category::class => ['is_active'],
            default => [],
        };
    }

    /** @return array<int, mixed> */
    private function quickEditSchema(string $model): array
    {
        $fields = [];
        foreach ($this->quickEditFields($model) as $field) {
            $fields[] = match (true) {
                $field === 'is_active' => Toggle::make($field)->label(__('admin.fields.is_active')),
                str_starts_with($field, 'body') => Textarea::make($field)->label(__('homepage.manager.quick.'.$field))->rows(3)
                    ->extraInputAttributes(['dir' => str_ends_with($field, '_ar') ? 'rtl' : 'ltr']),
                default => TextInput::make($field)->label(__('homepage.manager.quick.'.$field))->maxLength(255)
                    ->extraInputAttributes(['dir' => str_ends_with($field, '_ar') ? 'rtl' : 'ltr']),
            };
        }

        if ($model === Category::class || $fields === []) {
            $fields[] = View::make('filament.pages.homepage-manager.full-editor-note');
        }

        return $fields;
    }

    private function ctaTab(): Tab
    {
        return Tab::make('cta')->id('cta')->label(__('homepage.manager.tabs.cta'))
            ->icon(Heroicon::OutlinedMegaphone)
            ->schema([
                Section::make()->schema([
                    $this->localeTabs('cta', fn (string $l) => [
                        $this->text('cta_title', $l, __('homepage.cta.heading'), 200),
                        $this->text('cta_body', $l, __('homepage.cta.body'), 600, area: true),
                    ]),
                ]),
            ]);
    }

    private function introTab(): Tab
    {
        $media = self::may(Permissions::HOMEPAGE_MEDIA);

        return Tab::make('intro')->id('intro')->label(__('homepage.manager.tabs.intro'))
            ->icon(Heroicon::OutlinedFilm)
            ->schema([
                Section::make(__('homepage.manager.intro.title'))
                    ->description(__('homepage.manager.intro.hint'))
                    ->schema([
                        Toggle::make('home__intro_enabled')->label(__('homepage.manager.intro.enabled'))->live(),
                        Grid::make(['default' => 1, 'md' => 3])->schema([
                            MediaPicker::video('home__intro_video', __('homepage.manager.intro.video'), 'homepage')->disabled(! $media)
                                ->required(fn (Get $get): bool => (bool) $get('home__intro_enabled')),
                            MediaPicker::make('home__intro_video_mobile', __('homepage.manager.intro.mobile'), 'homepage', 'any')->disabled(! $media)
                                ->helperText(__('homepage.manager.intro.mobile_hint')),
                            MediaPicker::make('home__intro_poster', __('homepage.manager.intro.poster'), 'homepage')->disabled(! $media)
                                ->helperText(__('homepage.manager.intro.poster_hint')),
                        ]),
                        Grid::make(['default' => 1, 'md' => 4])->schema([
                            TextInput::make('home__intro_max_seconds')->label(__('homepage.manager.intro.max'))
                                ->numeric()->nullable()->minValue(2)->maxValue(3600)->suffix('s')
                                ->helperText(__('homepage.manager.intro.max_hint')),
                            Select::make('home__intro_frequency')->label(__('homepage.manager.intro.frequency'))
                                ->options(['session' => __('homepage.manager.intro.once_per_session'), 'always' => __('homepage.manager.intro.every_visit')])
                                ->default('session')->selectablePlaceholder(false),
                            DateTimePicker::make('home__intro_starts_at')->label(__('homepage.manager.schedule.starts'))->seconds(false),
                            DateTimePicker::make('home__intro_ends_at')->label(__('homepage.manager.schedule.ends'))->seconds(false)->after('home__intro_starts_at'),
                        ]),
                        Grid::make(['default' => 1, 'md' => 3])->schema([
                            Toggle::make('home__intro_sound')->label(__('homepage.manager.intro.sound'))
                                ->helperText(__('homepage.manager.intro.sound_hint')),
                            Toggle::make('home__intro_sound_button')->label(__('homepage.manager.intro.sound_button')),
                            Toggle::make('home__intro_loop')->label(__('homepage.manager.intro.loop')),
                        ]),
                        Grid::make(['default' => 1, 'md' => 2])->schema([
                            TextInput::make('home__intro_start')->label(__('homepage.manager.intro.start'))
                                ->numeric()->nullable()->minValue(0)->maxValue(86400)->suffix('s')
                                ->helperText(__('homepage.manager.intro.range_hint')),
                            TextInput::make('home__intro_end')->label(__('homepage.manager.intro.end'))
                                ->numeric()->nullable()->minValue(0)->maxValue(86400)->suffix('s'),
                        ]),
                        $this->localeTabs('intro_skip', fn (string $l) => [
                            $this->text('intro_skip_label', $l, __('homepage.manager.intro.skip'), 40),
                        ]),
                    ]),
                $this->introLanguageSection($media),
                Section::make(__('homepage.manager.intro.loading'))
                    ->description(__('homepage.manager.intro.loading_hint'))
                    ->schema([
                        Toggle::make('appearance__preloader_enabled')->label(__('homepage.manager.intro.loading_enabled')),
                    ]),
            ]);
    }

    private function seoTab(): Tab
    {
        return Tab::make('seo')->id('seo')->label(__('homepage.manager.tabs.seo'))
            ->icon(Heroicon::OutlinedMagnifyingGlass)
            ->schema([
                Section::make()->description(__('homepage.seo.hint'))->schema([
                    $this->localeTabs('seo', fn (string $l) => [
                        $this->text('seo_title', $l, __('homepage.seo.title'), 70),
                        $this->text('seo_description', $l, __('homepage.seo.description'), 180, area: true),
                    ]),
                    MediaPicker::make('home__seo_image', __('homepage.seo.image'), 'homepage')
                        ->helperText(__('homepage.seo.image_hint'))
                        ->disabled(! self::may(Permissions::HOMEPAGE_MEDIA)),
                ]),
            ]);
    }

    // ============================================================ layout

    public function content(Schema $schema): Schema
    {
        return $schema->components([
            View::make('filament.pages.homepage-manager.status')
                ->viewData(fn (): array => ['status' => app(HomepageStatus::class)->summary()]),
            Form::make([EmbeddedSchema::make('form')])
                ->id('homepage-form')
                ->livewireSubmitHandler('save')
                ->footer([Actions::make([
                    Action::make('save')->label(__('homepage.manager.save_draft'))
                        ->submit('homepage-form')->keyBindings(['mod+s'])
                        ->visible(self::may(Permissions::HOMEPAGE_EDIT)),
                ])]),
        ]);
    }

    /** @return array<int, Action> */
    protected function getHeaderActions(): array
    {
        return [
            Action::make('preview')
                ->label(__('homepage.manager.preview'))
                ->icon(Heroicon::OutlinedEye)
                ->color('gray')
                ->visible(self::may(Permissions::HOMEPAGE_PREVIEW))
                ->modalHeading(__('homepage.manager.preview_heading'))
                ->modalWidth('screen')
                ->modalSubmitAction(false)
                ->modalCancelActionLabel(__('homepage.manager.close'))
                // The preview shows the saved draft: save what is on screen first.
                ->mountUsing(fn () => $this->saveIfAllowed())
                ->modalContent(fn () => view('filament.pages.homepage-manager.preview', [
                    'url' => route('admin.homepage.preview'),
                    'locales' => ContentLocales::all(),
                ])),

            Action::make('history')
                ->label(__('homepage.manager.history'))
                ->icon(Heroicon::OutlinedClock)
                ->color('gray')
                ->slideOver()
                ->modalSubmitAction(false)
                ->modalCancelActionLabel(__('homepage.manager.close'))
                ->modalContent(fn () => view('filament.pages.homepage-manager.history', [
                    'revisions' => BuilderRevision::query()->where('page_key', HomepageRepository::PAGE_KEY)
                        ->with('author')->orderByDesc('id')->limit(30)->get(),
                    'canPreview' => self::may(Permissions::HOMEPAGE_PREVIEW),
                    'liveId' => app(HomepageRepository::class)->liveRevisionId(),
                ])),

            Action::make('schedule')
                ->label(__('homepage.manager.schedule.action'))
                ->icon(Heroicon::OutlinedCalendarDays)
                ->color('gray')
                ->visible(self::may(Permissions::HOMEPAGE_SCHEDULE))
                ->schema([
                    DateTimePicker::make('at')->label(__('homepage.manager.schedule.at'))->seconds(false)->required()
                        ->minDate(now())->helperText(__('homepage.manager.schedule.timezone', ['tz' => config('app.timezone')])),
                    TextInput::make('label')->label(__('homepage.manager.version_label'))->maxLength(120),
                ])
                ->modalDescription(__('homepage.manager.schedule.hint'))
                ->action(function (array $data): void {
                    if (! $this->saveIfAllowed()) {
                        return;
                    }
                    abort_unless(self::may(Permissions::HOMEPAGE_SCHEDULE), 403);
                    $this->runPublishing(fn () => app(HomepagePublisher::class)->schedule(Carbon::parse($data['at']), $data['label'] ?? null),
                        __('homepage.manager.schedule.done', ['at' => Carbon::parse($data['at'])->format('Y-m-d H:i')]));
                }),

            Action::make('rollback')
                ->label(__('homepage.manager.rollback'))
                ->icon(Heroicon::OutlinedArrowUturnLeft)
                ->color('warning')
                ->visible(self::may(Permissions::HOMEPAGE_ROLLBACK) && app(HomepageRepository::class)->isAdopted())
                ->requiresConfirmation()
                ->modalDescription(fn (): string => __('homepage.manager.rollback_confirm', ['version' => $this->previousVersion() ?? '—']))
                ->action(function (): void {
                    abort_unless(self::may(Permissions::HOMEPAGE_ROLLBACK), 403);
                    $this->runPublishing(fn () => app(HomepagePublisher::class)->rollback(), __('homepage.manager.rolled_back'));
                }),

            Action::make('publish')
                ->label(__('homepage.manager.publish'))
                ->icon(Heroicon::OutlinedRocketLaunch)
                ->visible(self::may(Permissions::HOMEPAGE_PUBLISH))
                ->requiresConfirmation()
                ->modalHeading(__('homepage.manager.publish_heading'))
                ->modalDescription(fn (): string => __('homepage.manager.publish_confirm'))
                ->schema([TextInput::make('label')->label(__('homepage.manager.version_label'))->maxLength(120)])
                ->action(function (array $data): void {
                    if (! $this->saveIfAllowed()) {
                        return;
                    }
                    abort_unless(self::may(Permissions::HOMEPAGE_PUBLISH), 403);
                    $this->runPublishing(fn () => app(HomepagePublisher::class)->publish($data['label'] ?? null), __('homepage.manager.published'));
                }),
        ];
    }

    // ============================================================ actions

    public function save(): void
    {
        $this->saveIfAllowed(notify: true);
    }

    /**
     * Save the draft as edited on screen. Publishing first saves, so what is
     * published is exactly what is on screen.
     */
    private function saveIfAllowed(bool $notify = false): bool
    {
        if (! self::may(Permissions::HOMEPAGE_EDIT)) {
            return true; // nothing on screen can differ from the stored draft
        }

        $state = $this->form->getState();

        try {
            app(HomepageEditor::class)->save($state, (int) ($this->data['draft_version'] ?? 0), [
                'media' => self::may(Permissions::HOMEPAGE_MEDIA),
                'markup' => HomeSectionResource::mayEditMarkup(),
            ]);
        } catch (HomepageConflictException) {
            Notification::make()->danger()->persistent()
                ->title(__('homepage.manager.conflict'))
                ->body(__('homepage.manager.conflict_body'))
                ->send();

            return false;
        }

        $this->form->fill(app(HomepageEditor::class)->load());

        if ($notify) {
            Notification::make()->success()->title(__('homepage.manager.saved'))->send();
        }

        return true;
    }

    private function runPublishing(callable $operation, string $success): void
    {
        try {
            $operation();
        } catch (HomepageValidationException $e) {
            Notification::make()->danger()->persistent()
                ->title(__('homepage.manager.invalid'))
                ->body(implode("\n", $e->errors))
                ->send();

            return;
        } catch (RuntimeException $e) {
            Notification::make()->danger()->title($e->getMessage())->send();

            return;
        }

        Notification::make()->success()->title($success)->send();
    }

    public function cancelSchedule(int $revisionId): void
    {
        abort_unless(self::may(Permissions::HOMEPAGE_SCHEDULE), 403);
        $this->runPublishing(fn () => app(HomepagePublisher::class)->cancelScheduled($revisionId), __('homepage.manager.schedule.cancelled'));
    }

    private function previousVersion(): ?int
    {
        return BuilderRevision::query()->where('page_key', HomepageRepository::PAGE_KEY)
            ->where('kind', HomepageRepository::PUBLISHED)
            ->orderByDesc('version')->skip(1)->value('version');
    }
}
