<?php

declare(strict_types=1);

namespace App\Filament\Resources\Company;

use App\Filament\Resources\Company\Pages\CreateCompanyLocation;
use App\Filament\Resources\Company\Pages\EditCompanyLocation;
use App\Filament\Resources\Company\Pages\ListCompanyLocations;
use App\Models\CompanyLocation;
use App\Support\Permissions;
use BackedEnum;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteAction;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Columns\ToggleColumn;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Table;
use Illuminate\Support\Facades\Auth;

class CompanyLocationResource extends Resource
{
    protected static ?string $model = CompanyLocation::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedMapPin;

    protected static ?int $navigationSort = 1;

    public static function getNavigationGroup(): ?string
    {
        return __('nav.groups.company');
    }

    public static function getModelLabel(): string
    {
        return __('locations.resource.label');
    }

    public static function getPluralModelLabel(): string
    {
        return __('locations.resource.plural');
    }

    public static function canAccess(): bool
    {
        return Auth::user()?->can(Permissions::CONTENT_VIEW) ?? false;
    }

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            \App\Filament\Forms\Components\AiTranslateButton::make(['name', 'address']),

            Section::make(__('locations.sections.identity'))
                ->columns(2)
                ->schema([
                    TextInput::make('name_en')
                        ->label(__('locations.fields.name_en'))
                        ->required()
                        ->maxLength(255),

                    TextInput::make('name_ar')
                        ->label(__('locations.fields.name_ar'))
                        ->maxLength(255),

                    Select::make('type')
                        ->label(__('locations.fields.type'))
                        ->options(static::typeOptions())
                        ->default('branch')
                        ->required()
                        ->native(false),

                    TextInput::make('display_order')
                        ->label(__('admin.fields.display_order'))
                        ->numeric()
                        ->default(0),
                ]),

            Section::make(__('locations.sections.address'))
                ->columns(2)
                ->schema([
                    Textarea::make('address_en')
                        ->label(__('locations.fields.address_en'))
                        ->rows(3)
                        ->maxLength(1000),

                    Textarea::make('address_ar')
                        ->label(__('locations.fields.address_ar'))
                        ->rows(3)
                        ->maxLength(1000),

                    TextInput::make('city')->label(__('locations.fields.city'))->maxLength(100),
                    TextInput::make('country')->label(__('locations.fields.country'))->maxLength(100),
                    TextInput::make('postal_code')->label(__('locations.fields.postal_code'))->maxLength(20),
                ]),

            Section::make(__('locations.sections.contact'))
                ->columns(3)
                ->schema([
                    TextInput::make('phone')->label(__('locations.fields.phone'))->tel()->maxLength(40),
                    TextInput::make('mobile')->label(__('locations.fields.mobile'))->tel()->maxLength(40),
                    TextInput::make('email')->label(__('locations.fields.email'))->email()->maxLength(255),
                ]),

            Section::make(__('locations.sections.map'))
                ->description(__('locations.hints.map'))
                ->columns(2)
                ->schema([
                    // Bounded rather than free numerics: a longitude of 500 is
                    // a typo, and the resulting map pin lands in the ocean
                    // without anything having reported an error.
                    TextInput::make('latitude')
                        ->label(__('locations.fields.latitude'))
                        ->numeric()
                        ->minValue(-90)
                        ->maxValue(90)
                        ->step('0.0000001')
                        ->helperText('-90 … 90'),

                    TextInput::make('longitude')
                        ->label(__('locations.fields.longitude'))
                        ->numeric()
                        ->minValue(-180)
                        ->maxValue(180)
                        ->step('0.0000001')
                        ->helperText('-180 … 180'),

                    TextInput::make('maps_url')
                        ->label(__('locations.fields.maps_url'))
                        ->url()
                        ->maxLength(500)
                        ->helperText(__('locations.hints.maps_url'))
                        ->columnSpanFull(),
                ]),

            Section::make()
                ->columns(2)
                ->schema([
                    Toggle::make('is_active')
                        ->label(__('admin.fields.is_active'))
                        ->default(true)
                        ->inline(false),

                    Toggle::make('is_primary')
                        ->label(__('locations.fields.is_primary'))
                        ->inline(false)
                        ->helperText(__('locations.hints.is_primary')),
                ]),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->defaultSort('display_order')
            ->reorderable('display_order')
            ->columns([
                TextColumn::make('name_en')
                    ->label(__('locations.fields.name'))
                    ->getStateUsing(fn (CompanyLocation $record): ?string => $record->localized('name'))
                    ->description(fn (CompanyLocation $record): ?string => $record->singleLineAddress())
                    ->weight('medium')
                    ->searchable(['name_en', 'name_ar', 'city'])
                    ->wrap(),

                TextColumn::make('type')
                    ->label(__('locations.fields.type'))
                    ->badge()
                    ->color('gray')
                    ->formatStateUsing(fn (CompanyLocation $record): string => $record->typeLabel()),

                TextColumn::make('city')
                    ->label(__('locations.fields.city'))
                    ->toggleable(),

                TextColumn::make('phone')
                    ->label(__('locations.fields.phone'))
                    ->toggleable(),

                IconColumn::make('is_primary')
                    ->label(__('locations.fields.is_primary'))
                    ->boolean(),

                ToggleColumn::make('is_active')
                    ->label(__('admin.fields.is_active'))
                    ->disabled(fn (): bool => ! (Auth::user()?->can(Permissions::CONTENT_MANAGE) ?? false)),
            ])
            ->filters([
                SelectFilter::make('type')
                    ->label(__('locations.fields.type'))
                    ->options(static::typeOptions()),
            ])
            ->recordActions([
                EditAction::make(),
                DeleteAction::make(),
            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ])
            ->emptyStateHeading(__('locations.empty.heading'))
            ->emptyStateDescription(__('locations.empty.description'));
    }

    /**
     * @return array<string, string>
     */
    public static function typeOptions(): array
    {
        $options = [];

        foreach ((array) config('wadi.locations.types', []) as $type) {
            $options[$type] = __('locations.types.'.$type);
        }

        return $options;
    }

    public static function getPages(): array
    {
        return [
            'index' => ListCompanyLocations::route('/'),
            'create' => CreateCompanyLocation::route('/create'),
            'edit' => EditCompanyLocation::route('/{record}/edit'),
        ];
    }
}
