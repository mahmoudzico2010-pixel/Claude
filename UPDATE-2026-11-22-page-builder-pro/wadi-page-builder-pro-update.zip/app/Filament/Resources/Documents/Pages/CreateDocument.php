<?php

declare(strict_types=1);

namespace App\Filament\Resources\Documents\Pages;

use App\Filament\Concerns\HandlesTranslations;
use App\Filament\Resources\Documents\DocumentResource;
use Filament\Resources\Pages\CreateRecord;
use Illuminate\Support\Str;

class CreateDocument extends CreateRecord
{
    use \App\Filament\Concerns\OffersAiTranslation;
    use HandlesTranslations;

    protected function getHeaderActions(): array
    {
        return [$this->aiTranslateAction()];
    }

    protected static string $resource = DocumentResource::class;

    /**
     * @param  array<string, mixed>  $data
     * @return array<string, mixed>
     */
    protected function mutateFormDataBeforeCreate(array $data): array
    {
        $data = $this->deriveSlug($data);

        return $this->extractTranslations($data);
    }

    /**
     * A readable slug from the English title, when one was not typed.
     *
     * Done here rather than in the form so it reflects whatever the title
     * ended up being, including a title typed after the slug field was passed.
     *
     * @param  array<string, mixed>  $data
     * @return array<string, mixed>
     */
    private function deriveSlug(array $data): array
    {
        $title = $data['translations']['en']['title'] ?? null;

        if (! is_string($title) || trim($title) === '') {
            return $data;
        }

        $current = (string) ($data['slug'] ?? '');

        // Only replace the generated placeholder, never a slug someone chose.
        if ($current !== '' && ! str_starts_with($current, 'document-')) {
            return $data;
        }

        $data['slug'] = Str::slug($title) ?: $current;

        return $data;
    }
}
