<?php

declare(strict_types=1);

namespace App\Filament\Resources\Products\Pages;

use App\Filament\Concerns\HandlesTranslations;
use App\Filament\Resources\Products\ProductResource;
use App\Filament\Support\CatalogMatrixForm;
use Filament\Notifications\Notification;
use Filament\Resources\Pages\CreateRecord;
use Illuminate\Support\Facades\Auth;

class CreateProduct extends CreateRecord
{
    use \App\Filament\Concerns\OffersAiTranslation;
    use HandlesTranslations;

    protected function getHeaderActions(): array
    {
        return [$this->aiTranslateAction()];
    }

    protected static string $resource = ProductResource::class;

    /**
     * @param  array<string, mixed>  $data
     * @return array<string, mixed>
     */
    protected function mutateFormDataBeforeCreate(array $data): array
    {
        $data['created_by'] = Auth::id();
        $data['updated_by'] = Auth::id();
        [$data, $this->matrixState] = CatalogMatrixForm::split($data);

        return $this->extractTranslations($data);
    }

    /** @var array<string, mixed> */
    protected array $matrixState = [];

    protected function afterCreate(): void
    {
        $r = CatalogMatrixForm::apply($this->getRecord()->refresh(), $this->matrixState);
        if ($r !== null && ($r['created'] + $r['restored'] + $r['archived']) > 0) {
            Notification::make()->success()->title(__('catalog.matrix.applied', $r))->send();
        }
    }

    protected function getRedirectUrl(): string
    {
        return $this->getResource()::getUrl('edit', ['record' => $this->getRecord()]);
    }
}
