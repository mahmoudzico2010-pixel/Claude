<?php

declare(strict_types=1);

namespace App\Filament\Resources\Products\Pages;

use App\Filament\Concerns\HandlesTranslations;
use App\Filament\Resources\Products\ProductResource;
use App\Filament\Support\CatalogMatrixForm;
use Filament\Notifications\Notification;
use Filament\Actions\DeleteAction;
use Filament\Actions\ForceDeleteAction;
use Filament\Actions\RestoreAction;
use Filament\Resources\Pages\EditRecord;
use Illuminate\Support\Facades\Auth;

class EditProduct extends EditRecord
{
    use \App\Filament\Concerns\OffersAiTranslation;
    use HandlesTranslations {
        mutateFormDataBeforeFill as private fillTranslations;
    }

    protected static string $resource = ProductResource::class;

    protected function getHeaderActions(): array
    {
        return [
            $this->aiTranslateAction(),
            DeleteAction::make()->label(__('admin.product.archive')),
            RestoreAction::make(),
            ForceDeleteAction::make(),
        ];
    }

    /**
     * @param  array<string, mixed>  $data
     * @return array<string, mixed>
     */
    protected function mutateFormDataBeforeSave(array $data): array
    {
        $data['updated_by'] = Auth::id();
        [$data, $this->matrixState] = CatalogMatrixForm::split($data);

        return $this->extractTranslations($data);
    }

    /** @var array<string, mixed> */
    protected array $matrixState = [];

    protected function mutateFormDataBeforeFill(array $data): array
    {
        return $this->fillTranslations($data) + CatalogMatrixForm::stateFor($this->getRecord());
    }

    protected function afterSave(): void
    {
        $r = CatalogMatrixForm::apply($this->getRecord()->refresh(), $this->matrixState);
        if ($r !== null && ($r['created'] + $r['restored'] + $r['archived']) > 0) {
            Notification::make()->success()->title(__('catalog.matrix.applied', $r))->send();
        }
    }
}
