<?php

declare(strict_types=1);

namespace App\Filament\Resources\Classifications\Pages;

use App\Filament\Concerns\HandlesTranslations;
use App\Filament\Resources\Classifications\CategoriesResource;
use Filament\Resources\Pages\CreateRecord;

class CreateCategory extends CreateRecord
{
    use \App\Filament\Concerns\OffersAiTranslation;
    use HandlesTranslations;

    protected function getHeaderActions(): array
    {
        return [$this->aiTranslateAction()];
    }

    protected static string $resource = CategoriesResource::class;
}
