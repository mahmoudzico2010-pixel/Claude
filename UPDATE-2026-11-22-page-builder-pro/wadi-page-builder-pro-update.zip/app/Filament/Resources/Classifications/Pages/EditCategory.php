<?php

declare(strict_types=1);

namespace App\Filament\Resources\Classifications\Pages;

use App\Filament\Concerns\HandlesTranslations;
use App\Filament\Resources\Classifications\CategoriesResource;
use Filament\Actions\DeleteAction;
use Filament\Resources\Pages\EditRecord;

class EditCategory extends EditRecord
{
    use \App\Filament\Concerns\OffersAiTranslation;
    use HandlesTranslations;

    protected static string $resource = CategoriesResource::class;

    protected function getHeaderActions(): array
    {
        return [
            $this->aiTranslateAction(),DeleteAction::make()];
    }
}
