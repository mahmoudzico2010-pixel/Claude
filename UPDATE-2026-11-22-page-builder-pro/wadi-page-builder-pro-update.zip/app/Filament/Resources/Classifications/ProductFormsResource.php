<?php

declare(strict_types=1);

namespace App\Filament\Resources\Classifications;

use App\Filament\Resources\Classifications\Pages\ManageProductForms;
use App\Models\ProductForm;
use BackedEnum;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteAction;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

/**
 * Managed on a single screen: these lists are short and are edited in modals
 * rather than through separate create and edit pages.
 */
class ProductFormsResource extends Resource
{
    protected static ?string $model = ProductForm::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedSquares2x2;

    protected static ?int $navigationSort = 4;

    public static function getNavigationGroup(): ?string
    {
        return __('nav.groups.catalogue');
    }

    public static function getModelLabel(): string
    {
        return __('admin.resources.product_form.label');
    }

    public static function getPluralModelLabel(): string
    {
        return __('admin.resources.product_form.plural');
    }

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            \App\Filament\Forms\Components\AiTranslateButton::make(['name']),
            Section::make()->columns(2)->schema([
                TextInput::make('name_en')
                    ->label(__('admin.fields.name_en'))
                    ->required()
                    ->maxLength(255),

                TextInput::make('name_ar')
                    ->label(__('admin.fields.name_ar'))
                    ->required()
                    ->maxLength(255),

                TextInput::make('slug')
                    ->label(__('admin.fields.slug'))
                    ->required()
                    ->maxLength(255)
                    ->unique(ignoreRecord: true)
                    ->rules(['alpha_dash']),

                TextInput::make('display_order')
                    ->label(__('admin.fields.display_order'))
                    ->numeric()
                    ->default(0),

                Toggle::make('is_active')
                    ->label(__('admin.fields.is_active'))
                    ->default(true)
                    ->inline(false),
            ]),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->defaultSort('display_order')
            ->reorderable('display_order')
            ->columns([
                TextColumn::make('name_en')
                    ->label(__('admin.fields.name_en'))
                    ->searchable()
                    ->weight('medium'),

                TextColumn::make('name_ar')
                    ->label(__('admin.fields.name_ar'))
                    ->searchable(),

                IconColumn::make('is_active')
                    ->label(__('admin.fields.is_active'))
                    ->boolean(),
            ])
            ->recordActions([
                EditAction::make(),
                DeleteAction::make(),
            ])
            ->toolbarActions([
                BulkActionGroup::make([DeleteBulkAction::make()]),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => ManageProductForms::route('/'),
        ];
    }
}
