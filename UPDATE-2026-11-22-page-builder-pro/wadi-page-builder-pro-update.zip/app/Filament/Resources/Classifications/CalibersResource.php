<?php

declare(strict_types=1);

namespace App\Filament\Resources\Classifications;

use App\Filament\Resources\Classifications\Pages\ManageCalibers;
use App\Models\Caliber;
use BackedEnum;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteAction;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

/**
 * Managed on a single screen: these lists are short and are edited in modals
 * rather than through separate create and edit pages.
 */
class CalibersResource extends Resource
{
    protected static ?string $model = Caliber::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedArrowsPointingOut;

    protected static ?int $navigationSort = 5;

    public static function getNavigationGroup(): ?string
    {
        return __('nav.groups.catalogue');
    }

    public static function getModelLabel(): string
    {
        return __('admin.resources.caliber.label');
    }

    public static function getPluralModelLabel(): string
    {
        return __('admin.resources.caliber.plural');
    }

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            \App\Filament\Forms\Components\AiTranslateButton::make(['name']),
            \App\Filament\Forms\Components\ExtraLanguageFields::section(['name']),
            Section::make()->columns(2)->schema([
                TextInput::make('name_en')
                    ->label(__('admin.fields.name_en'))
                    ->required()
                    ->maxLength(255),

                TextInput::make('name_ar')
                    ->label(__('admin.fields.name_ar'))
                    ->required()
                    ->maxLength(255),

                TextInput::make('code')
                    ->label(__('admin.resources.caliber.label'))
                    ->required()
                    ->maxLength(32)
                    ->unique(ignoreRecord: true)
                    ->helperText('e.g. 181/200'),

                TextInput::make('count_per_kg_min')
                    ->label('Min count / kg')
                    ->numeric()
                    ->minValue(1),

                TextInput::make('count_per_kg_max')
                    ->label('Max count / kg')
                    ->numeric()
                    ->minValue(1)
                    ->gte('count_per_kg_min'),

                TextInput::make('display_order')
                    ->label(__('admin.fields.display_order'))
                    ->numeric()
                    ->default(0),

                Toggle::make('is_active')
                    ->label(__('admin.fields.is_active'))
                    ->default(true)
                    ->inline(false),
            ]),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->defaultSort('display_order')
            ->reorderable('display_order')
            ->columns([
                TextColumn::make('name_en')
                    ->label(__('admin.fields.name_en'))
                    ->searchable()
                    ->weight('medium'),

                TextColumn::make('name_ar')
                    ->label(__('admin.fields.name_ar'))
                    ->searchable(),

                TextColumn::make('code')
                    ->label('Code')
                    ->searchable()
                    ->badge(),

                IconColumn::make('is_active')
                    ->label(__('admin.fields.is_active'))
                    ->boolean(),
            ])
            ->recordActions([
                EditAction::make(),
                DeleteAction::make(),
            ])
            ->toolbarActions([
                BulkActionGroup::make([DeleteBulkAction::make()]),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => ManageCalibers::route('/'),
        ];
    }
}
