<?php

declare(strict_types=1);

namespace App\Filament\Resources\Classifications;

use App\Filament\Forms\Components\MediaPicker;
use App\Filament\Resources\Classifications\Pages\ManageCertifications;
use App\Models\Certification;
use BackedEnum;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteAction;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\ImageColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class CertificationsResource extends Resource
{
    protected static ?string $model = Certification::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedShieldCheck;

    protected static ?int $navigationSort = 3;

    public static function getNavigationGroup(): ?string
    {
        return __('nav.groups.company');
    }

    public static function getModelLabel(): string
    {
        return __('admin.resources.certification.label');
    }

    public static function getPluralModelLabel(): string
    {
        return __('admin.resources.certification.plural');
    }

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            \App\Filament\Forms\Components\AiTranslateButton::make(['name', 'description']),
            Section::make()->columns(2)->schema([
                TextInput::make('name_en')->label(__('admin.fields.name_en'))->required()->maxLength(255),
                TextInput::make('name_ar')->label(__('admin.fields.name_ar'))->required()->maxLength(255),

                TextInput::make('slug')->label(__('admin.fields.slug'))->required()
                    ->maxLength(255)->unique(ignoreRecord: true)->rules(['alpha_dash']),

                TextInput::make('issuer')->label('Issuing body')->maxLength(255),

                Textarea::make('description_en')->label(__('admin.fields.description_en'))->rows(3),
                Textarea::make('description_ar')->label(__('admin.fields.description_ar'))->rows(3),

                MediaPicker::make('logo_id', 'Logo', 'certifications'),
                MediaPicker::document('document_id', 'Certificate (PDF)', 'certifications'),

                // Left blank when a certificate has no fixed expiry; the
                // public page shows nothing rather than an invented date.
                DatePicker::make('valid_until')->label('Valid until')->native(false),

                TextInput::make('display_order')->label(__('admin.fields.display_order'))->numeric()->default(0),

                Toggle::make('is_active')->label(__('admin.fields.is_active'))->default(true)->inline(false),
            ]),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->defaultSort('display_order')
            ->reorderable('display_order')
            ->columns([
                ImageColumn::make('logo')
                    ->label('')
                    ->getStateUsing(fn (Certification $r): ?string => $r->logo?->urlFor(120))
                    ->square()->size(40),
                TextColumn::make('name_en')->label(__('admin.fields.name_en'))->searchable()->weight('medium'),
                TextColumn::make('name_ar')->label(__('admin.fields.name_ar'))->searchable(),
                TextColumn::make('issuer')->label('Issuer')->placeholder('—'),
                TextColumn::make('valid_until')->label('Valid until')->date('j M Y')->placeholder('—')
                    ->color(fn (Certification $r): string => $r->isExpired() ? 'danger' : 'gray'),
                IconColumn::make('is_active')->label(__('admin.fields.is_active'))->boolean(),
            ])
            ->recordActions([EditAction::make(), DeleteAction::make()])
            ->toolbarActions([BulkActionGroup::make([DeleteBulkAction::make()])]);
    }

    public static function getPages(): array
    {
        return ['index' => ManageCertifications::route('/')];
    }
}
