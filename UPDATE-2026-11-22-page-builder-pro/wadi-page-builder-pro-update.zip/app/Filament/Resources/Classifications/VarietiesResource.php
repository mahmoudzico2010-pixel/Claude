<?php

declare(strict_types=1);

namespace App\Filament\Resources\Classifications;

use App\Filament\Resources\Classifications\Pages\ManageVarieties;
use App\Models\Variety;
use BackedEnum;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteAction;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use App\Filament\Forms\Components\MediaPicker;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

/**
 * Managed on a single screen: these lists are short and are edited in modals
 * rather than through separate create and edit pages.
 */
class VarietiesResource extends Resource
{
    protected static ?string $model = Variety::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedSwatch;

    protected static ?int $navigationSort = 3;

    public static function getNavigationGroup(): ?string
    {
        return __('nav.groups.catalogue');
    }

    public static function getModelLabel(): string
    {
        return __('admin.resources.variety.label');
    }

    public static function getPluralModelLabel(): string
    {
        return __('admin.resources.variety.plural');
    }

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            \App\Filament\Forms\Components\AiTranslateButton::make(['name', 'intro', 'description', 'characteristics', 'culinary_uses']),
            Section::make()->columns(2)->schema([
                TextInput::make('name_en')
                    ->label(__('admin.fields.name_en'))
                    ->required()
                    ->maxLength(255),

                TextInput::make('name_ar')
                    ->label(__('admin.fields.name_ar'))
                    ->required()
                    ->maxLength(255),

                TextInput::make('slug')
                    ->label(__('admin.fields.slug'))
                    ->required()
                    ->maxLength(255)
                    ->unique(ignoreRecord: true)
                    ->rules(['alpha_dash']),

                TextInput::make('display_order')
                    ->label(__('admin.fields.display_order'))
                    ->numeric()
                    ->default(0),

                MediaPicker::make('image_id', __('admin.fields.image'), 'products'),

                Textarea::make('intro_en')->label(__('catalog.admin.intro').' (EN)')->rows(2)->maxLength(400)->columnSpanFull(),
                Textarea::make('intro_ar')->label(__('catalog.admin.intro').' (AR)')->rows(2)->maxLength(400)->columnSpanFull()->extraInputAttributes(['dir' => 'rtl']),
                Textarea::make('description_en')->label(__('catalog.admin.description').' (EN)')->rows(4)->columnSpanFull(),
                Textarea::make('description_ar')->label(__('catalog.admin.description').' (AR)')->rows(4)->columnSpanFull()->extraInputAttributes(['dir' => 'rtl']),
                Textarea::make('characteristics_en')->label(__('catalog.variety.characteristics').' (EN)')->rows(3)->columnSpanFull(),
                Textarea::make('characteristics_ar')->label(__('catalog.variety.characteristics').' (AR)')->rows(3)->columnSpanFull()->extraInputAttributes(['dir' => 'rtl']),
                Textarea::make('culinary_uses_en')->label(__('catalog.variety.uses').' (EN)')->rows(3)->columnSpanFull(),
                Textarea::make('culinary_uses_ar')->label(__('catalog.variety.uses').' (AR)')->rows(3)->columnSpanFull()->extraInputAttributes(['dir' => 'rtl']),

                Toggle::make('show_in_menu')
                    ->label(__('catalog.admin.show_in_menu'))
                    ->default(true)
                    ->inline(false),

                Toggle::make('is_active')
                    ->label(__('admin.fields.is_active'))
                    ->default(true)
                    ->inline(false),
            ]),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->defaultSort('display_order')
            ->reorderable('display_order')
            ->columns([
                TextColumn::make('name_en')
                    ->label(__('admin.fields.name_en'))
                    ->searchable()
                    ->weight('medium'),

                TextColumn::make('name_ar')
                    ->label(__('admin.fields.name_ar'))
                    ->searchable(),

                IconColumn::make('is_active')
                    ->label(__('admin.fields.is_active'))
                    ->boolean(),
            ])
            ->recordActions([
                EditAction::make(),
                DeleteAction::make(),
            ])
            ->toolbarActions([
                BulkActionGroup::make([DeleteBulkAction::make()]),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => ManageVarieties::route('/'),
        ];
    }
}
