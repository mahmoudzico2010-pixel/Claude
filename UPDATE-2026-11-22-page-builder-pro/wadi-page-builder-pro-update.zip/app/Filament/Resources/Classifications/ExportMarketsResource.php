<?php

declare(strict_types=1);

namespace App\Filament\Resources\Classifications;

use App\Filament\Resources\Classifications\Pages\ManageExportMarkets;
use App\Models\ExportMarket;
use App\Support\Countries;
use BackedEnum;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteAction;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Utilities\Get;
use Filament\Schemas\Components\Utilities\Set;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

/**
 * Managed on a single screen: these lists are short and are edited in modals
 * rather than through separate create and edit pages.
 */
class ExportMarketsResource extends Resource
{
    protected static ?string $model = ExportMarket::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedGlobeAlt;

    protected static ?int $navigationSort = 2;

    public static function getNavigationGroup(): ?string
    {
        return __('nav.groups.company');
    }

    public static function getModelLabel(): string
    {
        return __('admin.resources.export_market.label');
    }

    public static function getPluralModelLabel(): string
    {
        return __('admin.resources.export_market.plural');
    }

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            \App\Filament\Forms\Components\AiTranslateButton::make(['name', 'region']),
            Section::make()->columns(2)->schema([
                Select::make('country_code')
                    ->label('Country (ISO 3166-1)')
                    ->helperText('Choose from the complete list of countries and territories. Adding a market here is the only way a country becomes one of "our markets"; customers can pick any country in an enquiry without it.')
                    ->options(fn (): array => Countries::options('en'))
                    ->searchable()
                    ->required()
                    ->rules([Countries::rule()])
                    ->unique(ignoreRecord: true)
                    ->validationMessages(['unique' => 'This country already has a market entry: edit that one instead.'])
                    ->live()
                    ->afterStateUpdated(function ($state, Set $set, Get $get): void {
                        // Offer the standard names; they stay editable wording for the public site.
                        if (Countries::exists($state)) {
                            blank($get('name_en')) && $set('name_en', Countries::name($state, 'en'));
                            blank($get('name_ar')) && $set('name_ar', Countries::name($state, 'ar'));
                        }
                    }),

                TextInput::make('name_en')
                    ->label(__('admin.fields.name_en'))
                    ->required()
                    ->maxLength(255),

                TextInput::make('name_ar')
                    ->label(__('admin.fields.name_ar'))
                    ->required()
                    ->maxLength(255),

                TextInput::make('region_en')
                    ->label('Region (English)')
                    ->maxLength(80),

                TextInput::make('region_ar')
                    ->label('Region (Arabic)')
                    ->maxLength(80),

                TextInput::make('display_order')
                    ->label(__('admin.fields.display_order'))
                    ->numeric()
                    ->default(0),

                Toggle::make('is_active')
                    ->label(__('admin.fields.is_active'))
                    ->default(true)
                    ->inline(false),
            ]),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->defaultSort('display_order')
            ->reorderable('display_order')
            ->columns([
                TextColumn::make('name_en')
                    ->label(__('admin.fields.name_en'))
                    ->searchable()
                    ->weight('medium'),

                TextColumn::make('name_ar')
                    ->label(__('admin.fields.name_ar'))
                    ->searchable(),

                TextColumn::make('country_code')
                    ->label('Code')
                    ->badge()
                    ->searchable(),

                IconColumn::make('is_active')
                    ->label(__('admin.fields.is_active'))
                    ->boolean(),
            ])
            ->recordActions([
                EditAction::make(),
                DeleteAction::make(),
            ])
            ->toolbarActions([
                BulkActionGroup::make([DeleteBulkAction::make()]),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => ManageExportMarkets::route('/'),
        ];
    }
}
