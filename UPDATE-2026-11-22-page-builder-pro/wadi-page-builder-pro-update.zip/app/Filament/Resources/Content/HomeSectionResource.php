<?php

declare(strict_types=1);

namespace App\Filament\Resources\Content;

use App\Filament\Forms\Components\MediaPicker;
use App\Filament\Resources\Content\Pages\CreateHomeSection;
use App\Filament\Resources\Content\Pages\EditHomeSection;
use App\Filament\Resources\Content\Pages\ListHomeSections;
use App\Models\HomeSection;
use App\Support\Permissions;
use BackedEnum;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteAction;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Actions\ReplicateAction;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Fieldset;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Tabs;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Columns\ToggleColumn;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;

class HomeSectionResource extends Resource
{
    protected static ?string $model = HomeSection::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedSquares2x2;

    protected static ?int $navigationSort = 1;

    /**
     * Retired into the Homepage Manager (one canonical editor). Hidden from
     * navigation, and no record can be created, edited or deleted through it.
     */
    protected static bool $shouldRegisterNavigation = false;

    public static function canCreate(): bool
    {
        return false;
    }

    public static function canEdit(Model $record): bool
    {
        return false;
    }

    public static function canDelete(Model $record): bool
    {
        return false;
    }

    public static function canDeleteAny(): bool
    {
        return false;
    }

    public static function getNavigationGroup(): ?string
    {
        return __('nav.groups.content');
    }

    public static function getModelLabel(): string
    {
        return __('home.resource.label');
    }

    public static function getPluralModelLabel(): string
    {
        return __('home.resource.plural');
    }

    /**
     * Raw HTML and CSS are Super Admin only.
     *
     * A block is printed unescaped on the public homepage, so the ability to
     * write one is the ability to run markup on the company's own origin. The
     * Content Editor role exists to write copy, not to inject markup — and the
     * create and edit pages drop these fields server-side as well, so hiding
     * them here is a convenience rather than the control.
     */
    public static function mayEditMarkup(): bool
    {
        return Auth::user()?->isSuperAdmin() ?? false;
    }

    public static function form(Schema $schema): Schema
    {
        return $schema->components([

            Section::make()
                ->columns(2)
                ->schema([
                    Select::make('type')
                        ->label(__('home.fields.type'))
                        ->options(fn (): array => array_filter([
                            HomeSection::TYPE_BUILTIN => __('home.types.builtin'),
                            HomeSection::TYPE_HTML => static::mayEditMarkup() ? __('home.types.html') : null,
                        ]))
                        ->default(HomeSection::TYPE_BUILTIN)
                        ->required()
                        ->live()
                        // A built-in section's key names a shipped template;
                        // changing it after creation would point the row at a
                        // different part of the page.
                        ->disabled(fn (?HomeSection $record): bool => $record !== null)
                        ->dehydrated(),

                    TextInput::make('key')
                        ->label(__('home.fields.key'))
                        ->disabled()
                        ->dehydrated(false)
                        ->visible(fn (?HomeSection $record): bool => $record !== null)
                        ->helperText(__('home.hints.key')),
                ]),

            Section::make(__('home.sections.content'))
                ->visible(fn (callable $get): bool => $get('type') === HomeSection::TYPE_HTML)
                ->schema([
                    \App\Filament\Forms\Components\AiTranslateButton::make(['heading', 'subheading', 'html'], 'dotted'),
                    Tabs::make('locales')->tabs(
                        collect(config('wadi.locales'))
                            ->map(fn (array $config, string $locale) => Tabs\Tab::make($config['native'])->schema([
                                TextInput::make("translations.{$locale}.heading")
                                    ->label(__('home.fields.heading'))
                                    ->maxLength(180),

                                Textarea::make("translations.{$locale}.subheading")
                                    ->label(__('home.fields.subheading'))
                                    ->rows(2)
                                    ->maxLength(400),

                                Textarea::make("translations.{$locale}.html")
                                    ->label(__('home.fields.html'))
                                    ->rows(14)
                                    ->visible(static::mayEditMarkup())
                                    ->helperText(__('home.hints.html'))
                                    ->extraInputAttributes([
                                        'class' => 'font-mono text-xs',
                                        'spellcheck' => 'false',
                                    ]),
                            ]))
                            ->values()
                            ->all()
                    ),

                    Textarea::make('css')
                        ->label(__('home.fields.css'))
                        ->rows(10)
                        ->visible(static::mayEditMarkup())
                        ->helperText(__('home.hints.css'))
                        ->extraInputAttributes([
                            'class' => 'font-mono text-xs',
                            'spellcheck' => 'false',
                        ]),
                ]),

            Section::make(__('home.sections.appearance'))
                ->visible(fn (callable $get): bool => $get('type') === HomeSection::TYPE_HTML)
                ->columns(3)
                ->schema([
                    Select::make('background')
                        ->label(__('home.fields.background'))
                        ->options(collect(HomeSection::BACKGROUNDS)
                            ->mapWithKeys(fn (string $b): array => [$b => __('home.backgrounds.'.$b)])
                            ->all())
                        ->default('default')
                        ->native(false),

                    Select::make('padding')
                        ->label(__('home.fields.padding'))
                        ->options(collect(HomeSection::PADDINGS)
                            ->mapWithKeys(fn (string $p): array => [$p => __('home.paddings.'.$p)])
                            ->all())
                        ->default('default')
                        ->native(false),

                    Toggle::make('constrain_width')
                        ->label(__('home.fields.constrain'))
                        ->default(true)
                        ->inline(false)
                        ->helperText(__('home.hints.constrain')),

                    MediaPicker::make('background_media_id', __('home.fields.background_image'))
                        ->helperText(__('home.hints.background_image')),
                ]),

            /*
             | Layout — available to every section, built-in or custom.
             |
             | Generated from config('design.section_settings') rather than
             | written out field by field, so adding a setting there gives it a
             | control here automatically. Responsive settings become one field
             | per breakpoint, and a blank field means "inherit from the screen
             | size below", which is what makes a partial override possible.
             */
            Section::make(__('home.sections.layout'))
                ->description(__('home.hints.layout'))
                ->collapsed()
                ->schema(static::layoutFields()),

            Section::make()
                ->columns(2)
                ->schema([
                    Toggle::make('is_active')
                        ->label(__('admin.fields.is_active'))
                        ->default(true)
                        ->inline(false),

                    TextInput::make('display_order')
                        ->label(__('admin.fields.display_order'))
                        ->numeric()
                        ->default(0),
                ]),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->modifyQueryUsing(fn (Builder $query) => $query->withTranslation())
            ->defaultSort('display_order')
            ->reorderable('display_order')
            ->paginated(false)
            ->columns([
                TextColumn::make('label')
                    ->label(__('home.fields.section'))
                    ->getStateUsing(fn (HomeSection $record): string => $record->isHtml()
                        ? ($record->t('heading') ?: __('home.untitled_block'))
                        : __('home.builtin.'.$record->key))
                    ->description(fn (HomeSection $record): ?string => $record->isHtml()
                        ? null
                        : __('home.builtin_hint.'.$record->key))
                    ->weight('medium')
                    ->wrap(),

                TextColumn::make('type')
                    ->label(__('home.fields.type'))
                    ->badge()
                    ->formatStateUsing(fn (string $state): string => __('home.types.'.$state))
                    ->color(fn (string $state): string => $state === HomeSection::TYPE_HTML ? 'warning' : 'gray'),

                ToggleColumn::make('is_active')
                    ->label(__('admin.fields.is_active'))
                    ->disabled(fn (): bool => ! (Auth::user()?->can(Permissions::CONTENT_MANAGE) ?? false)),
            ])
            ->recordActions([
                EditAction::make(),

                /*
                 | Duplicate.
                 |
                 | Copies appearance and layout but not the key: a built-in
                 | section's key names a shipped template, and two rows
                 | claiming the same one would render that band twice. So a
                 | duplicate is always a custom block, seeded with the
                 | original's settings and placed directly after it.
                 |
                 | It is created inactive. A copy appearing live on the
                 | homepage the instant someone clicks "duplicate" is not what
                 | anyone means by the word.
                 */
                ReplicateAction::make()
                    ->label(__('home.actions.duplicate'))
                    ->icon(Heroicon::OutlinedDocumentDuplicate)
                    ->excludeAttributes(['key'])
                    ->beforeReplicaSaved(function (HomeSection $replica, HomeSection $record): void {
                        $replica->type = HomeSection::TYPE_HTML;
                        $replica->key = 'block-'.Str::random(10);
                        $replica->is_active = false;
                        $replica->display_order = $record->display_order + 1;
                    })
                    // afterReplicaSaved, not after: only this hook receives the
                    // saved replica. And the parameters must be named $replica
                    // and $record — Filament injects closure arguments by name,
                    // not by type, so renaming either one hands the closure a
                    // null and fails at runtime rather than at lint time.
                    ->afterReplicaSaved(function (HomeSection $replica, HomeSection $record): void {
                        // Copy the translations too; without this the duplicate
                        // would come back with an empty heading in both
                        // languages, which reads as a bug rather than a copy.
                        foreach ($record->translations as $translation) {
                            $replica->translations()->create(
                                collect($translation->getAttributes())
                                    ->except(['id', 'home_section_id', 'created_at', 'updated_at'])
                                    ->all()
                            );
                        }

                        HomeSection::flushCache();
                    })
                    ->visible(fn (): bool => static::mayEditMarkup()),
                // Built-in sections are part of the application, not content;
                // switching one off is the supported way to remove it, and
                // deleting the row would only make it reappear from the
                // shipped defaults on the next cache rebuild.
                DeleteAction::make()->visible(fn (HomeSection $record): bool => $record->isHtml()),
            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ])
            ->emptyStateHeading(__('home.empty.heading'))
            ->emptyStateDescription(__('home.empty.description'));
    }

    public static function getPages(): array
    {
        return [
            'index' => ListHomeSections::route('/'),
            'create' => CreateHomeSection::route('/create'),
            'edit' => EditHomeSection::route('/{record}/edit'),
        ];
    }

    /**
     * Controls for every setting in config('design.section_settings').
     *
     * @return array<int, mixed>
     */
    public static function layoutFields(): array
    {
        $breakpoints = array_keys((array) config('design.breakpoints', []));
        $fields = [];

        foreach ((array) config('design.section_settings', []) as $setting => $definition) {
            if (! is_array($definition)) {
                continue;
            }

            $label = __('home.layout.'.$setting);
            $options = static::layoutOptions($setting, $definition);

            if ($definition['responsive'] ?? false) {
                $perTier = [];

                foreach ($breakpoints as $breakpoint) {
                    $perTier[] = static::layoutControl(
                        "layout.{$setting}.{$breakpoint}",
                        __('theme.breakpoints.'.$breakpoint),
                        $definition,
                        $options,
                    )->placeholder(__('theme.inherit'));
                }

                $fields[] = Fieldset::make($label)
                    ->columns(['default' => 1, 'sm' => 2, 'xl' => 5])
                    ->schema($perTier)
                    ->columnSpanFull();

                continue;
            }

            $fields[] = static::layoutControl("layout.{$setting}", $label, $definition, $options);
        }

        return $fields;
    }

    /**
     * @param  array<string, mixed>  $definition
     * @param  array<string, string>  $options
     */
    protected static function layoutControl(string $name, string $label, array $definition, array $options): mixed
    {
        $type = (string) ($definition['type'] ?? 'choice');

        // `choice` and `spacing` are both picked from a fixed list; everything
        // else is a measurement typed by hand.
        if ($options !== []) {
            return Select::make($name)->label($label)->options($options)->native(false);
        }

        return match ($type) {
            'integer' => TextInput::make($name)->label($label)->numeric()->minValue(1)->maxValue(6),
            default => TextInput::make($name)->label($label)->placeholder('—'),
        };
    }

    /**
     * @param  array<string, mixed>  $definition
     * @return array<string, string>
     */
    protected static function layoutOptions(string $setting, array $definition): array
    {
        $options = [];

        foreach ((array) ($definition['options'] ?? []) as $value) {
            $key = 'home.layout_options.'.$setting.'.'.$value;
            $translated = __($key);
            $options[$value] = $translated === $key ? $value : $translated;
        }

        return $options;
    }
}
