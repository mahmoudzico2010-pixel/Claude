<?php

declare(strict_types=1);

namespace App\Filament\Resources\Content;

use App\Filament\Resources\Content\Pages\ManageNavigationItems;
use App\Models\Document;
use App\Models\NavigationItem;
use App\Models\Page;
use App\Support\Locales;
use BackedEnum;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteAction;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Table;

class NavigationItemResource extends Resource
{
    protected static ?string $model = NavigationItem::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedBars3;

    protected static ?int $navigationSort = 4;

    public static function getNavigationGroup(): ?string
    {
        return __('nav.groups.content');
    }

    public static function getModelLabel(): string
    {
        return __('admin.resources.navigation_item.label');
    }

    public static function getPluralModelLabel(): string
    {
        return __('admin.resources.navigation_item.plural');
    }

    /** @return array<string, string> */
    public static function locationOptions(): array
    {
        return [
            'header' => 'Header',
            'footer_products' => 'Footer — Products',
            'footer_company' => 'Footer — Company',
            'legal' => 'Legal (footer bottom)',
        ];
    }

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            \App\Filament\Forms\Components\AiTranslateButton::make(['label']),
            \App\Filament\Forms\Components\ExtraLanguageFields::section(['label']),
            Section::make()->columns(2)->schema([
                Select::make('location')->label('Menu')->options(static::locationOptions())
                    ->default('header')->required()->native(false),

                Select::make('parent_id')
                    ->label('Parent item')
                    ->options(function (?NavigationItem $record, callable $get): array {
                        // Any item of the same menu except itself and its own sub-items, and only where the nested result still fits the depth limit.
                        $exclude = $record ? [$record->getKey(), ...$record->descendantIds()] : [];
                        $height = $record ? $record->subtreeHeight() : 1;

                        return NavigationItem::query()
                            ->when($get('location'), fn ($q, $loc) => $q->where('location', $loc))
                            ->whereNotIn('id', $exclude)
                            ->orderBy('display_order')->get()
                            ->filter(fn (NavigationItem $i): bool => $i->depth() + $height <= NavigationItem::maxDepth())
                            ->mapWithKeys(fn (NavigationItem $i): array => [$i->id => str_repeat('— ', $i->depth() - 1).$i->label_en])
                            ->all();
                    })
                    ->native(false),

                TextInput::make('label_en')->label(__('admin.fields.name_en'))->required()->maxLength(255),
                TextInput::make('label_ar')->label(__('admin.fields.name_ar'))->required()->maxLength(255)->extraInputAttributes(['dir' => 'rtl', 'lang' => 'ar']),

                // Every other supported language. Optional: a language that is missing a label is
                // reported as incomplete in System -> Languages and shows English meanwhile.
                // Editing a label that was signed off makes that language need review again.
                Section::make('Labels in other languages')->columnSpanFull()->columns(2)->collapsible()->collapsed()
                    ->description('Optional. Changing a label that has been signed off means the language needs to be reviewed again (System → Languages).')
                    ->schema(collect(Locales::supported())->except(['en', 'ar'])->map(
                        fn (array $cfg, string $code) => TextInput::make('label_'.$code)->label($cfg['name'].' — '.$cfg['native'])->maxLength(255)
                            ->extraInputAttributes(['dir' => $cfg['dir'], 'lang' => $code])
                    )->values()->all()),

                /*
                 | Destination.
                 |
                 | One selector that reveals the matching field, rather than
                 | four fields of which exactly one must be filled and the
                 | others left alone. The old form worked, but it asked the
                 | administrator to know the precedence rule — "the route wins
                 | over the page, which wins over the URL" — and silently did
                 | the wrong thing when two were set.
                 |
                 | `dehydrated` handling below clears the fields that do not
                 | belong to the chosen type, so switching from a page to a
                 | document cannot leave a stale page_id behind that would then
                 | win on precedence.
                 */
                Select::make('destination_type')
                    ->label(__('admin.navigation.destination'))
                    ->options([
                        'home' => __('admin.navigation.destinations.home'),
                        'route' => __('admin.navigation.destinations.route'),
                        'page' => __('admin.navigation.destinations.page'),
                        'document' => __('admin.navigation.destinations.document'),
                        'anchor' => __('admin.navigation.destinations.anchor'),
                        'url' => __('admin.navigation.destinations.url'),
                    ])
                    ->default('route')
                    ->required()
                    ->live()
                    ->native(false)
                    ->dehydrated(false)
                    ->columnSpanFull()
                    // Fill from the stored row so editing an existing item
                    // opens on the field it actually uses.
                    ->afterStateHydrated(function (Select $component, ?NavigationItem $record): void {
                        $component->state($record?->destinationType() ?? 'route');
                    }),

                Select::make('route_name')
                    ->label(__('admin.navigation.destinations.route'))
                    ->options([
                        'products.index' => 'Products',
                        'packaging.index' => 'Packaging',
                        'news.index' => 'News & Exhibitions',
                        'quote.create' => 'Request a Quote',
                        'contact.show' => 'Contact',
                        'about' => 'About Us',
                        'quality' => 'Quality',
                        'export' => 'Export',
                        'private-label' => 'Private Label',
                    ])
                    ->native(false)
                    ->visible(fn (callable $get): bool => $get('destination_type') === 'route')
                    ->required(fn (callable $get): bool => $get('destination_type') === 'route')
                    ->dehydrated()
                    // 'home' is the same column with a fixed value, which is
                    // what keeps the Home item editable like any other.
                    ->dehydrateStateUsing(fn ($state, callable $get) => match ($get('destination_type')) {
                        'home' => 'home',
                        'route' => $state,
                        default => null,
                    }),

                Select::make('page_id')
                    ->label(__('admin.resources.page.label'))
                    ->options(fn (): array => Page::query()->withTranslation()->get()
                        ->mapWithKeys(fn (Page $p): array => [$p->id => $p->t('title') ?? $p->slug])->all())
                    ->native(false)
                    ->searchable()
                    ->visible(fn (callable $get): bool => $get('destination_type') === 'page')
                    ->required(fn (callable $get): bool => $get('destination_type') === 'page')
                    ->dehydrated()
                    ->dehydrateStateUsing(fn ($state, callable $get) => $get('destination_type') === 'page' ? $state : null)
                    // By relation, not by URL: renaming a page keeps the link.
                    ->helperText(__('admin.navigation.hints.page')),

                Select::make('document_id')
                    ->label(__('documents.resource.label'))
                    ->options(fn (): array => Document::query()->withTranslation()->ordered()->get()
                        ->mapWithKeys(fn (Document $d): array => [$d->id => $d->t('title') ?? $d->slug])->all())
                    ->native(false)
                    ->searchable()
                    ->visible(fn (callable $get): bool => $get('destination_type') === 'document')
                    ->required(fn (callable $get): bool => $get('destination_type') === 'document')
                    ->dehydrated()
                    ->dehydrateStateUsing(fn ($state, callable $get) => $get('destination_type') === 'document' ? $state : null)
                    ->helperText(__('admin.navigation.hints.document')),

                TextInput::make('anchor')
                    ->label(__('admin.navigation.destinations.anchor'))
                    ->maxLength(64)
                    // Letters, numbers and hyphens: it becomes a URL fragment.
                    ->rule('regex:/^[A-Za-z0-9_-]+$/')
                    ->prefix('#')
                    ->visible(fn (callable $get): bool => $get('destination_type') === 'anchor')
                    ->required(fn (callable $get): bool => $get('destination_type') === 'anchor')
                    ->dehydrated()
                    ->dehydrateStateUsing(fn ($state, callable $get) => $get('destination_type') === 'anchor' ? $state : null)
                    ->helperText(__('admin.navigation.hints.anchor')),

                TextInput::make('url')
                    ->label(__('admin.navigation.destinations.url'))
                    ->url()
                    ->maxLength(255)
                    ->visible(fn (callable $get): bool => $get('destination_type') === 'url')
                    ->required(fn (callable $get): bool => $get('destination_type') === 'url')
                    ->dehydrated()
                    ->dehydrateStateUsing(fn ($state, callable $get) => $get('destination_type') === 'url' ? $state : null),

                TextInput::make('display_order')->label(__('admin.fields.display_order'))->numeric()->default(0),

                Toggle::make('open_in_new_tab')->label('Open in new tab')->inline(false),
                Toggle::make('source')
                    ->label(__('catalog.admin.fill_from_catalog'))
                    ->helperText(__('catalog.admin.fill_from_catalog_help'))
                    ->inline(false)
                    ->afterStateHydrated(fn ($component, $state) => $component->state($state === 'product_catalog'))
                    ->dehydrateStateUsing(fn ($state) => $state ? 'product_catalog' : null),
                Toggle::make('is_active')->label(__('admin.fields.is_active'))->default(true)->inline(false),
            ]),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->defaultSort('display_order')
            ->reorderable('display_order')
            ->groups(['location'])
            ->defaultGroup('location')
            ->columns([
                TextColumn::make('label_en')->label(__('admin.fields.name_en'))->searchable()->weight('medium'),
                TextColumn::make('label_ar')->label(__('admin.fields.name_ar'))->searchable(),
                TextColumn::make('location')->label('Menu')
                    ->formatStateUsing(fn (string $state): string => static::locationOptions()[$state] ?? $state)
                    ->badge()->color('gray'),
                TextColumn::make('parent.label_en')->label('Parent')->placeholder('—'),
                IconColumn::make('is_active')->label(__('admin.fields.is_active'))->boolean(),
            ])
            ->filters([
                SelectFilter::make('location')->label('Menu')->options(static::locationOptions()),
            ])
            ->recordActions([EditAction::make(), DeleteAction::make()])
            ->toolbarActions([BulkActionGroup::make([DeleteBulkAction::make()])]);
    }

    public static function getPages(): array
    {
        return ['index' => ManageNavigationItems::route('/')];
    }
}
