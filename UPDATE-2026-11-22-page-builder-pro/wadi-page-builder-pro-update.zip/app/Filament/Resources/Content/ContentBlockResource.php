<?php

declare(strict_types=1);

namespace App\Filament\Resources\Content;

use App\Filament\Forms\Components\MediaPicker;
use App\Filament\Resources\Content\Pages\ManageContentBlocks;
use App\Models\ContentBlock;
use App\Support\Builder\Icons3D;
use BackedEnum;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteAction;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Table;

/**
 * Repeatable homepage and inner-page content: values, statistics, production
 * steps, quality commitments, export services, private-label benefits.
 * Keeps this copy out of the Blade templates entirely.
 */
class ContentBlockResource extends Resource
{
    protected static ?string $model = ContentBlock::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedSquares2x2;

    protected static ?int $navigationSort = 3;

    public static function getNavigationGroup(): ?string
    {
        return __('nav.groups.content');
    }

    public static function getModelLabel(): string
    {
        return __('admin.resources.content_block.label');
    }

    public static function getPluralModelLabel(): string
    {
        return __('admin.resources.content_block.plural');
    }

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            \App\Filament\Forms\Components\AiTranslateButton::make(['title', 'body', 'value_suffix']),
            Section::make()->columns(2)->schema([
                Select::make('section')
                    ->label(__('admin.fields.section'))
                    ->options(fn (): array => ContentBlock::sectionOptions())
                    ->required()
                    ->native(false)
                    ->live(),

                Select::make('icon')
                    ->label(__('admin.fields.icon'))
                    ->placeholder(__('admin.builder.icon_search'))
                    ->helperText(__('admin.builder.icon_help'))
                    ->searchable()
                    ->allowHtml()
                    ->in(fn (): array => Icons3D::names())
                    ->native(false)
                    ->preload()
                    ->options(fn (): array => collect(Icons3D::names())->mapWithKeys(fn (string $n): array => [$n => Icons3D::option($n)])->all())
                    ->getSearchResultsUsing(fn (string $q): array => collect(Icons3D::search($q))->mapWithKeys(fn (string $n): array => [$n => Icons3D::option($n)])->all())
                    ->getOptionLabelUsing(fn ($v): ?string => Icons3D::resolve((string) $v) ? Icons3D::option(Icons3D::resolve((string) $v)) : null)
                    ->afterStateHydrated(fn (Select $c, $state) => $c->state(Icons3D::resolve((string) $state))),

                TextInput::make('title_en')->label(__('admin.fields.title_en'))->maxLength(255),
                TextInput::make('title_ar')->label(__('admin.fields.title_ar'))->maxLength(255),

                Textarea::make('body_en')->label(__('admin.fields.body_en'))->rows(3),
                Textarea::make('body_ar')->label(__('admin.fields.body_ar'))->rows(3),
            ]),

            // Only meaningful for the statistics section.
            Section::make(__('content.sections.statistics'))
                ->columns(3)
                ->visible(fn ($get): bool => $get('section') === ContentBlock::SECTION_STATISTICS)
                ->schema([
                    TextInput::make('value_text')->label(__('admin.fields.value_text'))->maxLength(32),
                    TextInput::make('value_suffix_en')->label(__('admin.fields.value_suffix_en'))->maxLength(48),
                    TextInput::make('value_suffix_ar')->label(__('admin.fields.value_suffix_ar'))->maxLength(48),
                ]),

            Section::make()->columns(3)->schema([
                MediaPicker::make('image_id', __('admin.fields.image'), 'pages'),
                TextInput::make('link_url')->label(__('admin.fields.link_url'))->url()->maxLength(255),
                TextInput::make('display_order')->label(__('admin.fields.display_order'))->numeric()->default(0),
                Toggle::make('is_active')->label(__('admin.fields.is_active'))->default(true)->inline(false),
            ]),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->defaultSort('display_order')
            ->reorderable('display_order')
            ->groups(['section'])
            ->defaultGroup('section')
            ->columns([
                TextColumn::make('icon')
                    ->label(__('admin.fields.icon'))
                    ->html()
                    ->getStateUsing(fn (ContentBlock $r): string => Icons3D::resolve($r->icon) ?? '')
                    ->formatStateUsing(fn (string $state): string => $state === '' ? '—' : (string) Icons3D::svg($state, 36))
                    ->toggleable(),
                TextColumn::make('section')
                    ->label(__('admin.fields.section'))
                    ->formatStateUsing(fn (string $state): string => ContentBlock::sectionOptions()[$state] ?? $state)
                    ->badge()->color('gray'),
                TextColumn::make('title_en')->label(__('admin.fields.title_en'))->searchable()->wrap()->weight('medium'),
                TextColumn::make('title_ar')->label(__('admin.fields.title_ar'))->searchable()->wrap(),
                TextColumn::make('value_text')->label(__('admin.fields.value_text'))->placeholder('—'),
                IconColumn::make('is_active')->label(__('admin.fields.is_active'))->boolean(),
            ])
            ->filters([
                SelectFilter::make('section')
                    ->label(__('admin.fields.section'))
                    ->options(fn (): array => ContentBlock::sectionOptions()),
            ])
            ->recordActions([EditAction::make(), DeleteAction::make()])
            ->toolbarActions([BulkActionGroup::make([DeleteBulkAction::make()])]);
    }

    public static function getPages(): array
    {
        return ['index' => ManageContentBlocks::route('/')];
    }
}
