<?php

declare(strict_types=1);

namespace App\Filament\Resources\Content\Pages;

use App\Filament\Concerns\HandlesTranslations;
use App\Filament\Resources\Content\PageResource;
use Filament\Resources\Pages\CreateRecord;

class CreatePage extends CreateRecord
{
    use \App\Filament\Concerns\OffersAiTranslation;
    use HandlesTranslations;

    protected function getHeaderActions(): array
    {
        return [$this->aiTranslateAction()];
    }

    protected static string $resource = PageResource::class;
}
