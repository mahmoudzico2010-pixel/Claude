<?php

declare(strict_types=1);

namespace App\Filament\Resources\Content\Pages;

use App\Filament\Concerns\HandlesTranslations;
use App\Filament\Resources\Content\PageResource;
use Filament\Actions\DeleteAction;
use Filament\Resources\Pages\EditRecord;

class EditPage extends EditRecord
{
    use \App\Filament\Concerns\OffersAiTranslation;
    use HandlesTranslations;

    protected static string $resource = PageResource::class;

    protected function getHeaderActions(): array
    {
        return [
            $this->aiTranslateAction(),
            \Filament\Actions\Action::make('editHeader')
                ->label(__('pageheader.edit'))->icon('heroicon-m-photo')->color('gray')
                ->url(fn (): string => \App\Filament\Pages\PageBuilder::urlForPage($this->getRecord(), true))
                ->visible(fn (): bool => \App\Filament\Pages\PageBuilder::canAccess()),
            \Filament\Actions\Action::make('editVisually')
                ->label(__('admin.builder.edit_visually'))->icon('heroicon-m-squares-2x2')
                ->url(fn (): string => \App\Filament\Pages\PageBuilder::urlForPage($this->getRecord()))
                ->visible(fn (): bool => \App\Filament\Pages\PageBuilder::canAccess()),
            DeleteAction::make()->visible(fn (): bool => blank($this->getRecord()->key)),
        ];
    }
}
