<?php

declare(strict_types=1);

namespace App\Filament\Resources\Content;

use App\Filament\Forms\Components\MediaPicker;
use App\Filament\Resources\Content\Pages\CreateHeroSlide;
use App\Filament\Resources\Content\Pages\EditHeroSlide;
use App\Filament\Resources\Content\Pages\ListHeroSlides;
use App\Models\HeroSlide;
use App\Support\Permissions;
use App\Support\Uploads\UploadLimits;
use BackedEnum;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteAction;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Actions\ReplicateAction;
use Filament\Forms\Components\DateTimePicker;
use Filament\Forms\Components\Radio;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Grid;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Tabs;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Columns\ImageColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Columns\ToggleColumn;
use Filament\Tables\Filters\TernaryFilter;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class HeroSlideResource extends Resource
{
    protected static ?string $model = HeroSlide::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedRectangleStack;

    protected static ?int $navigationSort = 1;

    /**
     * Retired into the Homepage Manager (one canonical editor). Hidden from
     * navigation, and no record can be created, edited or deleted through it.
     */
    protected static bool $shouldRegisterNavigation = false;

    public static function canCreate(): bool
    {
        return false;
    }

    public static function canEdit(Model $record): bool
    {
        return false;
    }

    public static function canDelete(Model $record): bool
    {
        return false;
    }

    public static function canDeleteAny(): bool
    {
        return false;
    }

    public static function getNavigationGroup(): ?string
    {
        return __('nav.groups.content');
    }

    public static function getModelLabel(): string
    {
        return __('hero.resource.label');
    }

    public static function getPluralModelLabel(): string
    {
        return __('hero.resource.plural');
    }

    public static function form(Schema $schema): Schema
    {
        return $schema->components([

            // ---------------------------------------------------- Media ---
            Section::make(__('hero.sections.media'))
                ->description(__('hero.hints.media'))
                ->columns(2)
                ->schema([
                    Radio::make('media_type')
                        ->label(__('hero.fields.media_type'))
                        ->options([
                            HeroSlide::TYPE_IMAGE => __('hero.types.image'),
                            HeroSlide::TYPE_VIDEO => __('hero.types.video'),
                        ])
                        ->default(HeroSlide::TYPE_IMAGE)
                        ->required()
                        // The video picker only appears once video is chosen,
                        // so an image slide never carries a stray video.
                        ->live()
                        ->columnSpanFull(),

                    MediaPicker::make('image_id', __('hero.fields.image'), 'branding')
                        // Required for an image slide — there would be nothing
                        // to show otherwise. Optional for video, though the
                        // helper text is blunt about the cost: with no poster
                        // the slide is an empty gradient until the video
                        // buffers, and stays that way wherever autoplay is
                        // blocked.
                        ->required(fn (callable $get): bool => $get('media_type') !== HeroSlide::TYPE_VIDEO)
                        ->helperText(fn (callable $get): string => $get('media_type') === HeroSlide::TYPE_VIDEO
                            ? __('hero.hints.poster')
                            : __('hero.hints.image')),

                    MediaPicker::video('video_id', __('hero.fields.video'), 'branding')
                        ->visible(fn (callable $get): bool => $get('media_type') === HeroSlide::TYPE_VIDEO)
                        ->required(fn (callable $get): bool => $get('media_type') === HeroSlide::TYPE_VIDEO)
                        ->helperText(__('hero.hints.video', [
                            'max' => round(UploadLimits::kb('video') / 1024, 1),
                        ])),

                    TextInput::make('video_start')->label(__('homepage.manager.intro.start'))->numeric()->nullable()->minValue(0)->maxValue(86400)->suffix('s')
                        ->visible(fn (callable $get): bool => $get('media_type') === HeroSlide::TYPE_VIDEO),
                    TextInput::make('video_end')->label(__('homepage.manager.intro.end'))->numeric()->nullable()->minValue(0)->maxValue(86400)->suffix('s')
                        ->visible(fn (callable $get): bool => $get('media_type') === HeroSlide::TYPE_VIDEO),
                    TextInput::make('slide_seconds')->label(__('hero.fields.slide_seconds'))->numeric()->nullable()->minValue(2)->maxValue(600)->suffix('s')
                        ->placeholder(fn (callable $get): string => $get('media_type') === HeroSlide::TYPE_VIDEO ? __('hero.hints.slide_seconds_ph_video') : __('hero.hints.slide_seconds_ph_image'))
                        ->helperText(fn (callable $get): string => $get('media_type') === HeroSlide::TYPE_VIDEO ? __('hero.hints.slide_seconds_video') : __('hero.hints.slide_seconds_image')),
                    Toggle::make('video_loop')->label(__('homepage.manager.intro.loop'))->default(true)
                        ->visible(fn (callable $get): bool => $get('media_type') === HeroSlide::TYPE_VIDEO),
                    Toggle::make('video_sound')->label(__('homepage.manager.intro.sound'))
                        ->visible(fn (callable $get): bool => $get('media_type') === HeroSlide::TYPE_VIDEO),
                    Toggle::make('video_sound_button')->label(__('homepage.manager.intro.sound_button'))
                        ->visible(fn (callable $get): bool => $get('media_type') === HeroSlide::TYPE_VIDEO),
                ]),

            // ----------------------------------------------------- Copy ---
            Section::make(__('hero.sections.copy'))
                ->schema([
                    \App\Filament\Forms\Components\AiTranslateButton::make(['eyebrow', 'title', 'subtitle', 'button_text', 'image_alt'], 'dotted'),
                    Tabs::make('locales')->tabs(
                        collect(config('wadi.locales'))
                            ->map(fn (array $config, string $locale) => Tabs\Tab::make($config['native'])->schema([
                                TextInput::make("translations.{$locale}.eyebrow")
                                    ->label(__('hero.fields.eyebrow'))
                                    ->maxLength(120),

                                TextInput::make("translations.{$locale}.title")
                                    ->label(__('hero.fields.title'))
                                    ->required($locale === config('app.fallback_locale'))
                                    ->maxLength(180),

                                Textarea::make("translations.{$locale}.subtitle")
                                    ->label(__('hero.fields.subtitle'))
                                    ->rows(3)
                                    ->maxLength(400),

                                TextInput::make("translations.{$locale}.button_text")
                                    ->label(__('hero.fields.button_text'))
                                    ->maxLength(60),

                                TextInput::make("translations.{$locale}.image_alt")
                                    ->label(__('hero.fields.image_alt'))
                                    ->maxLength(255)
                                    ->helperText(__('hero.hints.image_alt')),
                            ]))
                            ->values()
                            ->all()
                    ),
                ]),

            // ------------------------------------------------------ CTA ---
            Section::make(__('hero.sections.button'))
                ->description(__('hero.hints.button'))
                ->columns(2)
                ->schema([
                    Select::make('button_route_name')
                        ->label(__('hero.fields.button_route'))
                        ->options(static::routeOptions())
                        ->native(false)
                        ->searchable()
                        ->placeholder(__('hero.fields.button_route_none')),

                    TextInput::make('button_url')
                        ->label(__('hero.fields.button_url'))
                        ->url()
                        ->maxLength(255)
                        ->helperText(__('hero.hints.button_url')),

                    Toggle::make('button_new_tab')
                        ->label(__('hero.fields.button_new_tab'))
                        ->inline(false),
                ]),

            // ------------------------------------------- Presentation -----
            Section::make(__('hero.sections.presentation'))
                ->columns(2)
                ->schema([
                    Select::make('text_alignment')
                        ->label(__('hero.fields.alignment'))
                        ->options([
                            'start' => __('hero.alignments.start'),
                            'center' => __('hero.alignments.center'),
                        ])
                        ->default('start')
                        ->native(false),

                    TextInput::make('overlay_opacity')
                        ->label(__('hero.fields.overlay'))
                        ->numeric()
                        ->minValue(0)
                        ->maxValue(95)
                        ->default(70)
                        ->suffix('%')
                        ->helperText(__('hero.hints.overlay')),
                ]),

            // -------------------------------------------- Publishing ------
            Section::make(__('hero.sections.publishing'))
                ->columns(3)
                ->schema([
                    Toggle::make('is_active')
                        ->label(__('admin.fields.is_active'))
                        ->default(true)
                        ->inline(false),

                    TextInput::make('display_order')
                        ->label(__('admin.fields.display_order'))
                        ->numeric()
                        ->default(0),

                    Grid::make(2)->columnSpanFull()->schema([
                        DateTimePicker::make('starts_at')
                            ->label(__('hero.fields.starts_at'))
                            ->seconds(false)
                            ->helperText(__('hero.hints.schedule')),

                        DateTimePicker::make('ends_at')
                            ->label(__('hero.fields.ends_at'))
                            ->seconds(false)
                            ->after('starts_at'),
                    ]),
                ]),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->modifyQueryUsing(fn (Builder $query) => $query->withTranslation()->with(['image', 'video']))
            ->defaultSort('display_order')
            // Slide order is the whole point of a slider, and dragging is the
            // only way to set it that does not require mental arithmetic.
            ->reorderable('display_order')
            ->columns([
                ImageColumn::make('image')
                    ->label('')
                    ->getStateUsing(fn (HeroSlide $record): ?string => $record->image?->urlFor(400))
                    ->height(56)
                    ->extraImgAttributes(['class' => 'rounded-sm object-cover']),

                TextColumn::make('title')
                    ->label(__('admin.fields.title'))
                    ->getStateUsing(fn (HeroSlide $record): string => $record->t('title') ?? __('hero.untitled'))
                    ->description(fn (HeroSlide $record): ?string => $record->t('subtitle'))
                    ->weight('medium')
                    ->wrap(),

                TextColumn::make('media_type')
                    ->label(__('hero.fields.media_type'))
                    ->badge()
                    ->formatStateUsing(fn (string $state): string => __('hero.types.'.$state))
                    ->color(fn (string $state): string => $state === HeroSlide::TYPE_VIDEO ? 'warning' : 'gray'),

                TextColumn::make('window')
                    ->label(__('hero.fields.schedule'))
                    ->getStateUsing(fn (HeroSlide $record): string => match (true) {
                        $record->starts_at && $record->ends_at => $record->starts_at->isoFormat('D MMM')
                            .' – '.$record->ends_at->isoFormat('D MMM YYYY'),
                        (bool) $record->starts_at => __('hero.schedule.from', ['date' => $record->starts_at->isoFormat('D MMM YYYY')]),
                        (bool) $record->ends_at => __('hero.schedule.until', ['date' => $record->ends_at->isoFormat('D MMM YYYY')]),
                        default => __('hero.schedule.always'),
                    })
                    ->color(fn (HeroSlide $record): string => $record->starts_at || $record->ends_at ? 'primary' : 'gray')
                    ->badge()
                    ->toggleable(),

                ToggleColumn::make('is_active')
                    ->label(__('admin.fields.is_active'))
                    ->disabled(fn (): bool => ! (Auth::user()?->can(Permissions::CONTENT_MANAGE) ?? false)),
            ])
            ->filters([
                TernaryFilter::make('is_active')->label(__('admin.fields.is_active')),
            ])
            ->recordActions([
                EditAction::make(),
                // Seasonal campaigns tend to be variations on one layout.
                ReplicateAction::make()
                    ->label(__('hero.actions.duplicate'))
                    ->excludeAttributes(['created_at', 'updated_at'])
                    ->after(function (HeroSlide $replica, HeroSlide $record): void {
                        foreach ($record->translations as $translation) {
                            $replica->translations()->create(
                                collect($translation->toArray())
                                    ->except(['id', 'hero_slide_id'])
                                    ->all()
                            );
                        }

                        $replica->forceFill([
                            'is_active' => false,
                            'display_order' => $record->display_order + 1,
                        ])->save();
                    }),
                DeleteAction::make(),
            ])
            ->toolbarActions([BulkActionGroup::make([DeleteBulkAction::make()])])
            ->emptyStateHeading(__('hero.empty.heading'))
            ->emptyStateDescription(__('hero.empty.description'));
    }

    /**
     * Internal destinations offered for the call-to-action.
     *
     * Named routes rather than typed URLs: the route resolves per locale, so
     * one slide links correctly on both /en and /ar. A literal "/en/products"
     * would send every Arabic visitor to the English site.
     *
     * @return array<string, string>
     */
    public static function routeOptions(): array
    {
        return [
            'quote.create' => __('site.cta.request_quote'),
            'products.index' => __('site.nav.products'),
            'packaging.index' => __('site.nav.packaging'),
            'about' => __('site.nav.about'),
            'quality' => __('site.nav.quality'),
            'export' => __('site.nav.export'),
            'private-label' => __('site.nav.private_label'),
            'news.index' => __('site.nav.news'),
            'contact.show' => __('site.nav.contact'),
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => ListHeroSlides::route('/'),
            'create' => CreateHeroSlide::route('/create'),
            'edit' => EditHeroSlide::route('/{record}/edit'),
        ];
    }
}
