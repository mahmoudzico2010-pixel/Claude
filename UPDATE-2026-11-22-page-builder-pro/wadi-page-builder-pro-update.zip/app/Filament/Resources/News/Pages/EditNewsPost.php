<?php

declare(strict_types=1);

namespace App\Filament\Resources\News\Pages;

use App\Filament\Concerns\HandlesTranslations;
use App\Filament\Resources\News\NewsPostResource;
use Filament\Actions\DeleteAction;
use Filament\Resources\Pages\EditRecord;

class EditNewsPost extends EditRecord
{
    use \App\Filament\Concerns\OffersAiTranslation;
    use HandlesTranslations;

    protected static string $resource = NewsPostResource::class;

    protected function getHeaderActions(): array
    {
        return [
            $this->aiTranslateAction(),DeleteAction::make()];
    }
}
