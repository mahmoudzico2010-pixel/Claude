<?php

declare(strict_types=1);

namespace App\Filament\Resources\News\Pages;

use App\Filament\Concerns\HandlesTranslations;
use App\Filament\Resources\News\NewsPostResource;
use Filament\Resources\Pages\CreateRecord;
use Illuminate\Support\Facades\Auth;

class CreateNewsPost extends CreateRecord
{
    use \App\Filament\Concerns\OffersAiTranslation;
    use HandlesTranslations;

    protected function getHeaderActions(): array
    {
        return [$this->aiTranslateAction()];
    }

    protected static string $resource = NewsPostResource::class;

    /**
     * @param  array<string, mixed>  $data
     * @return array<string, mixed>
     */
    protected function mutateFormDataBeforeCreate(array $data): array
    {
        $data['created_by'] = Auth::id();

        return $this->extractTranslations($data);
    }
}
