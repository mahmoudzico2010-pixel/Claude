<?php

declare(strict_types=1);

namespace App\Filament\Concerns;

use App\Services\Translation\AiTranslator;
use Filament\Actions\Action;
use Filament\Notifications\Notification;
use Throwable;

/**
 * "Translate with AI" for edit/create pages whose form uses `translations.<locale>.<field>` (see HandlesTranslations).
 * Fills only the EMPTY language boxes from the source language (English, else the first language that has text) and leaves
 * everything typed by hand alone. Nothing is saved until the editor presses Save.
 */
trait OffersAiTranslation
{
    protected function aiTranslateAction(): Action
    {
        return Action::make('aiTranslate')
            ->label(__('admin.ai.button'))
            ->icon('heroicon-m-language')
            ->color('info')
            ->requiresConfirmation()
            ->modalHeading(__('admin.ai.button'))
            ->modalDescription(__('admin.ai.confirm'))
            ->action(function (): void {
                $this->runAiTranslation();
            });
    }

    protected function runAiTranslation(): void
    {
        $state = $this->form->getRawState();
        $tr = (array) ($state['translations'] ?? []);
        $locales = array_keys((array) config('wadi.locales', []));

        $filled = fn ($v): bool => is_string($v) && trim(strip_tags($v)) !== '';
        $source = in_array('en', $locales, true) && collect($tr['en'] ?? [])->contains($filled) ? 'en'
            : collect($locales)->first(fn ($l) => collect($tr[$l] ?? [])->contains($filled));

        if ($source === null) {
            Notification::make()->title(__('admin.ai.nothing'))->warning()->send();

            return;
        }

        $translator = app(AiTranslator::class);
        $texts = array_filter((array) $tr[$source], $filled);
        $targets = array_values(array_filter($locales, fn ($l) => $l !== $source));

        try {
            $result = $translator->translate($texts, $source, $targets);
        } catch (Throwable $e) {
            Notification::make()->title($e->getMessage())->danger()->send();

            return;
        }

        $count = 0;
        foreach ($result as $locale => $fields) {
            foreach ($fields as $field => $value) {
                if (! $filled($tr[$locale][$field] ?? null)) {
                    $tr[$locale][$field] = $value;
                    $count++;
                }
            }
        }

        $state['translations'] = $tr;
        $this->form->fill($state);

        Notification::make()->title(__('admin.ai.done', ['count' => $count]))->body(__('admin.ai.review'))->success()->send();
    }
}
