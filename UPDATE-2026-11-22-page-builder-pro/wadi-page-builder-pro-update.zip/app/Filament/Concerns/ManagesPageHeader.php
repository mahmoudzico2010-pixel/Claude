<?php

declare(strict_types=1);

namespace App\Filament\Concerns;

use App\Filament\Forms\Components\MediaPicker;
use App\Models\MediaAsset;
use App\Services\PageHeaders\PageHeaderService;
use App\Support\Permissions;
use Filament\Forms\Components\ColorPicker;
use Filament\Forms\Components\Radio;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Components\ViewField;
use Filament\Notifications\Notification;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Tabs;
use Filament\Schemas\Components\Utilities\Get;
use Filament\Schemas\Schema;
use Illuminate\Support\Facades\Auth;

/** The "Page Header / Hero" settings panel: used inside the page builder AND by the stand-alone header editor. */
trait ManagesPageHeader
{
    public string $headerKey = '';

    /** @var array<string, mixed> */
    public ?array $headerData = [];

    public bool $headerUnpublished = false;

    public function loadHeader(string $key): void
    {
        $this->headerKey = $key;
        $d = app(PageHeaderService::class)->draft($key);
        $this->headerData = ['mode' => $d['mode']] + $d['settings'];
        $this->headerUnpublished = $d['unpublished'];
        $this->headerForm->fill($this->headerData);
    }

    protected function canEditHeader(): bool
    {
        return Auth::user()?->can(Permissions::CONTENT_MANAGE) ?? false;
    }

    public function headerForm(Schema $schema): Schema
    {
        $custom = fn (Get $get): bool => ($get('mode') ?? 'default') === 'custom';
        $locales = (array) config('wadi.locales', []);
        $slider = fn (string $name, string $label) => ViewField::make($name)->label($label)->view('filament.forms.percent-field')->live(debounce: 300)->afterStateUpdated(fn () => $this->saveHeader());

        return $schema->statePath('headerData')->components([
            Section::make(__('pageheader.title'))->description(__('pageheader.hint'))->schema([
                Radio::make('mode')->hiddenLabel()->live()->options([
                    'default' => __('pageheader.mode_default'), 'custom' => __('pageheader.mode_custom'), 'hidden' => __('pageheader.mode_hidden'),
                ])->descriptions([
                    'default' => __('pageheader.mode_default_help'), 'custom' => __('pageheader.mode_custom_help'), 'hidden' => __('pageheader.mode_hidden_help'),
                ])->afterStateUpdated(fn () => $this->saveHeader()),
            ]),

            Section::make(__('pageheader.sec_background'))->visible($custom)->schema([
                MediaPicker::make('image_id', __('pageheader.image'), 'headers')->live()->afterStateUpdated(fn () => $this->saveHeader()),
                ViewField::make('thumb')->hiddenLabel()->view('filament.forms.header-thumb')->viewData(fn (Get $get) => ['media' => $get('image_id') ? MediaAsset::query()->find($get('image_id')) : null, 'label' => __('pageheader.no_image_note')]),
                ColorPicker::make('bg_color')->label(__('pageheader.bg_color'))->helperText(__('pageheader.bg_color_help'))->live()->afterStateUpdated(fn () => $this->saveHeader()),
                Select::make('fit')->label(__('pageheader.fit'))->native(false)->live()->options(['cover' => __('pageheader.fit_cover'), 'contain' => __('pageheader.fit_contain')])->afterStateUpdated(fn () => $this->saveHeader()),
                $slider('focal_x', __('pageheader.focal_x')),
                $slider('focal_y', __('pageheader.focal_y')),
                MediaPicker::make('mobile_image_id', __('pageheader.mobile_image'), 'headers')->live()->afterStateUpdated(fn () => $this->saveHeader()),
                ViewField::make('crop')->hiddenLabel()->view('filament.forms.header-crop-preview')->viewData(fn (Get $get) => [
                    'desktop' => $get('image_id') ? MediaAsset::query()->find($get('image_id')) : null,
                    'mobile' => $get('mobile_image_id') ? MediaAsset::query()->find($get('mobile_image_id')) : null,
                    'x' => (int) ($get('focal_x') ?? 50), 'y' => (int) ($get('focal_y') ?? 50), 'fit' => $get('fit') ?? 'cover',
                ]),
                $slider('image_opacity', __('pageheader.image_opacity'))->helperText(__('pageheader.image_opacity_help')),
            ]),

            Section::make(__('pageheader.sec_overlay'))->visible($custom)->schema([
                ColorPicker::make('overlay_color')->label(__('pageheader.overlay_color'))->live()->afterStateUpdated(fn () => $this->saveHeader()),
                $slider('overlay_opacity', __('pageheader.overlay_opacity'))->helperText(__('pageheader.overlay_opacity_help')),
            ]),

            Section::make(__('pageheader.sec_layout'))->visible($custom)->columns(2)->schema([
                TextInput::make('height_desktop')->label(__('pageheader.height_desktop'))->numeric()->suffix('px')->minValue(120)->maxValue(900)->live(onBlur: true)->afterStateUpdated(fn () => $this->saveHeader()),
                TextInput::make('height_mobile')->label(__('pageheader.height_mobile'))->numeric()->suffix('px')->minValue(100)->maxValue(700)->live(onBlur: true)->afterStateUpdated(fn () => $this->saveHeader()),
                TextInput::make('pad_desktop')->label(__('pageheader.pad_desktop'))->numeric()->suffix('px')->minValue(0)->maxValue(300)->live(onBlur: true)->afterStateUpdated(fn () => $this->saveHeader()),
                TextInput::make('pad_mobile')->label(__('pageheader.pad_mobile'))->numeric()->suffix('px')->minValue(0)->maxValue(200)->live(onBlur: true)->afterStateUpdated(fn () => $this->saveHeader()),
                Select::make('align')->label(__('pageheader.align'))->native(false)->live()->options(['start' => __('pageheader.align_start'), 'center' => __('pageheader.align_center'), 'end' => __('pageheader.align_end')])->afterStateUpdated(fn () => $this->saveHeader()),
                ColorPicker::make('text_color')->label(__('pageheader.text_color'))->live()->afterStateUpdated(fn () => $this->saveHeader()),
            ]),

            Section::make(__('pageheader.sec_content'))->visible($custom)->schema([
                Toggle::make('show_breadcrumb')->label(__('pageheader.show_breadcrumb'))->live()->afterStateUpdated(fn () => $this->saveHeader()),
                \App\Filament\Forms\Components\AiTranslateButton::make(['eyebrow', 'title', 'subtitle'], 'after', '', fn ($lw) => $lw->saveHeader()),
                Tabs::make('texts')->tabs(collect($locales)->map(fn ($v, $code) => Tabs\Tab::make(strtoupper($code))->schema([
                    TextInput::make("eyebrow.$code")->label(__('pageheader.eyebrow'))->placeholder(__('pageheader.use_page_text'))->maxLength(300)->extraInputAttributes($this->dirAttr($code))->live(onBlur: true)->afterStateUpdated(fn () => $this->saveHeader()),
                    TextInput::make("title.$code")->label(__('pageheader.page_title'))->placeholder(__('pageheader.use_page_text'))->maxLength(300)->extraInputAttributes($this->dirAttr($code))->live(onBlur: true)->afterStateUpdated(fn () => $this->saveHeader()),
                    TextInput::make("subtitle.$code")->label(__('pageheader.subtitle'))->placeholder(__('pageheader.use_page_text'))->maxLength(300)->extraInputAttributes($this->dirAttr($code))->live(onBlur: true)->afterStateUpdated(fn () => $this->saveHeader()),
                ]))->values()->all()),
            ]),
        ]);
    }

    /** @return array<string, string> */
    private function dirAttr(string $code): array
    {
        return ['dir' => in_array($code, ['ar', 'ur'], true) ? 'rtl' : 'ltr'];
    }

    /** Autosave the DRAFT (never what visitors see) and refresh the preview. */
    public function saveHeader(): void
    {
        if (! $this->canEditHeader() || $this->headerKey === '') {
            return;
        }
        $data = (array) $this->headerData;
        $mode = in_array($data['mode'] ?? 'default', PageHeaderService::MODES, true) ? $data['mode'] : 'default';
        // Images the form cleared come back as null/'' : normalise so "remove image" really removes it.
        foreach (['image_id', 'mobile_image_id'] as $k) {
            $data[$k] = filled($data[$k] ?? null) ? (int) $data[$k] : null;
        }
        $svc = app(PageHeaderService::class);
        $svc->saveDraft($this->headerKey, $mode, $data, Auth::user());
        $this->headerUnpublished = $svc->draft($this->headerKey)['unpublished'];
        $this->afterHeaderSaved();
    }

    /** Hook for the host page: reload its preview frame. */
    protected function afterHeaderSaved(): void
    {
        $this->dispatch('builder-refresh', url: $this->headerPreviewUrl());
    }

    public function headerPreviewUrl(): string
    {
        $d = app(PageHeaderService::class)->draft($this->headerKey);

        return route('admin.builder.header-preview', ['key' => $this->headerKey, 'locale' => app()->getLocale(), 'h' => md5(json_encode($d))]);
    }

    public function publishHeader(): void
    {
        abort_unless($this->canEditHeader(), 403);
        $this->saveHeader();
        app(PageHeaderService::class)->publish($this->headerKey, Auth::user());
        $this->headerUnpublished = false;
        Notification::make()->success()->title(__('pageheader.published'))->send();
    }

    public function discardHeader(): void
    {
        abort_unless($this->canEditHeader(), 403);
        app(PageHeaderService::class)->discard($this->headerKey);
        $this->loadHeader($this->headerKey);
        $this->afterHeaderSaved();
        Notification::make()->success()->title(__('pageheader.discarded'))->send();
    }
}
