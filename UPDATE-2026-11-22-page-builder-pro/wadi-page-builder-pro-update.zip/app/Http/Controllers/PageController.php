<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\Certification;
use App\Models\ContentBlock;
use App\Models\ExportMarket;
use App\Models\Page;
use App\Services\Launch\LaunchReadiness;
use App\Services\Seo\SeoData;
use App\Support\Permissions;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\Auth;

class PageController extends Controller
{
    public function about(): View
    {
        return $this->renderKeyed('about', 'pages.about', [
            'values' => ContentBlock::query()->section(ContentBlock::SECTION_VALUES)->active()->ordered()->get(),
            'statistics' => ContentBlock::query()->section(ContentBlock::SECTION_STATISTICS)->active()->ordered()->get(),
            'showStatistics' => app(LaunchReadiness::class)->showStatistics(),
            'productionSteps' => ContentBlock::query()->section(ContentBlock::SECTION_PRODUCTION)->active()->ordered()->get(),
        ]);
    }

    public function quality(): View
    {
        return $this->renderKeyed('quality', 'pages.quality', [
            'certifications' => Certification::query()
                ->active()
                ->where(function ($q): void {
                    $q->whereNotNull('logo_id')->orWhereNotNull('document_id');
                })
                ->ordered()->with(['logo', 'document'])->get(),
            'showCertifications' => app(LaunchReadiness::class)->showCertifications(),
            'qualityPoints' => ContentBlock::query()->section(ContentBlock::SECTION_QUALITY)->active()->ordered()->get(),
        ]);
    }

    public function export(): View
    {
        return $this->renderKeyed('export', 'pages.export', [
            'markets' => ExportMarket::query()->active()->ordered()->get(),
            'services' => ContentBlock::query()->section(ContentBlock::SECTION_EXPORT_SERVICES)->active()->ordered()->get(),
        ]);
    }

    public function privateLabel(): View
    {
        return $this->renderKeyed('private-label', 'pages.private-label', [
            'benefits' => ContentBlock::query()->section(ContentBlock::SECTION_PRIVATE_LABEL)->active()->ordered()->get(),
        ]);
    }

    public function privacy(): View
    {
        return $this->renderKeyed('privacy', 'pages.legal');
    }

    public function terms(): View
    {
        return $this->renderKeyed('terms', 'pages.legal');
    }

    /**
     * Catch-all for any other published page created in the panel.
     */
    public function show(string $locale, string $page): View
    {
        $record = Page::query()
            ->withTranslation()
            ->with(['featuredImage', 'seoImage'])
            ->where('slug', $page)
            ->firstOrFail();

        $this->assertViewable($record);

        if ($built = $this->builderPayload($record)) {
            return view('pages.built', ['seo' => $this->seoFor($record), 'page' => $record, 'payload' => $built]);
        }

        return view('pages.generic', [
            'seo' => $this->seoFor($record),
            'page' => $record,
        ]);
    }

    /** The published visual layout of a page, or null when it has none (the page then renders as before). */
    private function builderPayload(Page $page): ?array
    {
        // "Use basic version" in the editor: the builder layout is kept but the page shows its original content.
        if (\App\Services\Builder\BasicMode::isBasic($page->slug)) {
            return null;
        }

        $payload = app(\App\Services\Builder\PageRenderer::class)->payload('page:'.$page->slug, app()->getLocale());

        return ! empty($payload['nodes']) ? $payload : null;
    }

    /**
     * Resolve a built-in page by its stable key so renaming the slug in the
     * panel never breaks the route.
     *
     * @param  array<string, mixed>  $extra
     */
    private function renderKeyed(string $key, string $view, array $extra = []): View
    {
        $page = Page::query()
            ->withTranslation()
            ->with(['featuredImage', 'seoImage'])
            ->where('key', $key)
            ->first();

        abort_if($page === null, 404);

        $this->assertViewable($page);

        if ($built = $this->builderPayload($page)) {
            return view('pages.built', ['seo' => $this->seoFor($page), 'page' => $page, 'payload' => $built]);
        }

        return view($view, array_merge([
            'seo' => $this->seoFor($page),
            'page' => $page,
        ], $extra));
    }

    /**
     * A page awaiting legal review is invisible to the public but must stay
     * previewable, or the reviewer cannot see what they are approving.
     *
     * Signed-in staff who may manage content see it with a noindex header;
     * everyone else gets a plain 404.
     */
    private function assertViewable(Page $page): void
    {
        if ($page->isPubliclyVisible()) {
            return;
        }

        abort_unless(
            Auth::check() && Auth::user()?->can(Permissions::CONTENT_VIEW),
            404
        );
    }

    private function seoFor(Page $page): SeoData
    {
        return SeoData::make()
            ->title($page->t('seo_title') ?: $page->t('title'))
            ->description($page->t('seo_description') ?: $page->t('subtitle'))
            ->image($page->seoImage ?? $page->featuredImage)
            // An unreviewed page previewed by staff must never be indexed.
            ->noindex(! $page->isPubliclyVisible())
            ->breadcrumbs([
                ['label' => __('site.home'), 'url' => route('home')],
                ['label' => (string) $page->t('title'), 'url' => null],
            ]);
    }
}
