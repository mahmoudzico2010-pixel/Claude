<?php

declare(strict_types=1);

namespace App\Models\Concerns;

use Illuminate\Database\Eloquent\Builder;

/**
 * For the small lookup tables that keep their Arabic and English values in
 * sibling columns (`name_en` / `name_ar`) rather than a translations table.
 *
 * `$model->localized('name')` returns the value for the active locale and
 * falls back to the other language when one side is blank.
 */
trait HasBilingualFields
{
    /** @var array<string, array<string, mixed>> locale => field => text, written to content_translations after the model is saved */
    protected array $pendingExtra = [];

    public function initializeHasBilingualFields(): void
    {
        $this->mergeFillable(['extra']);
    }

    public static function bootHasBilingualFields(): void
    {
        static::saved(function ($model): void {
            if ($model->pendingExtra !== []) {
                $model->persistExtraTranslations($model->pendingExtra);
                $model->pendingExtra = [];
            }
        });
    }

    /** Form input `extra.<locale>.<field>`: texts in the languages beyond the _en/_ar columns. */
    public function setExtraAttribute(mixed $value): void
    {
        $this->pendingExtra = is_array($value) ? $value : [];
    }

    public function extraValue(string $locale, string $field): ?string
    {
        return $this->getKey() === null ? null : \App\Models\ContentTranslation::lookup($this->getTable(), (int) $this->getKey(), $locale, $field);
    }

    /** @param array<string, array<string, mixed>> $extra */
    public function persistExtraTranslations(array $extra): void
    {
        $known = array_keys((array) config('wadi.locales', []));
        foreach ($extra as $locale => $fields) {
            if (! is_array($fields) || ! in_array($locale, $known, true) || in_array($locale, ['en', 'ar'], true)) {
                continue;
            }
            foreach ($fields as $field => $value) {
                if (! preg_match('/^[a-z_]+$/', (string) $field)) {
                    continue;
                }
                $keys = ['entity' => $this->getTable(), 'entity_id' => (int) $this->getKey(), 'locale' => $locale, 'field' => (string) $field];
                $value = trim((string) $value);
                $row = \App\Models\ContentTranslation::query()->where($keys)->first();
                if ($value === '') {
                    $row?->delete();

                    continue;
                }
                if ($row === null) {
                    \App\Models\ContentTranslation::create($keys + ['value' => $value, 'value_hash' => sha1($value), 'origin' => 'human']);
                } elseif ($row->value !== $value) {
                    $row->update(['value' => $value, 'value_hash' => sha1($value), 'origin' => 'human']);
                }
            }
        }
        \App\Models\ContentTranslation::forget();
    }

    public function localized(string $field, ?string $locale = null): ?string
    {
        $locale ??= app()->getLocale();
        $fallback = config('app.fallback_locale', 'en');

        $value = $this->{$field.'_'.$locale} ?? null;

        // Languages beyond the two sibling columns live in content_translations.
        if (($value === null || $value === '') && $locale !== 'en' && $locale !== 'ar' && $this->getKey() !== null) {
            $value = \App\Models\ContentTranslation::lookup($this->getTable(), (int) $this->getKey(), $locale, $field);
        }

        if ($value === null || $value === '') {
            $value = $this->{$field.'_'.$fallback} ?? null;
        }

        // Still empty: use whatever locale does have content.
        if ($value === null || $value === '') {
            foreach (array_keys(config('wadi.locales', [])) as $candidate) {
                $alt = $this->{$field.'_'.$candidate} ?? null;
                if ($alt !== null && $alt !== '') {
                    return $alt;
                }
            }
        }

        return $value ?: null;
    }

    public function getNameAttribute(): ?string
    {
        return $this->localized('name');
    }

    public function scopeActive(Builder $query): Builder
    {
        return $query->where('is_active', true);
    }

    public function scopeOrdered(Builder $query): Builder
    {
        return $query->orderBy('display_order')->orderBy('id');
    }
}
