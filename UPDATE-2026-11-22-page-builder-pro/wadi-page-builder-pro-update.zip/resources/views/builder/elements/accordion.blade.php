@include('builder.elements._graphic-css')
@php $multi = ($settings['allow_multiple'] ?? 'off') === 'on'; $first = ($settings['first_open'] ?? 'on') === 'on'; $acc = preg_match('/^#[0-9a-fA-F]{3,8}$/', (string) ($settings['accent'] ?? '')) ? $settings['accent'] : null; $gid = 'acc'.$node['id']; @endphp
<div data-builder-node="{{ $node['id'] }}" class="wr-node wr-g-acc" @if ($acc) style="--wr-acc:{{ $acc }}" @endif>
    @foreach ((array) ($node['children'] ?? []) as $i => $child)
        @if (filled($child['content']['title'] ?? null))
            <details data-builder-node="{{ $child['id'] }}" @if ($first && $i === 0) open @endif @if (! $multi) name="{{ $gid }}" @endif>
                <summary>{{ $child['content']['title'] }}</summary>
                <div class="body">{!! nl2br(e($child['content']['body'] ?? '')) !!}</div>
            </details>
        @endif
    @endforeach
</div>
