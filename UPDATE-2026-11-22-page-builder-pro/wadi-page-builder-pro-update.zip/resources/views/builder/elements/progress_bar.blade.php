@include('builder.elements._graphic-css')
@php $v = max(0, min(100, (int) ($settings['value'] ?? 80))); $h = max(4, min(40, (int) ($settings['height'] ?? 10))); $col = preg_match('/^#[0-9a-fA-F]{3,8}$/', (string) ($settings['color'] ?? '')) ? $settings['color'] : null; @endphp
<div data-builder-node="{{ $node['id'] }}" class="wr-node wr-g-pb" @if ($col) style="--wr-pb:{{ $col }}" @endif>
    <div class="row"><span>{{ $content['label'] ?? '' }}</span>@if (($settings['show_value'] ?? 'on') === 'on')<span>{{ $v }}%</span>@endif</div>
    <div class="track" role="progressbar" aria-valuenow="{{ $v }}" aria-valuemin="0" aria-valuemax="100" style="height:{{ $h }}px"><div class="fill" style="width:{{ $v }}%"></div></div>
</div>
