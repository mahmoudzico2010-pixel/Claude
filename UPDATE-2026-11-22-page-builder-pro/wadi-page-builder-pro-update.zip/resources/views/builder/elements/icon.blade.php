@include('builder.elements._graphic-css')
<div data-builder-node="{{ $node['id'] }}" class="wr-node wr-icon" style="text-align:center">
    @include('builder.elements._icon', ['name' => $settings['name'] ?? 'check', 'size' => $settings['size'] ?? 48, 'style' => $settings['style'] ?? 'plain', 'color' => $settings['color'] ?? '', 'background' => $settings['background'] ?? ''])
    @if (filled($content['label'] ?? null))<p style="margin-top:.5rem;font-weight:600;color:#14281f">{{ $content['label'] }}</p>@endif
</div>
