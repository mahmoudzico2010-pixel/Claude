@include('builder.elements._graphic-css')
@php
    $shape = in_array($settings['shape'] ?? 'wave', ['wave', 'curve', 'tilt', 'triangle', 'zigzag', 'arc'], true) ? $settings['shape'] : 'wave';
    $paths = [
        'wave' => 'M0 40 C 180 90 360 0 540 40 S 900 90 1080 40 S 1260 10 1440 40 V100 H0 Z',
        'curve' => 'M0 0 C 480 100 960 100 1440 0 V100 H0 Z',
        'tilt' => 'M0 100 L1440 0 V100 Z',
        'triangle' => 'M0 100 H640 L720 20 L800 100 H1440 V100 H0 Z',
        'zigzag' => 'M0 100 L60 40 L120 100 L180 40 L240 100 L300 40 L360 100 L420 40 L480 100 L540 40 L600 100 L660 40 L720 100 L780 40 L840 100 L900 40 L960 100 L1020 40 L1080 100 L1140 40 L1200 100 L1260 40 L1320 100 L1380 40 L1440 100 Z',
        'arc' => 'M0 100 A 720 100 0 0 1 1440 100 Z',
    ];
    $col = preg_match('/^#[0-9a-fA-F]{3,8}$/', (string) ($settings['color'] ?? '')) ? $settings['color'] : '#ffffff';
    $bg = preg_match('/^#[0-9a-fA-F]{3,8}$/', (string) ($settings['background'] ?? '')) ? $settings['background'] : 'transparent';
    $h = max(20, min(400, (int) ($settings['height'] ?? 80)));
    $flip = ($settings['flip'] ?? 'off') === 'on';
    $invert = ($settings['invert'] ?? 'off') === 'on';
@endphp
<div data-builder-node="{{ $node['id'] }}" class="wr-node wr-g-shape" aria-hidden="true" style="height:{{ $h }}px;background:{{ $bg }};transform:{{ ($flip ? 'scaleX(-1) ' : '').($invert ? 'scaleY(-1)' : '') }}">
    <svg viewBox="0 0 1440 100" preserveAspectRatio="none" style="height:100%"><path d="{{ $paths[$shape] }}" fill="{{ $col }}"/></svg>
</div>
