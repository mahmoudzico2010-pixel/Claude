@php
    $__icons = [];
    $__name = $name ?? 'check';
    $__size = max(12, min(160, (int) ($size ?? 32)));
    $__style = in_array($style ?? 'plain', ['plain', 'circle', 'square', 'outline'], true) ? ($style ?? 'plain') : 'plain';
    $__box = $__style === 'plain' ? $__size : (int) round($__size * 1.9);
    $__c = preg_match('/^(#[0-9a-fA-F]{3,8}|var\(--[a-z0-9-]+\))$/', (string) ($color ?? '')) ? $color : null;
    $__bg = preg_match('/^(#[0-9a-fA-F]{3,8}|var\(--[a-z0-9-]+\))$/', (string) ($background ?? '')) ? $background : null;
@endphp
<span class="wr-g-iconwrap is-{{ $__style }}" aria-hidden="true" style="width:{{ $__box }}px;height:{{ $__box }}px;@if($__c)--wr-g-color:{{ $__c }};@endif @if($__bg)--wr-g-bg:{{ $__bg }};@endif">
    <svg width="{{ $__size }}" height="{{ $__size }}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">{!! \App\Support\Builder\Icons3D::inner($__name) !!}</svg>
</span>
