@include('builder.elements._graphic-css')
@php $photo = $node['media'][(int) ($settings['photo'] ?? 0)] ?? null; $rating = max(0, min(5, (int) ($settings['rating'] ?? 5))); @endphp
<figure data-builder-node="{{ $node['id'] }}" class="wr-node wr-g-testi {{ ($settings['card'] ?? 'on') === 'on' ? 'wr-g-card' : '' }}" style="margin:0;text-align:{{ ($settings['align'] ?? 'start') === 'center' ? 'center' : 'start' }}">
    @if ($rating > 0)<div class="wr-g-stars" role="img" aria-label="{{ $rating }}/5">@for ($i = 0; $i < 5; $i++)<svg width="18" height="18" viewBox="0 0 24 24" fill="{{ $i < $rating ? 'currentColor' : 'none' }}" stroke="currentColor" stroke-width="1.5"><path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/></svg>@endfor</div>@endif
    @if (filled($content['quote'] ?? null))<blockquote style="margin-top:.7rem">“{{ $content['quote'] }}”</blockquote>@endif
    <figcaption class="who" style="{{ ($settings['align'] ?? 'start') === 'center' ? 'justify-content:center' : '' }}">
        @if ($photo)<img src="{{ $photo }}" alt="" loading="lazy" decoding="async">@endif
        <div><b>{{ $content['name'] ?? '' }}</b><span>{{ $content['role'] ?? '' }}</span></div>
    </figcaption>
</figure>
