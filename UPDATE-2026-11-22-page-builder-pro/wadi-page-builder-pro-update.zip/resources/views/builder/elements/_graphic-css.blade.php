@once
<style>
.wr-g-iconwrap{display:inline-flex;align-items:center;justify-content:center;flex:none;color:var(--wr-g-color,#1f5a43)}
.wr-g-iconwrap.is-circle{border-radius:50%;background:var(--wr-g-bg,rgba(31,90,67,.12))}
.wr-g-iconwrap.is-square{border-radius:16px;background:var(--wr-g-bg,rgba(31,90,67,.12))}
.wr-g-iconwrap.is-outline{border-radius:50%;border:2px solid currentColor}
.wr-g-card{background:rgba(255,255,255,.62);-webkit-backdrop-filter:blur(14px);backdrop-filter:blur(14px);border:1px solid rgba(255,255,255,.8);border-radius:22px;box-shadow:0 10px 32px rgba(20,60,45,.1);padding:1.5rem}
.wr-g-iconbox{display:flex;gap:1rem;flex-direction:column}
.wr-g-iconbox.is-side{flex-direction:row;align-items:flex-start}
.wr-g-iconbox.a-center{align-items:center;text-align:center}.wr-g-iconbox.a-end{align-items:flex-end;text-align:end}
.wr-g-iconbox h3{font-size:1.15rem;font-weight:700;color:#14281f}.wr-g-iconbox p{margin-top:.4rem;color:#4a5a52;line-height:1.7}
.wr-g-iconbox a.more{display:inline-block;margin-top:.7rem;font-weight:600;color:#14382a;text-decoration:underline}
.wr-g-list{list-style:none;padding:0;margin:0;display:flex;flex-direction:column}
.wr-g-list li{display:flex;gap:.7rem;align-items:flex-start}
.wr-g-shape{display:block;line-height:0;width:100%;overflow:hidden}.wr-g-shape svg{display:block;width:100%}
.wr-g-cta{position:relative;overflow:hidden;color:var(--wr-cta-color,#fff);padding:clamp(1.75rem,4vw,3.25rem);display:flex;flex-wrap:wrap;gap:1.5rem;align-items:center;justify-content:space-between}
.wr-g-cta.a-center{justify-content:center;text-align:center;flex-direction:column}.wr-g-cta.a-end{flex-direction:row-reverse}
.wr-g-cta h2{font-size:clamp(1.5rem,3vw,2.2rem);font-weight:700}.wr-g-cta p{margin-top:.6rem;opacity:.85;max-width:38rem}
.wr-g-cta .btn-g{display:inline-block;padding:.85rem 1.6rem;border-radius:999px;background:#fff;color:#14382a;font-weight:700;box-shadow:0 8px 22px rgba(0,0,0,.2)}
.wr-g-cta .pat{position:absolute;inset:0;opacity:.12;background-image:radial-gradient(circle at 20% 20%,#fff 0 2px,transparent 3px),radial-gradient(circle at 70% 60%,#fff 0 2px,transparent 3px);background-size:42px 42px;pointer-events:none}
.wr-g-cta>*{position:relative}
.wr-g-testi blockquote{margin:0;font-size:1.1rem;line-height:1.8;color:#2b3b33}
.wr-g-testi .who{display:flex;align-items:center;gap:.8rem;margin-top:1.1rem}.wr-g-testi .who img{width:3rem;height:3rem;border-radius:50%;object-fit:cover}
.wr-g-testi .who b{display:block;color:#14281f}.wr-g-testi .who span{font-size:.85rem;color:#6a7a71}
.wr-g-stars{display:inline-flex;gap:.15rem;color:var(--wr-star,#b8903a)}
.wr-g-acc details{border:1px solid rgba(20,56,42,.14);border-radius:16px;background:rgba(255,255,255,.6);margin-bottom:.7rem;overflow:hidden}
.wr-g-acc summary{cursor:pointer;list-style:none;padding:1rem 1.25rem;font-weight:700;color:#14281f;display:flex;justify-content:space-between;gap:1rem;align-items:center}
.wr-g-acc summary::-webkit-details-marker{display:none}.wr-g-acc summary::after{content:"+";font-size:1.4rem;line-height:1;color:var(--wr-acc,#b8903a);transition:transform .2s}
.wr-g-acc details[open] summary::after{transform:rotate(45deg)}.wr-g-acc .body{padding:0 1.25rem 1.1rem;color:#43544b;line-height:1.8}
.wr-g-tl{position:relative;padding-inline-start:1.8rem}.wr-g-tl::before{content:"";position:absolute;inset-block:.4rem;inset-inline-start:.45rem;width:2px;background:var(--wr-tl-line,#b8903a)}
.wr-g-tl .item{position:relative;padding-bottom:1.6rem}.wr-g-tl .item::before{content:"";position:absolute;inset-inline-start:-1.8rem;top:.35rem;width:.95rem;height:.95rem;border-radius:50%;background:var(--wr-tl-dot,#14382a);border:3px solid #fff;box-shadow:0 0 0 2px var(--wr-tl-line,#b8903a)}
.wr-g-tl .date{font-size:.8rem;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--wr-tl-line,#b8903a)}.wr-g-tl h4{font-weight:700;color:#14281f;margin-top:.15rem}.wr-g-tl p{color:#4a5a52;margin-top:.3rem;line-height:1.7}
.wr-g-pb .row{display:flex;justify-content:space-between;font-weight:600;color:#14281f;margin-bottom:.4rem}.wr-g-pb .track{background:rgba(20,56,42,.12);border-radius:999px;overflow:hidden}.wr-g-pb .fill{height:100%;border-radius:999px;background:var(--wr-pb,#1f6b4f)}
.wr-g-badge{display:inline-flex;align-items:center;gap:.4rem;padding:.3rem .85rem;border-radius:999px;font-size:.8rem;font-weight:700;letter-spacing:.04em;border:1.5px solid var(--wr-bd,#14382a)}
.wr-g-badge.solid{background:var(--wr-bd);color:#fff}.wr-g-badge.soft{background:color-mix(in srgb,var(--wr-bd) 14%,transparent);color:var(--wr-bd);border-color:transparent}.wr-g-badge.outline{color:var(--wr-bd);background:transparent}
.wr-g-imgbox{position:relative;overflow:hidden;display:flex;align-items:flex-end;color:#fff;background:#14382a}
.wr-g-imgbox img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;transition:transform .5s}.wr-g-imgbox:hover img{transform:scale(1.05)}
.wr-g-imgbox .ov{position:absolute;inset:0}.wr-g-imgbox .tx{position:relative;padding:1.4rem;width:100%}.wr-g-imgbox h3{font-size:1.3rem;font-weight:700}.wr-g-imgbox p{opacity:.9;margin-top:.3rem}
.wr-g-social{display:flex;flex-wrap:wrap;gap:.6rem}
</style>
@endonce
