@include('builder.elements._graphic-css')
@php $st = in_array($settings['style'] ?? 'solid', ['solid', 'soft', 'outline'], true) ? $settings['style'] : 'solid'; $col = preg_match('/^#[0-9a-fA-F]{3,8}$/', (string) ($settings['color'] ?? '')) ? $settings['color'] : '#14382a'; @endphp
@if (filled($content['text'] ?? null))
<span data-builder-node="{{ $node['id'] }}" class="wr-node wr-g-badge {{ $st }}" style="--wr-bd:{{ $col }}">@if (filled($settings['name'] ?? null))@include('builder.elements._icon', ['name' => $settings['name'], 'size' => 14, 'style' => 'plain', 'color' => 'currentColor'])@endif{{ $content['text'] }}</span>
@endif
