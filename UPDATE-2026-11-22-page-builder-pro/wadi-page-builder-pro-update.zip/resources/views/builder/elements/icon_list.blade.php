@include('builder.elements._graphic-css')
<ul data-builder-node="{{ $node['id'] }}" class="wr-node wr-g-list" style="gap:{{ max(0, min(48, (int) ($settings['gap'] ?? 12))) }}px">
    @foreach ((array) ($node['children'] ?? []) as $child)
        @php($cs = (array) ($child['settings'] ?? []))
        @if (filled($child['content']['text'] ?? null))
            <li data-builder-node="{{ $child['id'] }}">@include('builder.elements._icon', ['name' => ($cs['name'] ?? '') ?: ($settings['name'] ?? 'check'), 'size' => 22, 'style' => 'plain', 'color' => $settings['color'] ?? ''])<span style="line-height:1.7">{{ $child['content']['text'] }}</span></li>
        @endif
    @endforeach
</ul>
