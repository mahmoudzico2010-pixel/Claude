@include('builder.elements._graphic-css')
@php
    $img = $node['media'][(int) ($settings['image'] ?? 0)] ?? null; $href = \App\Support\Builder\SafeLink::href($settings['link_url'] ?? '');
    $h = max(120, min(900, (int) ($settings['height'] ?? 320))); $r = max(0, min(60, (int) ($settings['radius'] ?? 20)));
    $oc = preg_match('/^#[0-9a-fA-F]{3,8}$/', (string) ($settings['overlay_color'] ?? '')) ? $settings['overlay_color'] : '#0b2a1f'; $oo = max(0, min(100, (int) ($settings['overlay_opacity'] ?? 45)));
    $al = in_array($settings['align'] ?? 'start', ['start', 'center', 'end'], true) ? $settings['align'] : 'start';
@endphp
@if ($href)
<a href="{{ $href }}" data-builder-node="{{ $node['id'] }}" class="wr-node wr-g-imgbox" style="height:{{ $h }}px;border-radius:{{ $r }}px;text-align:{{ $al }};display:flex">
@else
<div data-builder-node="{{ $node['id'] }}" class="wr-node wr-g-imgbox" style="height:{{ $h }}px;border-radius:{{ $r }}px;text-align:{{ $al }};display:flex">
@endif
    @if ($img)<img src="{{ $img }}" alt="" loading="lazy" decoding="async">@endif
    <span class="ov" style="background:linear-gradient(180deg,transparent 30%,{{ $oc }});opacity:{{ $oo / 100 }}"></span>
    <span class="tx">@if (filled($content['title'] ?? null))<h3>{{ $content['title'] }}</h3>@endif @if (filled($content['text'] ?? null))<p>{{ $content['text'] }}</p>@endif</span>
@if ($href)
</a>
@else
</div>
@endif
