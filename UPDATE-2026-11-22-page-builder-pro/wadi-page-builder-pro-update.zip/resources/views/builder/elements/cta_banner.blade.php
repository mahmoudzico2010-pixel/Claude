@include('builder.elements._graphic-css')
@php
    $c = fn ($v, $d) => preg_match('/^#[0-9a-fA-F]{3,8}$/', (string) $v) ? $v : $d;
    $from = $c($settings['gradient_from'] ?? '', '#14382a'); $to = $c($settings['gradient_to'] ?? '', '#1f6b4f'); $txt = $c($settings['text_color'] ?? '', '#ffffff');
    $angle = max(0, min(360, (int) ($settings['angle'] ?? 135))); $radius = max(0, min(60, (int) ($settings['radius'] ?? 24)));
    $href = \App\Support\Builder\SafeLink::href($settings['button_url'] ?? '');
    $al = in_array($settings['align'] ?? 'start', ['start', 'center', 'end'], true) ? $settings['align'] : 'start';
@endphp
<section data-builder-node="{{ $node['id'] }}" class="wr-node wr-g-cta a-{{ $al }}" style="background:linear-gradient({{ $angle }}deg,{{ $from }},{{ $to }});--wr-cta-color:{{ $txt }};border-radius:{{ $radius }}px">
    @if (($settings['pattern'] ?? 'on') === 'on')<span class="pat" aria-hidden="true"></span>@endif
    <div>
        @if (filled($content['heading'] ?? null))<h2>{{ $content['heading'] }}</h2>@endif
        @if (filled($content['text'] ?? null))<p>{{ $content['text'] }}</p>@endif
    </div>
    @if ($href && filled($content['button_label'] ?? null))<a class="btn-g" href="{{ $href }}">{{ $content['button_label'] }}</a>@endif
</section>
