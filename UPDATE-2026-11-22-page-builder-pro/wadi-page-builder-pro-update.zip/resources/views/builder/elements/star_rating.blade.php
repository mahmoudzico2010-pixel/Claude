@include('builder.elements._graphic-css')
@php $r = max(0, min(5, (int) ($settings['rating'] ?? 5))); $sz = max(12, min(64, (int) ($settings['size'] ?? 24))); $col = preg_match('/^#[0-9a-fA-F]{3,8}$/', (string) ($settings['color'] ?? '')) ? $settings['color'] : null; @endphp
<div data-builder-node="{{ $node['id'] }}" class="wr-node" style="display:flex;align-items:center;gap:.6rem">
    <span class="wr-g-stars" role="img" aria-label="{{ $r }}/5" @if ($col) style="--wr-star:{{ $col }}" @endif>@for ($i = 0; $i < 5; $i++)<svg width="{{ $sz }}" height="{{ $sz }}" viewBox="0 0 24 24" fill="{{ $i < $r ? 'currentColor' : 'none' }}" stroke="currentColor" stroke-width="1.5"><path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/></svg>@endfor</span>
    @if (filled($content['label'] ?? null))<span style="font-weight:600">{{ $content['label'] }}</span>@endif
</div>
