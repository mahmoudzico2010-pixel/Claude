@include('builder.elements._graphic-css')
@php($href = \App\Support\Builder\SafeLink::href($settings['link_url'] ?? ''))
<div data-builder-node="{{ $node['id'] }}" class="wr-node wr-g-iconbox {{ ($settings['layout'] ?? 'top') === 'side' ? 'is-side' : '' }} a-{{ in_array($settings['align'] ?? 'start', ['start', 'center', 'end'], true) ? $settings['align'] : 'start' }} {{ ($settings['card'] ?? 'on') === 'on' ? 'wr-g-card' : '' }}">
    @include('builder.elements._icon', ['name' => $settings['name'] ?? 'leaf', 'size' => $settings['size'] ?? 28, 'style' => $settings['style'] ?? 'circle', 'color' => $settings['color'] ?? '', 'background' => $settings['background'] ?? ''])
    <div>
        @if (filled($content['title'] ?? null))<h3>{{ $content['title'] }}</h3>@endif
        @if (filled($content['text'] ?? null))<p>{!! nl2br(e($content['text'])) !!}</p>@endif
        @if ($href && filled($content['link_label'] ?? null))<a class="more" href="{{ $href }}">{{ $content['link_label'] }}</a>@endif
    </div>
</div>
