@include('builder.elements._graphic-css')
@php
    $nets = [
        'facebook' => '<path d="M14 8h3V4h-3a4 4 0 0 0-4 4v3H7v4h3v6h4v-6h3l1-4h-4V8z"/>',
        'instagram' => '<rect x="4" y="4" width="16" height="16" rx="5"/><circle cx="12" cy="12" r="3.5"/><circle cx="17" cy="7" r=".6"/>',
        'linkedin' => '<rect x="4" y="9" width="3.5" height="11"/><circle cx="5.75" cy="5.5" r="1.8"/><path d="M11 20V9h3.4v1.6C15 9.5 16.3 8.8 18 9c2.2.2 3 1.8 3 4.2V20h-3.5v-6c0-1.3-.5-2-1.6-2-1.2 0-1.9.8-1.9 2.2V20z"/>',
        'x' => '<path d="M4 4l16 16M20 4L4 20"/>',
        'youtube' => '<rect x="3" y="6" width="18" height="12" rx="4"/><path d="M10 9.5v5l4.5-2.5z"/>',
        'whatsapp' => '<path d="M4 20l1.3-4.2A8 8 0 1 1 8.2 18.7z"/><path d="M9 9c0 3 3 6 6 6l1-1.5-2-1-1 .8c-1-.4-2-1.4-2.4-2.4l.8-1-1-2z"/>',
    ];
    $st = in_array($settings['style'] ?? 'circle', ['plain', 'circle', 'square'], true) ? $settings['style'] : 'circle';
    $sz = max(24, min(80, (int) ($settings['size'] ?? 40)));
    $al = ['start' => 'flex-start', 'center' => 'center', 'end' => 'flex-end'][$settings['align'] ?? 'start'] ?? 'flex-start';
@endphp
<nav data-builder-node="{{ $node['id'] }}" class="wr-node wr-g-social" style="justify-content:{{ $al }}" aria-label="Social">
    @foreach ($nets as $net => $svg)
        @if ($h = \App\Support\Builder\SafeLink::href($settings[$net] ?? ''))
            <a href="{{ $h }}" target="_blank" rel="noopener noreferrer" aria-label="{{ ucfirst($net) }}" class="wr-g-iconwrap is-{{ $st }}" style="width:{{ $sz }}px;height:{{ $sz }}px;@if (preg_match('/^#[0-9a-fA-F]{3,8}$/', (string) ($settings['color'] ?? '')))--wr-g-color:{{ $settings['color'] }}@endif">
                <svg width="{{ (int) round($sz * .55) }}" height="{{ (int) round($sz * .55) }}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">{!! $svg !!}</svg>
            </a>
        @endif
    @endforeach
</nav>
