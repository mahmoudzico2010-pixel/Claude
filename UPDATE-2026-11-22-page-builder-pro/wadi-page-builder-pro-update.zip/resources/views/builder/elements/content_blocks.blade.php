@include('builder.elements._graphic-css')
@php
    $__section = (string) ($settings['section'] ?? 'values');
    $__layout = in_array($settings['layout'] ?? 'cards', ['cards', 'list', 'numbers'], true) ? $settings['layout'] : 'cards';
    $__cols = max(1, min(6, (int) ($settings['columns'] ?? 3)));
    $__blocks = \App\Models\ContentBlock::query()->with('image')->where('is_active', true)->where('section', $__section)
        ->orderBy('display_order')->limit(max(1, min(48, (int) ($settings['limit'] ?? 12))))->get();
    $__icons = require config_path('builder_icons.php');
@endphp
@if ($__blocks->isNotEmpty())
    <div data-builder-node="{{ $node['id'] }}" class="wr-node wr-content-blocks" style="display:grid;gap:1.25rem;grid-template-columns:repeat({{ $__layout === 'list' ? 1 : $__cols }},minmax(0,1fr))">
        @foreach ($__blocks as $b)
            @php($__href = \App\Support\Builder\SafeLink::href($b->link_url))
            <div class="{{ $__layout === 'numbers' ? 'a-center' : '' }} wr-g-card" style="padding:1.25rem">
                @if ($__layout === 'numbers' && filled($b->value_text))
                    <div style="font-size:2.4rem;font-weight:700;line-height:1">{{ $b->value_text }}{{ $b->localized('value_suffix') }}</div>
                @elseif ($b->image)
                    <img src="{{ $b->image->urlFor(480) }}" alt="" style="max-width:100%;border-radius:.5rem;margin-bottom:.75rem" loading="lazy">
                @elseif ($b->icon && isset($__icons[$b->icon]))
                    @include('builder.elements._icon', ['name' => $b->icon, 'size' => 26, 'style' => 'circle'])
                @endif
                @if (filled($b->localized('title')))<h3 style="margin-top:.6rem;font-weight:600">{{ $b->localized('title') }}</h3>@endif
                @if (filled($b->localized('body')))<p style="margin-top:.35rem;opacity:.8">{!! nl2br(e($b->localized('body'))) !!}</p>@endif
                @if ($__href)<a href="{{ $__href }}" class="more">→</a>@endif
            </div>
        @endforeach
    </div>
@endif
