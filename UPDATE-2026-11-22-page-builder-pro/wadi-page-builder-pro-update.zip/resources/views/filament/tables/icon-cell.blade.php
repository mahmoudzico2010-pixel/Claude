@php
    $__r = $getRecord();
    $__n = \App\Support\Builder\Icons3D::resolve($__r->icon);
    $__d = $__n === null;
@endphp
<div style="padding:.35rem .75rem;{{ $__d ? 'opacity:.4' : '' }}">{!! \App\Support\Builder\Icons3D::svg($__n ?? \App\Support\Builder\Icons3D::defaultForSection($__r->section), 30) !!}</div>
