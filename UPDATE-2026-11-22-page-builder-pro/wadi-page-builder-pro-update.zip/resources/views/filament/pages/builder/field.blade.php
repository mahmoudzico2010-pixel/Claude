@php
    /*
     | One setting, rendered from its registry declaration.
     |
     | A responsive setting gets a breakpoint switcher and writes to
     | `form.<name>.<breakpoint>` instead of `form.<name>`. That shape is exactly
     | what NodeSettings::clean() expects for a per-breakpoint map and what
     | NodeStyle reads when emitting media queries, so the three agree by
     | construction rather than by three separate authors remembering the same
     | convention.
     */
    $fieldType = (string) ($definition['type'] ?? 'text');
    $responsive = (bool) ($definition['responsive'] ?? false);
    $options = (array) ($definition['options'] ?? []);

    $path = $responsive
        ? 'form.'.$name.'.'.$this->breakpoint
        : 'form.'.$name;

    $label = __('admin.builder.fields.'.$name);
@endphp

<label class="block">
    <span class="flex items-center justify-between gap-2">
        <span class="text-xs text-gray-600 dark:text-gray-300">{{ $label }}</span>

        @if ($responsive)
            {{-- Which breakpoint is being edited. One switcher drives every
                 responsive field in the panel, because setting a phone layout
                 means changing several values at that size, not switching
                 breakpoint per field. --}}
            <select wire:model.live="breakpoint"
                    class="rounded border-0 bg-transparent py-0 text-[0.7rem] text-gray-400 focus:ring-0"
                    aria-label="{{ __('admin.builder.breakpoint') }}">
                @foreach ($breakpoints as $breakpoint => $minWidth)
                    <option value="{{ $breakpoint }}">{{ __('admin.builder.breakpoints.'.$breakpoint) }}</option>
                @endforeach
            </select>
        @endif
    </span>

    @switch($fieldType)

        @case('select')
            @if (($definition['picker'] ?? null) === 'icon')
                @php $__icons = require config_path('builder_icons.php'); @endphp
                {{-- Icon picker: every icon is shown, one click chooses it. --}}
                <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(2.6rem,1fr));gap:.35rem;margin-top:.4rem;max-height:11rem;overflow-y:auto;padding:.25rem" role="listbox" aria-label="{{ $label }}">
                    <button type="button" wire:click="$set('{{ $path }}', '')" title="{{ __('admin.builder.inherit') }}" style="height:2.6rem;border:1px dashed #ccc;border-radius:.5rem;font-size:.7rem;color:#888">∅</button>
                    @foreach ($options as $option)
                        <button type="button" wire:click="$set('{{ $path }}', '{{ $option }}')" title="{{ \Illuminate\Support\Str::headline($option) }}" role="option"
                                style="height:2.6rem;border:2px solid {{ data_get($this, $path) === $option ? '#1f6b4f' : '#e3e3e3' }};background:{{ data_get($this, $path) === $option ? '#eef7f1' : '#fff' }};border-radius:.5rem;display:flex;align-items:center;justify-content:center;color:#14382a">
                            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">{!! $__icons[$option] ?? '' !!}</svg>
                        </button>
                    @endforeach
                </div>
            @else
                <select wire:model.blur="{{ $path }}"
                        class="mt-1 block w-full rounded-lg border-gray-300 text-sm dark:border-white/10 dark:bg-white/5">
                    <option value="">{{ __('admin.builder.inherit') }}</option>
                    @foreach ($options as $option)
                        <option value="{{ $option }}">{{ \Illuminate\Support\Facades\Lang::has('admin.builder.options.'.$option) ? __('admin.builder.options.'.$option) : \Illuminate\Support\Str::headline($option) }}</option>
                    @endforeach
                </select>
            @endif
            @break

        @case('toggle')
            <select wire:model.blur="{{ $path }}"
                    class="mt-1 block w-full rounded-lg border-gray-300 text-sm dark:border-white/10 dark:bg-white/5">
                <option value="">{{ __('admin.builder.inherit') }}</option>
                <option value="on">{{ __('admin.builder.on') }}</option>
                <option value="off">{{ __('admin.builder.off') }}</option>
            </select>
            @break

        @case('color')
            {{-- A text field beside the picker, not instead of it: the theme
                 tokens are named values like `var(--color-olive-deep)`, and a
                 colour input can only express a hex literal. Typing the token
                 is what keeps a section on the palette rather than pinning it
                 to a colour that will not follow a theme change. --}}
            <span class="mt-1 flex gap-2">
                <input type="text" wire:model.blur="{{ $path }}" placeholder="var(--color-olive-deep)"
                       class="block w-full rounded-lg border-gray-300 font-mono text-xs dark:border-white/10 dark:bg-white/5">
            </span>
            @break

        @case('html')
        @case('css')
        @case('textarea')
            <textarea wire:model.blur="{{ $path }}" rows="5"
                      class="mt-1 block w-full rounded-lg border-gray-300 font-mono text-xs dark:border-white/10 dark:bg-white/5"></textarea>
            @break

        @case('media')
        @case('document')
        @case('product')
        @case('integer')
            <input type="number" min="0" step="1" wire:model.blur="{{ $path }}"
                   class="mt-1 block w-full rounded-lg border-gray-300 text-sm dark:border-white/10 dark:bg-white/5">
            @break

        @case('media_list')
        @case('product_list')
            {{-- A comma-separated list of ids. NodeSettings::idList() accepts
                 this form, de-duplicates it and preserves the order typed,
                 because a hand-picked list renders in the order it was chosen. --}}
            <input type="text" wire:model.blur="{{ $path }}" placeholder="12, 4, 9"
                   class="mt-1 block w-full rounded-lg border-gray-300 font-mono text-xs dark:border-white/10 dark:bg-white/5">
            @break

        @default
            <input type="text" wire:model.blur="{{ $path }}"
                   placeholder="{{ $definition['default'] ?? '' }}"
                   class="mt-1 block w-full rounded-lg border-gray-300 text-sm dark:border-white/10 dark:bg-white/5">
    @endswitch
</label>
