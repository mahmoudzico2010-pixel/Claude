{{-- Structure tab: one level of the nested, sortable tree (recursive). Every <ul> is a SortableJS drop zone sharing the "tree" group;
     data-accepts is the registry's own list, so an illegal drop is never offered (the server still re-checks). --}}
@php
    $accepts = (array) ($node['accepts'] ?? []);
    $isSel = $this->selectedId === (int) $node['id'];
@endphp
<li data-id="{{ $node['id'] }}" data-type="{{ $node['type'] }}" wire:key="tree-{{ $node['id'] }}" style="list-style:none">
    <div class="wr-row" data-row="{{ $node['id'] }}" style="display:flex;align-items:center;gap:.25rem;padding:.25rem .35rem;border-radius:.4rem;border:1px solid {{ $isSel ? '#16a34a' : 'transparent' }};background:{{ $isSel ? '#ecfdf3' : 'transparent' }};{{ $node['enabled'] ? '' : 'opacity:.5;' }}">
        <span class="wr-handle" title="{{ __('admin.builder.drag_hint') }}" style="cursor:grab;color:#9ca3af;padding:0 .15rem;user-select:none;font-size:.9rem;line-height:1">⠿</span>
        <button type="button" wire:click="select({{ $node['id'] }})" style="flex:1;min-width:0;display:flex;gap:.4rem;align-items:center;text-align:start">
            <span style="font-size:.6rem;font-weight:700;text-transform:uppercase;letter-spacing:.04em;background:#f1f5f9;color:#475569;border-radius:.25rem;padding:.1rem .3rem;white-space:nowrap">{{ __('admin.builder.types.'.$node['type']) }}</span>
            <span style="font-size:.78rem;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">{{ $node['label'] }}</span>
        </button>
    </div>
    @if ($accepts !== [])
        <ul class="wr-drop" data-parent="{{ $node['id'] }}" data-accepts='@json($accepts)' style="margin:0;padding:0 0 0 .9rem;min-height:.5rem;border-inline-start:1px dashed #d1d5db;margin-inline-start:.55rem">
            @foreach ((array) $node['children'] as $child)
                @include('filament.pages.builder.tree', ['node' => $child])
            @endforeach
        </ul>
    @endif
</li>
