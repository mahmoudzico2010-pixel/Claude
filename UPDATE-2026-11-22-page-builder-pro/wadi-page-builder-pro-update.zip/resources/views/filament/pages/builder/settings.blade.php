@php
    /*
     | The selected node's settings.
     |
     | Built from the registry rather than hand-written per type: a type's
     | settings are declared once in config/builder.php, and the form, the
     | validator and the renderer all read that same declaration. A new element
     | type gets a working settings panel without a line of form code, and — more
     | to the point — a panel that cannot drift from what the validator accepts.
     */
    $type = (string) $node->type;
    $settings = \App\Support\Builder\NodeTypes::settings($type);
    $style = \App\Support\Builder\NodeTypes::styleSettings();
    $translatable = \App\Support\Builder\NodeTypes::translatable($type);
    $breakpoints = (array) config('design.breakpoints', []);
@endphp

<div class="space-y-4">

    <div class="flex items-center justify-between">
        <h2 class="text-sm font-semibold text-gray-700 dark:text-gray-200">
            {{ __('admin.builder.types.'.$type) }}
        </h2>
        <span class="text-xs text-gray-400">#{{ $node->id }}</span>
    </div>

    {{-- ================================================== TRANSITIONAL NOTICE --}}
    @if (\App\Support\Builder\NodeTypes::isTransitional($type))
        {{-- Said on the screen rather than left to be discovered by looking for
             settings that are not there: this band renders a shipped template,
             so its inner content is not editable here. --}}
        <div class="rounded-lg border border-warning-200 bg-warning-50 p-3 text-xs dark:border-warning-500/20 dark:bg-warning-500/10">
            <p class="font-semibold text-warning-800 dark:text-warning-300">
                {{ __('admin.builder.transitional') }}
            </p>
            <p class="mt-1 text-warning-700 dark:text-warning-400">
                {{ __('admin.builder.transitional_body') }}
            </p>

            @if ($this->canRebuildLegacy())
                <x-filament::button
                    wire:click="rebuildLegacy({{ $node->id }})"
                    wire:confirm="{{ __('admin.builder.confirm_rebuild') }}"
                    color="warning"
                    size="sm"
                    class="mt-2"
                    icon="heroicon-m-wrench-screwdriver">
                    {{ __('admin.builder.rebuild') }}
                </x-filament::button>
            @endif
        </div>
    @endif

    {{-- ===================================================== TRANSLATED TEXT --}}
    @if ($translatable !== [])
        <div class="space-y-3 rounded-lg bg-gray-50 p-3 dark:bg-white/5">
            <p class="text-xs font-semibold uppercase tracking-wide text-gray-400">
                {{ __('admin.builder.content') }}
            </p>
            <div style="display:flex;flex-wrap:wrap;gap:.4rem">
                <button type="button" wire:click="aiTranslateNode(false)" wire:loading.attr="disabled" wire:target="aiTranslateNode" data-testid="ai-translate-node"
                        style="border:1px solid #0ea5e9;color:#0369a1;background:#f0f9ff;border-radius:.5rem;padding:.35rem .7rem;font-size:.78rem;font-weight:600">
                    <span wire:loading.remove wire:target="aiTranslateNode">✦ {{ __('admin.ai.button_all') }}</span><span wire:loading wire:target="aiTranslateNode">…</span>
                </button>
                <button type="button" wire:click="aiTranslateNode(true)" wire:confirm="{{ __('admin.ai.overwrite') }}?" data-testid="ai-translate-node-replace"
                        style="border:1px solid #cbd5e1;color:#475569;background:#fff;border-radius:.5rem;padding:.35rem .7rem;font-size:.75rem">{{ __('admin.ai.replace_btn') }}</button>
            </div>

            @foreach ($locales as $locale)
                <p class="text-[0.7rem] font-semibold uppercase text-gray-400">{{ strtoupper($locale) }}</p>

                @foreach ($translatable as $field)
                    @php($definition = $settings[$field] ?? [])

                    <label class="block">
                        <span class="text-xs text-gray-600 dark:text-gray-300">{{ __('admin.builder.fields.'.$field) }}</span>

                        @if (in_array($definition['type'] ?? 'text', ['textarea', 'html'], true))
                            {{-- `.blur` rather than live: a re-render on every
                                 keystroke inside a 5,000-character field is a
                                 round trip per character. --}}
                            <textarea wire:model.blur="translations.{{ $locale }}.{{ $field }}"
                                      rows="3"
                                      @if ($locale === 'ar') dir="rtl" @endif
                                      class="mt-1 block w-full rounded-lg border-gray-300 text-sm dark:border-white/10 dark:bg-white/5"></textarea>
                        @else
                            <input type="text"
                                   wire:model.blur="translations.{{ $locale }}.{{ $field }}"
                                   @if ($locale === 'ar') dir="rtl" @endif
                                   class="mt-1 block w-full rounded-lg border-gray-300 text-sm dark:border-white/10 dark:bg-white/5">
                        @endif
                    </label>
                @endforeach
            @endforeach
        </div>
    @endif

    {{-- ========================================================== OWN SETTINGS --}}
    @foreach ($settings as $name => $definition)
        @continue(in_array($name, $translatable, true))

        @include('filament.pages.builder.field', [
            'name' => $name,
            'definition' => $definition,
            'breakpoints' => $breakpoints,
        ])
    @endforeach

    {{-- ============================================================== STYLE --}}
    <details class="rounded-lg border border-gray-200 p-3 dark:border-white/10">
        <summary class="cursor-pointer text-xs font-semibold uppercase tracking-wide text-gray-400">
            {{ __('admin.builder.style') }}
        </summary>

        <div class="mt-3 space-y-3">
            @foreach ($style as $name => $definition)
                @include('filament.pages.builder.field', [
                    'name' => $name,
                    'definition' => $definition,
                    'breakpoints' => $breakpoints,
                ])
            @endforeach
        </div>
    </details>

    <x-filament::button wire:click="save" class="w-full" icon="heroicon-m-check">
        {{ __('admin.builder.save') }}
    </x-filament::button>
</div>
