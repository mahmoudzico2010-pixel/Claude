{{--
    The visual builder.

    Left: the element library. Centre: the canvas. Right: the selected node's
    settings. Top: undo, save, preview and publish.

    Drag and drop is native HTML5, not a library. That is a deliberate choice —
    it adds no dependency to a build that has no Node on the server, and it
    degrades to the move buttons on each node rather than to nothing. Those
    buttons are not a fallback bolted on afterwards: a drag-only builder is
    unusable with a keyboard, so every structural change is reachable both ways.
--}}

<x-filament-panels::page>

    @php
        $tree = $this->tree();
        $selected = $this->selectedNode();
        $locales = array_keys((array) config('wadi.locales', []));
        $devices = ['desktop' => 'w-full', 'tablet' => 'w-[768px]', 'mobile' => 'w-[390px]'];

        /* A cache-busting token so the frame reloads after a change rather than
           showing a stale render. It is the draft's own fingerprint, so the URL
           only changes when the tree actually did. */
        $previewUrl = $this->previewUrl();
    @endphp

    {{-- ============================================================ TOOLBAR --}}
    <div class="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-gray-200 bg-white p-3 dark:border-white/10 dark:bg-gray-900">

        <div class="flex flex-wrap items-center gap-2">
            <x-filament::button
                wire:click="undo"
                color="gray"
                icon="heroicon-m-arrow-uturn-left"
                :disabled="! $this->canUndo()">
                {{ __('admin.builder.undo') }}
            </x-filament::button>

            <x-filament::button
                wire:click="redo"
                color="gray"
                icon="heroicon-m-arrow-uturn-right"
                :disabled="! $this->canRedo()">
                {{ __('admin.builder.redo') }}
            </x-filament::button>

            <x-filament::button wire:click="aiTranslatePage(false)" wire:confirm="{{ __('admin.ai.page_confirm') }}" color="info" icon="heroicon-m-language" data-testid="ai-translate-page">
                {{ __('admin.ai.page_btn') }}
            </x-filament::button>

            <x-filament::button wire:click="save" color="gray" icon="heroicon-m-check">
                {{ __('admin.builder.save_draft') }}
            </x-filament::button>

            {{-- Publish is the only control here that changes what a visitor
                 sees. Everything else acts on the draft. --}}
            <x-filament::button
                wire:click="publish"
                color="success"
                icon="heroicon-m-globe-alt"
                :disabled="! $this->isDirty()">
                {{ __('admin.builder.publish') }}
            </x-filament::button>
        </div>

        <div class="flex flex-wrap items-center gap-3">
            {{-- What is actually live, said plainly.

                 Without this the builder looks identical whether or not the
                 work has been made public, which is exactly the confusion that
                 separating draft from published exists to remove. --}}
            @if ($this->isDirty())
                <span class="inline-flex items-center gap-1.5 rounded-full bg-warning-50 px-2.5 py-1 text-xs font-medium text-warning-700 dark:bg-warning-500/10 dark:text-warning-400">
                    <span class="size-1.5 rounded-full bg-warning-500" aria-hidden="true"></span>
                    {{ __('admin.builder.unpublished') }}
                </span>
            @elseif ($this->publishedVersion() !== null)
                <span class="text-xs text-gray-400">
                    {{ __('admin.builder.live_version', ['version' => $this->publishedVersion()]) }}
                </span>
            @else
                <span class="text-xs text-gray-400">{{ __('admin.builder.never_published') }}</span>
            @endif

            {{-- Preview width. Changes the frame's width only: the page inside
                 is rendered by the same templates at every size, so this is the
                 real responsive behaviour rather than a simulation of it. --}}
            <div class="flex items-center gap-1" role="group" aria-label="{{ __('admin.builder.preview_width') }}">
                @foreach (['desktop', 'tablet', 'mobile'] as $device)
                    <x-filament::button
                        wire:click="$set('device', '{{ $device }}')"
                        :color="$this->device === $device ? 'primary' : 'gray'"
                        size="sm"
                        :aria-pressed="$this->device === $device ? 'true' : 'false'">
                        {{ __('admin.builder.devices.'.$device) }}
                    </x-filament::button>
                @endforeach
            </div>

            <x-filament::button
                tag="a"
                href="{{ route('home', ['locale' => app()->getLocale()]) }}"
                target="_blank"
                rel="noopener"
                color="gray"
                size="sm"
                icon="heroicon-m-arrow-top-right-on-square">
                {{ __('admin.builder.open_site') }}
            </x-filament::button>
        </div>
    </div>

    {{-- ==================================================== PUBLISHED HISTORY --}}
    @if ($this->history()->isNotEmpty())
        <details class="rounded-xl border border-gray-200 bg-white p-3 dark:border-white/10 dark:bg-gray-900">
            <summary class="cursor-pointer text-sm font-semibold text-gray-700 dark:text-gray-200">
                {{ __('admin.builder.history') }}
            </summary>

            <ul class="mt-3 divide-y divide-gray-100 dark:divide-white/5">
                @foreach ($this->history() as $revision)
                    <li class="flex flex-wrap items-center justify-between gap-2 py-2">
                        <div class="min-w-0 text-sm">
                            <span class="font-medium text-gray-700 dark:text-gray-200">
                                {{ __('admin.builder.version', ['version' => (int) $revision->version]) }}
                            </span>
                            <span class="text-gray-400">
                                · {{ $revision->created_at?->translatedFormat('j M Y, H:i') }}
                                @if ($revision->author)
                                    · {{ $revision->author->name }}
                                @endif
                                @if (filled($revision->label))
                                    · {{ $revision->label }}
                                @endif
                            </span>
                        </div>

                        @if (! $loop->first)
                            {{-- Reverting loads the version back into the DRAFT.
                                 It does not republish it — that stays a second,
                                 separate decision, so an accidental revert is
                                 not immediately visible to visitors. --}}
                            <x-filament::button
                                wire:click="revertTo({{ $revision->id }})"
                                wire:confirm="{{ __('admin.builder.confirm_revert') }}"
                                color="gray"
                                size="sm"
                                icon="heroicon-m-arrow-path">
                                {{ __('admin.builder.revert') }}
                            </x-filament::button>
                        @else
                            <span class="text-xs text-gray-400">{{ __('admin.builder.currently_live') }}</span>
                        @endif
                    </li>
                @endforeach
            </ul>
        </details>
    @endif

    @foreach ($this->reviewFlags() as $flag)
        <div role="alert" data-testid="heading-review" style="border:1px solid #e0b84a;background:#fff9e6;border-radius:.5rem;padding:.75rem 1rem;margin-bottom:.75rem;display:flex;flex-wrap:wrap;gap:.75rem;align-items:center;justify-content:space-between">
            <span>{{ $flag->reason }}</span>
            <span style="display:flex;gap:.5rem">
                <x-filament::button size="sm" color="danger" wire:click="resolveFlag({{ $flag->id }}, 'remove')" wire:confirm="Remove this heading from the page content?">Remove this heading</x-filament::button>
                <x-filament::button size="sm" color="gray" wire:click="resolveFlag({{ $flag->id }}, 'keep')">Keep it</x-filament::button>
            </span>
        </div>
    @endforeach

    @if ($this->hasHeader())
        <div style="display:flex;flex-wrap:wrap;gap:.5rem;align-items:center;border:1px solid {{ $this->isBasic() ? '#e0b84a' : '#e5e7eb' }};background:{{ $this->isBasic() ? '#fff9e6' : '#fff' }};border-radius:.75rem;padding:.5rem .75rem;margin-bottom:.75rem" data-testid="basic-bar">
            @if ($this->isBasic())
                <strong style="font-size:.8rem">{{ __('admin.builder.basic_bar') }}</strong>
                <x-filament::button size="sm" wire:click="setBasic(false)" data-testid="use-builder">{{ __('admin.builder.use_builder') }}</x-filament::button>
            @else
                <x-filament::button size="sm" color="gray" wire:click="setBasic(true)" data-testid="use-basic">{{ __('admin.builder.use_basic') }}</x-filament::button>
            @endif
            <x-filament::button size="sm" color="gray" wire:click="resetToOriginal" wire:confirm="{{ __('admin.builder.reset_confirm') }}">{{ __('admin.builder.reset_original') }}</x-filament::button>
            @if ($this->basicEditUrl())
                <x-filament::button size="sm" color="gray" tag="a" href="{{ $this->basicEditUrl() }}">{{ __('admin.builder.open_basic_editor') }}</x-filament::button>
            @endif
            <span style="margin-inline-start:auto;font-size:.68rem;color:#6b7280">{{ __('admin.builder.shortcuts') }}</span>
        </div>
    @endif

    <div class="grid gap-4 lg:grid-cols-[16rem_minmax(0,1fr)_20rem]">

        {{-- ============================================== LEFT: ELEMENTS / STRUCTURE / TEMPLATES --}}
        <aside class="rounded-xl border border-gray-200 bg-white p-3 dark:border-white/10 dark:bg-gray-900"
               x-data="{ tab: 'elements' }" x-init="wrSortables($wire)" style="max-height:80vh;overflow:auto" id="wr-left">
            <div style="display:flex;gap:.25rem;margin-bottom:.6rem" role="tablist">
                @foreach (['elements' => 'tab_elements', 'structure' => 'tab_structure', 'templates' => 'tab_templates'] as $k => $label)
                    <button type="button" role="tab" x-on:click="tab='{{ $k }}'"
                            x-bind:style="'flex:1;border-radius:.5rem;padding:.4rem .2rem;font-size:.75rem;font-weight:600;' + (tab==='{{ $k }}' ? 'background:#16a34a;color:#fff' : 'background:#f1f5f9;color:#334155')">{{ __('admin.builder.'.$label) }}</button>
                @endforeach
            </div>

            {{-- ELEMENTS: drag a tile onto the live page or into the Structure tree; click adds to the selected node. --}}
            <div x-show="tab==='elements'">
                <input type="search" x-on:input="wrFilter($event.target.value)" placeholder="{{ __('admin.builder.search') }}" style="width:100%;border:1px solid #d1d5db;border-radius:.5rem;padding:.4rem .6rem;font-size:.8rem;margin-bottom:.4rem" />
                <p style="font-size:.7rem;color:#6b7280;margin-bottom:.4rem">{{ __('admin.builder.drag_hint') }}</p>
                @foreach ($this->library() as $group => $types)
                    <p class="wr-group" style="margin-top:.8rem;font-size:.65rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#9ca3af">{{ __('admin.builder.groups.'.$group) }}</p>
                    <div class="wr-lib" style="display:grid;grid-template-columns:1fr 1fr;gap:.35rem;margin-top:.35rem">
                        @foreach ($types as $type)
                            <button type="button" data-type="{{ $type }}" data-name="{{ \Illuminate\Support\Str::lower(__('admin.builder.types.'.$type)) }}"
                                    wire:click="add('{{ $type }}', {{ $this->selectedId ?? 'null' }})"
                                    style="display:flex;flex-direction:column;align-items:center;gap:.2rem;border:1px solid #e5e7eb;border-radius:.6rem;padding:.55rem .25rem;font-size:.72rem;background:#fff;cursor:grab;text-align:center">
                                <span style="width:1.9rem;height:1.9rem;border-radius:.5rem;background:#ecfdf3;color:#15803d;display:grid;place-items:center;font-weight:700">{{ \Illuminate\Support\Str::upper(mb_substr(__('admin.builder.types.'.$type), 0, 1)) }}</span>
                                {{ __('admin.builder.types.'.$type) }}
                            </button>
                        @endforeach
                    </div>
                @endforeach
            </div>

            {{-- STRUCTURE: nested sortable tree of the whole page. --}}
            <div x-show="tab==='structure'" x-cloak>
                <ul id="wr-tree" class="wr-drop" data-parent="" data-accepts='["section"]' style="margin:0;padding:0;min-height:2rem">
                    @foreach ($tree as $node)
                        @include('filament.pages.builder.tree', ['node' => $node])
                    @endforeach
                </ul>
                <button type="button" wire:click="add('section')" style="margin-top:.6rem;width:100%;border:1px dashed #9ca3af;border-radius:.5rem;padding:.4rem;font-size:.75rem;color:#4b5563">+ {{ __('admin.builder.add_section') }}</button>
            </div>

            {{-- TEMPLATES: ready-made sections. Click inserts at the end; drag onto the page or the tree to place it. --}}
            <div x-show="tab==='templates'" x-cloak>
                <div id="wr-tpls">
                @forelse ($this->templates() as $tpl)
                    <div style="display:flex;align-items:center;gap:.3rem;margin-bottom:.35rem">
                        <button type="button" class="wr-tpl" data-tpl="{{ $tpl['key'] }}" wire:click="insertTemplate('{{ $tpl['key'] }}')"
                                style="flex:1;text-align:start;border:1px solid #e5e7eb;border-radius:.6rem;padding:.5rem .6rem;font-size:.78rem;cursor:grab;background:#fff">
                            {{ $tpl['name'] }}
                            <span style="float:inline-end;font-size:.65rem;color:#16a34a">{{ __('admin.builder.insert') }}</span>
                        </button>
                        @if ($tpl['saved'])
                            <button type="button" wire:click="deleteTemplate('{{ $tpl['key'] }}')" wire:confirm="{{ __('admin.builder.confirm_delete') }}" title="{{ __('admin.builder.delete_template') }}" style="color:#dc2626">✕</button>
                        @endif
                    </div>
                @empty
                    <p style="font-size:.8rem;color:#6b7280">{{ __('admin.builder.no_templates') }}</p>
                @endforelse
                </div>
            </div>
        </aside>

        {{-- ============================================================= CANVAS --}}
        <section class="rounded-xl border border-gray-200 bg-gray-50 dark:border-white/10 dark:bg-gray-950"
                 x-data="builderCanvas()"
                 x-on:builder-refresh.window="refresh($event.detail.url)"
                 x-on:builder-selected.window="highlight($event.detail.id)"
                 x-on:wr-context.window="openMenu($event.detail)"
                 x-on:click.window="menu.open = false">
            <div x-show="menu.open" x-cloak x-bind:style="'position:fixed;z-index:60;min-width:12rem;background:#fff;border:1px solid #e5e7eb;border-radius:.6rem;box-shadow:0 12px 32px rgba(0,0,0,.18);padding:.3rem;font-size:.8rem;left:'+menu.x+'px;top:'+menu.y+'px'" role="menu" data-testid="ctx-menu">
                <template x-for="item in items()" x-bind:key="item.label">
                    <button type="button" x-on:click="run(item)" x-bind:style="'display:block;width:100%;text-align:start;padding:.35rem .6rem;border-radius:.4rem;color:' + (item.danger ? '#dc2626' : '#111827')" x-text="item.label" role="menuitem"></button>
                </template>
            </div>

            {{-- Two views of the same tree.

                 The rendered preview is the page as it will actually publish —
                 same templates, same CSS, same partials. The outline is the
                 structural tree, which stays because it is the only way to see
                 and reach a node the preview cannot show: an empty column, a
                 hidden section, a node behind an overlay. They are views, not
                 modes: selecting in one selects in the other. --}}
            <div class="flex items-center justify-between gap-3 border-b border-gray-200 px-3 py-2 dark:border-white/10">
                <div class="flex items-center gap-1">
                    @foreach (['preview', 'outline'] as $view)
                        <button type="button"
                                wire:click="$set('canvasView', '{{ $view }}')"
                                @class([
                                    'rounded-lg px-3 py-1.5 text-xs font-semibold',
                                    'bg-primary-600 text-white' => $this->canvasView === $view,
                                    'text-gray-600 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-white/5' => $this->canvasView !== $view,
                                ])
                                aria-pressed="{{ $this->canvasView === $view ? 'true' : 'false' }}">
                            {{ __('admin.builder.views.'.$view) }}
                        </button>
                    @endforeach
                </div>

                @if ($this->trail() !== [])
                    <nav class="flex min-w-0 flex-wrap items-center gap-1 text-xs text-gray-500" aria-label="{{ __('admin.builder.trail') }}">
                        @foreach ($this->trail() as $ancestor)
                            <button type="button" wire:click="select({{ $ancestor['id'] }})" class="hover:underline">
                                {{ __('admin.builder.types.'.$ancestor['type']) }}
                            </button>
                            <span aria-hidden="true">/</span>
                        @endforeach
                    </nav>
                @endif
            </div>

            @if ($this->canvasView === 'preview')

                <div class="p-4">
                    <div id="wr-frame-wrap" style="position:relative" class="mx-auto overflow-hidden rounded-lg border border-gray-200 bg-white shadow-sm transition-[width] dark:border-white/10 {{ $devices[$this->device] ?? 'w-full' }}">
                        {{--
                            The draft, rendered by the real public templates.

                            Same-origin, which is what lets the two talk: the
                            frame posts the id of whatever is clicked, and the
                            builder posts back the current selection so the two
                            never disagree about what is selected.

                            `wire:ignore` keeps Livewire's DOM diffing away from
                            it — without it, every re-render would replace the
                            iframe element and reload the page inside, losing
                            the scroll position on every keystroke.
                        --}}
                        <iframe wire:ignore id="wr-frame"
                                x-ref="frame"
                                src="{{ $previewUrl }}"
                                title="{{ __('admin.builder.views.preview') }}"
                                class="h-[70vh] w-full"
                                loading="lazy"></iframe>
                        <div id="wr-shield" wire:ignore style="display:none;position:absolute;inset:0;z-index:7;cursor:copy"></div>
                        <div id="wr-dropbox" wire:ignore style="display:none;position:absolute;pointer-events:none;border:2px solid #16a34a;background:rgba(22,163,74,.08);border-radius:4px;z-index:5"></div>
                        <div id="wr-dropline" wire:ignore style="display:none;position:absolute;pointer-events:none;background:#16a34a;z-index:6;box-shadow:0 0 0 2px rgba(22,163,74,.3)"></div>
                    </div>

                    <p class="mt-2 text-center text-xs text-gray-400">
                        {{ __('admin.builder.preview_hint') }}
                    </p>
                </div>

            @else

                <div class="p-4">
                    <div class="mx-auto transition-[width] {{ $devices[$this->device] ?? 'w-full' }}">
                        @if ($this->hasHeader())
                            <button type="button" wire:click="selectHeader" data-testid="outline-header"
                                    style="display:flex;width:100%;align-items:center;gap:.5rem;text-align:start;margin-bottom:.5rem;padding:.5rem .75rem;border-radius:.5rem;border:1px solid {{ $this->headerSelected ? '#16a34a' : '#d4d4d4' }};{{ $this->headerSelected ? 'box-shadow:0 0 0 1px #16a34a;' : '' }}background:#f0faf4">
                                <x-filament::icon icon="heroicon-m-photo" style="width:1.1rem;height:1.1rem" />
                                <span style="font-weight:600">{{ __('pageheader.outline') }}</span>
                                <span style="margin-inline-start:auto;font-size:.75rem;color:#666">{{ $this->headerUnpublished ? __('pageheader.unpublished') : __('pageheader.published_state') }}</span>
                            </button>
                        @endif
                        @forelse ($tree as $node)
                            @include('filament.pages.builder.node', ['node' => $node, 'depth' => 0])
                        @empty
                            <div class="rounded-lg border-2 border-dashed border-gray-300 p-8 text-center dark:border-white/10">
                                <p class="text-sm text-gray-500">{{ __('admin.builder.empty') }}</p>
                                <x-filament::button class="mt-3" wire:click="add('section')" icon="heroicon-m-plus">
                                    {{ __('admin.builder.add_section') }}
                                </x-filament::button>
                            </div>
                        @endforelse

                        @if ($tree !== [])
                            <button type="button"
                                    wire:click="add('section')"
                                    class="mt-3 w-full rounded-lg border-2 border-dashed border-gray-300 py-3 text-sm text-gray-500 hover:border-primary-400 hover:text-primary-600 dark:border-white/10">
                                + {{ __('admin.builder.add_section') }}
                            </button>
                        @endif
                    </div>
                </div>

            @endif
        </section>

        {{-- =========================================================== SETTINGS --}}
        <aside class="rounded-xl border border-gray-200 bg-white p-3 dark:border-white/10 dark:bg-gray-900">
            @if ($this->headerSelected)
                <div data-testid="header-panel" style="display:flex;flex-direction:column;gap:1rem">
                    <div style="display:flex;align-items:center;justify-content:space-between;gap:.5rem;flex-wrap:wrap">
                        <h2 style="font-weight:600">{{ __('pageheader.title') }}</h2>
                        <span style="font-size:.75rem;color:{{ $this->headerUnpublished ? '#a16207' : '#15803d' }}">{{ $this->headerUnpublished ? __('pageheader.unpublished') : __('pageheader.published_state') }}</span>
                    </div>
                    {{ $this->headerForm }}
                    <div style="display:flex;gap:.5rem;flex-wrap:wrap">
                        <x-filament::button wire:click="publishHeader" icon="heroicon-m-check" data-testid="publish-header">{{ __('pageheader.publish') }}</x-filament::button>
                        <x-filament::button wire:click="discardHeader" color="gray" wire:confirm="{{ __('pageheader.discard') }}?">{{ __('pageheader.discard') }}</x-filament::button>
                    </div>
                </div>
            @elseif ($selected === null)
                <p class="text-sm text-gray-500">{{ __('admin.builder.select_prompt') }}</p>
            @else
                @include('filament.pages.builder.settings', [
                    'node' => $selected,
                    'locales' => $locales,
                ])
            @endif
        </aside>
    </div>


{{--
    The bridge between the builder and the rendered preview.

    Same-origin, so the two can post messages to each other — and the origin is
    checked on every inbound message rather than trusted, because an iframe can
    be addressed by anything that can reach this page and `event.origin` is the
    only part of a message that cannot be forged.

    Two directions:
      · the frame reports what was clicked, and the builder selects it
      · the builder reports what is selected, and the frame highlights it

    The frame is reloaded by changing its `src`, not by re-rendering the element:
    Livewire's DOM diffing would otherwise replace the iframe on every update
    and reload the page inside it, losing the scroll position on each keystroke.
--}}
<script>
    function builderCanvas() {
        return {
            menu: { open: false, x: 0, y: 0, id: null },
            labels: @js([
                'duplicate' => __('admin.builder.duplicate'), 'copy' => __('admin.builder.copy'), 'paste' => __('admin.builder.paste'),
                'up' => __('admin.builder.move_up'), 'down' => __('admin.builder.move_down'), 'toggle' => __('admin.builder.disable').' / '.__('admin.builder.enable'),
                'template' => __('admin.builder.save_template'), 'tname' => __('admin.builder.template_name'), 'delete' => __('admin.builder.delete'), 'confirm' => __('admin.builder.confirm_delete'),
            ]),
            openMenu(d) {
                this.$wire.select(d.id);
                this.menu = { open: true, x: Math.min(d.x, window.innerWidth - 220), y: Math.min(d.y, window.innerHeight - 300), id: d.id };
            },
            items() {
                var L = this.labels, id = this.menu.id, w = this.$wire, self = this;
                return [
                    { label: L.duplicate, fn: function () { w.duplicate(id); } },
                    { label: L.copy, fn: function () { w.copyNode(id); } },
                    { label: L.paste, fn: function () { w.pasteNode(id); } },
                    { label: L.up, fn: function () { w.nudge(id, -1); } },
                    { label: L.down, fn: function () { w.nudge(id, 1); } },
                    { label: L.toggle, fn: function () { w.toggleEnabled(id); } },
                    { label: L.template, fn: function () { var n = window.prompt(L.tname, ''); if (n) { w.saveAsTemplate(id, n); } } },
                    { label: L.delete, danger: true, fn: function () { if (window.confirm(L.confirm)) { w.remove(id); } } },
                ];
            },
            run(item) { this.menu.open = false; item.fn(); },
            init() {
                var self = this;
                window.wrCanvas = this;

                window.addEventListener('message', function (event) {
                    if (event.origin !== window.location.origin) {
                        return;
                    }

                    var data = event.data;

                    if (!data || data.source !== 'wr-builder-preview') {
                        return;
                    }

                    if (data.type === 'context' && data.id && data.id !== 'header') {
                        var r = self.$refs.frame.getBoundingClientRect();
                        self.openMenu({ id: data.id, x: r.left + data.x, y: r.top + data.y });
                    }
                    if (data.type === 'key') { wrKey(self.$wire, data); }
                    if (data.type === 'probed') { wrProbed(data); }

                    if (data.type === 'select' && data.id === 'header') {
                        self.$wire.selectHeader();
                    } else if (data.type === 'select' && data.id) {
                        self.$wire.select(data.id);
                    }

                    // Text edited directly on the canvas (double-click a heading or paragraph).
                    if (data.type === 'inline' && data.id) {
                        self.$wire.inlineEdit(data.id, String(data.value || ''));
                    }

                    // The frame announces itself once it is listening, which is
                    // when the current selection can be pushed to it — sending
                    // earlier would post into a document that is not ready.
                    if (data.type === 'ready') {
                        self.highlight(self.$wire.get('headerSelected') ? 'header' : self.$wire.get('selectedId'));
                    }
                });
            },

            highlight(id) {
                var frame = this.$refs.frame;

                if (!frame || !frame.contentWindow) {
                    return;
                }

                frame.contentWindow.postMessage({
                    source: 'wr-builder',
                    type: 'highlight',
                    id: id || null,
                }, window.location.origin);
            },

            refresh(url) {
                var frame = this.$refs.frame;

                if (frame && url) {
                    // Reassigning src rather than calling reload(): reload()
                    // re-requests the URL the frame already has, which after a
                    // fingerprint change is the previous version of the draft.
                    frame.src = url;
                }
            },
        };
    }
</script>


<script>
/* ---- Page Builder Pro: drag & drop engine, shortcuts --------------------------------------- */
(function () {
    if (window.__wrPro) { return; }
    window.__wrPro = true;

    var drag = null;       // { kind:'type'|'tpl', value, type, meta, target:{parent,index,box,line}|null, token }

    function frame() { return document.getElementById('wr-frame'); }
    function wrap() { return document.getElementById('wr-frame-wrap'); }
    function hide() {
        ['wr-dropbox', 'wr-dropline'].forEach(function (id) { var e = document.getElementById(id); if (e) { e.style.display = 'none'; } });
    }

    function ensureSortable(cb) {
        if (window.Sortable) { return cb(); }
        var s = document.createElement('script');
        s.src = @js(asset('vendor/sortablejs/Sortable.min.js'));
        s.onload = cb;
        document.head.appendChild(s);
    }

    window.wrFilter = function (q) {
        q = q.toLowerCase();
        document.querySelectorAll('#wr-left .wr-lib button').forEach(function (b) { b.style.display = (q === '' || b.dataset.name.indexOf(q) !== -1) ? '' : 'none'; });
    };

    window.wrSortables = function ($wire) {
        window.wrWire = $wire;
        ensureSortable(function () { boot($wire); });
        if (!window.__wrHook && window.Livewire && Livewire.hook) {
            window.__wrHook = true;
            Livewire.hook('commit', function (o) { o.succeed(function () { setTimeout(function () { boot(window.wrWire); }, 30); }); });
        }
    };

    function accepts(el, type) {
        try { return JSON.parse(el.dataset.accepts || '[]').indexOf(type) !== -1; } catch (e) { return false; }
    }

    function boot($wire) {
        // Structure tree: every list is a drop zone, rows move with the handle.
        document.querySelectorAll('#wr-left .wr-drop').forEach(function (ul) {
            if (ul._wr) { return; }
            ul._wr = Sortable.create(ul, {
                group: { name: 'wr-tree', pull: true, put: function (to, from, el) { return accepts(to.el, el.dataset.type); } },
                handle: '.wr-handle', forceFallback: true, fallbackTolerance: 3, animation: 160, ghostClass: 'wr-ghost', fallbackOnBody: true, swapThreshold: 0.6, invertSwap: true, emptyInsertThreshold: 14,
                onEnd: function (evt) {
                    if (evt.from === evt.to && evt.oldIndex === evt.newIndex) { return; }
                    $wire.move(parseInt(evt.item.dataset.id, 10), evt.to.dataset.parent ? parseInt(evt.to.dataset.parent, 10) : null, evt.newIndex);
                },
            });
        });

        // Elements and templates: dragged with the pointer onto the live page.
        document.querySelectorAll('#wr-left .wr-lib, #wr-tpls').forEach(function (box) {
            if (box._wr) { return; }
            box._wr = Sortable.create(box, {
                group: { name: 'wr-lib', pull: 'clone', put: false }, sort: false, forceFallback: true, fallbackOnBody: true, fallbackTolerance: 4,
                animation: 120, ghostClass: 'wr-ghost', draggable: 'button',
                onStart: function (evt) { startDrag($wire, evt.item); },
                onEnd: function (evt) { endDrag($wire, evt); },
            });
        });
    }

    function startDrag($wire, item) {
        var isTpl = !!item.dataset.tpl;
        drag = { kind: isTpl ? 'tpl' : 'type', value: isTpl ? item.dataset.tpl : item.dataset.type, type: isTpl ? 'section' : item.dataset.type, meta: null, target: null, token: 0, x: 0, y: 0 };
        $wire.nodeMeta().then(function (m) { if (drag) { drag.meta = m; } });
        // The frame is a separate document and would swallow the pointer; a shield above it keeps the events in this page.
        var sh = document.getElementById('wr-shield'); if (sh) { sh.style.display = 'block'; }
        document.addEventListener('pointermove', onMove, true);
        document.addEventListener('mousemove', onMove, true);
    }

    function onMove(e) {
        if (!drag) { return; }
        var f = frame();
        if (!f) { return; }
        var r = f.getBoundingClientRect();
        drag.x = e.clientX; drag.y = e.clientY;
        if (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom) {
            drag.target = null; hide(); return;
        }
        drag.token++;
        f.contentWindow.postMessage({ source: 'wr-builder', type: 'probe', x: e.clientX - r.left, y: e.clientY - r.top, token: drag.token }, window.location.origin);
    }

    function endDrag($wire, evt) {
        document.removeEventListener('pointermove', onMove, true);
        document.removeEventListener('mousemove', onMove, true);
        var d = drag, t = d && d.target;
        drag = null; hide();
        var sh = document.getElementById('wr-shield'); if (sh) { sh.style.display = 'none'; }
        if (evt && evt.clone && evt.clone.parentNode) { /* Sortable clone placeholder in the library: harmless */ }
        if (!t) { return; }
        if (d.kind === 'tpl') { $wire.insertTemplate(d.value, t.parent, t.index); }
        else { $wire.add(d.value, t.parent, t.index); }
    }

    // The frame answered with the stack of nodes under the pointer (deepest first).
    window.wrProbed = function (data) {
        if (!drag || !drag.meta || data.token !== drag.token) { return; }
        var meta = drag.meta, byId = {};
        meta.forEach(function (n) { byId[n.id] = n; });
        var type = drag.type, f = frame(), w = wrap();
        var target = null, probe = null;
        for (var i = 0; i < data.stack.length; i++) {
            var n = byId[data.stack[i].id];
            if (n && n.accepts.indexOf(type) !== -1) { target = n; probe = data.stack[i]; break; }
        }
        var res = null;
        if (target) {
            var kids = probe.kids, horiz = kids.length > 1 && Math.abs(kids[0].top - kids[1].top) < 6, idx = kids.length;
            for (var k = 0; k < kids.length; k++) {
                var mid = horiz ? (kids[k].left + kids[k].right) / 2 : (kids[k].top + kids[k].bottom) / 2;
                if ((horiz ? drag.x - f.getBoundingClientRect().left : drag.y - f.getBoundingClientRect().top) < mid) { idx = k; break; }
            }
            var full = target.children;
            var index = idx < kids.length ? full.indexOf(kids[idx].id) : null;
            res = { parent: target.id, index: index === -1 ? null : index, box: probe, line: line(kids, idx, probe, horiz) };
        } else if (type === 'section') {
            // Sections live at the page root: before or after the top-level section under the pointer.
            var roots = meta.filter(function (n) { return n.parent === null; }), hit = null;
            for (var j = data.stack.length - 1; j >= 0; j--) { if (byId[data.stack[j].id] && byId[data.stack[j].id].parent === null) { hit = data.stack[j]; break; } }
            var yy = drag.y - f.getBoundingClientRect().top;
            if (hit) {
                var after = yy > hit.top + hit.height / 2, ri = roots.findIndex(function (n) { return n.id === hit.id; }) + (after ? 1 : 0);
                res = { parent: null, index: ri >= roots.length ? null : ri, box: null, line: { top: after ? hit.top + hit.height : hit.top, left: hit.left, width: hit.width, height: 3 } };
            } else {
                res = { parent: null, index: null, box: null, line: { top: Math.max(0, yy), left: 0, width: f.clientWidth, height: 3 } };
            }
        }
        drag.target = res;
        paint(res);
    };

    function line(kids, idx, probe, horiz) {
        if (!kids.length) { return { top: probe.top + 4, left: probe.left + 4, width: Math.max(0, probe.width - 8), height: 3 }; }
        if (horiz) {
            var x = idx < kids.length ? kids[idx].left : kids[kids.length - 1].right;
            return { top: probe.top, left: x - 1, width: 3, height: probe.height };
        }
        var y = idx < kids.length ? kids[idx].top : kids[kids.length - 1].bottom;
        return { top: y - 1, left: probe.left, width: probe.width, height: 3 };
    }

    function paint(res) {
        var box = document.getElementById('wr-dropbox'), ln = document.getElementById('wr-dropline');
        if (!res) { hide(); return; }
        if (res.box) { Object.assign(box.style, { display: 'block', top: res.box.top + 'px', left: res.box.left + 'px', width: res.box.width + 'px', height: res.box.height + 'px' }); } else { box.style.display = 'none'; }
        if (res.line) { Object.assign(ln.style, { display: 'block', top: res.line.top + 'px', left: res.line.left + 'px', width: res.line.width + 'px', height: res.line.height + 'px' }); } else { ln.style.display = 'none'; }
    }

    /* ---- keyboard shortcuts (also fed by the preview frame) ---- */
    window.wrKey = function ($wire, k) {
        var key = (k.key || '').toLowerCase(), id = $wire.get('selectedId');
        if (k.ctrl && key === 'z') { k.shift ? $wire.redo() : $wire.undo(); }
        else if (k.ctrl && key === 'y') { $wire.redo(); }
        else if (k.ctrl && key === 's') { $wire.save(); }
        else if (k.ctrl && key === 'd' && id) { $wire.duplicate(id); }
        else if (k.ctrl && key === 'c' && id) { $wire.copyNode(id); }
        else if (k.ctrl && key === 'v') { $wire.pasteNode(id); }
        else if ((key === 'delete') && id && window.confirm(@js(__('admin.builder.confirm_delete')))) { $wire.remove(id); }
        else if (key === 'escape') { if (window.wrCanvas) { window.wrCanvas.menu.open = false; } }
        else { return false; }
        return true;
    };

    document.addEventListener('keydown', function (e) {
        var t = e.target, tag = (t.tagName || '').toLowerCase();
        if (tag === 'input' || tag === 'textarea' || tag === 'select' || t.isContentEditable || !window.wrWire || !document.getElementById('wr-left')) { return; }
        var ctrl = e.ctrlKey || e.metaKey;
        if (!ctrl && e.key !== 'Delete' && e.key !== 'Escape') { return; }
        if (window.wrKey(window.wrWire, { key: e.key, ctrl: ctrl, shift: e.shiftKey })) { if (ctrl) { e.preventDefault(); } }
    });

    /* ---- right-click on a structure row ---- */
    document.addEventListener('contextmenu', function (e) {
        var row = e.target.closest && e.target.closest('#wr-tree .wr-row');
        if (!row) { return; }
        e.preventDefault();
        window.dispatchEvent(new CustomEvent('wr-context', { detail: { id: parseInt(row.dataset.row, 10), x: e.clientX, y: e.clientY } }));
    });
})();
</script>
<style>
    .wr-ghost { opacity: .45; background: #dcfce7 !important; border-radius: .4rem; }
    .sortable-fallback { opacity: .9; z-index: 9999 !important; box-shadow: 0 10px 26px rgba(0,0,0,.25); border-radius: .6rem; background: #fff; }
    [x-cloak] { display: none !important; }
    #wr-tree .wr-row:hover { background: #f8fafc; }
</style>

</x-filament-panels::page>
