<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Filament\Pages\PageBuilder;
use App\Models\BuilderNode;
use App\Models\Page;
use App\Models\SiteSetting;
use App\Models\User;
use App\Services\Builder\BasicMode;
use App\Services\Builder\PageConverter;
use App\Services\Builder\TreeImporter;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Cache;
use Livewire\Livewire;
use PHPUnit\Framework\Attributes\Test;
use RuntimeException;
use Tests\TestCase;

/** Templates, copy/paste, nudge, save-as-template, and "return to the basic version". */
final class BuilderProToolsTest extends TestCase
{
    use RefreshDatabase;

    private Page $page;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
        SiteSetting::setMany(['maintenance_mode' => false], 'site');
        $this->page = Page::query()->where('key', 'quality')->firstOrFail();
        $admin = User::factory()->create(['is_active' => true]);
        $admin->assignRole(User::ROLE_ADMIN);
        $this->actingAs($admin->fresh());
    }

    private function key(): string
    {
        return PageConverter::key($this->page);
    }

    private function editor()
    {
        return Livewire::withQueryParams(['page' => $this->page->slug])->test(PageBuilder::class);
    }

    #[Test]
    public function every_bundled_template_imports_into_a_page_and_renders(): void
    {
        $component = $this->editor();
        $templates = json_decode((string) file_get_contents(database_path('data/builder-templates.json')), true);
        $this->assertCount(8, $templates);
        foreach ($templates as $t) {
            $before = BuilderNode::query()->forPage($this->key())->roots()->count();
            $component->call('insertTemplate', $t['key']);
            $this->assertSame($before + 1, BuilderNode::query()->forPage($this->key())->roots()->count(), $t['key']);
        }
        $html = view('builder.page', ['payload' => app(\App\Services\Builder\PageRenderer::class)->draftPayload($this->key(), 'en')])->render();
        $this->assertStringContainsString('Frequently asked questions', $html);
        $this->assertStringContainsString('Request a quote', $html);
        $ar = view('builder.page', ['payload' => app(\App\Services\Builder\PageRenderer::class)->draftPayload($this->key(), 'ar')])->render();
        $this->assertStringContainsString('الأسئلة الشائعة', $ar);
    }

    #[Test]
    public function the_importer_refuses_illegal_nesting_and_unknown_types(): void
    {
        $importer = app(TreeImporter::class);
        $this->expectException(RuntimeException::class);
        $importer->import($this->key(), null, [['type' => 'heading']]);
    }

    #[Test]
    public function copy_paste_and_nudge_and_save_as_template_work(): void
    {
        $component = $this->editor();
        $section = BuilderNode::query()->forPage($this->key())->roots()->firstOrFail();
        $component->call('insertTemplate', 'features_3');
        $component->call('copyNode', (int) $section->id)->call('pasteNode', (int) $section->id);
        $roots = BuilderNode::query()->forPage($this->key())->roots()->ordered()->pluck('id')->all();
        $this->assertCount(3, $roots, 'a pasted section lands beside the target');

        $component->call('nudge', $roots[1], -1);
        $after = BuilderNode::query()->forPage($this->key())->roots()->ordered()->pluck('id')->all();
        $this->assertSame($roots[1], $after[0]);

        $component->call('saveAsTemplate', (int) $section->id, 'My block');
        $this->assertStringContainsString('My block', (string) SiteSetting::get('builder.user_templates'));
        $key = array_keys(json_decode((string) SiteSetting::get('builder.user_templates'), true))[0];
        $component->call('insertTemplate', 'user:'.$key);
        $this->assertSame(4, BuilderNode::query()->forPage($this->key())->roots()->count());
    }

    #[Test]
    public function basic_version_hides_the_layout_publicly_without_losing_it_and_can_return(): void
    {
        $component = $this->editor();
        $component->call('publish');
        Cache::flush();
        $this->get('/en/quality')->assertOk()->assertSee('wr-built-page', false);

        $component->call('setBasic', true);
        Cache::flush();
        $this->get('/en/quality')->assertOk()->assertDontSee('wr-built-page', false);
        $this->assertTrue(BuilderNode::hasTreeFor($this->key()), 'the layout is kept');

        $component->call('setBasic', false);
        Cache::flush();
        $this->get('/en/quality')->assertOk()->assertSee('wr-built-page', false);
        $this->assertFalse(BasicMode::isBasic($this->page->slug));
    }

    #[Test]
    public function reset_to_original_rebuilds_the_starter_layout_and_undo_restores_the_previous_one(): void
    {
        $component = $this->editor();
        $component->call('insertTemplate', 'faq');
        $this->assertGreaterThan(0, BuilderNode::query()->forPage($this->key())->where('type', 'accordion')->count());
        $component->call('resetToOriginal');
        $this->assertSame(0, BuilderNode::query()->forPage($this->key())->where('type', 'accordion')->count());
        $this->assertSame(1, BuilderNode::query()->forPage($this->key())->where('type', 'rich_text')->count());
        $component->call('undo');
        $this->assertGreaterThan(0, BuilderNode::query()->forPage($this->key())->where('type', 'accordion')->count());
    }

    #[Test]
    public function the_editor_screen_renders_the_new_panels(): void
    {
        $this->get(PageBuilder::urlForPage($this->page))->assertOk()
            ->assertSee('wr-left', false)->assertSee('wr-tree', false)->assertSee('data-testid="basic-bar"', false)
            ->assertSee('Icon box', false);
    }
}
