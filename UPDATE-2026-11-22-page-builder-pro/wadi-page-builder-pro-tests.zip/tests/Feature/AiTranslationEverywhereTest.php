<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Filament\Forms\Components\AiTranslateButton;
use App\Filament\Pages\PageBuilder;
use App\Models\BuilderNode;
use App\Models\Page;
use App\Models\SiteSetting;
use App\Models\User;
use App\Services\Builder\PageConverter;
use App\Services\Translation\AiTranslator;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Http;
use Livewire\Livewire;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;

/** The "Translate to all 10 languages" engine behind every edit screen, and where it is wired. */
final class AiTranslationEverywhereTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
        SiteSetting::setMany(['maintenance_mode' => false], 'site');
        config(['services.anthropic.key' => null]);
        // Fake free service: "[<target>] <text>" so every cell can be recognised.
        Http::fake(['api.mymemory.translated.net/*' => function ($r) {
            [, $to] = explode('|', (string) ($r->data()['langpair'] ?? 'en|xx'));

            return Http::response(['responseStatus' => 200, 'responseData' => ['translatedText' => '['.$to.'] '.$r->data()['q']]]);
        }]);
    }

    private function admin(): void
    {
        $admin = User::factory()->create(['is_active' => true]);
        $admin->assignRole(User::ROLE_ADMIN);
        $this->actingAs($admin->fresh());
    }

    /** @return array<string, array{0: string, 1: string, 2: string}> mode, prefix, example cell for locale/base */
    public static function modes(): array
    {
        return ['pair' => ['pair', ''], 'dotted' => ['dotted', ''], 'suffix' => ['suffix', 'home__'], 'after' => ['after', '']];
    }

    #[Test]
    #[DataProvider('modes')]
    public function the_engine_fills_empty_boxes_and_untranslated_copies_in_all_ten_languages_for_every_naming_mode(string $mode, string $prefix): void
    {
        $locales = array_keys(config('wadi.locales'));
        $this->assertCount(10, $locales);
        $state = [];
        $get = function (string $path) use (&$state) { return data_get($state, $path) ?? (array_key_exists($path, $state) ? $state[$path] : null); };
        $set = function (string $path, string $v) use (&$state, $mode) {
            $mode === 'pair' || $mode === 'suffix' ? $state[$path] = $v : data_set($state, $path, $v);
        };
        $put = fn (string $loc, string $v) => $set(AiTranslateButton::cell($mode, $prefix, $loc, 'title'), $v);

        $put('en', 'Hello world');
        $put('fr', 'Hello world');        // untranslated copy of the source (the common leftover)
        $put('es', 'Hola a mano');        // a real, hand-written translation
        $n = AiTranslateButton::run(['title'], $mode, $prefix, false, $get, $set);

        $this->assertSame(8, $n, '10 languages - source - the hand-written one');
        $read = fn (string $loc) => $get(AiTranslateButton::cell($mode, $prefix, $loc, 'title'));
        $this->assertSame('Hola a mano', $read('es'), 'hand-written text is kept');
        foreach (array_diff($locales, ['en', 'es']) as $loc) {
            $this->assertStringContainsString('Hello world', (string) $read($loc), $loc);
            $this->assertStringStartsWith('[', (string) $read($loc), "$loc translated");
        }
        $this->assertSame('Hello world', $read('en'));

        $m = AiTranslateButton::run(['title'], $mode, $prefix, true, $get, $set);
        $this->assertSame(9, $m, 'replace-existing re-translates every language except the source');
        $this->assertStringStartsWith('[es]', (string) $read('es'));
    }

    #[Test]
    public function the_engine_uses_arabic_as_the_source_when_english_is_empty_and_reports_nothing_to_do(): void
    {
        $state = ['title_ar' => 'مرحبا'];
        $get = fn (string $p) => $state[$p] ?? null;
        $set = function (string $p, string $v) use (&$state) { $state[$p] = $v; };
        $this->assertSame(9, AiTranslateButton::run(['title'], 'pair', '', false, $get, $set));
        $this->assertStringStartsWith('[en]', $state['title_en']);
        $this->assertStringStartsWith('[fr]', $state['extra.fr.title']);
        $this->assertNull(AiTranslateButton::run(['body'], 'pair', '', false, $get, $set), 'no text anywhere = nothing to translate');
    }

    #[Test]
    public function html_and_placeholders_survive_the_free_service(): void
    {
        $out = app(AiTranslator::class)->translate(['body' => '<p>Hi <b>{name}</b>, see https://x.com/a now.</p>'], 'en', ['fr']);
        $this->assertStringContainsString('{name}', $out['fr']['body']);
        $this->assertStringContainsString('https://x.com/a', $out['fr']['body']);
        $this->assertStringContainsString('<b>', $out['fr']['body']);
    }

    #[Test]
    public function in_the_page_editor_untranslated_english_copies_are_translated_and_typed_translations_are_kept(): void
    {
        $this->admin();
        $page = Page::query()->where('key', 'quality')->firstOrFail();
        $key = PageConverter::key($page);
        $c = Livewire::withQueryParams(['page' => $page->slug])->test(PageBuilder::class);
        $node = BuilderNode::query()->forPage($key)->where('type', 'rich_text')->firstOrFail();
        $c->call('select', (int) $node->id);
        // The state in the user's screenshot: every other language holds the English text.
        foreach (array_keys(config('wadi.locales')) as $l) {
            $c->set("translations.$l.body", $l === 'ar' ? 'من مصر للعالم' : 'From Egypt to the World');
        }
        $c->set('translations.de.body', 'x'); // unknown locale is ignored harmlessly
        $c->call('aiTranslateNode');
        foreach (array_diff(array_keys(config('wadi.locales')), ['en', 'ar']) as $l) {
            $this->assertStringStartsWith("[".($l === 'zh' ? 'zh-CN' : $l)."]", (string) $c->get("translations.$l.body"), $l);
        }
        $this->assertSame('من مصر للعالم', $c->get('translations.ar.body'), 'Arabic was a real translation: kept');
        $c->set('translations.fr.body', 'Texte français écrit à la main');
        $c->call('aiTranslateNode');
        $this->assertSame('Texte français écrit à la main', $c->get('translations.fr.body'));
        $c->call('aiTranslateNode', true);
        $this->assertStringStartsWith('[fr]', (string) $c->get('translations.fr.body'), 'replace-all overwrites');
    }

    #[Test]
    public function translate_whole_page_translates_every_element_into_the_draft_and_undo_restores(): void
    {
        $this->admin();
        $page = Page::query()->where('key', 'quality')->firstOrFail();
        $key = PageConverter::key($page);
        $c = Livewire::withQueryParams(['page' => $page->slug])->test(PageBuilder::class);
        $c->call('insertTemplate', 'faq');
        $c->call('aiTranslatePage');
        $acc = BuilderNode::query()->forPage($key)->where('type', 'accordion_item')->with('translations')->firstOrFail();
        foreach (array_diff(array_keys(config('wadi.locales')), ['en', 'ar']) as $l) {
            $this->assertStringStartsWith("[".($l === 'zh' ? 'zh-CN' : $l)."]", (string) $acc->t('title', $l), "accordion title in $l");
        }
        $this->assertSame('What is the minimum order?', $acc->t('title', 'en'));
        $c->call('undo');
        $acc2 = BuilderNode::query()->forPage($key)->where('type', 'accordion_item')->with('translations')->firstOrFail();
        $this->assertStringNotContainsString('[fr]', (string) $acc2->t('title', 'fr'));
    }

    #[Test]
    #[DataProvider('screens')]
    public function the_button_is_present_on_each_edit_screen(string $url): void
    {
        $this->admin();
        $this->get($url)->assertOk();
    }

    /** @return array<string, array{0: string}> */
    public static function screens(): array
    {
        return ['homepage manager' => ['/admin/homepage-manager'], 'settings' => ['/admin/manage-settings'], 'news create' => ['/admin/news/news-posts/create'], 'page create' => ['/admin/content/pages/create']];
    }

    #[Test]
    public function the_page_header_editor_has_the_button_and_a_translated_title_is_autosaved_to_the_draft(): void
    {
        $this->admin();
        $page = Page::query()->where('key', 'quality')->firstOrFail();
        $this->get(PageBuilder::urlForPage($page, true))->assertOk();
        $c = Livewire::withQueryParams(['page' => $page->slug, 'header' => 1])->test(PageBuilder::class);
        $c->set('headerData.mode', 'custom')->assertSee(__('admin.ai.button_all'));
        $c->set('headerData.title.en', 'Our quality');
        $c->call('saveHeader');
        $this->assertSame('Our quality', data_get($c->get('headerData'), 'title.en'));
    }
}
