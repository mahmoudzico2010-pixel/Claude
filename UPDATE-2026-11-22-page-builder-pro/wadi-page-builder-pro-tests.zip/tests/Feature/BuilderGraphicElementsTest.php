<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Models\Page;
use App\Services\Builder\PageConverter;
use App\Services\Builder\PageRenderer;
use App\Services\Builder\TreeManager;
use App\Support\Builder\NodeTypes;
use App\Support\Builder\SafeLink;
use Illuminate\Foundation\Testing\RefreshDatabase;
use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;

final class BuilderGraphicElementsTest extends TestCase
{
    use RefreshDatabase;

    #[Test]
    public function every_graphic_element_is_placeable_renders_and_escapes_its_content(): void
    {
        $this->seed();
        $page = Page::where('key', 'about')->firstOrFail();
        $tree = app(TreeManager::class);
        $key = PageConverter::key($page);
        $s = $tree->add($key, null, 'section');
        $c = $tree->add($key, (int) $s->id, 'container');
        $col = $tree->add($key, (int) $c->id, 'column');

        $free = ['icon', 'icon_box', 'icon_list', 'shape_divider', 'cta_banner', 'testimonial', 'accordion', 'timeline', 'progress_bar', 'badge', 'image_box', 'star_rating', 'social_icons'];
        foreach ($free as $type) {
            $this->assertContains($type, NodeTypes::accepts('column'), "$type can be dropped into a column");
            $this->assertContains($type, array_merge(...array_values(NodeTypes::library())), "$type is in the library");
        }
        foreach (['icon_list_item', 'accordion_item', 'timeline_item'] as $child) {
            $this->assertNotContains($child, NodeTypes::accepts('column'), "$child lives only inside its parent");
            $this->assertFalse(in_array($child, array_merge(...array_values(NodeTypes::library())), true));
        }

        $xss = '<script>alert(1)</script>';
        foreach ($free as $type) {
            $n = $tree->add($key, (int) $col->id, $type);
            foreach (NodeTypes::translatable($type) as $f) {
                $n->translations()->updateOrCreate(['locale' => 'en'], ['content' => array_merge((array) ($n->translations()->where('locale', 'en')->first()?->content ?? []), [$f => $xss.$type])]);
            }
        }
        $acc = \App\Models\BuilderNode::where('page_key', $key)->where('type', 'accordion')->first();
        $item = $tree->add($key, (int) $acc->id, 'accordion_item');
        $item->translations()->updateOrCreate(['locale' => 'en'], ['content' => ['title' => 'Q?', 'body' => 'A.']]);
        $tl = \App\Models\BuilderNode::where('page_key', $key)->where('type', 'timeline')->first();
        $tree->add($key, (int) $tl->id, 'timeline_item')->translations()->updateOrCreate(['locale' => 'en'], ['content' => ['title' => 'Founded', 'date' => '2005']]);
        $il = \App\Models\BuilderNode::where('page_key', $key)->where('type', 'icon_list')->first();
        $tree->add($key, (int) $il->id, 'icon_list_item')->translations()->updateOrCreate(['locale' => 'en'], ['content' => ['text' => 'Listed point']]);

        app()->setLocale('en');
        $payload = app(PageRenderer::class)->draftPayload($key, 'en');
        $html = view('builder.page', ['payload' => $payload])->render();

        $this->assertStringNotContainsString('<script>alert', $html, 'typed content is escaped');
        foreach (['wr-g-iconbox', 'wr-g-shape', 'wr-g-cta', 'wr-g-testi', 'wr-g-acc', 'wr-g-tl', 'wr-g-pb', 'wr-g-badge', 'wr-g-imgbox', 'wr-g-stars', 'wr-g-social', 'wr-g-list'] as $cls) {
            $this->assertStringContainsString($cls, $html, $cls);
        }
        $this->assertStringContainsString('Q?', $html);
        $this->assertStringContainsString('Founded', $html);
        $this->assertStringContainsString('Listed point', $html);
    }

    #[Test]
    public function typed_links_only_allow_safe_schemes(): void
    {
        foreach (['https://a.example/x', 'http://a.example', '/en/contact', '#top', 'mailto:a@b.co', 'tel:+20100'] as $ok) {
            $this->assertSame($ok, SafeLink::href($ok));
        }
        foreach (['javascript:alert(1)', 'data:text/html,x', '//evil.example', 'vbscript:x', "java\nscript:alert(1)", ''] as $bad) {
            $this->assertNull(SafeLink::href($bad), $bad);
        }
    }
}
