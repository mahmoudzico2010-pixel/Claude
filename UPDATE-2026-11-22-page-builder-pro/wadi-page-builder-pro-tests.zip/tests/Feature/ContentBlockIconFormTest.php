<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Filament\Resources\Content\Pages\ManageContentBlocks;
use App\Models\ContentBlock;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Livewire\Livewire;
use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;

final class ContentBlockIconFormTest extends TestCase
{
    use RefreshDatabase;

    #[Test]
    public function an_icon_can_be_chosen_and_saved_and_a_legacy_value_is_accepted(): void
    {
        $this->seed();
        $admin = User::factory()->create(['is_active' => true]);
        $admin->assignRole(User::ROLE_ADMIN);
        $this->actingAs($admin->fresh());
        $block = ContentBlock::create(['section' => 'export_services', 'title_en' => 'A', 'title_ar' => 'ا', 'icon' => 'heroicon-o-truck', 'is_active' => true, 'display_order' => 1]);

        Livewire::test(ManageContentBlocks::class)
            ->callTableAction('edit', $block, ['icon' => 'ship'])
            ->assertHasNoTableActionErrors();
        $this->assertSame('ship', $block->fresh()->icon);

        Livewire::test(ManageContentBlocks::class)
            ->callTableAction('edit', $block, ['icon' => 'truck'])
            ->assertHasNoTableActionErrors();
        $this->assertSame('truck', $block->fresh()->icon);
    }
}
