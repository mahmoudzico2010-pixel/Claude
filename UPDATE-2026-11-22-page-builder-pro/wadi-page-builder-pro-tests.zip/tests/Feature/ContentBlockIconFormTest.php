<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Filament\Resources\Content\Pages\ManageContentBlocks;
use App\Models\ContentBlock;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Livewire\Livewire;
use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;

final class ContentBlockIconFormTest extends TestCase
{
    use RefreshDatabase;

    #[Test]
    public function an_icon_can_be_chosen_and_saved_and_a_legacy_value_is_accepted(): void
    {
        $this->seed();
        $admin = User::factory()->create(['is_active' => true]);
        $admin->assignRole(User::ROLE_ADMIN);
        $this->actingAs($admin->fresh());
        $block = ContentBlock::create(['section' => 'export_services', 'title_en' => 'A', 'title_ar' => 'ا', 'icon' => 'heroicon-o-truck', 'is_active' => true, 'display_order' => 1]);

        Livewire::test(ManageContentBlocks::class)
            ->callTableAction('edit', $block, ['icon' => 'ship'])
            ->assertHasNoTableActionErrors();
        $this->assertSame('ship', $block->fresh()->icon);

        Livewire::test(ManageContentBlocks::class)
            ->callTableAction('edit', $block, ['icon' => 'truck'])
            ->assertHasNoTableActionErrors();
        $this->assertSame('truck', $block->fresh()->icon);
    }

    #[Test]
    public function the_other_eight_languages_are_edited_in_the_same_form_saved_and_translated_in_one_go(): void
    {
        $this->seed();
        $admin = User::factory()->create(['is_active' => true]);
        $admin->assignRole(User::ROLE_ADMIN);
        $this->actingAs($admin->fresh());
        config(['services.anthropic.key' => null]);
        \Illuminate\Support\Facades\Http::fake(['api.mymemory.translated.net/*' => fn ($r) => \Illuminate\Support\Facades\Http::response(['responseStatus' => 200, 'responseData' => ['translatedText' => 'T:'.$r->data()['q']]])]);
        $block = ContentBlock::create(['section' => 'values', 'title_en' => 'Quality', 'title_ar' => 'الجودة', 'is_active' => true, 'display_order' => 1]);

        $component = Livewire::test(ManageContentBlocks::class)
            ->callTableAction('edit', $block, ['extra' => ['fr' => ['title' => 'Qualité'], 'zh' => ['title' => '质量']]]);
        $component->assertHasNoTableActionErrors();
        $this->assertSame('Qualité', \App\Models\ContentTranslation::query()->where(['entity' => 'content_blocks', 'entity_id' => $block->id, 'locale' => 'fr', 'field' => 'title'])->value('value'));
        app()->setLocale('zh');
        \App\Models\ContentTranslation::forget();
        $this->assertSame('质量', $block->fresh()->localized('title'));

        // AI: all 10 languages become filled (8 extra + en + ar) from English.
        $locales = array_keys(config('wadi.locales'));
        $translator = app(\App\Services\Translation\AiTranslator::class);
        $out = $translator->translate(['title' => 'Quality'], 'en', $locales);
        $this->assertCount(9, $out, 'every language except the source');
    }
}
