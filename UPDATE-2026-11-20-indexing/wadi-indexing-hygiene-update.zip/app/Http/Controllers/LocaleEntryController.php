<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Services\Locales\Detection\DetectionSettings;
use App\Services\Locales\Detection\LocaleResolver;
use App\Support\Locales;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Redirector;
use Illuminate\Support\Facades\Route;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpKernel\Exception\HttpException;

/**
 * The only places a visitor's language is chosen for them: the unlocalized entry point ("/"), unlocalized paths that
 * exist under a language prefix ("/request-a-quote?pack=…"), and the explicit language switch.
 *
 * Localized pages never redirect, so there is nothing to loop on. The redirects are TEMPORARY (302) and carry
 * `Cache-Control: no-store` + `Vary`, so a visitor-specific answer is never cached as a universal one.
 */
class LocaleEntryController extends Controller
{
    /** First path segments that must never be language-redirected (panel, framework endpoints, assets, installer, signed previews, APIs). */
    private const RESERVED = [
        'admin', 'livewire', 'up', 'install', 'storage', 'media', 'build', 'packaging-assets', 'js', 'css', 'fonts', 'images', 'api',
        'sitemap.xml', 'robots.txt', 'favicon.ico', 'vendor', '.well-known', 'language', 'broadcasting', 'sanctum', 'signed', 'preview', 'filament',
    ];

    public function entry(Request $request, LocaleResolver $resolver): RedirectResponse
    {
        $resolved = $resolver->resolveEntry($request);

        return $this->temporary('/'.$resolved->locale.$this->query($request));
    }

    /** Unlocalized path that is a real localized page: send the visitor to the right language, keeping the path and safe query. */
    public function fallback(Request $request, LocaleResolver $resolver): RedirectResponse
    {
        $path = trim($request->path(), '/');
        $first = strtolower(explode('/', $path)[0] ?? '');

        if ($path === '' || ! in_array($request->getMethod(), ['GET', 'HEAD'], true) || in_array($first, self::RESERVED, true)
            || $request->expectsJson() || preg_match('/\.[A-Za-z0-9]{1,6}$/', $path) || Locales::isSupported($first)) {
            throw new HttpException(404);
        }

        // Only paths whose first segment is a real localized section (products, packaging, contact, …) are redirected;
        // anything else stays a plain 404 instead of a pointless redirect to a localized 404.
        if (! in_array($first, $this->sections(), true)) {
            throw new HttpException(404);
        }

        $locale = $resolver->resolveEntry($request)->locale;
        $target = '/'.$locale.'/'.$path;

        // ... and only when the localized address really is a page; never a redirect to a localized 404.
        try {
            $route = app('router')->getRoutes()->match(Request::create($target, 'GET'));
        } catch (\Throwable) {
            throw new HttpException(404);
        }
        if ($route->isFallback) {
            throw new HttpException(404);
        }

        return $this->temporary($target.$this->query($request));
    }

    /** The visitor deliberately picked a language: remember it, then continue to the equivalent page. */
    public function switch(Request $request, Redirector $redirect, string $locale): RedirectResponse
    {
        abort_unless(Locales::isSupported($locale) && Locales::canServe($locale, $request->user()), 404);

        $to = (string) $request->query('to', '');
        $path = parse_url($to, PHP_URL_PATH);
        $ok = $to !== '' && is_string($path) && str_starts_with($to, '/') && ! str_starts_with($to, '//') && ! str_contains($to, '\\')
            && ! preg_match('/[\x00-\x1f]/', $to) && preg_match('#^/'.preg_quote($locale, '#').'(/|$)#', $path) === 1;

        $response = $this->temporary($ok ? $to : '/'.$locale);
        $response->headers->set('X-Robots-Tag', 'noindex, nofollow');

        // Only a PUBLIC language is remembered; an administrator previewing a draft language is not.
        if (Locales::isPublished($locale)) {
            $response->headers->setCookie(cookie(
                (string) config('wadi.locale_detection.cookie', 'wr_locale'), $locale,
                60 * 24 * (int) config('wadi.locale_detection.cookie_days', 365), '/', null, $request->isSecure(), true, false, 'lax',
            ));
        }

        return $response;
    }

    /** @return list<string> literal first segments below the language prefix, taken from the route table */
    private function sections(): array
    {
        static $sections = null;

        if ($sections === null) {
            $sections = [];
            foreach (Route::getRoutes()->getRoutes() as $route) {
                if (preg_match('#^\{locale\}/([A-Za-z0-9._-]+)#', $route->uri(), $m)) {
                    $sections[$m[1]] = true;
                }
            }
            $sections = array_keys($sections);
        }

        return $sections;
    }

    private function temporary(string $url): RedirectResponse
    {
        $vary = ['Accept-Language', 'Cookie'];
        if (($h = DetectionSettings::countryHeader()) !== '') {
            $vary[] = $h;
        }

        $r = new RedirectResponse($url, 302);
        $r->headers->set('Cache-Control', 'no-store, private, max-age=0');
        $r->headers->set('Vary', implode(', ', $vary));

        return $r;
    }

    /** The visitor's query string, kept as-is for the keys that are plain parameter names (pack, variant, model, utm_*, …). */
    private function query(Request $request): string
    {
        $safe = [];
        foreach ($request->query() as $key => $value) {
            if (is_string($key) && preg_match('/^[A-Za-z0-9_.\-]{1,64}$/', $key) && (is_string($value) || is_array($value))) {
                $safe[$key] = $value;
            }
        }

        return $safe === [] ? '' : '?'.http_build_query($safe, '', '&', PHP_QUERY_RFC3986);
    }
}
