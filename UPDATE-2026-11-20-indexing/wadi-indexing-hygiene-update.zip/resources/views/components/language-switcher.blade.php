@props(['variant' => 'desktop'])
@php
    $items = \App\Support\LanguagePicker::items();
    $mode = \App\Support\LanguagePicker::mode();
    $current = collect($items)->firstWhere('active', true) ?? ($items[0] ?? null);
    $mobile = $variant === 'mobile';
@endphp
@if (count($items) > 1 && $current)
    {{-- Header language picker: the flag above the small native name; the active language is marked. Horizontal lists every
         enabled language side by side; Dropdown shows the current one and opens the others. Links keep the visitor on the
         equivalent page (switch_locale_url). Keyboard: Tab / arrows, Escape closes the dropdown. --}}
    @if ($mode === 'horizontal')
        <nav aria-label="{{ __('chrome.lang.switch') }}" {{ $attributes->merge(['class' => 'flex flex-wrap items-start '.($mobile ? 'gap-x-1 gap-y-2' : 'gap-x-0.5')]) }}>
            @foreach ($items as $it)
                <a href="{{ $it['url'] }}" rel="nofollow" hreflang="{{ $it['hreflang'] }}" lang="{{ $it['code'] }}" dir="{{ $it['dir'] }}"
                   @if ($it['active']) aria-current="true" @endif
                   @class([
                       'group flex min-w-[3.1rem] flex-col items-center gap-1 rounded-sm px-1.5 py-1 text-center leading-none transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-gold',
                       'text-olive-deep font-semibold' => $it['active'],
                       'text-ink-subtle hover:text-ink' => ! $it['active'],
                   ])>
                    <span @class(['rounded-[3px] p-[2px]', 'bg-gold' => $it['active'], 'bg-transparent' => ! $it['active']])><x-flag :code="$it['flag']" :height="15" class="block" /></span>
                    <span class="text-[0.6875rem] {{ $mobile ? 'text-ink' : '' }}">{{ $it['native'] }}</span>
                </a>
            @endforeach
        </nav>
    @else
        <div x-data="{ open: false }" x-on:keydown.escape="if (open) { open = false; $refs.btn.focus() }" x-on:click.outside="open = false"
             {{ $attributes->merge(['class' => 'relative '.($mobile ? 'w-full' : 'inline-block')]) }}>
            <button type="button" x-ref="btn" x-on:click="open = ! open" :aria-expanded="open.toString()" aria-haspopup="true"
                    aria-label="{{ __('chrome.lang.menu') }}: {{ $current['native'] }}"
                    class="flex flex-col items-center gap-1 rounded-sm px-2 py-1 leading-none text-olive-deep focus-visible:outline focus-visible:outline-2 focus-visible:outline-gold {{ $mobile ? 'w-full' : '' }}">
                <span class="rounded-[3px] bg-gold p-[2px]"><x-flag :code="$current['flag']" :height="15" class="block" /></span>
                <span class="flex items-center gap-1 text-[0.6875rem] font-semibold">{{ $current['native'] }}
                    <svg class="size-2.5 transition-transform" :class="open && 'rotate-180'" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="2.4" aria-hidden="true"><path d="m5 8 5 5 5-5" stroke-linecap="round" stroke-linejoin="round"/></svg>
                </span>
            </button>
            <ul x-show="open" x-cloak role="list" aria-label="{{ __('chrome.lang.switch') }}"
                x-on:keydown.arrow-down.prevent="$focus.wrap().next()" x-on:keydown.arrow-up.prevent="$focus.wrap().previous()"
                class="{{ $mobile ? 'mt-2 grid grid-cols-3 gap-1' : 'absolute end-0 top-full z-[var(--z-navigation)] mt-1 grid min-w-[11rem] grid-cols-2 gap-1 border border-line bg-surface p-2 shadow-raised' }}">
                @foreach ($items as $it)
                    <li>
                        <a href="{{ $it['url'] }}" rel="nofollow" hreflang="{{ $it['hreflang'] }}" lang="{{ $it['code'] }}" dir="{{ $it['dir'] }}"
                           @if ($it['active']) aria-current="true" @endif
                           @class([
                               'flex flex-col items-center gap-1 rounded-sm px-2 py-1.5 text-center leading-none focus-visible:outline focus-visible:outline-2 focus-visible:outline-gold',
                               'bg-surface-alt text-olive-deep font-semibold' => $it['active'],
                               'text-ink-muted hover:bg-surface-alt hover:text-ink' => ! $it['active'],
                           ])>
                            <x-flag :code="$it['flag']" :height="15" class="block" />
                            <span class="text-[0.6875rem]">{{ $it['native'] }}</span>
                        </a>
                    </li>
                @endforeach
            </ul>
        </div>
    @endif
@endif
