<?php

declare(strict_types=1);

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;

final class IndexingHygieneTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
    }

    #[Test]
    public function robots_txt_keeps_crawlers_off_the_language_switch_redirect(): void
    {
        $txt = $this->get('/robots.txt')->assertOk()->getContent();
        $this->assertStringContainsString("Disallow: /language/\n", $txt);
        $this->assertStringContainsString('Disallow: /admin', $txt);
        $this->assertStringContainsString('Sitemap: ', $txt);
    }

    #[Test]
    public function the_switch_redirect_is_marked_noindex_and_still_works(): void
    {
        $r = $this->get('/language/en?to=/en/products');
        $r->assertRedirect('/en/products');
        $this->assertStringContainsString('noindex', (string) $r->headers->get('X-Robots-Tag'));
    }

    #[Test]
    public function every_language_switch_link_is_nofollow_on_desktop_and_phone(): void
    {
        $html = $this->get('/en')->assertOk()->getContent();
        preg_match_all('#<a [^>]*href="[^"]*/language/[a-z]{2}\?[^"]*"[^>]*>#', $html, $m);
        $this->assertNotEmpty($m[0], 'the page offers language-switch links');
        foreach ($m[0] as $a) {
            $this->assertStringContainsString('rel="nofollow"', $a, $a);
        }
    }
}
