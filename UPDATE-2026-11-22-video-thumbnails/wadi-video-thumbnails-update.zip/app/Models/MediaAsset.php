<?php

declare(strict_types=1);

namespace App\Models;

use App\Models\Concerns\Auditable;
use App\Packaging\Catalog\MediaUsage;
use App\Services\Homepage\HomepageMediaUsage;
use App\Support\PublicMediaUrl;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Storage;

/**
 * A single uploaded file plus its generated derivatives.
 *
 * `variants` holds the responsive renditions produced at upload time:
 *   [{"width": 1280, "path": "media/2026/01/name-1280.webp", "size": 84213}, ...]
 */
class MediaAsset extends Model
{
    use Auditable;
    use HasFactory;
    use SoftDeletes;

    protected $fillable = [
        'disk', 'path', 'filename', 'original_filename', 'mime_type', 'extension',
        'size', 'width', 'height', 'alt_en', 'alt_ar', 'title_en', 'title_ar',
        'folder', 'variants', 'checksum', 'uploaded_by',
    ];

    protected static function booted(): void
    {
        // An image the PUBLISHED packaging catalog shows cannot be deleted from under it.
        // (The Filament action is already disabled for in-use assets; this holds for every
        // other caller too.) Draft usage does not block deletion: publishing then fails
        // validation until the reference is replaced.
        static::deleting(function (self $asset): void {
            if (($used = MediaUsage::live($asset->id)) > 0) {
                throw new \RuntimeException(__('media.errors.in_use', ['count' => $used]));
            }
        });
    }

    protected function casts(): array
    {
        return [
            'variants' => 'array',
            'size' => 'integer',
            'width' => 'integer',
            'height' => 'integer',
        ];
    }

    public function uploader(): BelongsTo
    {
        return $this->belongsTo(User::class, 'uploaded_by');
    }

    // ---------------------------------------------------------------- URLs

    public function url(): string
    {
        return $this->publicUrl($this->path);
    }

    /**
     * Build the browser-facing URL for a stored path.
     *
     * Normally that is the disk's own URL — /storage/..., served straight off
     * disk by Apache through the storage:link symlink. Where that symlink is
     * unavailable or Apache refuses to follow it, MEDIA_PUBLIC_FALLBACK routes
     * the file through MediaFileController instead.
     */
    protected function publicUrl(string $path): string
    {
        if ($this->disk === 'public') {
            return PublicMediaUrl::for($path);
        }

        return Storage::disk($this->disk)->url($path);
    }

    /**
     * URL for the smallest variant at least `$minWidth` wide, falling back to
     * the original. Used for thumbnails and cards so a 4000px source is never
     * shipped to a phone.
     */
    public function urlFor(int $minWidth): string
    {
        $variants = collect($this->variants ?? [])
            ->sortBy('width')
            ->firstWhere(fn (array $v): bool => ($v['width'] ?? 0) >= $minWidth);

        return $variants
            ? $this->publicUrl($variants['path'])
            : $this->url();
    }

    /**
     * The best available source for a detail zoom.
     *
     * The widest generated rendition, or the original when none exist. A
     * magnifier can only reveal detail that is present in the file it is
     * given — feeding it the same 1280px image the page already displays
     * would enlarge pixels rather than reveal anything, which is the whole
     * complaint a magnifier exists to answer.
     */
    public function zoomUrl(): string
    {
        $widest = collect($this->variants ?? [])->sortByDesc('width')->first();

        // Only prefer a rendition when it is genuinely large; below that the
        // original is the better source even if it is heavier.
        if ($widest && ($widest['width'] ?? 0) >= 1600) {
            return $this->publicUrl($widest['path']);
        }

        return $this->url();
    }

    /**
     * A `srcset` string covering every generated width.
     */
    public function srcset(): ?string
    {
        $variants = collect($this->variants ?? [])->sortBy('width');

        if ($variants->isEmpty()) {
            return null;
        }

        return $variants
            ->map(fn (array $v): string => $this->publicUrl($v['path']).' '.$v['width'].'w')
            ->implode(', ');
    }

    // ------------------------------------------------------------- Helpers

    public function altTexts(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(MediaAssetTranslation::class, 'media_id');
    }

    /** Alt text for a language: its own row, then English, then the legacy columns, then the file name. */
    public function alt(?string $locale = null): string
    {
        $locale ??= app()->getLocale();
        $fallback = config('app.fallback_locale', 'en');

        $rows = $this->relationLoaded('altTexts') ? $this->altTexts : $this->altTexts()->get();
        $fromRow = fn (string $l): ?string => filled($v = $rows->firstWhere('locale', $l)?->alt) ? (string) $v : null;
        $attributes = $this->getAttributes();
        $read = fn (string $key): ?string => filled($attributes[$key] ?? null) ? (string) $attributes[$key] : null;

        return $fromRow($locale)
            ?? $read('alt_'.$locale)
            ?? $fromRow($fallback)
            ?? $read('alt_'.$fallback)
            ?? $read('title_'.$locale)
            ?? $read('title_'.$fallback)
            ?? (string) $this->original_filename;
    }

    /** Write one language's alt text; en/ar also keep the legacy columns in step. */
    public function setAlt(string $locale, ?string $alt, bool $generated = false): void
    {
        $this->altTexts()->updateOrCreate(['locale' => $locale], ['alt' => $alt, 'generated' => $generated]);
        if (in_array($locale, ['en', 'ar'], true)) {
            DB::table('media_assets')->where('id', $this->id)->update(['alt_'.$locale => $alt]);
        }
        $this->unsetRelation('altTexts');
    }

    public function isImage(): bool
    {
        return str_starts_with($this->mime_type, 'image/');
    }

    public function isRaster(): bool
    {
        return in_array($this->mime_type, ['image/jpeg', 'image/png', 'image/webp'], true);
    }

    public function isPdf(): bool
    {
        return $this->mime_type === 'application/pdf';
    }

    /** The type to declare on a <source>: a QuickTime / m4v file is announced as MP4, which is what browsers can decode when it holds H.264. */
    public function playbackType(): string
    {
        return in_array($this->mime_type, ['video/quicktime', 'video/x-m4v'], true) ? 'video/mp4' : (string) $this->mime_type;
    }

    /**
     * The DISPLAYED width/height of a video (rotation applied), for laying out its tile before it loads. Read from the file header of MP4 /
     * QuickTime files and remembered in `width`/`height`; null when the format has no readable header (the page then measures it in the browser).
     *
     * @return array{0: int, 1: int}|null
     */
    public function videoSize(): ?array
    {
        if (! $this->isVideo()) {
            return null;
        }
        if ($this->width && $this->height) {
            return [(int) $this->width, (int) $this->height];
        }
        if ($this->disk !== 'public' || ! in_array($this->extension, ['mp4', 'm4v', 'mov', 'qt', '3gp', '3g2'], true)) {
            return null;
        }
        try {
            $path = Storage::disk($this->disk)->path($this->path);
            $d = is_file($path) ? \App\Support\Media\Mp4Probe::dimensions($path) : null;
        } catch (\Throwable) {
            $d = null;
        }
        if ($d === null) {
            return null;
        }
        $this->forceFill(['width' => $d['width'], 'height' => $d['height']])->saveQuietly();

        return [$d['width'], $d['height']];
    }

    public function isVideo(): bool
    {
        return str_starts_with($this->mime_type, 'video/');
    }

    /**
     * A still that can stand in for this asset in a grid or a card.
     *
     * Video has none — there is no ffmpeg on shared hosting to extract a
     * frame — so callers get null and must fall back to an icon or to the
     * slide's own poster image.
     */
    public function thumbnailUrl(int $width = 400): ?string
    {
        return $this->isImage() ? $this->urlFor($width) : null;
    }

    public function humanSize(): string
    {
        $bytes = $this->size;

        foreach (['B', 'KB', 'MB', 'GB'] as $index => $unit) {
            if ($bytes < 1024 || $unit === 'GB') {
                return round($bytes, $index === 0 ? 0 : 1).' '.$unit;
            }
            $bytes /= 1024;
        }

        return $this->size.' B';
    }

    /**
     * Every place this asset is referenced, so the admin can see what breaks
     * before deleting it.
     *
     * @return array<int, array{label: string, count: int}>
     */
    public function usage(): array
    {
        $usages = [
            ['label' => __('media.usage.product_primary'), 'count' => Product::withTrashed()->where('primary_image_id', $this->id)->count()],
            ['label' => __('media.usage.product_gallery'), 'count' => ProductImage::where('media_id', $this->id)->count()],
            ['label' => __('media.usage.product_spec_sheet'), 'count' => Product::withTrashed()->where('spec_sheet_id', $this->id)->count()],
            ['label' => __('media.usage.category'), 'count' => Category::withTrashed()->where('image_id', $this->id)->count()],
            ['label' => __('media.usage.packaging'), 'count' => PackagingType::withTrashed()->where('image_id', $this->id)->count()],
            ['label' => __('media.usage.packaging_catalog'), 'count' => MediaUsage::live($this->id)],
            ['label' => __('media.usage.packaging_catalog_draft'), 'count' => MediaUsage::draft($this->id)],
            ['label' => __('media.usage.certification'), 'count' => Certification::where('logo_id', $this->id)->orWhere('document_id', $this->id)->count()],
            ['label' => __('media.usage.news'), 'count' => NewsPost::withTrashed()->where('featured_image_id', $this->id)->count()],
            ['label' => __('media.usage.news_gallery'), 'count' => \App\Models\NewsPostMedia::where('media_id', $this->id)->count()],
            ['label' => __('media.usage.page'), 'count' => Page::withTrashed()->where('featured_image_id', $this->id)->count()],
            ['label' => __('media.usage.content_block'), 'count' => ContentBlock::where('image_id', $this->id)->count()],
            ['label' => __('media.usage.homepage_draft'), 'count' => (int) in_array($this->id, app(HomepageMediaUsage::class)->ids()['draft'], true)],
            ['label' => __('media.usage.homepage_live'), 'count' => (int) in_array($this->id, app(HomepageMediaUsage::class)->ids()['published'], true)],
        ];

        return array_values(array_filter($usages, fn (array $u): bool => $u['count'] > 0));
    }

    public function isInUse(): bool
    {
        return $this->usage() !== [];
    }

    // -------------------------------------------------------------- Scopes

    public function scopeImages(Builder $query): Builder
    {
        return $query->where('mime_type', 'like', 'image/%');
    }

    public function scopeDocuments(Builder $query): Builder
    {
        return $query->where('mime_type', 'application/pdf');
    }

    public function scopeVideos(Builder $query): Builder
    {
        return $query->where('mime_type', 'like', 'video/%');
    }

    public function scopeInFolder(Builder $query, string $folder): Builder
    {
        return $query->where('folder', $folder);
    }

    public function scopeSearch(Builder $query, ?string $term): Builder
    {
        if (blank($term)) {
            return $query;
        }

        $term = '%'.str_replace('%', '\%', $term).'%';

        return $query->where(function (Builder $q) use ($term): void {
            $q->where('original_filename', 'like', $term)
                ->orWhere('alt_en', 'like', $term)
                ->orWhere('alt_ar', 'like', $term)
                ->orWhere('title_en', 'like', $term)
                ->orWhere('title_ar', 'like', $term);
        });
    }
}
