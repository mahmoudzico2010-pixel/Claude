<?php

declare(strict_types=1);

namespace App\Services\Media;

use App\Models\MediaAsset;
use App\Models\User;
use App\Support\ResourceLimits;
use App\Support\Uploads\UploadLimits;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Intervention\Image\Drivers\Gd\Driver as GdDriver;
use Intervention\Image\Encoders\WebpEncoder;
use Intervention\Image\ImageManager;
use RuntimeException;
use Throwable;

/**
 * Stores uploads and produces the derivatives the public site serves.
 *
 * Design notes for shared hosting:
 *
 *  - Conversion happens once, at upload time, never per request.
 *  - **Dimensions are checked before anything is decoded.** `getimagesize()`
 *    reads only the header, so a decompression bomb is rejected for a few
 *    bytes of work instead of being expanded into hundreds of megabytes of
 *    raw pixels and killing the request.
 *  - Failure to optimise is never fatal: the original is kept and the asset
 *    still saves, because losing a buyer's spec sheet to a GD quirk is worse
 *    than serving a slightly larger file.
 *  - Filenames are regenerated from a slug plus a random suffix, so a hostile
 *    upload can never choose its own path or extension.
 *  - SVG is a scripting-capable format. Only a Super Admin may upload one,
 *    and it is rebuilt from an allowlist before it reaches disk.
 */
class MediaManager
{
    public function __construct(
        private readonly SvgSanitizer $svgSanitizer,
    ) {}

    /**
     * Store an uploaded file and create its MediaAsset record.
     *
     * @throws RuntimeException when the file is rejected on safety grounds
     */
    public function store(UploadedFile $file, string $folder = 'general', array $attributes = []): MediaAsset
    {
        $disk = config('wadi.media.disk', 'public');
        $extension = strtolower($file->getClientOriginalExtension() ?: $file->guessExtension() ?: 'bin');
        $mime = $file->getMimeType() ?? 'application/octet-stream';

        $isSvg = $extension === 'svg' || $mime === 'image/svg+xml';

        if ($isSvg) {
            $this->assertMayUploadSvg();
        }

        // Final, server-side size check per category (the form's own check is only a convenience).
        if (! str_starts_with($mime, 'video/')) {
            $cat = $mime === 'application/pdf' ? 'document' : 'image';
            if (($file->getSize() ?: 0) > UploadLimits::bytes($cat)) {
                throw new RuntimeException(__('media.errors.too_large', ['max' => UploadLimits::kb($cat)]));
            }
        }

        if (str_starts_with($mime, 'video/')) {
            $this->assertAcceptableVideo($file, $mime, $extension);
        }

        // Raster images are vetted before a single pixel is decoded.
        $dimensions = [null, null];

        if (str_starts_with($mime, 'video/') && in_array($extension, ['mp4', 'm4v', 'mov', 'qt', '3gp', '3g2'], true) && ($probe = \App\Support\Media\Mp4Probe::dimensions((string) $file->getRealPath())) !== null) {
            $dimensions = [$probe['width'], $probe['height']];   // displayed size (rotation applied): tells portrait from landscape
        }

        if (! $isSvg && str_starts_with($mime, 'image/')) {
            $dimensions = $this->assertSafeRasterImage($file);
        }

        $directory = $this->directoryFor($folder);
        $basename = $this->safeBasename($file->getClientOriginalName());
        $filename = $basename.'-'.Str::lower(Str::random(8)).'.'.$extension;
        $path = $directory.'/'.$filename;

        $checksum = hash_file('sha1', $file->getRealPath()) ?: null;

        if ($isSvg) {
            $clean = $this->svgSanitizer->sanitize((string) file_get_contents($file->getRealPath()));

            if ($clean === null) {
                throw new RuntimeException(__('media.errors.invalid_svg'));
            }

            Storage::disk($disk)->put($path, $clean);
            $dimensions = $this->svgDimensions($clean);
        } else {
            Storage::disk($disk)->putFileAs($directory, $file, $filename);
        }

        $asset = new MediaAsset(array_merge([
            'disk' => $disk,
            'path' => $path,
            'filename' => $filename,
            'original_filename' => $file->getClientOriginalName(),
            'mime_type' => $mime,
            'extension' => $extension,
            'size' => Storage::disk($disk)->size($path),
            'width' => $dimensions[0],
            'height' => $dimensions[1],
            'folder' => $folder,
            'checksum' => $checksum,
            'uploaded_by' => Auth::id(),
        ], $attributes));

        $asset->save();

        if ($this->shouldOptimize($mime)) {
            $this->generateVariants($asset);
        }

        return $asset;
    }

    /**
     * Replace the binary of an existing asset, keeping its ID and therefore
     * every reference to it across the site.
     */
    public function replace(MediaAsset $asset, UploadedFile $file): MediaAsset
    {
        // Validate and store the NEW file first: if that fails, the working asset is untouched.
        $fresh = $this->store($file, $asset->folder);
        $this->deleteFiles($asset);

        $asset->forceFill([
            'path' => $fresh->path,
            'filename' => $fresh->filename,
            'original_filename' => $fresh->original_filename,
            'mime_type' => $fresh->mime_type,
            'extension' => $fresh->extension,
            'size' => $fresh->size,
            'width' => $fresh->width,
            'height' => $fresh->height,
            'checksum' => $fresh->checksum,
            'variants' => $fresh->variants,
        ])->save();

        // The temporary record held only the moved files, which now belong
        // to $asset; remove the row without touching them.
        MediaAsset::withoutEvents(fn () => $fresh->forceDelete());

        return $asset->refresh();
    }

    /**
     * Generate WebP renditions at each configured width.
     *
     * Each rendition is decoded, encoded and released one at a time, and the
     * loop stops early if either the memory or the time budget runs short —
     * a product with three renditions is better than a killed request.
     */
    public function generateVariants(MediaAsset $asset): void
    {
        if (! $asset->isRaster()) {
            return;
        }

        $startedAt = microtime(true);

        try {
            $source = Storage::disk($asset->disk)->get($asset->path);

            if ($source === null) {
                return;
            }

            $info = @getimagesizefromstring($source);

            if ($info === false || ! ResourceLimits::canDecodeImage((int) $info[0], (int) $info[1])) {
                return;
            }

            $manager = new ImageManager(new GdDriver);
            $originalWidth = (int) $info[0];

            $variants = [];
            $quality = (int) config('wadi.media.webp_quality', 82);

            foreach (config('wadi.media.responsive_widths', []) as $width) {
                // Never upscale.
                if ($width > $originalWidth) {
                    continue;
                }

                if (ResourceLimits::shouldStop($startedAt)) {
                    // Out of time. Keep what we have; the rest can be
                    // regenerated from the media library later.
                    break;
                }

                if (! ResourceLimits::canDecodeImage($originalWidth, (int) $info[1])) {
                    break;
                }

                $encoded = $manager->decode($source)
                    ->scaleDown(width: $width)
                    ->encode(new WebpEncoder(quality: $quality));

                $variantPath = $this->variantPath($asset, $width);
                Storage::disk($asset->disk)->put($variantPath, $encoded->toString());

                $variants[] = [
                    'width' => $width,
                    'path' => $variantPath,
                    'size' => Storage::disk($asset->disk)->size($variantPath),
                ];

                // Release the encoded copy before decoding the next size.
                unset($encoded);
                gc_collect_cycles();
            }

            if ($variants !== []) {
                $asset->forceFill(['variants' => $variants])->save();
            }
        } catch (Throwable $e) {
            // Optimisation is best-effort; the original remains usable.
            report($e);
        }
    }

    /**
     * Remove the asset's files, including every generated variant.
     */
    public function deleteFiles(MediaAsset $asset): void
    {
        $disk = Storage::disk($asset->disk);

        foreach ($asset->variants ?? [] as $variant) {
            if (isset($variant['path']) && $disk->exists($variant['path'])) {
                $disk->delete($variant['path']);
            }
        }

        if ($disk->exists($asset->path)) {
            $disk->delete($asset->path);
        }
    }

    /**
     * Find an existing asset with the same contents, so re-uploading the same
     * logo twice does not fill the library with duplicates.
     */
    public function findDuplicate(UploadedFile $file): ?MediaAsset
    {
        $checksum = hash_file('sha1', $file->getRealPath());

        if ($checksum === false) {
            return null;
        }

        return MediaAsset::query()->where('checksum', $checksum)->first();
    }

    // -------------------------------------------------------------- Guards

    /**
     * SVG can carry script, so uploading one is a privileged action.
     *
     * Everyone else uses PNG or WebP, which cannot execute anything.
     */
    public function assertMayUploadSvg(): void
    {
        if (! static::userMayUploadSvg()) {
            throw new RuntimeException(__('media.errors.svg_not_permitted'));
        }
    }

    /**
     * Normalise Filament FileUpload state into an UploadedFile.
     *
     * A FileUpload configured with `->storeFiles(false)` keeps the Livewire
     * temporary file in state, which extends UploadedFile. Filament may hand
     * it over on its own or wrapped in a single-element array depending on
     * where in the lifecycle the handler runs, so both shapes are accepted.
     *
     * Returns null for anything else — notably a plain path string, which is
     * what state dehydrates to when FileUpload was allowed to store the file
     * itself. Callers must treat null as a failure the user is told about,
     * never as "nothing to do".
     */
    public static function resolveUpload(mixed $state): ?UploadedFile
    {
        if (is_array($state)) {
            $state = reset($state) ?: null;
        }

        return $state instanceof UploadedFile ? $state : null;
    }

    public static function userMayUploadSvg(?User $user = null): bool
    {
        $user ??= Auth::user();

        return $user instanceof User && $user->isSuperAdmin();
    }

    /**
     * Read the header only, and refuse anything that would be expensive or
     * dangerous to decode.
     *
     * @return array{0: int, 1: int}
     *
     * @throws RuntimeException
     */
    private function assertSafeRasterImage(UploadedFile $file): array
    {
        $info = @getimagesize($file->getRealPath());

        if ($info === false) {
            throw new RuntimeException(__('media.errors.unreadable_image'));
        }

        [$width, $height] = [(int) $info[0], (int) $info[1]];

        if ($width > ResourceLimits::MAX_IMAGE_DIMENSION || $height > ResourceLimits::MAX_IMAGE_DIMENSION) {
            throw new RuntimeException(__('media.errors.dimensions_too_large', [
                'width' => $width,
                'height' => $height,
                'max' => ResourceLimits::MAX_IMAGE_DIMENSION,
            ]));
        }

        if (($width * $height) > ResourceLimits::MAX_IMAGE_PIXELS) {
            throw new RuntimeException(__('media.errors.pixels_too_large', [
                'pixels' => ResourceLimits::formatPixels($width * $height),
                'max' => ResourceLimits::formatPixels(ResourceLimits::MAX_IMAGE_PIXELS),
            ]));
        }

        // Final gate: would decoding this actually fit in what is left?
        if (! ResourceLimits::canDecodeImage($width, $height)) {
            throw new RuntimeException(__('media.errors.decode_too_costly', [
                'size' => $width.'×'.$height,
                'pixels' => ResourceLimits::formatPixels($width * $height),
                'limit' => ResourceLimits::formatPixels(ResourceLimits::practicalImagePixels()),
                'side' => ResourceLimits::MAX_IMAGE_DIMENSION,
                'file' => (int) config('wadi.media.max_upload_kb', 8192) / 1024,
            ]));
        }

        return [$width, $height];
    }

    // ------------------------------------------------------------- Internals

    /**
     * Video is stored verbatim — there is no transcoding available — so the
     * only defences are a narrow format allowlist and a hard size ceiling.
     *
     * The ceiling matters more than it looks: the file is served in full on
     * every uncached view, and shared hosting bills bandwidth long before it
     * bills storage.
     */
    private function assertAcceptableVideo(UploadedFile $file, string $mime, string $extension): void
    {
        if (! config('wadi.media.video.enabled', false)) {
            throw new RuntimeException(__('media.errors.video_not_permitted'));
        }

        $mimes = (array) config('wadi.media.video.mimes', []);
        $extensions = (array) config('wadi.media.video.extensions', []);

        $mimeOk = in_array($mime, $mimes, true) || (in_array('video/*', $mimes, true) && str_starts_with($mime, 'video/'));

        if (! $mimeOk || ! in_array($extension, $extensions, true)) {
            throw new RuntimeException(__('media.errors.video_format', [
                'formats' => strtoupper(implode(', ', $extensions)),
            ]));
        }

        $maxKb = UploadLimits::kb('video');

        if (($file->getSize() ?: 0) > $maxKb * 1024) {
            throw new RuntimeException(__('media.errors.video_too_large', [
                'max' => round($maxKb / 1024, 1),
            ]));
        }
    }

    private function shouldOptimize(string $mime): bool
    {
        return config('wadi.media.optimize', true)
            && in_array($mime, ['image/jpeg', 'image/png', 'image/webp'], true)
            && extension_loaded('gd');
    }

    private function directoryFor(string $folder): string
    {
        return 'media/'.$folder.'/'.now()->format('Y/m');
    }

    private function variantPath(MediaAsset $asset, int $width): string
    {
        $directory = dirname($asset->path);
        $name = pathinfo($asset->filename, PATHINFO_FILENAME);

        return $directory.'/'.$name.'-'.$width.'.webp';
    }

    /**
     * Build a filesystem-safe base name. Arabic filenames transliterate to
     * ASCII rather than being dropped, so uploads stay identifiable.
     */
    private function safeBasename(string $originalName): string
    {
        $name = pathinfo($originalName, PATHINFO_FILENAME);
        $slug = Str::slug($name);

        if ($slug === '') {
            $slug = 'file';
        }

        return Str::limit($slug, 60, '');
    }

    /**
     * @return array{0: ?int, 1: ?int}
     */
    private function svgDimensions(string $svg): array
    {
        if (preg_match('/viewBox\s*=\s*"[\d.\-]+\s+[\d.\-]+\s+([\d.]+)\s+([\d.]+)"/i', $svg, $m) === 1) {
            return [(int) round((float) $m[1]), (int) round((float) $m[2])];
        }

        return [null, null];
    }
}
