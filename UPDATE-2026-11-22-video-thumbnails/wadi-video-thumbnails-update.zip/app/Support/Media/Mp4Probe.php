<?php

declare(strict_types=1);

namespace App\Support\Media;

/**
 * Reads the DISPLAYED size of an MP4 / QuickTime (.mp4 .m4v .mov .3gp) video from its own header — no ffmpeg needed.
 *
 * It walks the top-level boxes by seeking (so a 200 MB file is never loaded; the `moov` box may be at the start or, for an iPhone
 * recording, at the end), finds the first video track's `tkhd` and applies its rotation matrix: an iPhone portrait video is stored
 * 1920×1080 with a 90° matrix and is really 1080×1920. Anything that is not an ISO-base-media file returns null.
 */
final class Mp4Probe
{
    private const MAX_MOOV = 64 * 1024 * 1024;

    /** @return array{width: int, height: int, rotation: int}|null */
    public static function dimensions(string $path): ?array
    {
        $fh = @fopen($path, 'rb');
        if ($fh === false) {
            return null;
        }
        try {
            $size = (int) (fstat($fh)['size'] ?? 0);
            $moov = self::findTopLevel($fh, 'moov', 0, $size);
            if ($moov === null || $moov[1] > self::MAX_MOOV) {
                return null;
            }
            fseek($fh, $moov[0]);
            $data = (string) fread($fh, $moov[1]);

            return self::fromMoov($data);
        } finally {
            fclose($fh);
        }
    }

    /** @return array{width: int, height: int, rotation: int}|null  parse a `moov` payload held in memory (also used by tests) */
    public static function fromMoov(string $moov): ?array
    {
        foreach (self::boxes($moov) as [$type, $start, $len]) {
            if ($type !== 'trak') {
                continue;
            }
            $trak = substr($moov, $start, $len);
            $tkhd = $hdlr = null;
            foreach (self::boxes($trak) as [$t, $s, $l]) {
                if ($t === 'tkhd') {
                    $tkhd = substr($trak, $s, $l);
                } elseif ($t === 'mdia') {
                    $mdia = substr($trak, $s, $l);
                    foreach (self::boxes($mdia) as [$mt, $ms, $ml]) {
                        if ($mt === 'hdlr') {
                            $hdlr = substr($mdia, $ms, $ml);
                        }
                    }
                }
            }
            if ($tkhd === null || $hdlr === null || substr($hdlr, 8, 4) !== 'vide') {
                continue;     // an audio or text track
            }

            return self::fromTkhd($tkhd);
        }

        return null;
    }

    /** @return array{width: int, height: int, rotation: int}|null */
    private static function fromTkhd(string $p): ?array
    {
        if (strlen($p) < 84) {
            return null;
        }
        $v1 = ord($p[0]) === 1;
        $m = $v1 ? 52 : 40;                       // start of the 3×3 matrix
        $w = $v1 ? 88 : 76;
        if (strlen($p) < $w + 8) {
            return null;
        }
        $i32 = static fn (int $o): int => unpack('l', pack('l', (int) (unpack('N', substr($p, $o, 4))[1])))[1];
        $a = $i32($m);
        $b = $i32($m + 4);
        $c = $i32($m + 12);
        $d = $i32($m + 16);
        $width = (int) round($i32($w) / 65536);
        $height = (int) round($i32($w + 4) / 65536);
        if ($width <= 0 || $height <= 0) {
            return null;
        }
        $rot = 0;
        if ($a === 0 && $d === 0 && $b > 0 && $c < 0) {
            $rot = 90;
        } elseif ($a === 0 && $d === 0 && $b < 0 && $c > 0) {
            $rot = 270;
        } elseif ($a < 0 && $d < 0) {
            $rot = 180;
        }
        if ($rot === 90 || $rot === 270) {
            [$width, $height] = [$height, $width];
        }

        return ['width' => $width, 'height' => $height, 'rotation' => $rot];
    }

    /** @return list<array{0: string, 1: int, 2: int}> [type, payload offset, payload length] of the boxes in a buffer */
    private static function boxes(string $buf): array
    {
        $out = [];
        $o = 0;
        $n = strlen($buf);
        while ($o + 8 <= $n) {
            $len = (int) unpack('N', substr($buf, $o, 4))[1];
            $type = substr($buf, $o + 4, 4);
            $hdr = 8;
            if ($len === 1 && $o + 16 <= $n) {
                $len = (int) unpack('J', substr($buf, $o + 8, 8))[1];
                $hdr = 16;
            } elseif ($len === 0) {
                $len = $n - $o;
            }
            if ($len < $hdr || $o + $len > $n) {
                break;
            }
            $out[] = [$type, $o + $hdr, $len - $hdr];
            $o += $len;
        }

        return $out;
    }

    /** @param resource $fh @return array{0: int, 1: int}|null payload offset and length of the first top-level box of a type */
    private static function findTopLevel($fh, string $want, int $from, int $size): ?array
    {
        $o = $from;
        $guard = 0;
        while ($o + 8 <= $size && $guard++ < 10000) {
            fseek($fh, $o);
            $h = (string) fread($fh, 16);
            if (strlen($h) < 8) {
                return null;
            }
            $len = (int) unpack('N', substr($h, 0, 4))[1];
            $type = substr($h, 4, 4);
            $hdr = 8;
            if ($len === 1 && strlen($h) >= 16) {
                $len = (int) unpack('J', substr($h, 8, 8))[1];
                $hdr = 16;
            } elseif ($len === 0) {
                $len = $size - $o;
            }
            if ($len < $hdr) {
                return null;
            }
            if ($type === $want) {
                return [$o + $hdr, min($len - $hdr, $size - $o - $hdr)];
            }
            $o += $len;
        }

        return null;
    }
}
