<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Enums\ContentStatus;
use App\Enums\NewsType;
use App\Models\MediaAsset;
use App\Models\NewsPost;
use App\Models\NewsPostMedia;
use App\Models\SiteSetting;
use App\Support\Media\Mp4Probe;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Storage;
use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;

final class VideoStripAndSizeTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        Storage::fake('public');
        $this->seed();
        SiteSetting::setMany(['maintenance_mode' => false], 'site');
    }

    private function box(string $type, string $payload): string
    {
        return pack('N', 8 + strlen($payload)).$type.$payload;
    }

    /** A video track: tkhd (version 0) with the stored size and a rotation matrix, plus an hdlr of the given handler. */
    private function trak(int $w, int $h, int $rotation = 0, string $handler = 'vide'): string
    {
        $one = 0x00010000;
        $matrix = match ($rotation) {
            90 => [0, $one, 0, -$one, 0, 0, 0, 0, 0x40000000],
            270 => [0, -$one, 0, $one, 0, 0, 0, 0, 0x40000000],
            default => [$one, 0, 0, 0, $one, 0, 0, 0, 0x40000000],
        };
        $tkhd = "\x00\x00\x00\x07".pack('N5', 0, 0, 1, 0, 1000).str_repeat("\x00", 8).pack('n4', 0, 0, 0, 0).pack('N9', ...array_map(fn (int $v): int => $v & 0xFFFFFFFF, $matrix)).pack('N2', $w << 16, $h << 16);
        $hdlr = "\x00\x00\x00\x00".pack('N', 0).$handler.str_repeat("\x00", 12).'handler'."\x00";

        return $this->box('trak', $this->box('tkhd', $tkhd).$this->box('mdia', $this->box('hdlr', $hdlr)));
    }

    private function mp4(string $moov, bool $moovLast = true): string
    {
        $ftyp = $this->box('ftyp', 'isom'.pack('N', 512).'isomiso2');
        $mdat = $this->box('mdat', str_repeat('M', 3000));

        return $moovLast ? $ftyp.$mdat.$this->box('moov', $moov) : $ftyp.$this->box('moov', $moov).$mdat;
    }

    private function file(string $bytes): string
    {
        $p = sys_get_temp_dir().'/'.uniqid('probe').'.mp4';
        file_put_contents($p, $bytes);

        return $p;
    }

    #[Test]
    public function landscape_portrait_and_rotated_iphone_videos_are_told_apart(): void
    {
        $this->assertSame(['width' => 1920, 'height' => 1080, 'rotation' => 0], Mp4Probe::dimensions($this->file($this->mp4($this->trak(1920, 1080)))));
        $this->assertSame(['width' => 1080, 'height' => 1920, 'rotation' => 0], Mp4Probe::dimensions($this->file($this->mp4($this->trak(1080, 1920)))));
        // an iPhone portrait recording: stored 1920x1080 with a 90 degree matrix, displayed 1080x1920 (and moov at the END of the file)
        $r = Mp4Probe::dimensions($this->file($this->mp4($this->trak(1920, 1080, 90), true)));
        $this->assertSame([1080, 1920], [$r['width'], $r['height']]);
        $r = Mp4Probe::dimensions($this->file($this->mp4($this->trak(1920, 1080, 270), false)));   // moov at the start, other rotation
        $this->assertSame([1080, 1920], [$r['width'], $r['height']]);
    }

    #[Test]
    public function an_audio_track_is_skipped_and_garbage_or_other_containers_give_nothing(): void
    {
        $r = Mp4Probe::dimensions($this->file($this->mp4($this->trak(0, 0, 0, 'soun').$this->trak(640, 360))));
        $this->assertSame([640, 360], [$r['width'], $r['height']]);
        $this->assertNull(Mp4Probe::dimensions($this->file('RIFF....AVI LIST'.str_repeat('x', 500))));
        $this->assertNull(Mp4Probe::dimensions($this->file(substr($this->mp4($this->trak(640, 360)), 0, 40))));
        $this->assertNull(Mp4Probe::dimensions($this->file('')));
        $this->assertNull(Mp4Probe::dimensions('/nonexistent/file.mp4'));
    }

    #[Test]
    public function the_size_is_read_once_from_the_file_and_remembered(): void
    {
        Storage::disk('public')->put('media/news/p.mp4', $this->mp4($this->trak(1920, 1080, 90)));
        $m = MediaAsset::create(['disk' => 'public', 'path' => 'media/news/p.mp4', 'filename' => 'p.mp4', 'original_filename' => 'p.mp4', 'mime_type' => 'video/mp4', 'extension' => 'mp4', 'size' => 100, 'folder' => 'news', 'checksum' => sha1('p')]);
        $this->assertNull($m->width);
        $this->assertSame([1080, 1920], $m->videoSize());
        $this->assertSame([1080, 1920], [$m->fresh()->width, $m->fresh()->height], 'stored for next time');
        $img = new MediaAsset(['mime_type' => 'image/png']);
        $this->assertNull($img->videoSize());
    }

    #[Test]
    public function the_public_videos_are_one_line_each_tile_shaped_like_its_video_with_the_first_scene_requested(): void
    {
        $p = NewsPost::create(['slug' => 'vids', 'type' => NewsType::Exhibition, 'status' => ContentStatus::Published, 'published_at' => now()->subDay()]);
        $p->translations()->create(['locale' => 'en', 'title' => 'Vids']);
        foreach ([[1920, 1080, 0], [1920, 1080, 90]] as $i => [$w, $h, $rot]) {
            Storage::disk('public')->put("media/news/v$i.mp4", $this->mp4($this->trak($w, $h, $rot)));
            $m = MediaAsset::create(['disk' => 'public', 'path' => "media/news/v$i.mp4", 'filename' => "v$i.mp4", 'original_filename' => "v$i.mp4", 'mime_type' => 'video/mp4', 'extension' => 'mp4', 'size' => 100, 'folder' => 'news', 'checksum' => sha1("v$i")]);
            NewsPostMedia::create(['news_post_id' => $p->id, 'media_id' => $m->id, 'kind' => 'video', 'display_order' => $i]);
        }
        $html = $this->get('/en/news/vids')->assertOk()->getContent();
        $this->assertStringContainsString('data-wr-vs', $html, 'a single-row strip');
        $this->assertSame(2, substr_count($html, 'class="wr-vs-item'));
        $this->assertStringContainsString('is-landscape', $html);
        $this->assertStringContainsString('is-portrait', $html);
        $this->assertStringContainsString('--wr-ar:1920/1080', $html);
        $this->assertStringContainsString('--wr-ar:1080/1920', $html);
        $this->assertSame(2, substr_count($html, '#t=0.001"'), 'the first scene is requested as the thumbnail');
        $this->assertStringContainsString('data-wr-vs-next', $html, 'arrows when there is more than one video');
    }
}
