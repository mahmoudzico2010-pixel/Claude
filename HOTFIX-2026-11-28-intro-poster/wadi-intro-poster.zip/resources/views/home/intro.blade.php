{{--
    Cinematic intro video — shown before the homepage, configured in the
    Homepage Manager (draft → preview → publish like everything else).

    Server side decides only whether an intro EXISTS (enabled, in schedule,
    valid media). Whether a visitor SEES it is decided by the inline script
    below, synchronously, before the page is painted:

      · not on reduced motion, not without JavaScript (ships `hidden`);
      · once per browser session by default (`frequency = session`);
      · phones get the mobile video, or the mobile still image, if one is set;
      · it ends on `ended`, Skip, Escape, playback error, a stall, or the
        maximum duration — and resources/css/intro.css hides it on its own a
        few seconds after that maximum even if every script has failed.

    The homepage itself is fully server-rendered underneath and is never
    hidden or delayed for crawlers. The site's own header is the only header.
--}}
@php
    /** @var \App\Services\Homepage\HomepageSnapshot $homepage */
    $introLocale = app()->getLocale();

    // The schedule is shared by every language.
    $introStarts = $homepage->setting('home.intro_starts_at');
    $introEnds = $homepage->setting('home.intro_ends_at');
    $introInSchedule = (blank($introStarts) || \Illuminate\Support\Carbon::parse((string) $introStarts)->lte(now()))
        && (blank($introEnds) || \Illuminate\Support\Carbon::parse((string) $introEnds)->gte(now()));

    // This language's Intro: its own override, the shared default, or none (disabled / nothing valid) — see LocalizedMedia.
    $intro = $introInSchedule ? \App\Services\Homepage\LocalizedMedia::intro($homepage, $introLocale) : null;
    $introVideo = $intro['video'] ?? null;
    $introStill = $intro['still'] ?? null;
@endphp

@if ($intro)
    @php
        $introMobile = $intro['video_mobile'];
        $introPoster = $intro['poster'];

        // Maximum on-screen time. Empty / 0 = no cap: the intro lasts as long
        // as the video does (or until Skip when it loops). There is no
        // built-in ceiling any more; the validator bounds the value.
        $introSeconds = $intro['max_seconds'];
        $introStart = $intro['start'];
        $introEnd = $intro['end'];
        $introLoop = $intro['loop'];
        $introSound = $intro['sound'];
        $introSoundButton = $introSound || $intro['sound_button'];
        $introFrequency = $intro['frequency'];
        $introSkip = $homepage->text('intro_skip_label', $introLocale) ?: __('home.intro.skip');

        // A new video (or a new version of the intro) is shown again even to someone who saw the previous one this
        // session. The language is part of the key: the English Intro having played never suppresses the Spanish one
        // after a deliberate language switch.
        $introKey = 'wr:intro:'.substr(sha1($introLocale.'|'.($introVideo?->id ?? 'still'.$introStill?->id).'|'.($introMobile?->id).'|'.($introVideo?->updated_at ?? $introStill?->updated_at)), 0, 12);
    @endphp

    @push('body-start')
        <div id="wr-intro"
             class="wr-intro"
             hidden
             role="dialog"
             aria-label="{{ __('home.intro.label') }}"
             data-key="{{ $introKey }}"
             data-frequency="{{ $introFrequency }}"
             data-max-ms="{{ $introSeconds * 1000 }}"
             data-start="{{ $introStart }}"
             data-end="{{ $introEnd }}"
             data-loop="{{ $introLoop ? '1' : '0' }}"
             data-sound="{{ $introSound ? '1' : '0' }}"
             data-locale="{{ $introLocale }}"
             data-source="{{ $intro['source'] }}"
             @if ($introVideo)
                 data-desktop="{{ $introVideo->url() }}"
                 data-desktop-type="{{ $introVideo->mime_type }}"
             @else
                 data-desktop-still="{{ $introStill->urlFor(1920) }}"
             @endif
             @if ($introMobile?->isVideo())
                 data-mobile="{{ $introMobile->url() }}"
                 data-mobile-type="{{ $introMobile->mime_type }}"
             @elseif ($introMobile?->isImage())
                 data-mobile-still="{{ $introMobile->urlFor(1080) }}"
             @endif
             style="--wr-intro-failsafe: {{ $introSeconds > 0 ? $introSeconds + 3 : 3600 }}s">
            @if ($introPoster)
                {{-- The still shown under/before the video. Sized to the screen (srcset) instead of always fetching the 1920 px file, and it is
                     the ONLY copy: the <video> below no longer carries a second `poster` address, which made phones download two images. --}}
                <img class="wr-intro-media" src="{{ $introPoster->urlFor(1920) }}"
                     @if ($introPoster->srcset()) srcset="{{ $introPoster->srcset() }}" sizes="100vw" @endif
                     alt="" aria-hidden="true" decoding="async">
            @endif
            <video class="wr-intro-media"
                   muted
                   playsinline
                   preload="auto"
                   aria-hidden="true"
                   tabindex="-1"></video>
            @if ($introSoundButton)
                <button type="button" class="wr-intro-sound" aria-pressed="false"
                        data-label-on="{{ __('home.intro.mute') }}" data-label-off="{{ __('home.intro.unmute') }}"
                        aria-label="{{ __('home.intro.unmute') }}" hidden>
                    <span class="wr-intro-sound-text">{{ __('home.intro.unmute') }}</span>
                </button>
            @endif
            <button type="button" class="wr-intro-skip">{{ $introSkip }}</button>
        </div>
        <script>
            (function () {
                var el = document.getElementById('wr-intro');
                if (!el) return;

                function store(key, value) { try { window.sessionStorage.setItem(key, value); } catch (e) {} }
                function read(key) { try { return window.sessionStorage.getItem(key); } catch (e) { return null; } }
                function mq(q) { return !!(window.matchMedia && window.matchMedia(q).matches); }

                var video = el.querySelector('video');
                var reduce = mq('(prefers-reduced-motion: reduce)');
                var seen = el.dataset.frequency === 'session' && read(el.dataset.key) === '1';

                if (reduce || seen || !video || typeof video.canPlayType !== 'function') {
                    el.parentNode.removeChild(el);
                    return;
                }

                var phone = mq('(max-width: 767px)');
                var src = el.dataset.desktop, type = el.dataset.desktopType;
                var still = null;

                if (phone && el.dataset.mobile) { src = el.dataset.mobile; type = el.dataset.mobileType; }
                else if (phone && el.dataset.mobileStill) { still = el.dataset.mobileStill; }
                else if (!el.dataset.desktop && el.dataset.desktopStill) { still = el.dataset.desktopStill; }

                if (!still && type && video.canPlayType(type) === '') {
                    el.parentNode.removeChild(el);
                    return;
                }

                if (el.dataset.frequency === 'session') store(el.dataset.key, '1');
                // The logo loading screen is separate and must not appear after
                // the intro (an ivory flash): treat it as shown for this visit.
                store('wr:preloaded', '1');

                var closed = false, timers = [];
                var previousFocus = document.activeElement;

                function close() {
                    if (closed) return;
                    closed = true;
                    timers.forEach(clearTimeout);
                    try { video.pause(); } catch (e) {}
                    document.removeEventListener('keydown', onKey);
                    el.classList.add('is-closing');
                    window.setTimeout(function () {
                        if (el.parentNode) el.parentNode.removeChild(el);
                        if (previousFocus && previousFocus.focus) { try { previousFocus.focus(); } catch (e) {} }
                    }, 420);
                }
                function onKey(e) { if (e.key === 'Escape') close(); }

                el.hidden = false;
                var skip = el.querySelector('.wr-intro-skip');
                skip.addEventListener('click', close);
                try { skip.focus({ preventScroll: true }); } catch (e) {}
                document.addEventListener('keydown', onKey);

                var max = parseInt(el.dataset.maxMs, 10) || 0; // 0 = no cap
                var startAt = parseFloat(el.dataset.start) || 0;
                var endAt = parseFloat(el.dataset.end) || 0;
                var loop = el.dataset.loop === '1';
                var wantSound = el.dataset.sound === '1';
                var soundBtn = el.querySelector('.wr-intro-sound');

                if (still) {
                    video.parentNode.removeChild(video);
                    var img = document.createElement('img');
                    img.className = 'wr-intro-media';
                    img.alt = '';
                    img.setAttribute('aria-hidden', 'true');
                    img.onerror = close;
                    img.src = still;
                    el.insertBefore(img, el.querySelector('.wr-intro-skip'));
                    timers.push(window.setTimeout(close, max > 0 ? Math.min(max, 4000) : 4000));
                    return;
                }

                video.addEventListener('error', close);

                // One audible source at a time: when anything else on the page
                // becomes audible, the intro goes quiet.
                window.addEventListener('wr:audible', function (e) {
                    if (e.detail !== 'intro') { video.muted = true; showSound(); }
                });
                function showSound() {
                    if (!soundBtn) return;
                    soundBtn.hidden = false;
                    var on = !video.muted;
                    soundBtn.setAttribute('aria-pressed', on ? 'true' : 'false');
                    var label = on ? soundBtn.dataset.labelOn : soundBtn.dataset.labelOff;
                    soundBtn.setAttribute('aria-label', label);
                    soundBtn.querySelector('.wr-intro-sound-text').textContent = label;
                }
                if (soundBtn) {
                    soundBtn.addEventListener('click', function () {
                        video.muted = !video.muted;
                        if (!video.muted) {
                            window.dispatchEvent(new CustomEvent('wr:audible', { detail: 'intro' }));
                            try { var p = video.play(); if (p && p.catch) p.catch(function () {}); } catch (e) {}
                        }
                        showSound();
                    });
                }

                function restart() {
                    try { video.currentTime = startAt; } catch (e) {}
                    var p = video.play();
                    if (p && typeof p.catch === 'function') p.catch(close);
                }
                video.addEventListener('ended', function () { loop ? restart() : close(); });
                video.addEventListener('loadedmetadata', function () {
                    if (startAt > 0 && (!video.duration || startAt < video.duration)) {
                        try { video.currentTime = startAt; } catch (e) {}
                    }
                });
                if (endAt > 0) {
                    video.addEventListener('timeupdate', function () {
                        if (video.currentTime >= endAt) { loop ? restart() : close(); }
                    });
                }
                video.src = src;

                // Nothing playing within 3 s (slow network, blocked autoplay):
                // reveal the homepage rather than a frozen frame.
                var playing = false;
                video.addEventListener('playing', function () { playing = true; showSound(); });
                timers.push(window.setTimeout(function () { if (!playing) close(); }, 3000));
                if (max > 0) timers.push(window.setTimeout(close, max));

                // Audible attempt first when configured; the browser's autoplay
                // policy may refuse, in which case it plays muted and the sound
                // button (if shown) lets the visitor opt in.
                video.muted = !wantSound;
                if (wantSound) window.dispatchEvent(new CustomEvent('wr:audible', { detail: 'intro' }));
                var attempt = video.play();
                if (attempt && typeof attempt.catch === 'function') {
                    attempt.catch(function () {
                        if (wantSound) {
                            video.muted = true;
                            var retry = video.play();
                            if (retry && typeof retry.catch === 'function') retry.catch(close);
                            showSound();
                        } else {
                            close();
                        }
                    });
                }
            })();
        </script>
    @endpush
@endif
