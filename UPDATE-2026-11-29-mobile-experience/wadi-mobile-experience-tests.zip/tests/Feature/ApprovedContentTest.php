<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Models\NavigationItem;
use App\Models\SiteSetting;
use App\Models\User;
use App\Packaging\Admin\TranslationRows;
use App\Packaging\Catalog\Drafts;
use App\Packaging\Catalog\TranslationStatus;
use App\Services\Homepage\HomepagePublisher;
use App\Services\Locales\Interface\InterfaceNotPublishable;
use App\Services\Locales\Interface\InterfaceTranslations;
use App\Services\Locales\LocaleReadiness;
use App\Services\Locales\LocaleReviews;
use App\Support\LocaleEligibility;
use App\Support\Locales;
use Database\Seeders\NavigationSeeder;
use Database\Seeders\PageSeeder;
use Database\Seeders\RolePermissionSeeder;
use Database\Seeders\SettingsSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Cache;
use Tests\Support\InstallsPackagingCatalog;
use Tests\TestCase;

/**
 * A language that is ready keeps showing its last REVIEWED content while newer text is being edited:
 * the edit is a draft (invisible to visitors, visible in an authorised preview), it invalidates its
 * own sign-off but not the approved content, unreviewed replacements are refused, and signing the
 * replacement off is what makes it public.
 */
class ApprovedContentTest extends TestCase
{
    use InstallsPackagingCatalog;
    use RefreshDatabase;

    private User $admin;

    private string $oldLabel;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed([RolePermissionSeeder::class, SettingsSeeder::class, PageSeeder::class, NavigationSeeder::class]);
        $this->installPackagingCatalog();
        Cache::flush();
        $this->admin = User::factory()->create(['is_active' => true]);
        $this->admin->assignRole(User::ROLE_ADMIN);
        $this->admin = $this->admin->fresh();

        config(['wadi.published' => ['en', 'ar'], 'wadi.enforce_locale_readiness' => true]);
        app(HomepagePublisher::class)->publish('Baseline');
        $this->artisan('packaging:import-translations', ['locales' => ['ar']])->assertSuccessful();

        $drafts = app(Drafts::class);
        $draft = $drafts->get()->data();
        $rows = array_map(fn (array $r): array => ['status' => TranslationStatus::REVIEWED] + $r, TranslationRows::rows($draft, 'ar'));
        $drafts->save(TranslationRows::apply($draft, 'ar', $rows, canReview: true));
        $drafts->publish();

        foreach (LocaleReadiness::AREAS as $area) {
            app(LocaleReviews::class)->record('ar', $area, $this->admin);
        }
        $this->oldLabel = (string) NavigationItem::query()->where('is_active', true)->where('location', 'header')->orderBy('id')->firstOrFail()->label_ar;
        $this->assertTrue(app(LocaleReadiness::class)->forLocale('ar')['ready'], implode(' | ', app(LocaleReadiness::class)->blockers('ar')));
        $this->assertTrue(Locales::isPublished('ar'));
    }

    private function editLabel(string $text): void
    {
        NavigationItem::query()->where('is_active', true)->where('location', 'header')->orderBy('id')->firstOrFail()->update(['label_ar' => $text]);
    }

    public function test_an_editors_draft_does_not_suspend_a_ready_language_and_visitors_keep_the_reviewed_text(): void
    {
        $oldTagline = (string) SiteSetting::get('company.tagline_ar');
        $this->editLabel('عنوان جديد لم يُراجع');
        SiteSetting::set('company.tagline_ar', 'شعار جديد لم يُراجع', SiteSetting::TYPE_TEXT);
        LocaleEligibility::forget();

        $this->assertTrue(Locales::isPublished('ar'), 'the draft did not take the language away');
        $this->assertFalse(Locales::isSuspended('ar'));

        $html = $this->get('/ar')->assertOk()->getContent();
        $this->assertStringContainsString($this->oldLabel, $html);
        $this->assertStringContainsString($oldTagline, $html);
        $this->assertStringNotContainsString('عنوان جديد لم يُراجع', $html);
        $this->assertStringNotContainsString('شعار جديد لم يُراجع', $html);

        $area = app(LocaleReadiness::class)->forLocale('ar')['areas']['navigation'];
        $this->assertTrue($area['pending'], 'the draft is reported as awaiting sign-off');
        $this->assertTrue($area['reviewed'] && $area['translated']);
        $this->assertTrue(app(LocaleReadiness::class)->forLocale('ar')['ready']);
    }

    public function test_an_authorised_preview_shows_the_new_draft_and_is_never_indexed(): void
    {
        $this->editLabel('عنوان جديد لم يُراجع');
        SiteSetting::set('company.tagline_ar', 'شعار جديد لم يُراجع', SiteSetting::TYPE_TEXT);

        // visitors cannot opt in to drafts
        $public = $this->get('/ar?draft=1')->assertOk();
        $this->assertStringNotContainsString('عنوان جديد لم يُراجع', $public->getContent());
        $this->assertNull($public->headers->get('X-Robots-Tag'));

        $viewer = User::factory()->create(['is_active' => true]);
        $viewer->assignRole(User::ROLE_SALES);                 // a panel user without languages.view
        $this->actingAs($viewer->fresh())->get('/ar?draft=1')->assertOk()->assertDontSee('عنوان جديد لم يُراجع');

        $preview = $this->actingAs($this->admin)->get('/ar?draft=1')->assertOk()->assertHeader('X-Robots-Tag', 'noindex, nofollow');
        $this->assertStringContainsString('عنوان جديد لم يُراجع', $preview->getContent());
        $this->assertStringContainsString('شعار جديد لم يُراجع', $preview->getContent());

        // and the next ordinary request is a visitor again
        auth()->logout();
        $this->get('/ar')->assertOk()->assertDontSee('عنوان جديد لم يُراجع');
    }

    public function test_an_incomplete_replacement_cannot_be_signed_off_and_the_public_keeps_the_reviewed_text(): void
    {
        $this->editLabel('');                                     // the draft blanks a label: not translated
        LocaleEligibility::forget();

        try {
            app(LocaleReviews::class)->record('ar', 'navigation', $this->admin);
            $this->fail('an incomplete draft was signed off');
        } catch (\InvalidArgumentException $e) {
            $this->assertStringContainsString('not translated', $e->getMessage());
        }

        $this->assertStringContainsString($this->oldLabel, $this->get('/ar')->assertOk()->getContent());
        $this->assertTrue(Locales::isPublished('ar'));
    }

    public function test_signing_the_replacement_off_makes_it_public(): void
    {
        $this->editLabel('عنوان جديد تمت مراجعته');
        SiteSetting::set('company.tagline_ar', 'شعار جديد تمت مراجعته', SiteSetting::TYPE_TEXT);
        $this->assertStringNotContainsString('عنوان جديد تمت مراجعته', $this->get('/ar')->getContent());

        app(LocaleReviews::class)->record('ar', 'navigation', $this->admin);

        $html = $this->get('/ar')->assertOk()->getContent();
        $this->assertStringContainsString('عنوان جديد تمت مراجعته', $html);
        $this->assertStringContainsString('شعار جديد تمت مراجعته', $html);
        // The phone-only bottom bar (hidden on tablet/desktop) carries its own static "Home" label.
        $this->assertStringNotContainsString($this->oldLabel.'<', preg_replace('#<nav class="wrm wrm-nav".*?</nav>#s', '', $html));
        $this->assertFalse(app(LocaleReadiness::class)->forLocale('ar')['areas']['navigation']['pending']);
    }

    public function test_a_new_menu_item_has_no_approved_label_and_shows_english_until_it_is_signed_off(): void
    {
        $item = NavigationItem::create(['location' => 'header', 'label_en' => 'Brand New Page', 'label_ar' => 'صفحة جديدة', 'url' => '/new', 'is_active' => true, 'display_order' => 99]);

        $html = $this->get('/ar')->assertOk()->getContent();
        $this->assertStringContainsString('Brand New Page', $html);
        $this->assertStringNotContainsString('صفحة جديدة', $html);

        app(LocaleReviews::class)->record('ar', 'navigation', $this->admin);
        $this->assertStringContainsString('صفحة جديدة', $this->get('/ar')->getContent());
        $this->assertNotNull($item->fresh());
    }

    public function test_a_published_homepage_text_waits_for_its_signoff_too(): void
    {
        $old = (string) SiteSetting::get('home.hero_title_ar');
        SiteSetting::set('home.hero_title_ar', 'عنوان رئيسي جديد لم يُراجع', SiteSetting::TYPE_TEXT);
        Cache::flush();
        app()->forgetScopedInstances();
        app(HomepagePublisher::class)->publish('New Arabic title');
        LocaleEligibility::forget();

        $this->assertTrue(Locales::isPublished('ar'));
        $this->assertTrue(app(LocaleReadiness::class)->forLocale('ar')['areas']['homepage']['pending']);
        $html = $this->get('/ar')->assertOk()->getContent();
        $this->assertStringContainsString($old, $html);
        $this->assertStringNotContainsString('عنوان رئيسي جديد لم يُراجع', $html);

        $this->assertStringContainsString('عنوان رئيسي جديد لم يُراجع', $this->actingAs($this->admin)->get('/ar?draft=1')->getContent());

        auth()->logout();
        app(LocaleReviews::class)->record('ar', 'homepage', $this->admin);
        $this->assertStringContainsString('عنوان رئيسي جديد لم يُراجع', $this->get('/ar')->getContent());
    }

    public function test_interface_drafts_keep_the_published_text_public_and_only_reviewed_publication_replaces_it(): void
    {
        $key = 'forms.contact.title';
        $default = trans($key, [], 'ar');
        $svc = app(InterfaceTranslations::class);

        $svc->saveDraft($this->admin, 'ar', $key, 'عنوان مسودة', 'needs_review');
        LocaleEligibility::forget();
        $this->assertTrue(Locales::isPublished('ar'));
        $this->get('/ar/contact')->assertOk()->assertSee($default)->assertDontSee('عنوان مسودة');
        $this->actingAs($this->admin)->get('/ar/contact?draft=1')->assertOk()->assertSee('عنوان مسودة');

        auth()->logout();
        $this->expectException(InterfaceNotPublishable::class);
        try {
            $svc->publish($this->admin, 'ar', [$key]);
        } finally {
            $this->get('/ar/contact')->assertOk()->assertSee($default);
            $svc->saveDraft($this->admin, 'ar', $key, 'عنوان مسودة', 'reviewed');
            $svc->publish($this->admin, 'ar', [$key]);
            $this->assertTrue(Locales::isPublished('ar'), 'publishing a reviewed text keeps the language ready');
            $this->get('/ar/contact')->assertOk()->assertSee('عنوان مسودة')->assertDontSee($default);
        }
    }
}
