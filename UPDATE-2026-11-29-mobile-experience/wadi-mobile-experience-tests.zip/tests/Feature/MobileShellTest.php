<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Models\SiteSetting;
use App\Support\Locales;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\File;
use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;

final class MobileShellTest extends TestCase
{
    use RefreshDatabase;

    private const LOCALES = ['ar', 'en', 'es', 'fr', 'it', 'pt', 'el', 'ru', 'zh', 'ur'];

    protected function setUp(): void
    {
        parent::setUp();
        SiteSetting::setMany(['maintenance_mode' => false], 'site');
        SiteSetting::set(Locales::SETTING, self::LOCALES, SiteSetting::TYPE_JSON);
        SiteSetting::flushCache();
        config(['wadi.enforce_locale_readiness' => false]);
    }

    #[Test]
    public function the_phone_stylesheet_is_applied_by_the_browser_only_at_599px_and_below(): void
    {
        $html = $this->get('/en')->assertOk()->getContent();
        $this->assertStringContainsString('<style media="(max-width: 599px)">', $html);
        $this->assertStringContainsString('.wrm-bar', $html);
        $this->assertStringContainsString('<style>.wrm{display:none}</style>', $html, 'the shell is hidden by default, so desktop and tablet never render it');
        $css = (string) file_get_contents(public_path('css/wr-mobile.css'));
        $this->assertStringContainsString('header[data-wr-site-header] { display: none !important; }', $css);
        $this->assertStringContainsString('<header', $html);
        $this->assertSame(1, preg_match_all('#<header\s+data-wr-site-header#', $html), 'the existing header is only tagged, not changed');
    }

    #[Test]
    public function the_language_strip_lists_every_published_language_with_its_flag_native_name_and_the_current_one_marked(): void
    {
        foreach (['en', 'ar', 'ur'] as $current) {
            $html = $this->get("/$current")->assertOk()->getContent();
            preg_match('#<div class="wrm wrm-langs".*?</div>#s', $html, $m);
            $strip = $m[0] ?? '';
            $this->assertSame(count(self::LOCALES), substr_count($strip, 'class="wrm-lang"'), "$current: one link per language");
            $this->assertSame(1, substr_count($strip, 'aria-current="true"'), "$current: exactly one current language");
            $this->assertMatchesRegularExpression('#lang="'.$current.'"[^>]*aria-current="true"#', $strip);
            foreach (self::LOCALES as $l) {
                $this->assertStringContainsString('hreflang="'.($l === 'zh' ? 'zh' : $l).'"', $strip);
                $this->assertStringContainsString(e(config('wadi.locales.'.$l.'.native')), $strip, "native name of $l");
            }
            $this->assertStringContainsString('<svg', $strip, 'chevrons for the "more languages" hint');
            $this->assertStringContainsString('<img', $strip, 'flags');
        }
    }

    #[Test]
    public function the_bottom_bar_has_the_five_destinations_with_real_routes_and_the_right_active_state(): void
    {
        $cases = ['/en' => 'home', '/en/products' => 'products', '/en/request-a-quote' => 'quote'];
        foreach ($cases as $url => $active) {
            $html = $this->get($url)->assertOk()->getContent();
            preg_match('#<nav class="wrm wrm-nav".*?</nav>#s', $html, $m);
            $nav = $m[0];
            $this->assertSame(5, preg_match_all('#class="wrm-nav-item#', $nav));
            foreach (['/en"', '/en/products"', '/en/packaging"', '/en/request-a-quote"'] as $href) {
                $this->assertStringContainsString($href, $nav);
            }
            $this->assertStringContainsString('data-wrm-open="more"', $nav);
            $this->assertSame(1, substr_count($nav, 'aria-current="page"'), "$url: one active item");
        }
    }

    #[Test]
    public function the_more_sheet_is_an_accessible_dialog_that_lists_the_rest_of_the_menu_and_quick_contact(): void
    {
        SiteSetting::set('contact.phone', '+20 2 3795 7755', SiteSetting::TYPE_STRING);
        SiteSetting::set('contact.email', 'sales@example.com', SiteSetting::TYPE_STRING);
        SiteSetting::flushCache();
        $html = $this->get('/en')->getContent();
        preg_match('#<div class="wrm wrm-sheet".*?\n</div>\n?#s', $html, $m);
        $sheet = $m[0] ?? $html;
        $this->assertStringContainsString('role="dialog" aria-modal="true" aria-labelledby="wrm-more-title" hidden', $sheet);
        $this->assertStringContainsString('aria-label="'.e(__('site.close')).'"', $sheet);
        foreach (['/en/about', '/en/quality', '/en/export', '/en/private-label', '/en/news', '/en/contact'] as $href) {
            $this->assertStringContainsString('href="'.url($href).'"', $sheet, $href);
        }
        $this->assertStringContainsString('tel:+20237957755', $sheet);
        $this->assertStringContainsString('mailto:sales@example.com', $sheet);
        $this->assertSame(1, substr_count($html, 'id="wrm-more-title"'));
        $this->assertStringNotContainsString('<h2 id="wrm-more-title"', $html, 'no extra heading element in the page outline');
    }

    #[Test]
    public function every_new_label_exists_in_all_ten_languages_and_nothing_is_left_untranslated(): void
    {
        $keys = array_keys(require lang_path('en/mobile.php'));
        $this->assertGreaterThanOrEqual(13, count($keys));
        $english = require lang_path('en/mobile.php');
        foreach (self::LOCALES as $l) {
            $own = require lang_path("$l/mobile.php");
            $this->assertSame($keys, array_keys($own), "$l has exactly the same keys");
            foreach ($own as $k => $v) {
                $this->assertNotSame('', trim((string) $v), "$l.$k is empty");
                if ($l !== 'en' && ! in_array($english[$k], ['WhatsApp', 'Email', 'Menu'], true) && $v === $english[$k]) {
                    $this->fail("$l.$k is still the English text");
                }
            }
        }
        // the bottom bar renders in the visitor's language
        $this->assertStringContainsString('>'.e(__('mobile.quote', [], 'ar')).'<', $this->get('/ar')->getContent());
        $this->assertStringContainsString('>'.e(__('mobile.more', [], 'ru')).'<', $this->get('/ru')->getContent());
    }

    #[Test]
    public function rtl_pages_keep_dir_rtl_and_ltr_pages_do_not(): void
    {
        foreach (['ar', 'ur'] as $l) {
            $this->assertStringContainsString('<html lang="'.$l.'" dir="rtl">', $this->get("/$l")->getContent());
        }
        $this->assertStringContainsString('<html lang="en" dir="ltr">', $this->get('/en')->getContent());
    }

    #[Test]
    public function the_shell_adds_no_second_h1_no_second_analytics_script_and_leaves_seo_tags_untouched(): void
    {
        $html = $this->get('/en')->assertOk()->getContent();
        $this->assertSame(1, substr_count($html, '<h1'), 'one main heading');
        $this->assertSame(substr_count($html, 'wr-analytics.js'), substr_count($html, 'wr-analytics.js'));
        $this->assertLessThanOrEqual(1, substr_count($html, 'js/wr-analytics.js'));
        $this->assertSame(1, substr_count($html, 'js/wr-mobile.js'));
        $this->assertStringContainsString('rel="canonical"', $html);
        $this->assertGreaterThanOrEqual(10, substr_count($html, '<link rel="alternate" hreflang='));
        $this->assertStringContainsString('<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">', $html);
        $head = explode('</head>', $html)[0];
        $this->assertStringNotContainsString('wrm-', $head === '' ? '' : preg_replace(['#<script[^>]*wr-mobile[^>]*>#', '#<style media="\(max-width: 599px\)">.*?</style>#s'], '', $head), 'the head only gains the stylesheet link and the script');
    }

    #[Test]
    public function filter_and_form_hooks_exist_for_the_phone_sheet_and_the_fields_carry_keyboard_hints(): void
    {
        $products = $this->get('/en/products')->assertOk()->getContent();
        foreach (['data-wr-filters', 'data-wr-filter-panel', 'data-wr-filter-toggle', 'data-wrm-filter-strings'] as $hook) {
            $this->assertStringContainsString($hook, $products);
        }
        $quote = $this->get('/en/request-a-quote')->assertOk()->getContent();
        $this->assertMatchesRegularExpression('#name="email"[^>]*autocomplete="email"#s', $quote);
        $this->assertMatchesRegularExpression('#name="phone"[^>]*inputmode="tel"#s', $quote);
        $this->assertMatchesRegularExpression('#type="email"#', $quote);
    }

    #[Test]
    public function the_phone_assets_are_plain_static_files_with_no_build_step_and_no_external_requests(): void
    {
        foreach (['css/wr-mobile.css', 'js/wr-mobile.js'] as $f) {
            $body = (string) File::get(public_path($f));
            $this->assertStringNotContainsString('http://', $body);
            $this->assertStringNotContainsString('https://', $body);
            $this->assertStringNotContainsString('@import', $body);
        }
        $this->assertLessThan(40 * 1024, filesize(public_path('css/wr-mobile.css')));
        $this->assertLessThan(30 * 1024, filesize(public_path('js/wr-mobile.js')));
    }
}
