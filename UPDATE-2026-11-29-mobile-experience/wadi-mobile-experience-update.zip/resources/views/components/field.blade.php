@props([
    'name',
    'label',
    'type' => 'text',
    'required' => false,
    'value' => null,
    'placeholder' => null,
    'help' => null,
    'rows' => 4,
    'options' => null,
    'prompt' => null,
    'dir' => null,
])

@php
    $hasError = $errors->has($name);
    $id = 'field-'.str_replace(['[', ']', '.'], ['-', '', '-'], $name);
    // Keyboard and autofill hints only (no visual effect): the right on-screen keyboard and one-tap autofill on phones.
    $autoMap = ['email' => 'email', 'phone' => 'tel', 'whatsapp' => 'tel', 'company_name' => 'organization', 'contact_person' => 'name', 'name' => 'name'];
    $autoComplete = $autoMap[$name] ?? null;
    $inputMode = match (true) { $type === 'tel' => 'tel', $type === 'email' => 'email', $type === 'number' => 'decimal', default => null };
@endphp

<div>
    <label for="{{ $id }}" @class(['field-label', 'field-required' => $required])>{{ $label }}</label>

    @if ($type === 'textarea')
        <textarea id="{{ $id }}"
                  name="{{ $name }}"
                  rows="{{ $rows }}"
                  @if ($required) required @endif
                  @if ($placeholder) placeholder="{{ $placeholder }}" @endif
                  @if ($dir) dir="{{ $dir }}" @endif
                  @if ($hasError) aria-invalid="true" aria-describedby="{{ $id }}-error" @endif
                  @class(['input', 'input-error' => $hasError])
        >{{ old($name, $value) }}</textarea>

    @elseif ($type === 'select')
        <select id="{{ $id }}"
                name="{{ $name }}"
                @if ($required) required @endif
                @if ($hasError) aria-invalid="true" aria-describedby="{{ $id }}-error" @endif
                @class(['input', 'input-error' => $hasError])>
            <option value="">{{ $prompt ?? '—' }}</option>
            @foreach ($options ?? [] as $optValue => $optLabel)
                <option value="{{ $optValue }}" @selected((string) old($name, $value) === (string) $optValue)>{{ $optLabel }}</option>
            @endforeach
        </select>

    @else
        <input id="{{ $id }}"
               type="{{ $type }}"
               name="{{ $name }}"
               value="{{ old($name, $value) }}"
               @if ($required) required @endif
               @if ($placeholder) placeholder="{{ $placeholder }}" @endif
               @if ($dir) dir="{{ $dir }}" @endif
               @if ($autoComplete && ! $attributes->has('autocomplete')) autocomplete="{{ $autoComplete }}" @endif
               @if ($inputMode && ! $attributes->has('inputmode')) inputmode="{{ $inputMode }}" @endif
               @if ($hasError) aria-invalid="true" aria-describedby="{{ $id }}-error" @endif
               {{ $attributes->class(['input', 'input-error' => $hasError]) }}>
    @endif

    @if ($help && ! $hasError)
        <p class="mt-1.5 text-[0.8125rem] text-ink-subtle">{{ $help }}</p>
    @endif

    @error($name)
        <p id="{{ $id }}-error" class="field-error">{{ $message }}</p>
    @enderror
</div>
