{{--
    PHONE-ONLY shell (viewport 599 px and narrower): language strip, compact header, bottom navigation and the "More" sheet.

    Everything here carries the class `wrm` and is display:none by default (the tiny rule below), so desktop and tablet never render,
    focus or announce any of it. The look comes from public/css/wr-mobile.css, which the browser applies only at <= 599 px
    (media attribute on its <link>); behaviour from public/js/wr-mobile.js, which activates and deactivates with the viewport.
    Same routes, same menu, same languages as the rest of the site: nothing here is a second content system.
--}}
@php
    $mLocale = app()->getLocale();
    $mLogo = setting_media('company.logo_light');
    $mName = setting('company.short_name_'.$mLocale) ?? setting('company.short_name_en') ?? config('app.name');
    $mLangs = \App\Support\LanguagePicker::items();
    $mPhone = (string) setting('contact.phone');
    $mEmail = (string) setting('contact.email');
    $mWa = preg_replace('/[^0-9]/', '', (string) setting('contact.whatsapp'));

    // The same menu the desktop header uses; fallback to the built-in routes on a fresh install.
    $mTree = function ($children) use (&$mTree, $mLocale): array {
        return collect($children)->map(fn ($c) => ['label' => $c->label($mLocale), 'href' => $c->href($mLocale), 'new_tab' => $c->open_in_new_tab, 'children' => $mTree($c->children ?? [])])->all();
    };
    $mMenu = ($headerMenu ?? collect())->isNotEmpty()
        ? ($headerMenu ?? collect())->map(fn ($i) => ['label' => $i->label($mLocale), 'href' => $i->href($mLocale), 'new_tab' => $i->open_in_new_tab, 'children' => $mTree($i->children ?? [])])->all()
        : [
            ['label' => __('site.nav.about'), 'href' => route('about'), 'new_tab' => false, 'children' => []],
            ['label' => __('site.nav.quality'), 'href' => route('quality'), 'new_tab' => false, 'children' => []],
            ['label' => __('site.nav.export'), 'href' => route('export'), 'new_tab' => false, 'children' => []],
            ['label' => __('site.nav.private_label'), 'href' => route('private-label'), 'new_tab' => false, 'children' => []],
            ['label' => __('site.nav.news'), 'href' => route('news.index'), 'new_tab' => false, 'children' => []],
            ['label' => __('site.nav.contact'), 'href' => route('contact.show'), 'new_tab' => false, 'children' => []],
        ];

    // What the bottom bar already offers is not repeated in the sheet.
    $mBar = [route('home'), route('products.index'), route('packaging.index'), route('quote.create')];
    $mRest = array_values(array_filter($mMenu, fn ($i) => ! in_array(rtrim((string) $i['href'], '/'), array_map(fn ($u) => rtrim($u, '/'), $mBar), true)));

    $icon = fn (string $d) => '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">'.$d.'</svg>';
    $ico = [
        'home' => '<path d="M3 11.5 12 4l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
        'products' => '<path d="M21 8 12 3 3 8v8l9 5 9-5z"/><path d="m3 8 9 5 9-5M12 13v8"/>',
        'packaging' => '<path d="M8 3h8v3H8z"/><path d="M7 6h10a1 1 0 0 1 1 1v12a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V7a1 1 0 0 1 1-1z"/><path d="M6 11h12"/>',
        'quote' => '<path d="M5 4h14a1 1 0 0 1 1 1v11a1 1 0 0 1-1 1H9l-5 4V5a1 1 0 0 1 1-1z"/><path d="M8 9h8M8 12.5h5"/>',
        'more' => '<circle cx="5" cy="12" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="19" cy="12" r="1.5"/>',
        'menu' => '<path d="M4 7h16M4 12h16M4 17h16"/>',
        'close' => '<path d="m6 6 12 12M18 6 6 18"/>',
        'phone' => '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/>',
        'mail' => '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
        'wa' => '<path d="M3 21l1.6-4.7A8.5 8.5 0 1 1 8 19.5z"/><path d="M9 9.5c.5 3 2.5 5 5.5 5.5l1.2-1.2-2-1-.9.7c-1-.4-1.8-1.2-2.2-2.2l.7-.9-1-2z"/>',
        'chev' => '<path d="m9 6 6 6-6 6"/>',
    ];
    $nav = [
        ['home', __('site.nav.home'), route('home'), request()->routeIs('home')],
        ['products', __('site.nav.products'), route('products.index'), request()->routeIs('products.*')],
        ['packaging', __('site.nav.packaging'), route('packaging.index'), request()->routeIs('packaging.*')],
    ];
@endphp

<style>.wrm{display:none}</style>

{{-- 1. Language strip: every enabled language, flag over its native name, current one highlighted; scrolls sideways if needed. --}}
<div class="wrm wrm-langs" data-wrm-langs>
    @if (count($mLangs) > 1)
        <nav aria-label="{{ __('chrome.lang.switch') }}">
            <ul class="wrm-langs-list" role="list" data-wrm-langs-list>
                @foreach ($mLangs as $it)
                    <li>
                        <a href="{{ $it['url'] }}" hreflang="{{ $it['hreflang'] }}" lang="{{ $it['code'] }}" dir="{{ $it['dir'] }}"
                           @if ($it['active']) aria-current="true" @endif
                           class="wrm-lang">
                            @php($fc = strtolower(preg_replace('/[^A-Za-z]/', '', (string) $it['flag'])))
                            <span class="wrm-flag">@if (strlen($fc) === 2 && is_file(public_path('flags/sm/'.$fc.'.webp')))<img src="{{ asset('flags/sm/'.$fc.'.webp') }}" alt="" width="21" height="16" decoding="async" class="block" style="width:21px;height:16px;border-radius:2px;object-fit:cover">@else<x-flag :code="$it['flag']" :height="16" class="block" />@endif</span>
                            <span class="wrm-lang-name">{{ $it['native'] }}</span>
                        </a>
                    </li>
                @endforeach
            </ul>
        </nav>
        <span class="wrm-fade wrm-fade-start" aria-hidden="true">{!! $icon($ico['chev']) !!}</span>
        <span class="wrm-fade wrm-fade-end" aria-hidden="true">{!! $icon($ico['chev']) !!}</span>
    @endif
</div>

{{-- 2. Compact header: logo + menu button (opens the same sheet as "More"). --}}
<header class="wrm wrm-bar">
    <a href="{{ route('home') }}" class="wrm-logo" aria-label="{{ $mName }}">
        @if ($mLogo)
            <img src="{{ $mLogo->urlFor(240) }}" alt="{{ $mName }}" width="{{ $mLogo->width }}" height="{{ $mLogo->height }}" decoding="async">
        @else
            <span>{{ $mName }}</span>
        @endif
    </a>
    <button type="button" class="wrm-menu-btn" data-wrm-open="more" aria-haspopup="dialog" aria-controls="wrm-more" aria-expanded="false" aria-label="{{ __('site.menu') }}">
        {!! $icon($ico['menu']) !!}
    </button>
</header>

{{-- 3. Bottom navigation --}}
<nav class="wrm wrm-nav" aria-label="{{ __('site.menu') }}" data-wrm-nav data-wrm-sending="{{ __('mobile.sending') }}" data-wrm-prev="{{ __('mobile.prev') }}" data-wrm-next="{{ __('mobile.next') }}" data-wrm-table="{{ __('mobile.table') }}">
    @foreach ($nav as [$k, $label, $href, $active])
        <a href="{{ $href }}" class="wrm-nav-item" @if ($active) aria-current="page" @endif>
            {!! $icon($ico[$k]) !!}<span>{{ $label }}</span>
        </a>
    @endforeach
    <a href="{{ route('quote.create') }}" class="wrm-nav-item wrm-nav-primary" @if (request()->routeIs('quote.*')) aria-current="page" @endif>
        {!! $icon($ico['quote']) !!}<span>{{ __('mobile.quote') }}</span>
    </a>
    <button type="button" class="wrm-nav-item" data-wrm-open="more" aria-haspopup="dialog" aria-controls="wrm-more" aria-expanded="false">
        {!! $icon($ico['more']) !!}<span>{{ __('mobile.more') }}</span>
    </button>
</nav>

{{-- 4. "More" sheet: the rest of the site navigation, quick contact. Closes with Escape / backdrop / close button; focus returns to the opener. --}}
<div class="wrm wrm-sheet" id="wrm-more" role="dialog" aria-modal="true" aria-labelledby="wrm-more-title" hidden data-wrm-sheet>
    <div class="wrm-backdrop" data-wrm-close></div>
    <div class="wrm-panel" tabindex="-1">
        <div class="wrm-panel-head">
            <div id="wrm-more-title" class="wrm-title">{{ __('mobile.menu_title') }}</div>
            <button type="button" class="wrm-close" data-wrm-close aria-label="{{ __('site.close') }}">{!! $icon($ico['close']) !!}</button>
        </div>
        <nav class="wrm-more-list" aria-label="{{ __('site.menu') }}">
            @foreach ($mRest as $item)
                @if (empty($item['children']))
                    <a href="{{ $item['href'] }}" @if ($item['new_tab']) target="_blank" rel="noopener noreferrer" @endif class="wrm-more-link">
                        <span>{{ $item['label'] }}</span>{!! $icon($ico['chev']) !!}
                    </a>
                @else
                    <details class="wrm-more-group">
                        <summary class="wrm-more-link"><span>{{ $item['label'] }}</span>{!! $icon($ico['chev']) !!}</summary>
                        <div class="wrm-more-sub">
                            <a href="{{ $item['href'] }}" class="wrm-more-link wrm-more-sub-link"><span>{{ $item['label'] }}</span></a>
                            @foreach ($item['children'] as $child)
                                <a href="{{ $child['href'] }}" @if ($child['new_tab']) target="_blank" rel="noopener noreferrer" @endif class="wrm-more-link wrm-more-sub-link"><span>{{ $child['label'] }}</span></a>
                            @endforeach
                        </div>
                    </details>
                @endif
            @endforeach
        </nav>
        {{-- The floating "Privacy choices" pill is replaced on phones by this entry (it reopens the same consent notice). Shown by JS only when the pill exists. --}}
        <button type="button" class="wrm-more-link wrm-consent-link" data-wrm-consent hidden><span></span>{!! $icon($ico['chev']) !!}</button>
        @if ($mPhone !== '' || $mEmail !== '' || $mWa !== '')
            <div class="wrm-quick" aria-label="{{ __('mobile.quick_contact') }}">
                @if ($mPhone !== '')<a href="tel:{{ preg_replace('/[^0-9+]/', '', $mPhone) }}">{!! $icon($ico['phone']) !!}<span>{{ __('mobile.call') }}</span></a>@endif
                @if ($mEmail !== '')<a href="mailto:{{ $mEmail }}">{!! $icon($ico['mail']) !!}<span>{{ __('mobile.email') }}</span></a>@endif
                @if ($mWa !== '')<a href="https://wa.me/{{ $mWa }}" target="_blank" rel="noopener noreferrer">{!! $icon($ico['wa']) !!}<span>{{ __('mobile.whatsapp') }}</span></a>@endif
            </div>
        @endif
    </div>
</div>
