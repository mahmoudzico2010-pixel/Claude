<?php

// Phone-only navigation and sheets (bottom bar, More sheet, filter sheet). Short labels; the long forms live in site.php.
return [
    'quote' => 'Προσφορά',
    'more' => 'Περισσότερα',
    'filters' => 'Φίλτρα',
    'filters_active' => ':count ενεργά',
    'call' => 'Κλήση',
    'email' => 'Email',
    'whatsapp' => 'WhatsApp',
    'sending' => 'Αποστολή…',
    'menu_title' => 'Μενού',
    'quick_contact' => 'Επικοινωνία',
    'languages_hint' => 'Περισσότερες γλώσσες',
    'prev' => 'Προηγούμενο',
    'next' => 'Επόμενο',
    'table' => 'Πίνακας',
];
