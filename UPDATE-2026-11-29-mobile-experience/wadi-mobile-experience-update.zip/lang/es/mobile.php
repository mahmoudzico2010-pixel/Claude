<?php

// Phone-only navigation and sheets (bottom bar, More sheet, filter sheet). Short labels; the long forms live in site.php.
return [
    'quote' => 'Presupuesto',
    'more' => 'Más',
    'filters' => 'Filtros',
    'filters_active' => ':count activos',
    'call' => 'Llamar',
    'email' => 'Correo',
    'whatsapp' => 'WhatsApp',
    'sending' => 'Enviando…',
    'menu_title' => 'Menú',
    'quick_contact' => 'Contacto',
    'languages_hint' => 'Más idiomas',
    'prev' => 'Anterior',
    'next' => 'Siguiente',
    'table' => 'Tabla',
];
