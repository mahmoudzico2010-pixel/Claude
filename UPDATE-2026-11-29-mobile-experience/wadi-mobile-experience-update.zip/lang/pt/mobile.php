<?php

// Phone-only navigation and sheets (bottom bar, More sheet, filter sheet). Short labels; the long forms live in site.php.
return [
    'quote' => 'Orçamento',
    'more' => 'Mais',
    'filters' => 'Filtros',
    'filters_active' => ':count ativos',
    'call' => 'Ligar',
    'email' => 'E-mail',
    'whatsapp' => 'WhatsApp',
    'sending' => 'A enviar…',
    'menu_title' => 'Menu',
    'quick_contact' => 'Contacte-nos',
    'languages_hint' => 'Mais idiomas',
    'prev' => 'Anterior',
    'next' => 'Seguinte',
    'table' => 'Tabela',
];
