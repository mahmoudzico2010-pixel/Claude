<?php

// Phone-only navigation and sheets (bottom bar, More sheet, filter sheet). Short labels; the long forms live in site.php.
return [
    'quote' => 'کوٹیشن',
    'more' => 'مزید',
    'filters' => 'فلٹرز',
    'filters_active' => ':count فعال',
    'call' => 'کال کریں',
    'email' => 'ای میل',
    'whatsapp' => 'واٹس ایپ',
    'sending' => 'بھیج رہے ہیں…',
    'menu_title' => 'مینو',
    'quick_contact' => 'رابطہ کریں',
    'languages_hint' => 'مزید زبانیں',
    'prev' => 'پچھلا',
    'next' => 'اگلا',
    'table' => 'جدول',
];
