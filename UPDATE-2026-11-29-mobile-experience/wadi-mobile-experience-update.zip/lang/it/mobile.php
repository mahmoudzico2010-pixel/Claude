<?php

// Phone-only navigation and sheets (bottom bar, More sheet, filter sheet). Short labels; the long forms live in site.php.
return [
    'quote' => 'Preventivo',
    'more' => 'Altro',
    'filters' => 'Filtri',
    'filters_active' => ':count attivi',
    'call' => 'Chiama',
    'email' => 'Email',
    'whatsapp' => 'WhatsApp',
    'sending' => 'Invio…',
    'menu_title' => 'Menu',
    'quick_contact' => 'Contattaci',
    'languages_hint' => 'Altre lingue',
    'prev' => 'Precedente',
    'next' => 'Successivo',
    'table' => 'Tabella',
];
