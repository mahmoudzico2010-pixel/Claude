<?php

// Phone-only navigation and sheets (bottom bar, More sheet, filter sheet). Short labels; the long forms live in site.php.
return [
    'quote' => 'Quote',
    'more' => 'More',
    'filters' => 'Filters',
    'filters_active' => ':count active',
    'call' => 'Call',
    'email' => 'Email',
    'whatsapp' => 'WhatsApp',
    'sending' => 'Sending…',
    'menu_title' => 'Menu',
    'quick_contact' => 'Get in touch',
    'languages_hint' => 'More languages',
    'prev' => 'Previous',
    'next' => 'Next',
    'table' => 'Table',
];
