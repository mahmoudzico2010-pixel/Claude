<?php

// Phone-only navigation and sheets (bottom bar, More sheet, filter sheet). Short labels; the long forms live in site.php.
return [
    'quote' => 'Запрос',
    'more' => 'Ещё',
    'filters' => 'Фильтры',
    'filters_active' => 'выбрано: :count',
    'call' => 'Позвонить',
    'email' => 'Почта',
    'whatsapp' => 'WhatsApp',
    'sending' => 'Отправка…',
    'menu_title' => 'Меню',
    'quick_contact' => 'Связаться',
    'languages_hint' => 'Другие языки',
    'prev' => 'Назад',
    'next' => 'Вперёд',
    'table' => 'Таблица',
];
