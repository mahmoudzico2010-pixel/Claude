<?php

// Phone-only navigation and sheets (bottom bar, More sheet, filter sheet). Short labels; the long forms live in site.php.
return [
    'quote' => '报价',
    'more' => '更多',
    'filters' => '筛选',
    'filters_active' => '已选 :count 项',
    'call' => '致电',
    'email' => '邮件',
    'whatsapp' => 'WhatsApp',
    'sending' => '发送中…',
    'menu_title' => '菜单',
    'quick_contact' => '联系我们',
    'languages_hint' => '更多语言',
    'prev' => '上一张',
    'next' => '下一张',
    'table' => '表格',
];
