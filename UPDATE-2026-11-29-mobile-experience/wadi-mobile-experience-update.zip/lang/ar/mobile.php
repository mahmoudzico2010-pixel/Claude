<?php

// Phone-only navigation and sheets (bottom bar, More sheet, filter sheet). Short labels; the long forms live in site.php.
return [
    'quote' => 'عرض سعر',
    'more' => 'المزيد',
    'filters' => 'تصفية',
    'filters_active' => ':count نشط',
    'call' => 'اتصال',
    'email' => 'بريد',
    'whatsapp' => 'واتساب',
    'sending' => 'جارٍ الإرسال…',
    'menu_title' => 'القائمة',
    'quick_contact' => 'تواصل معنا',
    'languages_hint' => 'لغات أخرى',
    'prev' => 'السابق',
    'next' => 'التالي',
    'table' => 'جدول',
];
