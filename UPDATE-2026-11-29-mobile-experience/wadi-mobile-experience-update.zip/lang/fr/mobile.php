<?php

// Phone-only navigation and sheets (bottom bar, More sheet, filter sheet). Short labels; the long forms live in site.php.
return [
    'quote' => 'Devis',
    'more' => 'Plus',
    'filters' => 'Filtres',
    'filters_active' => ':count actifs',
    'call' => 'Appeler',
    'email' => 'E-mail',
    'whatsapp' => 'WhatsApp',
    'sending' => 'Envoi…',
    'menu_title' => 'Menu',
    'quick_contact' => 'Nous contacter',
    'languages_hint' => 'Plus de langues',
    'prev' => 'Précédent',
    'next' => 'Suivant',
    'table' => 'Tableau',
];
