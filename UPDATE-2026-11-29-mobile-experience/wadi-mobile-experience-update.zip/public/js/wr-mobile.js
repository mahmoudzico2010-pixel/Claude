/*
 * Wadi El Rayan — phone-only behaviour (viewport 599 px and narrower).
 * No framework, no dependencies. Everything starts only while the phone media query matches and is undone completely when it stops
 * matching (rotate / resize), so desktop and tablet never keep any of it: no listeners, no wrapped tables, no extra buttons.
 */
(function () {
    'use strict';

    var mq = window.matchMedia('(max-width: 599px)');
    var root = document.documentElement;
    var state = { active: false, cleanup: [], opener: null, sheet: null, extras: [] };

    function on(target, type, fn, opts) {
        target.addEventListener(type, fn, opts);
        state.cleanup.push(function () { target.removeEventListener(type, fn, opts); });
    }
    function qs(sel, ctx) { return (ctx || document).querySelector(sel); }
    function qsa(sel, ctx) { return Array.prototype.slice.call((ctx || document).querySelectorAll(sel)); }
    function isRtl() { return (root.getAttribute('dir') || 'ltr') === 'rtl'; }

    /* ------------------------------------------------------------------ language strip */
    function initLangs() {
        var box = qs('[data-wrm-langs]');
        var list = box && qs('[data-wrm-langs-list]', box);
        if (!list) { return; }
        function hint() {
            var max = list.scrollWidth - list.clientWidth;
            var pos = Math.abs(list.scrollLeft);
            box.toggleAttribute('data-more-start', max > 2 && pos > 2);
            box.toggleAttribute('data-more-end', max > 2 && pos < max - 2);
        }
        var current = qs('[aria-current]', list);
        if (current) {
            var y = window.pageYOffset;
            current.scrollIntoView({ inline: 'center', block: 'nearest' });
            window.scrollTo(0, y);   // never let this move the page itself
        }
        hint();
        on(list, 'scroll', hint, { passive: true });
        on(window, 'resize', hint);
    }

    /* ------------------------------------------------------------------ sheets (More, filters) */
    function focusable(ctx) {
        return qsa('a[href],button:not([disabled]),input:not([disabled]),select,textarea,summary,[tabindex]:not([tabindex="-1"])', ctx)
            .filter(function (el) { return el.offsetParent !== null || el === document.activeElement; });
    }
    function setInert(on_) {
        qsa('main, footer, .wrm-bar, .wrm-langs, .wrm-nav, a[aria-label="WhatsApp"]').forEach(function (el) {
            if (on_) { el.setAttribute('inert', ''); } else { el.removeAttribute('inert'); }
        });
    }
    function syncConsent(sheet) {
        var entry = qs('[data-wrm-consent]', sheet), pill = document.getElementById('wr-consent-open');
        if (!entry) { return; }
        var show = !!pill && !pill.hidden;
        entry.hidden = !show;
        if (show) { entry.firstChild.textContent = pill.textContent.trim(); }
    }
    function openSheet(sheet, opener) {
        if (!sheet || state.sheet) { return; }
        state.sheet = sheet; state.opener = opener || document.activeElement;
        syncConsent(sheet);
        sheet.hidden = false;
        void sheet.offsetWidth;
        sheet.classList.add('is-open');
        root.classList.add('wrm-locked');
        qsa('[data-wrm-open]').forEach(function (b) { b.setAttribute('aria-expanded', 'true'); });
        setInert(true);
        var first = qs('.wrm-close', sheet) || qs('.wrm-panel', sheet);
        if (first) { first.focus({ preventScroll: true }); }
    }
    function closeSheet(immediate) {
        var sheet = state.sheet;
        if (!sheet) { return; }
        state.sheet = null;
        sheet.classList.remove('is-open');
        root.classList.remove('wrm-locked');
        setInert(false);
        qsa('[data-wrm-open]').forEach(function (b) { b.setAttribute('aria-expanded', 'false'); });
        var done = function () { sheet.hidden = true; };
        if (immediate || window.matchMedia('(prefers-reduced-motion: reduce)').matches) { done(); } else { setTimeout(done, 230); }
        var opener = state.opener; state.opener = null;
        if (opener && opener.focus && !immediate) { opener.focus({ preventScroll: true }); }
    }
    function initSheet() {
        var sheet = qs('[data-wrm-sheet]');
        if (!sheet) { return; }
        qsa('[data-wrm-open]').forEach(function (btn) {
            on(btn, 'click', function () { openSheet(sheet, btn); });
        });
        qsa('[data-wrm-close]', sheet).forEach(function (el) { on(el, 'click', function () { closeSheet(); }); });
        var consentEntry = qs('[data-wrm-consent]', sheet);
        if (consentEntry) {
            on(consentEntry, 'click', function () {
                var pill = document.getElementById('wr-consent-open');
                closeSheet(true);
                if (pill) { pill.click(); }
            });
        }
        on(sheet, 'click', function (e) { if (e.target.closest('a[href]')) { closeSheet(true); } });
        on(document, 'keydown', function (e) {
            if (!state.sheet) { return; }
            if (e.key === 'Escape') { e.preventDefault(); closeSheet(); return; }
            if (e.key === 'Tab') {
                var f = focusable(state.sheet);
                if (!f.length) { return; }
                var first = f[0], last = f[f.length - 1];
                if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
                else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
            }
        });
        on(window, 'pageshow', function (e) { if (e.persisted) { closeSheet(true); } });
    }

    /* ------------------------------------------------------------------ product filters as a bottom sheet */
    function initFilters() {
        var panel = qs('[data-wr-filter-panel]');
        var wrap = qs('[data-wr-filters]');
        if (!panel || !wrap) { return; }
        var form = qs('form', panel);
        if (!form) { return; }
        var strings = qs('[data-wrm-filter-strings]');
        var label = strings ? strings.getAttribute('data-label') : 'Filters';
        var activeTpl = strings ? strings.getAttribute('data-active') : ':count';
        var title = strings ? strings.getAttribute('data-title') : '';
        var closeLabel = strings ? strings.getAttribute('data-close') : 'Close';
        var clearLabel = strings ? strings.getAttribute('data-clear') : 'Clear';

        function count() { return qsa('input[type=checkbox]:checked', form).length; }

        var btn = document.createElement('button');
        btn.type = 'button'; btn.className = 'wrm-filter-btn'; btn.setAttribute('aria-haspopup', 'dialog');
        var badge = document.createElement('span'); badge.className = 'wrm-filter-count';
        var txt = document.createElement('span'); txt.textContent = label;
        btn.appendChild(txt); btn.appendChild(badge);
        // The button lives in its own sticky bar (a sibling of the aside) so it stays reachable while scrolling a long list and the
        // fixed sheet is not trapped inside a stacking context.
        var bar = document.createElement('div'); bar.className = 'wrm-fbar'; bar.appendChild(btn);
        wrap.parentNode.insertBefore(bar, wrap);
        function paint() {
            var n = count();
            badge.textContent = n ? String(n) : '';
            badge.hidden = !n;
            btn.setAttribute('aria-label', label + (n ? ', ' + activeTpl.replace(':count', String(n)) : ''));
        }
        paint();

        var backdrop = document.createElement('div'); backdrop.className = 'wrm-fbackdrop'; backdrop.hidden = true;
        document.body.appendChild(backdrop);
        var head = document.createElement('div'); head.className = 'wrm-fhead';
        head.innerHTML = '<strong></strong><button type="button" class="wrm-close" aria-label=""><svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" aria-hidden="true"><path d="m6 6 12 12M18 6 6 18"/></svg></button>';
        head.firstChild.textContent = title || label;
        head.lastChild.setAttribute('aria-label', closeLabel);
        panel.insertBefore(head, panel.firstChild);

        var clear = document.createElement('button');
        clear.type = 'button'; clear.className = 'wrm-fclear'; clear.textContent = clearLabel;
        var actions = qs('button[type=submit]', form);
        if (actions && actions.parentNode) { actions.parentNode.classList.add('wrm-factions'); actions.parentNode.appendChild(clear); }

        var isOpen = false;
        function open() {
            if (isOpen) { return; } isOpen = true;
            panel.classList.add('wrm-fopen'); backdrop.hidden = false; root.classList.add('wrm-locked');
            btn.setAttribute('aria-expanded', 'true');
            panel.setAttribute('role', 'dialog'); panel.setAttribute('aria-modal', 'true'); panel.setAttribute('aria-label', title || label);
            var f = qs('.wrm-close', head); if (f) { f.focus({ preventScroll: true }); }
        }
        function close(silent) {
            if (!isOpen) { return; } isOpen = false;
            panel.classList.remove('wrm-fopen'); backdrop.hidden = true; root.classList.remove('wrm-locked');
            btn.setAttribute('aria-expanded', 'false');
            panel.removeAttribute('role'); panel.removeAttribute('aria-modal'); panel.removeAttribute('aria-label');
            if (!silent) { btn.focus({ preventScroll: true }); }
        }
        on(btn, 'click', open);
        on(backdrop, 'click', function () { close(); });
        on(head.lastChild, 'click', function () { close(); });
        on(clear, 'click', function () { qsa('input[type=checkbox]', form).forEach(function (c) { c.checked = false; }); paint(); });
        on(form, 'change', paint);
        on(document, 'keydown', function (e) {
            if (!isOpen) { return; }
            if (e.key === 'Escape') { e.preventDefault(); close(); return; }
            if (e.key === 'Tab') {
                var f = focusable(panel); if (!f.length) { return; }
                var first = f[0], last = f[f.length - 1];
                if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
                else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
            }
        });
        state.cleanup.push(function () {
            close(true);
            [bar, backdrop, head, clear].forEach(function (el) { if (el.parentNode) { el.parentNode.removeChild(el); } });
            if (actions && actions.parentNode) { actions.parentNode.classList.remove('wrm-factions'); }
        });
    }

    /* ------------------------------------------------------------------ forms: no double submit, keyboard-friendly */
    function initForms() {
        var strings = qs('[data-wrm-sending]');
        var sendingText = strings ? strings.getAttribute('data-wrm-sending') : '';
        on(document, 'submit', function (e) {
            var f = e.target;
            if (!f || f.tagName !== 'FORM' || (f.method || '').toLowerCase() !== 'post' || f.hasAttribute('data-wrm-skip')) { return; }
            if (f.getAttribute('data-wrm-busy') === '1') { e.preventDefault(); return; }
            f.setAttribute('data-wrm-busy', '1');
            setTimeout(function () {
                qsa('button[type=submit], input[type=submit]', f).forEach(function (b) {
                    b.setAttribute('aria-disabled', 'true'); b.classList.add('wrm-busy');
                    if (b.tagName === 'BUTTON' && sendingText) { b.setAttribute('data-wrm-label', b.textContent); b.textContent = sendingText; }
                });
            }, 0);
        }, true);
        on(window, 'pageshow', function () {
            qsa('form[data-wrm-busy]').forEach(function (f) {
                f.removeAttribute('data-wrm-busy');
                qsa('.wrm-busy', f).forEach(function (b) {
                    b.removeAttribute('aria-disabled'); b.classList.remove('wrm-busy');
                    if (b.hasAttribute('data-wrm-label')) { b.textContent = b.getAttribute('data-wrm-label'); b.removeAttribute('data-wrm-label'); }
                });
            });
        });
    }
    function initKeyboard() {
        function isField(el) { return el && /^(INPUT|TEXTAREA|SELECT)$/.test(el.tagName) && !/^(checkbox|radio|button|submit|file)$/.test(el.type || ''); }
        var timer;
        on(document, 'focusin', function (e) {
            if (!isField(e.target) || e.target.closest('[data-wrm-sheet], .wrm-fopen')) { return; }
            clearTimeout(timer); root.classList.add('wrm-kb');
            setTimeout(function () { try { e.target.scrollIntoView({ block: 'center', behavior: 'smooth' }); } catch (x) {} }, 280);
        });
        on(document, 'focusout', function () { timer = setTimeout(function () { if (!isField(document.activeElement)) { root.classList.remove('wrm-kb'); } }, 120); });
        state.cleanup.push(function () { root.classList.remove('wrm-kb'); });
    }

    /* ------------------------------------------------------------------ tables never widen the page */
    function initTables() {
        var wrapped = [];
        qsa('main table').forEach(function (t) {
            if (t.closest('.wrm-table')) { return; }
            var w = document.createElement('div'); w.className = 'wrm-table'; w.tabIndex = 0; w.setAttribute('role', 'region');
            w.setAttribute('aria-label', (t.getAttribute('aria-label') || (t.caption && t.caption.textContent) || (qs('[data-wrm-table]') && qs('[data-wrm-table]').getAttribute('data-wrm-table')) || 'Table').trim());
            t.parentNode.insertBefore(w, t); w.appendChild(t); wrapped.push(w);
        });
        state.cleanup.push(function () { wrapped.forEach(function (w) { if (w.parentNode && w.firstChild) { w.parentNode.insertBefore(w.firstChild, w); w.parentNode.removeChild(w); } }); });
    }

    /* ------------------------------------------------------------------ product gallery: swipe + visible arrows */
    function initGallery() {
        var frame = qs('.media-frame-magnify');
        var host = frame && frame.closest('[x-data]');
        if (!frame || !host || !window.Alpine || !Alpine.$data) { return; }
        var data; try { data = Alpine.$data(host); } catch (e) { return; }
        if (!data || !data.images || data.images.length < 2) { return; }
        function go(d) { var n = (data.active + d + data.images.length) % data.images.length; data.select(n); }
        var made = [];
        var labels = qs('[data-wrm-prev]');
        [['prev', -1], ['next', 1]].forEach(function (p) {
            var b = document.createElement('button'); b.type = 'button'; b.className = 'wrm-gal-btn wrm-gal-' + p[0];
            b.setAttribute('aria-label', (labels && labels.getAttribute('data-wrm-' + p[0])) || p[0]);
            b.innerHTML = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 6 6 6-6 6"/></svg>';
            on(b, 'click', function (e) { e.stopPropagation(); go(p[1]); });
            frame.appendChild(b); made.push(b);
        });
        var x0 = null;
        on(frame, 'touchstart', function (e) { x0 = e.touches[0].clientX; }, { passive: true });
        on(frame, 'touchend', function (e) {
            if (x0 === null) { return; }
            var dx = e.changedTouches[0].clientX - x0; x0 = null;
            if (Math.abs(dx) > 40) { go((dx < 0 ? 1 : -1) * (isRtl() ? -1 : 1)); }
        }, { passive: true });
        state.cleanup.push(function () { made.forEach(function (b) { if (b.parentNode) { b.parentNode.removeChild(b); } }); });
    }

    /* ------------------------------------------------------------------ activate / deactivate with the viewport */
    function activate() {
        if (state.active) { return; }
        state.active = true; root.classList.add('wrm-on');
        initLangs(); initSheet(); initFilters(); initForms(); initKeyboard(); initTables();
        initGallery();
        if (window.Alpine === undefined) { on(document, 'alpine:initialized', initGallery); }
    }
    function deactivate() {
        if (!state.active) { return; }
        closeSheet(true);
        state.cleanup.splice(0).forEach(function (fn) { try { fn(); } catch (e) {} });
        state.active = false; root.classList.remove('wrm-on', 'wrm-kb', 'wrm-locked');
        qsa('[data-wrm-langs]').forEach(function (b) { b.removeAttribute('data-more-start'); b.removeAttribute('data-more-end'); });
    }
    function sync() { if (mq.matches) { activate(); } else { deactivate(); } }

    if (mq.addEventListener) { mq.addEventListener('change', sync); } else if (mq.addListener) { mq.addListener(sync); }
    if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', sync); } else { sync(); }
})();
