<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Services\Analytics\Geo;
use App\Services\Locales\Detection\IpCountryDatabase;
use Illuminate\Http\Request;
use Illuminate\Foundation\Testing\RefreshDatabase;
use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;

final class AnalyticsOfflineCountryTest extends TestCase
{
    use RefreshDatabase;

    private function install(): string
    {
        $dir = sys_get_temp_dir().'/wr-geo-'.bin2hex(random_bytes(4));
        mkdir($dir, 0775, true);
        (new IpCountryDatabase($dir))->build(['41.32.0.0,41.47.255.255,EG', '2.136.0.0,2.139.255.255,ES', '2001:4860::,2001:4860:ffff:ffff:ffff:ffff:ffff:ffff,US']);
        config(['wadi.locale_detection.geo_dir' => $dir, 'wadi.proxies.trusted' => []]);
        Request::setTrustedProxies([], Request::HEADER_X_FORWARDED_FOR);   // other tests may have left a trusted proxy behind

        return $dir;
    }

    #[Test]
    public function the_countrys_own_offline_files_give_a_country_without_any_proxy_header(): void
    {
        $this->install();
        $at = fn (string $ip, array $server = []) => Request::create('/', 'GET', [], [], [], ['REMOTE_ADDR' => $ip] + $server);

        $this->assertSame('EG', Geo::country($at('41.40.1.2')));
        $this->assertSame('ES', Geo::country($at('2.137.9.9')));
        $this->assertSame('US', Geo::country($at('2001:4860::1')));
        $this->assertNull(Geo::country($at('203.0.113.9')), 'an address that is not in the files stays Unknown');
        $this->assertNull(Geo::country($at('not-an-ip')));
        // a header sent by the visitor is still never believed; the real address decides
        $this->assertSame('EG', Geo::country($at('41.40.1.2', ['HTTP_CF_IPCOUNTRY' => 'US'])));
        $this->assertNull(Geo::country($at('203.0.113.9', ['HTTP_CF_IPCOUNTRY' => 'ES'])));
    }

    #[Test]
    public function the_source_check_reports_the_offline_files_and_nothing_is_stored(): void
    {
        $dir = $this->install();
        $d = Geo::diagnose(Request::create('/', 'GET', [], [], [], ['REMOTE_ADDR' => '41.40.1.2']));
        $this->assertTrue($d['ip_database']);
        $this->assertSame('EG', $d['result']);
        $this->assertSame('working', $d['verdict']);
        $this->assertStringNotContainsString('41.40', json_encode($d));
        $this->assertSame('ip_unlisted', Geo::diagnose(Request::create('/', 'GET', [], [], [], ['REMOTE_ADDR' => '203.0.113.9']))['verdict']);

        config(['wadi.locale_detection.geo_dir' => $dir.'-none']);
        $this->assertSame('no_source', Geo::diagnose(Request::create('/', 'GET', [], [], [], ['REMOTE_ADDR' => '41.40.1.2']))['verdict']);
    }
}
