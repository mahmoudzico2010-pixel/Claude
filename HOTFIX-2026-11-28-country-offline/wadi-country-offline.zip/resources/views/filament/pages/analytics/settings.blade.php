<x-filament-panels::page>
    @php
    $in = 'border:1px solid #d9d2bd;border-radius:.5rem;padding:.4rem .6rem;width:100%;max-width:22rem;font-size:.85rem';
    $lb = 'display:flex;flex-direction:column;gap:.2rem;font-size:.8rem;color:#1c2a24';
@endphp
    <form wire:submit="save" style="background:#fff;border:1px solid #e5e0cf;border-radius:.9rem;padding:1.1rem 1.3rem;display:grid;gap:.9rem;max-width:46rem">
        <label style="display:flex;gap:.5rem;align-items:center;font-size:.9rem"><input type="checkbox" wire:model="data.enabled"> {{ __('analytics.set.enabled') }}</label>
        <div><label style="display:flex;gap:.5rem;align-items:center;font-size:.9rem"><input type="checkbox" wire:model="data.consent_required"> {{ __('analytics.set.consent_required') }}</label><p style="font-size:.74rem;color:#6b7280;margin:.2rem 0 0">{{ __('analytics.set.consent_help') }}</p></div>
        <label style="{{ $lb }}">{{ __('analytics.set.session_timeout_min') }}<input type="number" wire:model="data.session_timeout_min" style="{{ $in }}"></label>
        <label style="{{ $lb }}">{{ __('analytics.set.events_days') }}<input type="number" wire:model="data.events_days" style="{{ $in }}"></label>
        <label style="{{ $lb }}">{{ __('analytics.set.sessions_days') }}<input type="number" wire:model="data.sessions_days" style="{{ $in }}"><span style="font-size:.72rem;color:#6b7280">{{ __('analytics.set.retention_help') }}</span></label>
        <label style="{{ $lb }}">{{ __('analytics.set.min_cohort') }}<input type="number" wire:model="data.min_cohort" style="{{ $in }}"></label>
        <label style="{{ $lb }}">{{ __('analytics.set.timezone') }}<input type="text" wire:model="data.timezone" style="{{ $in }}"><span style="font-size:.72rem;color:#6b7280">{{ __('analytics.set.timezone_help') }}</span></label>
        <label style="{{ $lb }}">{{ __('analytics.set.geo_headers') }}<input type="text" wire:model="data.geo_headers" style="{{ $in }};max-width:34rem"><span style="font-size:.72rem;color:#6b7280">{{ __('analytics.set.geo_help') }}</span></label>
        <label style="{{ $lb }}">{{ __('analytics.set.campaign_fields') }}<input type="text" wire:model="data.campaign_fields" style="{{ $in }}"></label>
        <div><button type="submit" style="background:#14382a;color:#fff;border-radius:.5rem;padding:.5rem 1.4rem;font-weight:600" data-testid="an-settings-save">{{ __('analytics.set.save') }}</button></div>
    </form>

    <section style="background:#fff;border:1px solid #e5e0cf;border-radius:.9rem;padding:1.1rem 1.3rem;display:grid;gap:.7rem;max-width:46rem">
        <h3 style="font-weight:700;color:#14382a;margin:0">{{ __('analytics.set.status') }}</h3>
        @php
            $cov = (new \App\Services\Analytics\ReportService(\App\Services\Analytics\ReportFilters::fromArray([])))->coverage();
        @endphp
        <p style="font-size:.82rem;margin:0">{{ __('analytics.ui.coverage') }}: <b>{{ $cov['start'] ?? __('analytics.ui.coverage_none') }}</b> · {{ __('analytics.ui.refreshed') }}: <b>{{ $cov['last_refresh'] ?? '—' }}</b></p>
        <p style="font-size:.78rem;margin:0;color:#4a5a52">{{ __('analytics.set.cron') }}: <code style="direction:ltr;display:inline-block">* * * * * cd {{ base_path() }} &amp;&amp; php artisan schedule:run &gt;&gt; /dev/null 2&gt;&amp;1</code></p>
    </section>

    <section style="background:#fff;border:1px solid #e5e0cf;border-radius:.9rem;padding:1.1rem 1.3rem;display:grid;gap:.6rem;max-width:46rem" data-testid="geo-check">
        @php $g = \App\Services\Analytics\Geo::diagnose(request()); $yn = fn ($b) => $b ? __('analytics.set.yes') : __('analytics.set.no'); @endphp
        <h3 style="font-weight:700;color:#14382a;margin:0">{{ __('analytics.set.geo_check') }}</h3>
        <p style="font-size:.78rem;color:#6b7280;margin:0">{{ __('analytics.set.geo_check_help') }}</p>
        <ul style="font-size:.82rem;margin:0;padding-inline-start:1.1rem;display:grid;gap:.2rem">
            <li>{{ __('analytics.set.geo_trusted_configured') }}: <b>{{ $yn($g['trusted_configured']) }}</b></li>
            <li>{{ __('analytics.set.geo_from_trusted') }}: <b>{{ $yn($g['from_trusted_proxy']) }}</b></li>
            @foreach ($g['headers'] as $h => $st)<li><code style="direction:ltr;display:inline-block">{{ $h }}</code>: <b>{{ $st }}</b></li>@endforeach
            <li>{{ __('analytics.set.geo_ip_db') }}: <b>{{ $yn($g['ip_database']) }}</b></li>
            <li>{{ __('analytics.set.geo_db_file') }}: <b>{{ $yn($g['database_file']) }}</b> · {{ __('analytics.set.geo_db_reader') }}: <b>{{ $yn($g['database_reader']) }}</b></li>
            <li>{{ __('analytics.set.geo_result') }}: <b>{{ $g['result'] ? \App\Services\Analytics\Labels::country($g['result']) : __('analytics.unknown') }}</b></li>
        </ul>
        <p style="font-size:.82rem;margin:0;padding:.5rem .7rem;border-radius:.5rem;background:#f7f4ea" data-testid="geo-verdict">{{ __('analytics.set.geo_verdict.'.$g['verdict']) }}</p>
    </section>

    <form wire:submit="importAge" style="background:#fff;border:1px solid #e5e0cf;border-radius:.9rem;padding:1.1rem 1.3rem;display:grid;gap:.7rem;max-width:46rem">
        <h3 style="font-weight:700;color:#14382a;margin:0">{{ __('analytics.set.age_import') }}</h3>
        <p style="font-size:.78rem;color:#6b7280;margin:0">{{ __('analytics.set.age_help') }}</p>
        <label style="{{ $lb }}">{{ __('analytics.set.age_source') }}<input type="text" wire:model="ageSource" style="{{ $in }}"></label>
        <div style="display:flex;gap:.8rem;flex-wrap:wrap"><label style="{{ $lb }}">{{ __('analytics.set.age_from') }}<input type="date" wire:model="ageFrom" style="{{ $in }};width:10rem"></label><label style="{{ $lb }}">{{ __('analytics.set.age_to') }}<input type="date" wire:model="ageTo" style="{{ $in }};width:10rem"></label><label style="{{ $lb }}">{{ __('analytics.set.age_coverage') }}<input type="text" wire:model="ageCoverage" style="{{ $in }};width:8rem"></label></div>
        <textarea wire:model="ageBands" rows="5" placeholder="18-24,120&#10;25-34,310&#10;35-44,205" style="{{ $in }};max-width:22rem;font-family:monospace"></textarea>
        <div><button type="submit" style="border:1px solid #14382a;color:#14382a;border-radius:.5rem;padding:.4rem 1.2rem;font-weight:600">{{ __('analytics.set.age_import_btn') }}</button></div>
    </form>
</x-filament-panels::page>
