<?php

return [
    'edit' => 'Bulk edit…', 'activate' => 'Activate', 'deactivate' => 'Deactivate', 'delete' => 'Move to trash', 'restore' => 'Restore',
    'n_products' => '{1} 1 product|[2,*] :count products',
    'scope_all' => 'ALL :count products matching the current filters (every page).',
    'scope_ticked' => ':count ticked products.',
    'counts' => ':change will change, :skip will be skipped, :invalid are invalid or blocked.',
    'sample' => 'For example: :names.',
    'done' => 'Done — :changed changed, :skipped skipped, :invalid invalid, :failed failed.',
    'title' => 'Bulk edit products', 'preview' => 'Preview', 'apply' => 'Apply changes', 'rollback' => 'Roll back',
    'history' => 'Recent bulk edits', 'keep' => 'Keep', 'set' => 'Set', 'clear' => 'Clear', 'add' => 'Add', 'remove' => 'Remove', 'replace' => 'Replace',
    'selected_all' => 'All :count products matching your filters (across every page)',
    'selected_ticked' => ':count products you ticked',
    'filters' => 'Active filters',
    'nothing' => 'Nothing to apply yet — choose at least one change.',
    'preview_first' => 'Preview first: the apply button works on the preview you are looking at.',
    'changed_since' => 'The selection or settings changed after the preview. Preview again.',
    'expired' => 'This selection has expired. Go back to Products and select again.',
];
