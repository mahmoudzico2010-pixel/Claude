<x-filament-panels::page>
    <div class="rounded-lg border border-primary-300 bg-primary-50 p-4 dark:bg-white/5" role="status">
        <p class="text-lg font-semibold">
            @if ($selectionMode === 'all_filtered')
                {{ __('bulk.selected_all', ['count' => count($ids)]) }}
            @else
                {{ __('bulk.selected_ticked', ['count' => count($ids)]) }}
            @endif
        </p>
        @if ($filters)<p class="text-sm text-gray-600">{{ __('bulk.filters') }}: {{ implode(' · ', $filters) }}</p>@endif
    </div>

    <form wire:submit.prevent="previewChanges" class="space-y-4">
        {{ $this->form }}
        <div class="flex flex-wrap gap-3">
            <x-filament::button type="submit" color="gray" icon="heroicon-o-eye">{{ __('bulk.preview') }}</x-filament::button>
        </div>
    </form>

    @if ($preview)
        @php($t = $preview['totals'])
        <section class="space-y-3 rounded-lg border p-4" aria-live="polite">
            <h3 class="text-base font-semibold">{{ __('bulk.preview') }}: {{ $t['selected'] }} · <span class="text-success-600">{{ $t['change'] }} change</span> · {{ $t['skip'] }} skipped · <span class="text-danger-600">{{ $t['invalid'] }} invalid</span></h3>
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead><tr class="text-start text-gray-500"><th class="p-1 text-start">Product</th><th class="p-1 text-start">Result</th><th class="p-1 text-start">Before → after / reason</th></tr></thead>
                    <tbody>
                    @foreach ($preview['rows'] as $row)
                        <tr class="border-t align-top">
                            <td class="p-1 font-medium">{{ $row['label'] }}</td>
                            <td class="p-1">
                                <x-filament::badge :color="['change' => 'success', 'skip' => 'gray', 'invalid' => 'danger'][$row['status']]">{{ $row['status'] }}</x-filament::badge>
                            </td>
                            <td class="p-1">
                                @foreach ($row['changes'] as $c)
                                    <div><span class="text-gray-500">{{ $c['field'] }}{{ $c['locale'] ? ' ('.$c['locale'].')' : '' }}:</span>
                                        <s class="text-gray-400">{{ \Illuminate\Support\Str::limit(is_array($c['before']) ? json_encode($c['before']) : (string) ($c['before'] ?? '—'), 50) }}</s>
                                        → <strong>{{ \Illuminate\Support\Str::limit(is_array($c['after']) ? json_encode($c['after']) : (string) ($c['after'] ?? '—'), 70) }}</strong></div>
                                @endforeach
                                @foreach ($row['reasons'] as $r)<div class="text-gray-500">{{ $r }}</div>@endforeach
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
            @if ($t['change'] > 0)
                <x-filament::button wire:click="applyChanges" wire:confirm="{{ __('bulk.apply') }}: {{ $t['change'] }}?" color="primary" icon="heroicon-o-check">{{ __('bulk.apply') }} ({{ $t['change'] }})</x-filament::button>
            @else
                <p class="text-gray-500">{{ __('bulk.nothing') }}</p>
            @endif
        </section>
    @endif

    <section class="space-y-2">
        <h3 class="text-base font-semibold">{{ __('bulk.history') }}</h3>
        @forelse ($this->history() as $run)
            <div class="flex flex-wrap items-center justify-between gap-2 rounded border p-2 text-sm">
                <span>#{{ $run->id }} · {{ $run->created_at->format('Y-m-d H:i') }} · {{ $run->user?->name ?? '—' }} · {{ $run->action }} · {{ json_encode($run->outcome['changed'] ?? 0) }} changed</span>
                @if ($run->rolled_back_at)
                    <span class="text-gray-500">rolled back</span>
                @elseif (($run->outcome['changed'] ?? 0) > 0)
                    <x-filament::button size="xs" color="gray" wire:click="rollbackRun({{ $run->id }})" wire:confirm="{{ __('bulk.rollback') }} #{{ $run->id }}?">{{ __('bulk.rollback') }}</x-filament::button>
                @endif
            </div>
        @empty
            <p class="text-gray-500">—</p>
        @endforelse
    </section>
</x-filament-panels::page>
