<x-filament-panels::page>
    @php($counts = $this->counts())
    <div class="flex flex-wrap items-center gap-2" role="tablist" aria-label="Queue status">
        @foreach (['pending' => 'To review', 'assigned' => 'Assigned', 'group' => 'Group/category only', 'rejected' => 'Rejected', 'all' => 'All'] as $key => $label)
            <x-filament::button size="sm" :color="$status === $key ? 'primary' : 'gray'" wire:click="$set('status', '{{ $key }}')">
                {{ $label }}@if ($key !== 'all') ({{ $counts[$key] ?? 0 }})@endif
            </x-filament::button>
        @endforeach
        <input type="search" wire:model.live.debounce.300ms="search" placeholder="Search file name or reason" style="border:1px solid #ccc;border-radius:.5rem;padding:.35rem .6rem" aria-label="Search the queue">
        <x-filament::button size="sm" color="gray" icon="heroicon-o-arrow-down-tray" wire:click="downloadMapping">Download mapping CSV</x-filament::button>
    </div>

    <div style="display:grid;grid-template-columns:minmax(260px,1.1fr) minmax(300px,1.3fr) minmax(280px,1.1fr);gap:1.5rem;align-items:start">
        {{-- Thumbnails --}}
        <div>
            <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:.5rem;max-height:75vh;overflow-y:auto" role="list">
                @forelse ($this->items() as $item)
                    <div role="listitem" style="position:relative;border:2px solid {{ $focus === $item->id ? '#1f6f4a' : '#e5e5e5' }};border-radius:.4rem;overflow:hidden">
                        <input type="checkbox" value="{{ $item->id }}" wire:model="selected" style="position:absolute;top:4px;inset-inline-start:4px;z-index:2" aria-label="Select {{ $item->original_filename }}">
                        <button type="button" wire:click="focusOn({{ $item->id }})" class="block w-full text-start" title="{{ $item->original_filename }}">
                            <img src="{{ $item->media->urlFor(240) }}" alt="{{ $item->original_filename }}" loading="lazy" style="width:100%;aspect-ratio:1/1;object-fit:cover;display:block">
                            <span style="display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding:0 4px;font-size:11px">{{ $item->original_filename }}</span>
                            @if ($item->status !== 'pending')<span style="display:block;padding:0 4px;font-size:11px;color:#777">{{ $item->status }}{{ $item->product ? ' → '.($item->product->t('name', 'en')) : '' }}</span>@endif
                        </button>
                    </div>
                @empty
                    <p class="col-span-3 text-gray-500">Nothing here.</p>
                @endforelse
            </div>
            @if ($selected)<p class="mt-2 text-sm">{{ count($selected) }} photo(s) ticked — they will be assigned together.</p>@endif
        </div>

        {{-- Enlarged photo + decision --}}
        <div style="display:flex;flex-direction:column;gap:.75rem">
            @if ($f = $this->focused())
                <img src="{{ $f->media->url() }}" alt="{{ $f->original_filename }}" style="max-height:60vh;width:100%;object-fit:contain;background:#fff;border:1px solid #ddd;border-radius:.5rem">
                <p class="text-sm"><strong>{{ $f->original_filename }}</strong><br><span class="text-gray-600">Why it is here: {{ $f->reason }}</span></p>
                @if ($f->status !== 'pending')
                    <p class="text-sm">Status: <strong>{{ $f->status }}</strong>{{ $f->product ? ' → '.$f->product->t('name', 'en').' ('.$f->assigned_role.')' : '' }}</p>
                    <x-filament::button size="sm" color="warning" wire:click="undo({{ $f->id }})">Undo — back to the queue</x-filament::button>
                @else
                    <div class="flex flex-wrap gap-2">
                        <x-filament::button size="sm" color="gray" wire:click="decide('group')">Category / group only</x-filament::button>
                        <x-filament::button size="sm" color="danger" wire:click="decide('rejected')">Reject</x-filament::button>
                    </div>
                @endif
            @else
                <p class="text-gray-500">Select a photo.</p>
            @endif
        </div>

        {{-- Product search --}}
        <div style="display:flex;flex-direction:column;gap:.75rem">
            <label class="block text-sm font-medium" for="psearch">Find a product (name, cultivar, colour or cut)</label>
            <input id="psearch" type="search" wire:model.live.debounce.300ms="productSearch" style="width:100%;border:1px solid #ccc;border-radius:.5rem;padding:.4rem .6rem" placeholder="e.g. Azizi pitted">
            <ul style="max-height:12rem;overflow-y:auto;font-size:.875rem;display:flex;flex-direction:column;gap:.25rem">
                @foreach ($this->results() as $p)
                    <li><button type="button" wire:click="chooseProduct({{ $p->id }})" style="width:100%;text-align:start;border:1px solid {{ $productId === $p->id ? '#1f6f4a' : '#ddd' }};background:{{ $productId === $p->id ? '#eef7f1' : '#fff' }};border-radius:.4rem;padding:.25rem .5rem">
                        {{ $p->t('name', 'en') ?: $p->slug }} <span class="text-gray-500">· {{ $p->variety?->name_en }} {{ $p->form?->name_en }} {{ $p->color }}</span></button></li>
                @endforeach
            </ul>

            @if ($c = $this->chosen())
                <div style="border:1px solid #ddd;border-radius:.5rem;padding:.5rem">
                    <p class="font-medium">{{ $c->t('name', 'en') }}</p>
                    <div class="mt-1 flex gap-2" role="radiogroup" aria-label="Role">
                        <label><input type="radio" wire:model.live="role" value="gallery"> Gallery</label>
                        <label><input type="radio" wire:model.live="role" value="primary"> Primary</label>
                    </div>
                    <div class="mt-2 flex flex-wrap gap-2">
                        <x-filament::button size="sm" wire:click="assign(false)">Assign {{ $selected ? count($selected).' ticked' : 'this photo' }}</x-filament::button>
                        <x-filament::button size="sm" color="success" wire:click="assign(true)">Save and review next</x-filament::button>
                    </div>
                    <p class="mt-3 text-sm font-medium">Gallery order</p>
                    <ol class="space-y-1">
                        @foreach ($c->images->sortBy('display_order') as $img)
                            <li class="flex items-center gap-2 text-sm">
                                <img src="{{ $img->media->urlFor(120) }}" alt="" style="width:40px;height:40px;object-fit:cover;border-radius:4px">
                                <span class="min-w-0 flex-1 truncate">{{ $img->media->original_filename }}@if ((int) $c->primary_image_id === (int) $img->media_id) <strong>· primary</strong>@endif</span>
                                <button type="button" wire:click="move({{ $img->media_id }}, -1)" aria-label="Move up">↑</button>
                                <button type="button" wire:click="move({{ $img->media_id }}, 1)" aria-label="Move down">↓</button>
                                @if ((int) $c->primary_image_id !== (int) $img->media_id)<button type="button" wire:click="makePrimary({{ $img->media_id }})" class="text-xs underline">make primary</button>@endif
                            </li>
                        @endforeach
                    </ol>
                </div>
            @endif
        </div>
    </div>
</x-filament-panels::page>
