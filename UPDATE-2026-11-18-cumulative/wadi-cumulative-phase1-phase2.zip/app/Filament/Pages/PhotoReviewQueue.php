<?php

declare(strict_types=1);

namespace App\Filament\Pages;

use App\Models\CatalogMediaReview;
use App\Models\ProductImage;
use App\Services\Catalog\PhotoReviewService;
use App\Support\Permissions;
use BackedEnum;
use Filament\Notifications\Notification;
use Filament\Pages\Page;
use Filament\Support\Icons\Heroicon;
use Illuminate\Support\Facades\Auth;
use Livewire\Attributes\Url;
use Symfony\Component\HttpFoundation\StreamedResponse;

/** Resolve queued photographs: assign to a product (primary or gallery), mark group-only or rejected, undo, order the gallery. */
class PhotoReviewQueue extends Page
{
    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedPhoto;

    protected static ?int $navigationSort = 18;

    protected static ?string $slug = 'photo-review';

    protected string $view = 'filament.pages.photo-review-queue';

    #[Url]
    public string $status = 'pending';

    #[Url]
    public string $search = '';

    #[Url]
    public ?int $focus = null;

    /** @var array<int, int> */
    public array $selected = [];

    public string $productSearch = '';

    public ?int $productId = null;

    public string $role = 'gallery';

    public static function getNavigationGroup(): ?string
    {
        return __('nav.groups.catalogue');
    }

    public static function getNavigationLabel(): string
    {
        return 'Photo review';
    }

    public function getTitle(): string
    {
        return 'Photo review queue';
    }

    public static function canAccess(): bool
    {
        return Auth::user()?->can(Permissions::PRODUCTS_UPDATE) ?? false;
    }

    private function svc(): PhotoReviewService
    {
        return new PhotoReviewService;
    }

    public function mount(): void
    {
        $this->focus ??= $this->svc()->queue($this->status, $this->search)->first()?->id;
    }

    public function items()
    {
        return $this->svc()->queue($this->status, $this->search)->limit(120)->get();
    }

    public function focused(): ?CatalogMediaReview
    {
        return $this->focus ? CatalogMediaReview::with(['media', 'product'])->find($this->focus) : null;
    }

    public function counts(): array
    {
        return $this->svc()->counts();
    }

    public function results()
    {
        return $this->svc()->searchProducts($this->productSearch);
    }

    public function chosen()
    {
        return $this->productId ? \App\Models\Product::with(['translations', 'images.media', 'variety', 'form'])->find($this->productId) : null;
    }

    public function chooseProduct(int $id): void
    {
        $this->productId = $id;
    }

    public function focusOn(int $id): void
    {
        $this->focus = $id;
    }

    /** Assign the focused photo, or every ticked photo, to the chosen product. */
    public function assign(bool $next = false): void
    {
        $ids = $this->selected !== [] ? array_map('intval', $this->selected) : array_filter([$this->focus]);
        if ($this->productId === null || $ids === []) {
            Notification::make()->warning()->title('Choose a product and at least one photo first.')->send();

            return;
        }
        $nextId = $next ? $this->nextAfter((int) ($this->focus ?? 0), $ids) : null;
        $r = $this->svc()->assign($ids, $this->productId, $this->role, Auth::user());
        Notification::make()->success()->title("Assigned {$r['assigned']} photo(s) as {$this->role}.")->send();
        $this->selected = [];
        if ($next) {
            $this->focus = $nextId;
        }
    }

    public function decide(string $status, bool $next = true): void
    {
        $ids = $this->selected !== [] ? $this->selected : array_filter([$this->focus]);
        $nextId = $this->nextAfter((int) ($this->focus ?? 0), array_map('intval', $ids));
        foreach ($ids as $id) {
            $this->svc()->markGroup((int) $id, Auth::user(), $status);
        }
        $this->selected = [];
        if ($next) {
            $this->focus = $nextId;
        }
    }

    public function undo(int $id): void
    {
        $this->svc()->undo($id);
        Notification::make()->success()->title('Back in the queue.')->send();
    }

    public function move(int $mediaId, int $delta): void
    {
        $this->productId && $this->svc()->moveInGallery($this->productId, $mediaId, $delta);
    }

    public function makePrimary(int $mediaId): void
    {
        $this->productId && $this->svc()->makePrimary($this->productId, $mediaId);
    }

    /** The next unresolved photo after the current one in the filtered list (wraps; keeps the filters). */
    private function nextAfter(int $current, array $handled): ?int
    {
        $pending = $this->svc()->queue('pending', $this->search)->whereNotIn('id', $handled)->pluck('id')->all();
        foreach ($pending as $id) {
            if ($id > $current) {
                return (int) $id;
            }
        }

        return $pending[0] ?? null;
    }

    public function downloadMapping(): StreamedResponse
    {
        return response()->streamDownload(fn () => print ($this->svc()->csv()), 'photo-mapping.csv', ['Content-Type' => 'text/csv']);
    }
}
