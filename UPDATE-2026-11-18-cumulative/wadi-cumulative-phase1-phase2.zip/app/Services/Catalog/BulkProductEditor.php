<?php

declare(strict_types=1);

namespace App\Services\Catalog;

use App\Enums\ContentStatus;
use App\Models\BulkEditChange;
use App\Models\BulkEditRun;
use App\Models\Category;
use App\Models\Product;
use App\Models\ProductForm;
use App\Models\ProductImage;
use App\Models\User;
use App\Models\Variety;
use App\Support\Permissions;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

/**
 * Bulk product changes in two steps: plan() decides, per product, what WOULD change / be skipped / be invalid and why (nothing
 * is written); apply() carries out exactly that plan, records every field change with before/after values, and rollback() puts
 * back only the values that nobody has edited since. Every control defaults to "keep"; an empty input never erases data.
 *
 * $spec shape (all optional, missing = keep):
 *   category_id, variety_id, product_form_id, processing_method, color, is_featured : ['mode' => keep|set|clear, 'value' => ...]
 *   packaging : ['mode' => keep|add|remove|replace|clear, 'ids' => int[]]
 *   text      : ['fields' => string[], 'locales' => string[], 'mode' => fill_missing|overwrite, 'overwrite_human' => bool,
 *               'source' => prepared|text, 'value' => string]
 *   media     : ['mode' => keep|add_gallery|remove_gallery|replace_primary, 'media_id' => int, 'allow_shared_primary' => bool]
 *   status    : activate|deactivate        trash : delete|restore
 */
final class BulkProductEditor
{
    public const TEXT_FIELDS = ['short_description', 'description', 'seo_title', 'seo_description'];

    /** @param  array<int, int>  $ids */
    public function products(array $ids): Collection
    {
        return Product::withTrashed()->whereIn('id', $ids)->with(['translations', 'category.parent', 'variety', 'form', 'images', 'packagingTypes'])->orderBy('id')->get();
    }

    /** @return array{rows: list<array<string, mixed>>, totals: array<string, int>} */
    public function plan(Collection $products, array $spec, ?User $user): array
    {
        $rows = [];
        $prepared = $this->prepared();
        foreach ($products as $p) {
            $row = ['id' => $p->id, 'label' => (string) ($p->t('name', 'en') ?: $p->slug), 'status' => 'skip', 'changes' => [], 'reasons' => []];
            $this->planOne($p, $spec, $user, $row, $prepared);
            if (($row['invalid'] ?? false) === true) {
                $row['status'] = 'invalid';
                $row['changes'] = [];
            } else {
                $row['status'] = $row['changes'] !== [] ? 'change' : 'skip';
            }
            unset($row['invalid']);
            $rows[] = $row;
        }

        $totals = ['selected' => count($rows), 'change' => 0, 'skip' => 0, 'invalid' => 0];
        foreach ($rows as $r) {
            $totals[$r['status']]++;
        }

        return ['rows' => $rows, 'totals' => $totals];
    }

    // ------------------------------------------------------------------ planning

    private function planOne(Product $p, array $spec, ?User $user, array &$row, array $prepared): void
    {
        $canUpdate = $user?->can(Permissions::PRODUCTS_UPDATE) && $user?->can('update', $p);
        $touches = $this->touchesAnything($spec);

        if ($p->trashed() && $touches) {
            $row['reasons'][] = 'In the trash: restore it before editing.';

            return;
        }
        if ($touches && ! $canUpdate) {
            $row['reasons'][] = 'You do not have permission to edit this product.';
            $row['invalid'] = true;

            return;
        }

        // ---- scalar columns, with the resulting combination validated as a whole
        $new = ['category_id' => $p->category_id, 'variety_id' => $p->variety_id, 'product_form_id' => $p->product_form_id, 'processing_method' => $p->processing_method];
        foreach (['category_id', 'variety_id', 'product_form_id', 'processing_method', 'color'] as $col) {
            $op = $spec[$col] ?? ['mode' => 'keep'];
            $mode = $op['mode'] ?? 'keep';
            if ($mode === 'keep') {
                continue;
            }
            if ($mode === 'set') {
                $value = $op['value'] ?? null;
                if ($value === null || $value === '') {
                    $row['reasons'][] = "$col: Set needs a value (use Clear to remove it).";
                    $row['invalid'] = true;

                    continue;
                }
                $after = in_array($col, ['processing_method', 'color'], true) ? (string) $value : (int) $value;
            } else {
                if ($col === 'category_id') {
                    $row['reasons'][] = 'A product must keep a category; it cannot be cleared.';
                    $row['invalid'] = true;

                    continue;
                }
                $after = null;
            }
            if ($p->{$col} !== $after && (string) $p->{$col} !== (string) $after) {
                $row['changes'][] = ['kind' => 'column', 'field' => $col, 'locale' => null, 'before' => $p->{$col}, 'after' => $after];
                $new[$col] = $after;
            }
        }
        if (array_intersect(array_column($row['changes'], 'field'), ['category_id', 'variety_id', 'product_form_id', 'processing_method'])) {
            $problems = ProductCompatibility::problems(
                Category::query()->with('parent')->find($new['category_id']),
                $new['variety_id'] ? Variety::find($new['variety_id']) : null,
                $new['product_form_id'] ? ProductForm::find($new['product_form_id']) : null,
                $new['processing_method'] ?? null,
            );
            if ($problems !== []) {
                $row['reasons'] = array_merge($row['reasons'], $problems);
                $row['invalid'] = true;

                return;
            }
        }

        $feat = $spec['is_featured'] ?? ['mode' => 'keep'];
        if (($feat['mode'] ?? 'keep') !== 'keep') {
            $after = ($feat['mode'] === 'set') ? (bool) ($feat['value'] ?? true) : false;
            if ((bool) $p->is_featured !== $after) {
                $row['changes'][] = ['kind' => 'column', 'field' => 'is_featured', 'locale' => null, 'before' => (bool) $p->is_featured, 'after' => $after];
            }
        }

        // ---- packaging list
        $pk = $spec['packaging'] ?? ['mode' => 'keep'];
        if (($pk['mode'] ?? 'keep') !== 'keep') {
            $cur = $p->packagingTypes->pluck('id')->map(fn ($i) => (int) $i)->sort()->values()->all();
            $ids = array_values(array_unique(array_map('intval', (array) ($pk['ids'] ?? []))));
            $after = match ($pk['mode']) {
                'add' => array_values(array_unique(array_merge($cur, $ids))),
                'remove' => array_values(array_diff($cur, $ids)),
                'replace' => $ids,
                'clear' => [],
                default => $cur,
            };
            sort($after);
            if (in_array($pk['mode'], ['add', 'remove', 'replace'], true) && $ids === []) {
                $row['reasons'][] = 'Packaging: choose at least one type, or use Clear.';
                $row['invalid'] = true;
            } elseif ($after !== $cur) {
                $row['changes'][] = ['kind' => 'relation', 'field' => 'packaging', 'locale' => null, 'before' => $cur, 'after' => $after];
            }
        }

        // ---- translations / SEO
        $tx = $spec['text'] ?? null;
        if ($tx && ! empty($tx['fields']) && ! empty($tx['locales'])) {
            foreach ($tx['locales'] as $locale) {
                $t = $p->translations->firstWhere('locale', $locale);
                foreach ($tx['fields'] as $field) {
                    if (! in_array($field, self::TEXT_FIELDS, true)) {
                        continue;
                    }
                    $current = trim((string) ($t?->{$field} ?? ''));
                    $value = ($tx['source'] ?? 'text') === 'prepared'
                        ? ($p->import_key ? ($prepared[$p->import_key][$locale][$field] ?? null) : null)
                        : ($tx['value'] ?? null);
                    if (blank($value)) {
                        $row['reasons'][] = "$locale $field: no replacement text for this product, left untouched.";

                        continue;
                    }
                    $mode = $tx['mode'] ?? 'fill_missing';
                    if ($current === '') {
                        $go = true;
                    } elseif ($mode !== 'overwrite') {
                        $go = false;
                    } else {
                        $human = ! $t->isPristine($field);
                        $go = ! $human || ! empty($tx['overwrite_human']);
                        if (! $go) {
                            $row['reasons'][] = "$locale $field: human-edited, protected.";
                        }
                    }
                    if ($go && $current !== trim((string) $value)) {
                        $row['changes'][] = ['kind' => 'translation', 'field' => $field, 'locale' => $locale, 'before' => $t?->{$field}, 'after' => (string) $value, 'source' => $tx['source'] ?? 'text'];
                    }
                }
            }
        }

        // ---- media
        $md = $spec['media'] ?? ['mode' => 'keep'];
        if (($md['mode'] ?? 'keep') !== 'keep') {
            $mid = (int) ($md['media_id'] ?? 0);
            $links = $p->images;
            if ($mid === 0) {
                $row['reasons'][] = 'Media: choose a photo.';
                $row['invalid'] = true;
            } elseif ($md['mode'] === 'add_gallery') {
                if (! $links->contains('media_id', $mid) && (int) $p->primary_image_id !== $mid) {
                    $row['changes'][] = ['kind' => 'media', 'field' => 'gallery_add', 'locale' => null, 'before' => null, 'after' => $mid];
                }
            } elseif ($md['mode'] === 'remove_gallery') {
                if ((int) $p->primary_image_id === $mid) {
                    $row['reasons'][] = 'That photo is the primary image; replace the primary instead of removing it.';
                    $row['invalid'] = true;
                } elseif ($links->contains('media_id', $mid)) {
                    $row['changes'][] = ['kind' => 'media', 'field' => 'gallery_remove', 'locale' => null, 'before' => $mid, 'after' => null];
                }
            } elseif ($md['mode'] === 'replace_primary' && (int) $p->primary_image_id !== $mid) {
                $other = Product::query()->where('primary_image_id', $mid)->whereKeyNot($p->id)->count();
                if (empty($md['allow_shared_primary']) && $other > 0) {
                    $row['reasons'][] = "That photo is already the primary image of $other other product(s); confirm to share it.";
                    $row['invalid'] = true;
                } else {
                    $row['changes'][] = ['kind' => 'media', 'field' => 'primary', 'locale' => null, 'before' => $p->primary_image_id, 'after' => $mid];
                }
            }
        }

        // ---- status / trash
        if (! empty($spec['status'])) {
            $want = $spec['status'] === 'activate' ? ContentStatus::Published : ContentStatus::Draft;
            if (! $user?->can(Permissions::PRODUCTS_PUBLISH)) {
                $row['reasons'][] = 'No permission to change publication status.';
                $row['invalid'] = true;
            } elseif ($p->trashed()) {
                $row['reasons'][] = 'In the trash.';
            } elseif ($p->status === $want) {
                $row['reasons'][] = 'Already '.($want === ContentStatus::Published ? 'active' : 'inactive').'.';
            } elseif ($want === ContentStatus::Published && blank($p->t('name', 'en'))) {
                $row['reasons'][] = 'Blocked: a product needs an English name before it can be published.';
                $row['invalid'] = true;
            } else {
                $row['changes'][] = ['kind' => 'status', 'field' => 'status', 'locale' => null, 'before' => $p->status->value, 'after' => $want->value];
            }
        }
        if (! empty($spec['trash'])) {
            $del = $spec['trash'] === 'delete';
            if (! $user?->can(Permissions::PRODUCTS_DELETE) || ! $user?->can($del ? 'delete' : 'restore', $p)) {
                $row['reasons'][] = 'No permission to '.($del ? 'delete' : 'restore').' this product.';
                $row['invalid'] = true;
            } elseif ($del === $p->trashed()) {
                $row['reasons'][] = $del ? 'Already in the trash.' : 'Not in the trash.';
            } else {
                $row['changes'][] = ['kind' => 'trash', 'field' => 'deleted_at', 'locale' => null, 'before' => $p->trashed(), 'after' => $del];
            }
        }
    }

    private function touchesAnything(array $spec): bool
    {
        foreach (['category_id', 'variety_id', 'product_form_id', 'processing_method', 'color', 'is_featured', 'packaging', 'media'] as $k) {
            if (($spec[$k]['mode'] ?? 'keep') !== 'keep') {
                return true;
            }
        }

        return ! empty($spec['text']['fields']) && ! empty($spec['text']['locales']);
    }

    /** @return array<string, array<string, array<string, string>>> import_key => locale => field => prepared text */
    private function prepared(): array
    {
        static $cache = null;
        if ($cache === null) {
            $cache = [];
            foreach ((array) (json_decode((string) file_get_contents(database_path('data/catalog/products-59.json')), true)['products'] ?? []) as $r) {
                $cache[$r['key']] = array_map(fn ($t) => $t, $r['translations']);
            }
        }

        return $cache;
    }

    // ------------------------------------------------------------------ applying

    /** @param  array{rows: list<array<string, mixed>>, totals: array<string, int>}  $plan */
    public function apply(array $plan, array $spec, ?User $user, string $action, array $scope = []): BulkEditRun
    {
        $run = BulkEditRun::create(['user_id' => $user?->id, 'action' => $action, 'scope' => $scope + ['totals' => $plan['totals']]]);
        $done = $failed = 0;
        $failures = [];
        foreach ($plan['rows'] as $row) {
            if ($row['status'] !== 'change') {
                continue;
            }
            try {
                DB::transaction(function () use ($row, $run): void {
                    $p = Product::withTrashed()->with(['translations', 'images'])->findOrFail($row['id']);
                    foreach ($row['changes'] as $c) {
                        $this->write($p, $c);
                        BulkEditChange::create(['run_id' => $run->id, 'product_id' => $p->id, 'kind' => $c['kind'], 'field' => $c['field'], 'locale' => $c['locale'] ?? null, 'before' => ['v' => $c['before']], 'after' => ['v' => $c['after']]]);
                    }
                });
                $done++;
            } catch (\Throwable $e) {
                $failed++;
                $failures[] = ['id' => $row['id'], 'error' => $e->getMessage()];
            }
        }
        $run->update(['outcome' => ['changed' => $done, 'skipped' => $plan['totals']['skip'], 'invalid' => $plan['totals']['invalid'], 'failed' => $failed, 'failures' => $failures]]);

        return $run;
    }

    private function write(Product $p, array $c): void
    {
        $field = $c['field'];
        match ($c['kind']) {
            'column' => $p->forceFill([$field => $c['after']])->save(),
            'status' => $p->forceFill(['status' => ContentStatus::from($c['after']), 'published_at' => $c['after'] === 'published' ? ($p->published_at ?? now()) : $p->published_at])->save(),
            'trash' => $c['after'] ? $p->delete() : $p->restore(),
            'relation' => $p->packagingTypes()->sync($this->pivotFor($p, (array) $c['after'])),
            'translation' => $this->writeTranslation($p, $c),
            'media' => $this->writeMedia($p, $c),
        };
    }

    /** Keep pivot data of types that stay; new ones start empty (weights are only entered by a person). */
    private function pivotFor(Product $p, array $ids): array
    {
        $existing = $p->packagingTypes->keyBy('id');
        $out = [];
        foreach ($ids as $i => $id) {
            $out[$id] = $existing->has($id) ? ['display_order' => $existing[$id]->pivot->display_order] : ['display_order' => $i];
        }

        return $out;
    }

    private function writeTranslation(Product $p, array $c): void
    {
        $t = $p->translations()->where('locale', $c['locale'])->first();
        $hashes = (array) ($t?->imported_hashes ?? []);
        if (($c['source'] ?? 'text') === 'prepared') {
            $hashes[$c['field']] = sha1((string) $c['after']);
        } else {
            unset($hashes[$c['field']]);   // typed by a person from now on
        }
        $p->translations()->updateOrCreate(['locale' => $c['locale']], [$c['field'] => $c['after'], 'imported_hashes' => $hashes]);
    }

    private function writeMedia(Product $p, array $c): void
    {
        $mid = (int) ($c['after'] ?? $c['before']);
        match ($c['field']) {
            'gallery_add' => ProductImage::query()->firstOrCreate(['product_id' => $p->id, 'media_id' => $mid], ['is_primary' => false, 'display_order' => (int) ($p->images->max('display_order') ?? -1) + 1]),
            'gallery_remove' => ProductImage::query()->where('product_id', $p->id)->where('media_id', $mid)->where('is_primary', false)->delete(),
            'primary' => $this->setPrimary($p, $mid),
        };
    }

    private function setPrimary(Product $p, int $mid): void
    {
        ProductImage::query()->where('product_id', $p->id)->update(['is_primary' => false]);
        ProductImage::query()->updateOrCreate(['product_id' => $p->id, 'media_id' => $mid], ['is_primary' => true]);
        DB::table('products')->where('id', $p->id)->update(['primary_image_id' => $mid]);
    }

    // ------------------------------------------------------------------ rollback

    /** @return array{restored: int, conflicts: list<array<string, mixed>>} */
    public function rollback(BulkEditRun $run, ?User $user): array
    {
        abort_if($run->rolled_back_at !== null, 422, 'Already rolled back.');
        $restored = 0;
        $conflicts = [];
        foreach ($run->changes()->orderByDesc('id')->get() as $ch) {
            $p = Product::withTrashed()->with(['translations', 'images', 'packagingTypes'])->find($ch->product_id);
            if (! $p || ! $this->currentEquals($p, $ch)) {
                $conflicts[] = ['product_id' => $ch->product_id, 'field' => $ch->field, 'locale' => $ch->locale, 'reason' => 'changed since this bulk edit; left as it is'];

                continue;
            }
            $this->restore($p, $ch);
            $restored++;
        }
        $run->update(['rolled_back_at' => now(), 'rollback_outcome' => ['restored' => $restored, 'conflicts' => $conflicts, 'by' => $user?->id]]);

        return ['restored' => $restored, 'conflicts' => $conflicts];
    }

    private function restore(Product $p, BulkEditChange $ch): void
    {
        $before = $ch->before['v'] ?? null;
        match ($ch->kind) {
            'column' => $p->forceFill([$ch->field => $before])->save(),
            'status' => $p->forceFill(['status' => ContentStatus::from((string) $before)])->save(),
            'trash' => $before ? $p->delete() : $p->restore(),
            'relation' => $p->packagingTypes()->sync($this->pivotFor($p, array_map('intval', (array) $before))),
            'translation' => $p->translations()->updateOrCreate(['locale' => $ch->locale], [$ch->field => $before, 'imported_hashes' => collect((array) $p->translations->firstWhere('locale', $ch->locale)?->imported_hashes)->except($ch->field)->all()]),
            'media' => match ($ch->field) {
                'gallery_add' => ProductImage::query()->where('product_id', $p->id)->where('media_id', (int) ($ch->after['v'] ?? 0))->where('is_primary', false)->delete(),
                'gallery_remove' => ProductImage::query()->firstOrCreate(['product_id' => $p->id, 'media_id' => (int) $before], ['is_primary' => false, 'display_order' => (int) ($p->images->max('display_order') ?? -1) + 1]),
                'primary' => $before === null ? $this->clearPrimary($p) : $this->setPrimary($p, (int) $before),
            },
        };
    }

    private function clearPrimary(Product $p): void
    {
        ProductImage::query()->where('product_id', $p->id)->update(['is_primary' => false]);
        DB::table('products')->where('id', $p->id)->update(['primary_image_id' => null]);
    }

    private static function norm(mixed $v): string
    {
        return is_bool($v) ? (string) (int) $v : (string) ($v ?? '');
    }

    private function currentEquals(Product $p, BulkEditChange $ch): bool
    {
        $after = $ch->after['v'] ?? null;

        return match ($ch->kind) {
            'column' => self::norm($p->{$ch->field}) === self::norm($after),
            'status' => $p->status->value === $after,
            'trash' => $p->trashed() === (bool) $after,
            'relation' => $p->packagingTypes->pluck('id')->map(fn ($i) => (int) $i)->sort()->values()->all() === array_map('intval', (array) $after),
            'translation' => (string) ($p->translations->firstWhere('locale', $ch->locale)?->{$ch->field}) === (string) $after,
            'media' => match ($ch->field) {
                'gallery_add' => $p->images->contains('media_id', (int) $after),
                'gallery_remove' => ! $p->images->contains('media_id', (int) ($ch->before['v'] ?? 0)),
                'primary' => (int) $p->primary_image_id === (int) $after,
                default => false,
            },
            default => false,
        };
    }
}
