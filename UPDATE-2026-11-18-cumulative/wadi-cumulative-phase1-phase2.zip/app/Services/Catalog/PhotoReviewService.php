<?php

declare(strict_types=1);

namespace App\Services\Catalog;

use App\Models\CatalogMediaReview;
use App\Models\Product;
use App\Models\ProductImage;
use App\Models\User;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

/** Decisions on queued photos: assign (primary / gallery), group-only, reject, undo, gallery order. Image files are never touched. */
final class PhotoReviewService
{
    public const STATUSES = ['pending', 'assigned', 'group', 'rejected'];

    public function queue(string $status = 'pending', string $search = ''): Builder
    {
        return CatalogMediaReview::query()->with(['media', 'product'])
            ->when($status !== 'all', fn (Builder $q) => $q->where('status', $status))
            ->when(trim($search) !== '', fn (Builder $q) => $q->where(fn (Builder $w) => $w->where('original_filename', 'like', '%'.trim($search).'%')->orWhere('reason', 'like', '%'.trim($search).'%')))
            ->orderBy('id');
    }

    /** @return array<string, int> */
    public function counts(): array
    {
        $c = CatalogMediaReview::query()->selectRaw('status, count(*) n')->groupBy('status')->pluck('n', 'status')->all();

        return array_merge(array_fill_keys(self::STATUSES, 0), array_map('intval', $c));
    }

    /** Products matching a name, cultivar, colour, cut or key fragment. */
    public function searchProducts(string $term, int $limit = 15): Collection
    {
        $t = trim($term);
        if (mb_strlen($t) < 2) {
            return collect();
        }

        $q = Product::query()->with(['translations', 'variety', 'form', 'category']);
        // Every word must match something (name, cultivar, cut, colour, key): "azizi pitted" finds the Azizi pitted product.
        foreach (preg_split('/\s+/', $t) as $word) {
            $q->where(fn (Builder $w) => $w
                ->whereHas('translations', fn (Builder $x) => $x->where('name', 'like', "%$word%"))
                ->orWhereHas('variety', fn (Builder $x) => $x->where('name_en', 'like', "%$word%")->orWhere('slug', 'like', "%$word%"))
                ->orWhereHas('form', fn (Builder $x) => $x->where('name_en', 'like', "%$word%")->orWhere('slug', 'like', "%$word%"))
                ->orWhere('color', 'like', "%$word%")->orWhere('import_key', 'like', "%$word%")->orWhere('slug', 'like', "%$word%"));
        }

        return $q
            ->orderBy('id')->limit($limit)->get();
    }

    /** @param  array<int, int>  $reviewIds
     * @return array{assigned: int, skipped: int} */
    public function assign(array $reviewIds, int $productId, string $role, ?User $by): array
    {
        $product = Product::findOrFail($productId);
        $done = $skip = 0;
        DB::transaction(function () use ($reviewIds, $product, $role, $by, &$done, &$skip): void {
            foreach (CatalogMediaReview::whereIn('id', $reviewIds)->orderBy('id')->get() as $i => $r) {
                if ($r->status === 'assigned') {
                    $skip++;

                    continue;
                }
                $existing = ProductImage::where('product_id', $product->id)->where('media_id', $r->media_id)->first();
                $order = (int) (ProductImage::where('product_id', $product->id)->max('display_order') ?? -1) + 1;
                $link = $existing ?? ProductImage::create(['product_id' => $product->id, 'media_id' => $r->media_id, 'is_primary' => false, 'display_order' => $order]);
                $prev = $product->fresh()->primary_image_id;
                if ($role === 'primary') {
                    ProductImage::where('product_id', $product->id)->update(['is_primary' => false]);
                    $link->update(['is_primary' => true]);
                    DB::table('products')->where('id', $product->id)->update(['primary_image_id' => $r->media_id]);
                }
                $r->update(['status' => 'assigned', 'product_id' => $product->id, 'assigned_role' => $role, 'link_created' => $existing === null,
                    'previous_primary_id' => $role === 'primary' ? $prev : null, 'decided_at' => now(), 'decided_by' => $by?->id]);
                $done++;
            }
        });

        return ['assigned' => $done, 'skipped' => $skip];
    }

    public function markGroup(int $reviewId, ?User $by, string $status = 'group', ?string $note = null): void
    {
        abort_unless(in_array($status, ['group', 'rejected'], true), 422);
        CatalogMediaReview::findOrFail($reviewId)->update(['status' => $status, 'decided_at' => now(), 'decided_by' => $by?->id, 'note' => $note]);
    }

    /** Put a decided photo back in the queue, reversing exactly what the decision changed. */
    public function undo(int $reviewId): void
    {
        DB::transaction(function () use ($reviewId): void {
            $r = CatalogMediaReview::findOrFail($reviewId);
            if ($r->status === 'assigned' && $r->product_id) {
                $pid = $r->product_id;
                if ($r->assigned_role === 'primary' && (int) Product::whereKey($pid)->value('primary_image_id') === (int) $r->media_id) {
                    $prev = $r->previous_primary_id;
                    ProductImage::where('product_id', $pid)->update(['is_primary' => false]);
                    if ($prev && ProductImage::where('product_id', $pid)->where('media_id', $prev)->exists()) {
                        ProductImage::where('product_id', $pid)->where('media_id', $prev)->update(['is_primary' => true]);
                    }
                    DB::table('products')->where('id', $pid)->update(['primary_image_id' => $prev]);
                }
                if ($r->link_created) {
                    ProductImage::where('product_id', $pid)->where('media_id', $r->media_id)->delete();
                }
            }
            $r->update(['status' => 'pending', 'product_id' => null, 'assigned_role' => null, 'link_created' => false, 'previous_primary_id' => null, 'decided_at' => null, 'decided_by' => null, 'note' => null]);
        });
    }

    /** @param  array<int, int>  $orderedMediaIds */
    public function reorderGallery(int $productId, array $orderedMediaIds): void
    {
        foreach (array_values($orderedMediaIds) as $i => $mid) {
            ProductImage::where('product_id', $productId)->where('media_id', $mid)->update(['display_order' => $i]);
        }
    }

    public function moveInGallery(int $productId, int $mediaId, int $delta): void
    {
        $ids = ProductImage::where('product_id', $productId)->orderBy('display_order')->orderBy('id')->pluck('media_id')->map(fn ($i) => (int) $i)->all();
        $pos = array_search($mediaId, $ids, true);
        $to = $pos === false ? false : max(0, min(count($ids) - 1, $pos + $delta));
        if ($pos === false || $to === $pos) {
            return;
        }
        array_splice($ids, $pos, 1);
        array_splice($ids, $to, 0, [$mediaId]);
        $this->reorderGallery($productId, $ids);
    }

    public function makePrimary(int $productId, int $mediaId): void
    {
        DB::transaction(function () use ($productId, $mediaId): void {
            abort_unless(ProductImage::where('product_id', $productId)->where('media_id', $mediaId)->exists(), 404);
            ProductImage::where('product_id', $productId)->update(['is_primary' => false]);
            ProductImage::where('product_id', $productId)->where('media_id', $mediaId)->update(['is_primary' => true]);
            DB::table('products')->where('id', $productId)->update(['primary_image_id' => $mediaId]);
        });
    }

    /** Mapping CSV rows that reflect the importer's matches AND every decision made in the queue. @return list<array<string, string>> */
    public function mapping(): array
    {
        $rows = [];
        $reviewMedia = CatalogMediaReview::pluck('media_id')->all();
        $reviews = CatalogMediaReview::with(['media', 'product'])->orderBy('id')->get();
        foreach (ProductImage::with(['media', 'product'])->whereHas('media', fn (Builder $q) => $q->where('path', 'like', 'products/catalog/%'))->orderBy('product_id')->orderBy('display_order')->get() as $l) {
            if (in_array($l->media_id, $reviewMedia, true)) {
                continue;     // reported through its review decision below
            }
            $rows[] = ['product_key' => (string) ($l->product?->import_key ?? $l->product?->slug), 'source_filename' => (string) $l->media->original_filename,
                'role' => (int) $l->product?->primary_image_id === (int) $l->media_id ? 'primary' : 'gallery', 'status' => 'matched: file name'];
        }
        foreach ($reviews as $r) {
            $status = match ($r->status) {
                'assigned' => 'assigned by '.($r->decided_by ? 'reviewer' : 'importer').' ('.$r->decided_at?->toDateString().')',
                'group' => 'group/category-only photo',
                'rejected' => 'rejected'.($r->note ? ': '.$r->note : ''),
                default => 'review pending: '.$r->reason,
            };
            $role = $r->status === 'assigned'
                ? ((int) $r->product?->primary_image_id === (int) $r->media_id ? 'primary' : 'gallery')
                : ($r->status === 'pending' ? 'review' : $r->status);
            $rows[] = ['product_key' => $r->status === 'assigned' ? (string) ($r->product?->import_key ?? $r->product?->slug) : '', 'source_filename' => $r->original_filename, 'role' => $role, 'status' => $status];
        }

        return $rows;
    }

    public function csv(): string
    {
        $fh = fopen('php://temp', 'r+');
        fputcsv($fh, ['product_key', 'source_filename', 'role', 'status']);
        foreach ($this->mapping() as $m) {
            fputcsv($fh, [$m['product_key'], $m['source_filename'], $m['role'], $m['status']]);
        }
        rewind($fh);

        return (string) stream_get_contents($fh);
    }
}
