<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Models\User;
use App\Support\Admin\NavigationMap;
use Filament\Facades\Filament;
use Illuminate\Foundation\Testing\RefreshDatabase;
use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;

final class AdminSidebarTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
    }

    private function nav(string $role, string $locale = 'en'): array
    {
        $u = User::factory()->create(['is_active' => true]);
        $u->assignRole($role);
        $this->actingAs($u->fresh());
        app()->setLocale($locale);
        Filament::setCurrentPanel(Filament::getPanel('admin'));
        Filament::bootCurrentPanel();
        $groups = Filament::getNavigation();
        $items = [];
        $named = [];
        foreach ($groups as $g) {
            if ($g->getLabel() === null) {
                $items = array_merge($items, (array) $g->getItems());
            } else {
                $named[] = $g;
            }
        }

        return ['items' => $items, 'groups' => $named];
    }

    #[Test]
    public function the_admin_sees_dashboard_alone_then_the_six_groups_in_the_briefed_order(): void
    {
        $n = $this->nav(User::ROLE_ADMIN);
        $this->assertCount(1, $n['items']);
        $this->assertSame(__('nav.dashboard'), $n['items'][0]->getLabel());
        $this->assertSame(['Sales & Enquiries', 'Catalogue & Packaging', 'Content & Design', 'Analytics & Reports', 'Users & Roles', 'System Settings'], array_map(fn ($g) => $g->getLabel(), $n['groups']));
    }

    #[Test]
    public function arabic_labels_are_used_and_never_a_raw_translation_key(): void
    {
        $n = $this->nav(User::ROLE_ADMIN, 'ar');
        $labels = array_map(fn ($g) => $g->getLabel(), $n['groups']);
        $this->assertSame(['المبيعات والاستفسارات', 'الكتالوج والتعبئة', 'المحتوى والتصميم', 'التحليلات والتقارير', 'المستخدمون والصلاحيات', 'إعدادات النظام'], $labels);
        foreach ($n['groups'] as $g) {
            foreach ($g->getItems() as $i) {
                $this->assertStringNotContainsString('nav.', (string) $i->getLabel());
            }
        }
    }

    #[Test]
    public function every_screen_has_exactly_one_canonical_location(): void
    {
        $all = [];
        foreach (NavigationMap::MAP as $classes) {
            foreach ($classes as $c) {
                $this->assertTrue(class_exists($c), $c);
                $all[] = $c;
            }
        }
        $this->assertSame($all, array_values(array_unique($all)), 'a screen is listed twice');
    }

    #[Test]
    public function a_role_without_access_gets_no_empty_groups_and_no_hidden_entries(): void
    {
        $n = $this->nav(User::ROLE_VIEWER);
        foreach ($n['groups'] as $g) {
            $this->assertNotEmpty($g->getItems(), 'empty group drawn: '.$g->getLabel());
        }
        $labels = array_map(fn ($g) => $g->getLabel(), $n['groups']);
        $this->assertNotContains('Users & Roles', $labels);
    }

    #[Test]
    public function unauthorised_direct_urls_are_refused_like_the_sidebar_hides_them(): void
    {
        $u = User::factory()->create(['is_active' => true]);
        $u->assignRole(User::ROLE_VIEWER);
        $this->actingAs($u->fresh());
        $this->get('/admin/users')->assertForbidden();
        $this->get('/admin/analytics/settings')->assertForbidden();
    }

    #[Test]
    public function the_old_urls_still_resolve_for_an_admin(): void
    {
        $u = User::factory()->create(['is_active' => true]);
        $u->assignRole(User::ROLE_ADMIN);
        $this->actingAs($u->fresh());
        foreach (['/admin', '/admin/quote-requests', '/admin/products', '/admin/content/pages', '/admin/users', '/admin/analytics'] as $url) {
            $this->get($url)->assertOk();
        }
    }
}
