<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Filament\Pages\Analytics\AnalyticsAcquisition;
use App\Filament\Pages\Analytics\AnalyticsAudience;
use App\Filament\Pages\Analytics\AnalyticsContent;
use App\Filament\Pages\Analytics\AnalyticsOverview;
use App\Filament\Pages\Analytics\AnalyticsSaved;
use App\Filament\Pages\Analytics\TrackingSettings;
use App\Models\User;
use App\Support\Permissions;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Livewire\Livewire;
use PHPUnit\Framework\Attributes\Test;
use Spatie\Permission\Models\Role;
use Tests\TestCase;

final class AnalyticsAdminTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
    }

    private function as(string $role): User
    {
        $u = User::factory()->create(['is_active' => true]);
        $u->assignRole($role);
        $this->actingAs($u->fresh());

        return $u;
    }

    /** A role that can see reports but not export or configure (the "analyst"). */
    private function analyst(): User
    {
        $role = Role::findOrCreate('analyst', 'web');
        $role->syncPermissions([Permissions::ANALYTICS_VIEW]);

        return $this->as('analyst');
    }

    #[Test]
    public function all_report_pages_render_empty_states_for_an_admin(): void
    {
        $this->as(User::ROLE_ADMIN);
        foreach ([AnalyticsOverview::class, AnalyticsAudience::class, AnalyticsContent::class, AnalyticsAcquisition::class, AnalyticsSaved::class, TrackingSettings::class] as $page) {
            Livewire::test($page)->assertSuccessful();
        }
        foreach (['', 'languages', 'devices', 'age'] as $tab) {
            Livewire::test(AnalyticsAudience::class)->set('tab', $tab)->assertSuccessful();
        }
        foreach (['', 'products', 'categories', 'packs'] as $tab) {
            Livewire::test(AnalyticsContent::class)->set('tab', $tab)->assertSuccessful();
        }
        Livewire::test(AnalyticsAcquisition::class)->set('tab', 'funnel')->assertSuccessful();
        Livewire::test(AnalyticsOverview::class)->assertSee(__('analytics.ui.empty'), false);
    }

    #[Test]
    public function an_analyst_can_view_but_not_export_or_configure_and_the_server_refuses_forged_calls(): void
    {
        $this->analyst();
        $c = Livewire::test(AnalyticsOverview::class)->assertSuccessful()->assertDontSee('data-testid="an-csv"', false)->assertSee(__('analytics.ui.no_export'));
        $c->call('exportCsv', 'overview')->assertForbidden();
        Livewire::test(AnalyticsOverview::class)->call('exportPdf', 'overview', 'ar')->assertForbidden();
        $this->get('/admin/analytics/settings')->assertForbidden();
        $this->assertSame(0, DB::table('audit_logs')->where('action', 'like', 'analytics.export%')->count());
    }

    #[Test]
    public function exports_are_allowed_for_the_export_permission_and_audited(): void
    {
        $this->as(User::ROLE_ADMIN);
        Livewire::test(AnalyticsOverview::class)->call('exportCsv', 'overview')->assertHasNoErrors()->assertFileDownloaded();
        Livewire::test(AnalyticsOverview::class)->call('exportPdf', 'overview', 'ar')->assertFileDownloaded();
        $this->assertSame(2, DB::table('audit_logs')->where('action', 'like', 'analytics.export%')->count());
    }

    #[Test]
    public function settings_are_validated_saved_and_audited_and_a_content_editor_is_refused(): void
    {
        $this->as(User::ROLE_ADMIN);
        Livewire::test(TrackingSettings::class)->set('data.events_days', 5)->set('data.timezone', 'Mars/Phobos')->set('data.consent_required', false)->call('save');
        $this->assertSame(7, \App\Services\Analytics\AnalyticsSettings::get('events_days'), 'clamped to the minimum');
        $this->assertSame('Africa/Cairo', \App\Services\Analytics\AnalyticsSettings::timezone(), 'unknown timezone refused');
        $this->assertFalse((bool) \App\Services\Analytics\AnalyticsSettings::get('consent_required'));
        $this->assertSame(1, DB::table('audit_logs')->where('action', 'analytics.settings')->count());
        $this->as(User::ROLE_CONTENT_EDITOR);
        $this->get('/admin/analytics')->assertForbidden();
        $this->get('/admin/analytics/settings')->assertForbidden();
    }

    #[Test]
    public function presets_are_private_to_their_owner_and_hold_only_whitelisted_filters(): void
    {
        $u = $this->analyst();
        Livewire::test(AnalyticsOverview::class)->set('country', 'ES')->set('product', '5')->set('presetName', 'Spain olives')->call('savePreset', 'overview');
        $row = DB::table('analytics_presets')->first();
        $this->assertSame($u->id, (int) $row->user_id);
        $this->assertSame(['range' => '30d', 'country' => 'ES', 'product' => 5], json_decode($row->filters, true));
        $other = $this->as(User::ROLE_ADMIN);
        Livewire::test(AnalyticsSaved::class)->assertDontSee('Spain olives');
        $this->actingAs($u->fresh());
        Livewire::test(AnalyticsSaved::class)->assertSee('Spain olives');
        Livewire::test(AnalyticsOverview::class)->call('applyPreset', (int) $row->id)->assertSet('country', 'ES')->assertSet('product', '5');
    }
}
