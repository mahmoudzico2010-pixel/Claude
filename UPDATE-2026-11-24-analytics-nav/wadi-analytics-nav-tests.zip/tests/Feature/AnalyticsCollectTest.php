<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Models\Product;
use App\Models\SiteSetting;
use App\Models\User;
use App\Services\Analytics\AnalyticsSettings;
use App\Services\Analytics\PageContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;

final class AnalyticsCollectTest extends TestCase
{
    use RefreshDatabase;

    private const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36';

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
        SiteSetting::setMany(['maintenance_mode' => false], 'site');
        config(['wadi.proxies.trusted' => ['127.0.0.1', '::1']]);
    }

    private function ctx(string $key = 'route:home', array $extra = []): array
    {
        $c = ['k' => $key, 'loc' => 'en'] + $extra;

        return $c + ['sig' => PageContext::sign($c)];
    }

    private function beacon(array $payload, array $cookies = ['wr_consent' => 'granted'], array $headers = [], string $ua = self::UA)
    {
        $server = ['HTTP_USER_AGENT' => $ua, 'CONTENT_TYPE' => 'text/plain', 'HTTP_ACCEPT' => 'application/json'];
        foreach ($headers as $k => $v) {
            $server['HTTP_'.strtoupper(str_replace('-', '_', $k))] = $v;
        }

        return $this->call('POST', '/_wr/a', [], $cookies, [], $server, json_encode($payload));
    }

    private function uid(): string
    {
        return bin2hex(random_bytes(16));
    }

    #[Test]
    public function nothing_is_recorded_before_consent_or_after_refusal(): void
    {
        $p = ['type' => 'pv', 'uid' => $this->uid(), 'ctx' => $this->ctx(), 'ref' => '', 'bl' => 'en-gb'];
        $this->beacon($p, [])->assertStatus(202);
        $this->beacon($p, ['wr_consent' => 'denied'])->assertStatus(202);
        $this->assertSame(0, DB::table('analytics_sessions')->count());
        $this->assertSame(0, DB::table('analytics_events')->count());
        $this->beacon($p)->assertStatus(202);
        $this->assertSame(1, DB::table('analytics_sessions')->count());
        // consent not required by the site: still honours an explicit refusal
        AnalyticsSettings::set('consent_required', false);
        $this->beacon(['uid' => $this->uid()] + $p, ['wr_consent' => 'denied']);
        $this->assertSame(1, DB::table('analytics_sessions')->count());
        $this->beacon(['uid' => $this->uid()] + $p, []);
        $this->assertSame(2, DB::table('analytics_sessions')->count());
    }

    #[Test]
    public function a_consented_visit_stores_only_safe_aggregates_country_from_a_trusted_proxy_and_source_rules(): void
    {
        $r = $this->beacon(['type' => 'pv', 'uid' => $this->uid(), 'ctx' => $this->ctx(), 'ref' => 'www.google.com', 'bl' => 'es-es', 'utm' => ['utm_medium' => 'organic', 'utm_source' => 'x', 'junk' => 'y'], 'bid' => $this->uid()], headers: ['CF-IPCountry' => 'ES']);
        $r->assertStatus(202);
        $s = DB::table('analytics_sessions')->first();
        $this->assertSame('ES', $s->country);
        $this->assertSame(['Chrome', 'Windows', 'desktop', 'organic', 'google.com'], [$s->browser, $s->os, $s->device, $s->source_type, $s->referrer_domain]);
        $this->assertSame('es-es', $s->browser_lang);
        $this->assertSame(40, strlen((string) $s->browser_hash));
        $dump = json_encode((array) $s).json_encode(DB::table('analytics_events')->get());
        foreach (['Mozilla', '127.0.0.1', 'https://', 'AppleWebKit'] as $needle) {
            $this->assertStringNotContainsString($needle, $dump, "never stored: $needle");
        }
        $this->assertNotNull(AnalyticsSettings::coverageStart());
    }

    #[Test]
    public function country_header_is_ignored_unless_it_comes_from_a_trusted_proxy_and_unknown_stays_unknown(): void
    {
        config(['wadi.proxies.trusted' => []]);
        $this->beacon(['type' => 'pv', 'uid' => $this->uid(), 'ctx' => $this->ctx()], headers: ['CF-IPCountry' => 'FR']);
        $this->assertNull(DB::table('analytics_sessions')->value('country'), 'a forged header from an untrusted peer is not used');
    }

    #[Test]
    public function missing_referrer_is_direct_never_a_made_up_source_and_internal_referrers_do_not_count(): void
    {
        $this->beacon(['type' => 'pv', 'uid' => $this->uid(), 'ctx' => $this->ctx(), 'ref' => (string) parse_url((string) config('app.url'), PHP_URL_HOST)]);
        $this->assertSame('direct', DB::table('analytics_sessions')->value('source_type'));
        $this->assertNull(DB::table('analytics_sessions')->value('referrer_domain'));
    }

    #[Test]
    public function bots_staff_previews_prefetch_and_maintenance_are_excluded(): void
    {
        $p = ['type' => 'pv', 'uid' => $this->uid(), 'ctx' => $this->ctx()];
        $this->beacon($p, ua: 'Googlebot/2.1 (+http://www.google.com/bot.html)');
        $this->beacon(['uid' => $this->uid()] + $p, headers: ['X-WR-Preview' => '1']);
        $this->beacon(['uid' => $this->uid()] + $p, headers: ['Sec-Purpose' => 'prefetch']);
        $this->assertSame(0, DB::table('analytics_sessions')->count());
        SiteSetting::setMany(['maintenance_mode' => true], 'site');
        $this->beacon(['uid' => $this->uid()] + $p);
        $this->assertSame(0, DB::table('analytics_sessions')->count());
        SiteSetting::setMany(['maintenance_mode' => false], 'site');
        $admin = User::factory()->create(['is_active' => true]);
        $admin->assignRole(User::ROLE_ADMIN);
        $this->actingAs($admin->fresh());
        $this->beacon(['uid' => $this->uid()] + $p);
        $this->assertSame(0, DB::table('analytics_sessions')->count(), 'signed-in staff are never measured');
    }

    #[Test]
    public function an_unsigned_or_tampered_page_context_is_rejected(): void
    {
        $c = $this->ctx('route:home');
        $c['k'] = 'product:999';
        $this->beacon(['type' => 'pv', 'uid' => $this->uid(), 'ctx' => $c]);
        $this->beacon(['type' => 'pv', 'uid' => $this->uid(), 'ctx' => ['k' => 'route:home', 'loc' => 'en']]);
        $this->assertSame(0, DB::table('analytics_events')->count());
    }

    #[Test]
    public function duplicate_events_reloads_and_retries_do_not_inflate_counts(): void
    {
        $uid = $this->uid();
        $p = ['type' => 'pv', 'uid' => $uid, 'ctx' => $this->ctx()];
        $r = $this->beacon($p);
        $sid = $r->json('sid');
        $this->beacon($p, ['wr_consent' => 'granted', 'wr_as' => $sid]);                                         // retry, same uid
        $this->beacon(['uid' => $this->uid()] + $p, ['wr_consent' => 'granted', 'wr_as' => $sid]);                // reload of the same page seconds later
        $this->assertSame(1, DB::table('analytics_events')->where('type', 'pageview')->count());
        $this->assertSame(1, (int) DB::table('analytics_sessions')->value('pageviews'));
    }

    #[Test]
    public function product_and_packaging_views_use_stable_ids_and_distinguish_browsing_from_clicks(): void
    {
        $product = Product::query()->published()->firstOrFail();
        $pc = $this->ctx('product:'.$product->id, ['et' => 'product', 'ei' => $product->id, 'cat' => (int) $product->category_id, 'var' => (int) $product->variety_id]);
        $sid = $this->beacon(['type' => 'pv', 'uid' => $this->uid(), 'ctx' => $this->ctx()])->json('sid');
        $ck = ['wr_consent' => 'granted', 'wr_as' => $sid];
        $this->travel(15)->seconds();
        $this->beacon(['type' => 'pv', 'uid' => $this->uid(), 'ctx' => $pc], $ck);
        $this->beacon(['type' => 'ev', 'ev' => 'rfq_click', 'uid' => $this->uid(), 'ctx' => $pc], $ck);
        $this->beacon(['type' => 'pv', 'uid' => $this->uid(), 'ctx' => $this->ctx('pack:glass-jar', ['et' => 'pack'])], $ck);
        $e = DB::table('analytics_events');
        $this->assertSame(1, (clone $e)->where('type', 'product_view')->where('entity_id', $product->id)->count());
        $this->assertSame(1, (clone $e)->where('type', 'pack_view')->count());
        $this->assertSame(1, (clone $e)->where('type', 'rfq_click')->count());
        $this->assertSame(3, (clone $e)->where('type', 'pageview')->count());
        $this->assertSame(1, (int) DB::table('analytics_sessions')->value('rfq_clicks'));
        $this->assertSame(1, DB::table('analytics_events')->where('type', 'pageview')->where('is_entrance', true)->count());
    }

    #[Test]
    public function engaged_time_is_capped_never_overlaps_across_tabs_and_stays_unknown_without_signals(): void
    {
        $pv = $this->uid();
        $sid = $this->beacon(['type' => 'pv', 'uid' => $pv, 'ctx' => $this->ctx()])->json('sid');
        $this->assertNull(DB::table('analytics_sessions')->value('engaged_ms'), 'no timing signal = unknown, not zero');
        $ck = ['wr_consent' => 'granted', 'wr_as' => $sid];
        $this->beacon(['type' => 'hb', 'pv' => $pv, 'ms' => 999999], $ck);       // absurd claim is capped at 20 s
        $this->assertLessThanOrEqual(20000, (int) DB::table('analytics_sessions')->value('engaged_ms'));
        $before = (int) DB::table('analytics_sessions')->value('engaged_ms');
        $this->beacon(['type' => 'hb', 'pv' => $pv, 'ms' => 15000], $ck);        // a second tab claims time that is already credited
        $after = (int) DB::table('analytics_sessions')->value('engaged_ms');
        $this->assertLessThan(2000, $after - $before, 'overlapping intervals are not added twice');
    }

    #[Test]
    public function a_new_session_starts_after_the_inactivity_timeout(): void
    {
        $sid = $this->beacon(['type' => 'pv', 'uid' => $this->uid(), 'ctx' => $this->ctx()])->json('sid');
        $this->travel(31)->minutes();
        $sid2 = $this->beacon(['type' => 'pv', 'uid' => $this->uid(), 'ctx' => $this->ctx()], ['wr_consent' => 'granted', 'wr_as' => $sid])->json('sid');
        $this->assertNotSame($sid, $sid2);
        $this->assertSame(2, DB::table('analytics_sessions')->count());
    }

    #[Test]
    public function the_cairo_day_is_fixed_at_ingestion_and_follows_daylight_saving(): void
    {
        $this->travelTo(\Carbon\CarbonImmutable::parse('2026-06-14 21:30:00', 'UTC'));    // summer, Cairo = UTC+3 → already 15 June 00:30
        $this->beacon(['type' => 'pv', 'uid' => $this->uid(), 'ctx' => $this->ctx()]);
        $this->assertSame('2026-06-15', DB::table('analytics_sessions')->value('local_day'));
        DB::table('analytics_sessions')->delete();
        $this->travelTo(\Carbon\CarbonImmutable::parse('2026-01-14 21:30:00', 'UTC'));    // winter, Cairo = UTC+2 → still 14 January 23:30
        $this->beacon(['type' => 'pv', 'uid' => $this->uid(), 'ctx' => $this->ctx()]);
        $this->assertSame('2026-01-14', DB::table('analytics_sessions')->value('local_day'));
    }
}
