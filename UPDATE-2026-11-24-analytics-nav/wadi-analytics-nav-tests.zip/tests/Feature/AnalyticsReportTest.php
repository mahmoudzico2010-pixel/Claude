<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Models\Product;
use App\Services\Analytics\Aggregator;
use App\Services\Analytics\AnalyticsSettings;
use App\Services\Analytics\ReportFilters;
use App\Services\Analytics\ReportService;
use Carbon\CarbonImmutable;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;

/** Synthetic TEST data only (never shipped, never seeded). */
final class AnalyticsReportTest extends TestCase
{
    use RefreshDatabase;

    private Product $olive;

    private Product $other;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
        [$this->olive, $this->other] = Product::query()->published()->limit(2)->get()->all();
        $this->travelTo(CarbonImmutable::parse('2026-07-10 10:00:00', 'UTC'));
    }

    private function mkSession(array $a = []): int
    {
        $at = $a['at'] ?? '2026-07-09 09:00:00';
        $row = ['session_uid' => bin2hex(random_bytes(16)), 'browser_hash' => $a['bid'] ?? null, 'started_at' => $at, 'last_seen_at' => $at,
            'local_day' => AnalyticsSettings::localDay(CarbonImmutable::parse($at, 'UTC')), 'country' => $a['country'] ?? null, 'locale' => $a['locale'] ?? 'en',
            'browser_lang' => 'en', 'device' => $a['device'] ?? 'desktop', 'browser' => 'Chrome', 'os' => 'Windows', 'source_type' => $a['source'] ?? 'direct',
            'landing_page' => 'route:home', 'pageviews' => 0, 'product_views' => 0, 'engaged_ms' => $a['engaged'] ?? null, 'rfq_clicks' => 0, 'rfq_starts' => 0, 'rfq_submits' => 0];

        return DB::table('analytics_sessions')->insertGetId($row);
    }

    private function ev(int $sid, string $type, array $a = []): int
    {
        $s = DB::table('analytics_sessions')->find($sid);
        $id = DB::table('analytics_events')->insertGetId(['session_id' => $sid, 'event_uid' => bin2hex(random_bytes(16)), 'occurred_at' => $s->started_at, 'local_day' => $s->local_day, 'type' => $type,
            'page_key' => $a['page'] ?? null, 'locale' => $a['locale'] ?? $s->locale, 'entity_type' => $a['et'] ?? null, 'entity_id' => $a['ei'] ?? null, 'category_id' => $a['cat'] ?? null, 'variety_id' => $a['var'] ?? null,
            'is_entrance' => $a['entr'] ?? false, 'is_exit' => $a['exit'] ?? true, 'next_page_key' => $a['next'] ?? null, 'engaged_ms' => $a['eng'] ?? null]);
        $col = ['pageview' => 'pageviews', 'product_view' => 'product_views', 'rfq_click' => 'rfq_clicks', 'rfq_start' => 'rfq_starts', 'rfq_submit' => 'rfq_submits'][$type] ?? null;
        if ($col) {
            DB::table('analytics_sessions')->where('id', $sid)->increment($col);
        }

        return $id;
    }

    private function seedScenario(): void
    {
        // Spain, mobile, organic: views olive (EN), clicks RFQ, starts, submits a 2-product RFQ.
        $a = $this->mkSession(['country' => 'ES', 'device' => 'mobile', 'source' => 'organic', 'bid' => 'b1', 'engaged' => 120000]);
        $this->ev($a, 'pageview', ['page' => 'route:home', 'entr' => true, 'next' => 'product:'.$this->olive->id, 'exit' => false, 'eng' => 30000]);
        $this->ev($a, 'pageview', ['page' => 'product:'.$this->olive->id, 'et' => 'product', 'ei' => $this->olive->id, 'eng' => 90000]);
        $this->ev($a, 'product_view', ['page' => 'product:'.$this->olive->id, 'et' => 'product', 'ei' => $this->olive->id, 'cat' => $this->olive->category_id, 'var' => $this->olive->variety_id]);
        $this->ev($a, 'rfq_click', ['page' => 'product:'.$this->olive->id, 'et' => 'product', 'ei' => $this->olive->id]);
        $this->ev($a, 'rfq_start', ['page' => 'route:quote.create']);
        $r = $this->ev($a, 'rfq_submit', ['page' => 'route:quote.create']);
        foreach ([$this->olive, $this->other] as $p) {
            DB::table('analytics_event_items')->insert(['event_id' => $r, 'product_id' => $p->id, 'category_id' => $p->category_id, 'variety_id' => $p->variety_id, 'packaging_type_id' => null]);
        }
        // Unknown country, desktop, direct: only browses a product, no RFQ.
        $b = $this->mkSession(['bid' => 'b2']);
        $this->ev($b, 'pageview', ['page' => 'product:'.$this->other->id, 'et' => 'product', 'ei' => $this->other->id, 'entr' => true]);
        $this->ev($b, 'product_view', ['page' => 'product:'.$this->other->id, 'et' => 'product', 'ei' => $this->other->id, 'cat' => $this->other->category_id, 'var' => $this->other->variety_id]);
        // Egypt, Arabic site, direct RFQ from the quote page (no product view).
        $c = $this->mkSession(['country' => 'EG', 'locale' => 'ar', 'bid' => 'b1']);
        $this->ev($c, 'pageview', ['page' => 'route:quote.create', 'entr' => true]);
        $this->ev($c, 'rfq_start', ['page' => 'route:quote.create']);
        $this->ev($c, 'rfq_submit', ['page' => 'route:quote.create']);
    }

    private function svc(array $f = []): ReportService
    {
        return ReportService::for($f + ['range' => 'custom', 'from' => '2026-07-01', 'to' => '2026-07-10']);
    }

    #[Test]
    public function totals_charts_tables_and_funnel_reconcile_and_unknown_is_exposed(): void
    {
        $this->seedScenario();
        $o = $this->svc()->overview();
        $cards = collect($o['cards'])->keyBy('k');
        $this->assertSame(3, $cards['sessions']['v']);
        $this->assertSame(2, $cards['browsers']['v'], 'b1 is one estimated browser even across two sessions');
        $this->assertSame(2, $cards['rfqs']['v']);
        $this->assertSame(66.7, $cards['conversion']['v']);
        $countries = $this->svc()->countries();
        $this->assertSame(3, array_sum(array_column($countries['rows'], 'sessions')), 'country rows add up to the total');
        $this->assertContains('unknown', array_column($countries['rows'], 'key'));
        $this->assertSame(3, array_sum(array_column($o['trend']['rows'], 'sessions')));
        foreach (['languages', 'devices', 'browsers', 'systems', 'sources'] as $r) {
            $this->assertSame(3, array_sum(array_column($this->svc()->{$r}()['rows'], 'sessions')), $r.' reconcile');
        }
    }

    #[Test]
    public function the_funnel_is_ordered_and_a_direct_request_is_not_credited_to_a_product(): void
    {
        $this->seedScenario();
        $f = $this->svc()->funnel();
        $this->assertSame([2, 1, 1, 1], array_column($f['rows'], 'sessions'));
        $rfq = collect($this->svc()->rfqSummary()['rows'])->pluck('value', 'name');
        $this->assertSame(2, $rfq[__('analytics.rfq.attributed')]);
        $this->assertSame(1, $rfq[__('analytics.rfq.after_product')]);
        $this->assertSame(1, $rfq[__('analytics.rfq.direct')]);
        $this->assertSame(1, $rfq[__('analytics.rfq.multi')], 'a multi-product request counts once');
        $p = collect($this->svc()->products()['rows'])->keyBy('key');
        $this->assertSame(1, $p[(string) $this->olive->id]['rfq_clicks']);
        $this->assertSame(1, $p[(string) $this->olive->id]['rfqs']);
        $this->assertSame(1, $p[(string) $this->other->id]['rfqs']);
    }

    #[Test]
    public function filters_apply_to_every_report_consistently(): void
    {
        $this->seedScenario();
        $es = $this->svc(['country' => 'ES']);
        $this->assertSame(1, collect($es->overview()['cards'])->firstWhere('k', 'sessions')['v']);
        $this->assertSame(1, array_sum(array_column($es->devices()['rows'], 'sessions')));
        $this->assertSame(2, array_sum(array_column($es->pages()['rows'], 'views')));
        $byProduct = $this->svc(['product' => $this->olive->id]);
        $this->assertSame(1, collect($byProduct->overview()['cards'])->firstWhere('k', 'sessions')['v']);
        $this->assertSame(0, collect($this->svc(['country' => 'unknown', 'source' => 'organic'])->overview()['cards'])->firstWhere('k', 'sessions')['v']);
        $this->assertSame(1, collect($this->svc(['country' => 'unknown'])->overview()['cards'])->firstWhere('k', 'sessions')['v']);
    }

    #[Test]
    public function engaged_time_is_unknown_when_not_measured_and_the_denominator_is_shown(): void
    {
        $this->seedScenario();
        $cards = collect($this->svc()->overview()['cards'])->keyBy('k');
        $this->assertSame(120000, $cards['engaged']['v']);
        $this->assertStringContainsString('1 ', $cards['engaged']['note']);
        $this->assertNull(collect($this->svc(['country' => 'unknown'])->overview()['cards'])->firstWhere('k', 'engaged')['v']);
    }

    #[Test]
    public function pages_aggregate_all_languages_of_one_stable_id_with_an_optional_language_breakdown(): void
    {
        foreach (array_keys(config('wadi.locales')) as $loc) {
            $s = $this->mkSession(['locale' => $loc, 'bid' => 'x'.$loc]);
            $this->ev($s, 'pageview', ['page' => 'product:'.$this->olive->id, 'et' => 'product', 'ei' => $this->olive->id, 'entr' => true]);
            $this->ev($s, 'product_view', ['page' => 'product:'.$this->olive->id, 'et' => 'product', 'ei' => $this->olive->id, 'cat' => $this->olive->category_id]);
        }
        $rows = $this->svc()->pages()['rows'];
        $this->assertCount(1, $rows);
        $this->assertSame(10, $rows[0]['views']);
        $this->assertCount(10, $this->svc()->pages(true)['rows']);
        $this->assertSame(10, $this->svc()->products()['rows'][0]['views']);
    }

    #[Test]
    public function daily_aggregates_are_idempotent_additive_and_keep_unique_browsers_out(): void
    {
        $this->seedScenario();
        $agg = app(Aggregator::class);
        $agg->day('2026-07-09');
        $agg->day('2026-07-09');
        $all = DB::table('analytics_daily')->where('dim', 'all')->get();
        $this->assertCount(1, $all);
        $this->assertSame(3, (int) $all[0]->sessions);
        $this->assertSame(3, (int) DB::table('analytics_daily')->where('dim', 'country')->count(), 'ES, EG and unknown');
        $this->assertFalse(\Illuminate\Support\Facades\Schema::hasColumn('analytics_daily', 'browsers'), 'unique browsers cannot be added across days');
        $this->assertSame(2, (int) DB::table('analytics_daily')->where('dim', 'all')->value('rfq_submits'));
    }

    #[Test]
    public function raw_rows_are_pruned_only_after_aggregation_and_rollups_survive(): void
    {
        $this->seedScenario();
        AnalyticsSettings::set('events_days', 7);
        AnalyticsSettings::set('sessions_days', 30);
        $agg = app(Aggregator::class);
        $this->assertSame(['events' => 0, 'sessions' => 0], $agg->prune(), 'nothing is removed before a day is aggregated');
        $this->travelTo(CarbonImmutable::parse('2026-09-20 10:00:00', 'UTC'));
        $agg->run('2026-07-09', '2026-09-20');
        $r = $agg->prune();
        $this->assertGreaterThan(0, $r['events']);
        $this->assertSame(3, $r['sessions']);
        $this->assertSame(0, DB::table('analytics_events')->count());
        $this->assertSame(3, (int) DB::table('analytics_daily')->where('dim', 'all')->where('day', '2026-07-09')->value('sessions'));
    }

    #[Test]
    public function age_is_unavailable_by_default_and_small_cohorts_are_withheld(): void
    {
        $this->assertStringContainsString('unavailable', strtolower($this->svc()->age()['note']));
        DB::table('analytics_age_bands')->insert([
            ['period_start' => '2026-07-01', 'period_end' => '2026-07-31', 'band' => '25-34', 'sessions' => 120, 'source' => 'GA4 export', 'coverage_pct' => 41.5, 'created_at' => now(), 'updated_at' => now()],
            ['period_start' => '2026-07-01', 'period_end' => '2026-07-31', 'band' => '65+', 'sessions' => 2, 'source' => 'GA4 export', 'coverage_pct' => 41.5, 'created_at' => now(), 'updated_at' => now()],
        ]);
        $rows = collect($this->svc()->age()['rows'])->keyBy('name');
        $this->assertSame(120, $rows['25-34']['sessions']);
        $this->assertNull($rows['65+']['sessions']);
        $this->assertStringContainsString('GA4 export', $this->svc()->age()['note']);
    }

    #[Test]
    public function compare_with_the_previous_period_and_week_buckets_count_uniques_over_the_whole_bucket(): void
    {
        $this->seedScenario();
        $o = $this->svc(['compare' => true])->overview('week');
        $this->assertNotNull($o['trend']['chart']['compare']);
        $weekBrowsers = array_sum(array_column($o['trend']['rows'], 'browsers'));
        $this->assertLessThanOrEqual(2, collect($o['trend']['rows'])->max('browsers'));
        $this->assertGreaterThanOrEqual(2, $weekBrowsers);
        $this->assertSame(0, collect($o['cards'])->firstWhere('k', 'sessions')['prev']);
    }

    #[Test]
    public function csv_matches_the_report_tables_and_is_utf8_with_bom_and_arabic_labels(): void
    {
        $this->seedScenario();
        app()->setLocale('ar');
        $svc = $this->svc();
        $reports = [$svc->countries(), $svc->funnel()];
        $csv = \App\Services\Analytics\ReportExporter::csv($reports, $svc->filters());
        $this->assertStringStartsWith("\xEF\xBB\xBF", $csv);
        $this->assertStringContainsString('مصر', $csv);
        $this->assertStringContainsString(__('analytics.reports.countries'), $csv);
        $rows = array_map('str_getcsv', explode("\r\n", $csv));
        $sum = 0;
        foreach ($reports[0]['rows'] as $r) {
            $sum += $r['sessions'];
        }
        $this->assertSame(3, $sum);
        $this->assertStringContainsString('"'.$reports[0]['rows'][0]['name'].'"', str_replace($reports[0]['rows'][0]['name'], '"'.$reports[0]['rows'][0]['name'].'"', $csv));
        $this->assertGreaterThan(8, count($rows));
    }

    #[Test]
    public function the_pdf_renders_in_english_and_arabic_without_errors(): void
    {
        $this->seedScenario();
        foreach (['en', 'ar'] as $loc) {
            app()->setLocale($loc);
            $svc = $this->svc();
            $pdf = \App\Services\Analytics\ReportExporter::pdf($svc->summary(), $svc->filters(), $loc)->output();
            $this->assertStringStartsWith('%PDF', $pdf);
            $this->assertGreaterThan(5000, strlen($pdf));
            file_put_contents(sys_get_temp_dir().'/wr-analytics-'.$loc.'.pdf', $pdf);
        }
    }
}
