<?php

declare(strict_types=1);

namespace Tests\Unit;

use App\Support\ArabicShaper;
use PHPUnit\Framework\Attributes\Test;
use PHPUnit\Framework\TestCase;

final class ArabicShaperTest extends TestCase
{
    #[Test]
    public function letters_are_joined_into_presentation_forms_and_reordered_for_the_pdf(): void
    {
        $v = ArabicShaper::visual('مصر');
        $this->assertNotSame('مصر', $v);
        $this->assertMatchesRegularExpression('/[\x{FE70}-\x{FEFF}]/u', $v, 'contextual presentation forms expected');
        $this->assertSame('', ArabicShaper::visual(''));
    }

    #[Test]
    public function latin_and_numbers_are_left_readable(): void
    {
        $this->assertStringContainsString('2026', ArabicShaper::visual('تقرير 2026'));
        $this->assertSame('Spain', ArabicShaper::visual('Spain'));
    }
}
