<?php

declare(strict_types=1);

namespace App\Support;

/**
 * Minimal Arabic text shaper for PDF output (dompdf has no shaping or bidi).
 * Logical text → joined presentation forms (U+FE70–FEFC) → VISUAL order (right to left), keeping digits and Latin runs readable.
 * Each wrapped line is shaped on its own, so long paragraphs are wrapped by us and not re-flowed by the PDF engine.
 */
final class ArabicShaper
{
    /** letter => [isolated, final, initial, medial]; null = does not join to the following letter */
    private const FORMS = [
        'ا' => [0xFE8D, 0xFE8E], 'أ' => [0xFE83, 0xFE84], 'إ' => [0xFE87, 0xFE88], 'آ' => [0xFE81, 0xFE82], 'ء' => [0xFE80],
        'ؤ' => [0xFE85, 0xFE86], 'ئ' => [0xFE89, 0xFE8A, 0xFE8B, 0xFE8C], 'ب' => [0xFE8F, 0xFE90, 0xFE91, 0xFE92], 'ة' => [0xFE93, 0xFE94],
        'ت' => [0xFE95, 0xFE96, 0xFE97, 0xFE98], 'ث' => [0xFE99, 0xFE9A, 0xFE9B, 0xFE9C], 'ج' => [0xFE9D, 0xFE9E, 0xFE9F, 0xFEA0],
        'ح' => [0xFEA1, 0xFEA2, 0xFEA3, 0xFEA4], 'خ' => [0xFEA5, 0xFEA6, 0xFEA7, 0xFEA8], 'د' => [0xFEA9, 0xFEAA], 'ذ' => [0xFEAB, 0xFEAC],
        'ر' => [0xFEAD, 0xFEAE], 'ز' => [0xFEAF, 0xFEB0], 'س' => [0xFEB1, 0xFEB2, 0xFEB3, 0xFEB4], 'ش' => [0xFEB5, 0xFEB6, 0xFEB7, 0xFEB8],
        'ص' => [0xFEB9, 0xFEBA, 0xFEBB, 0xFEBC], 'ض' => [0xFEBD, 0xFEBE, 0xFEBF, 0xFEC0], 'ط' => [0xFEC1, 0xFEC2, 0xFEC3, 0xFEC4],
        'ظ' => [0xFEC5, 0xFEC6, 0xFEC7, 0xFEC8], 'ع' => [0xFEC9, 0xFECA, 0xFECB, 0xFECC], 'غ' => [0xFECD, 0xFECE, 0xFECF, 0xFED0],
        'ف' => [0xFED1, 0xFED2, 0xFED3, 0xFED4], 'ق' => [0xFED5, 0xFED6, 0xFED7, 0xFED8], 'ك' => [0xFED9, 0xFEDA, 0xFEDB, 0xFEDC],
        'ل' => [0xFEDD, 0xFEDE, 0xFEDF, 0xFEE0], 'م' => [0xFEE1, 0xFEE2, 0xFEE3, 0xFEE4], 'ن' => [0xFEE5, 0xFEE6, 0xFEE7, 0xFEE8],
        'ه' => [0xFEE9, 0xFEEA, 0xFEEB, 0xFEEC], 'و' => [0xFEED, 0xFEEE], 'ى' => [0xFEEF, 0xFEF0], 'ي' => [0xFEF1, 0xFEF2, 0xFEF3, 0xFEF4],
    ];

    /** lam + alef variants: [isolated, final] */
    private const LAM_ALEF = ['ا' => [0xFEFB, 0xFEFC], 'أ' => [0xFEF7, 0xFEF8], 'إ' => [0xFEF9, 0xFEFA], 'آ' => [0xFEF5, 0xFEF6]];

    private const MIRROR = ['(' => ')', ')' => '(', '[' => ']', ']' => '[', '{' => '}', '}' => '{', '<' => '>', '>' => '<', '«' => '»', '»' => '«'];

    public static function hasArabic(string $s): bool
    {
        return preg_match('/[\x{0600}-\x{06FF}]/u', $s) === 1;
    }

    /** Shape + reorder one logical line for left-to-right rendering. */
    public static function visual(string $text): string
    {
        $text = preg_replace('/[\x{064B}-\x{065F}\x{0670}\x{0640}]/u', '', $text) ?? $text;   // diacritics, tatweel
        if (! self::hasArabic($text)) {
            return $text;
        }
        // Word-level reordering: words are reversed in order; an Arabic word has its (joined) letters reversed, a Latin/number word stays intact.
        $tokens = preg_split('/(\s+)/u', $text, -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY) ?: [];
        // Units: an Arabic word, or a maximal run of non-Arabic words (kept in its own left-to-right order).
        $units = [];
        $ltr = '';
        $flush = function () use (&$ltr, &$units): void {
            if ($ltr !== '') {
                $units[] = rtrim($ltr) === '' ? $ltr : $ltr;
                $ltr = '';
            }
        };
        foreach ($tokens as $i => $t) {
            if (trim($t) !== '' && self::hasArabic($t)) {
                $flush();
                $units[] = implode('', array_reverse(array_map(fn ($c) => self::MIRROR[$c] ?? $c, self::shape(mb_str_split($t)))));
            } elseif (trim($t) === '' ) {
                // whitespace: stays inside a Latin run only when Latin continues after it
                $nextIsLatin = isset($tokens[$i + 1]) && trim($tokens[$i + 1]) !== '' && ! self::hasArabic($tokens[$i + 1]);
                if ($ltr !== '' && $nextIsLatin) {
                    $ltr .= $t;
                } else {
                    $flush();
                    $units[] = $t;
                }
            } else {
                $ltr .= $t;
            }
        }
        $flush();

        return implode('', array_reverse($units));
    }

    private static function isRtl(string $ch): bool
    {
        return preg_match('/[\x{0600}-\x{06FF}\x{FB50}-\x{FDFF}\x{FE70}-\x{FEFF}]/u', $ch) === 1;
    }

    /** @param list<string> $chars @return list<string> */
    private static function shape(array $chars): array
    {
        $out = [];
        $n = count($chars);
        $joinsNext = fn (?string $c) => $c !== null && isset(self::FORMS[$c]) && count(self::FORMS[$c]) === 4;      // dual-joining letters connect forward
        $joinable = fn (?string $c) => $c !== null && isset(self::FORMS[$c]) && count(self::FORMS[$c]) > 1;           // can accept a connection from the previous letter
        for ($i = 0; $i < $n; $i++) {
            $c = $chars[$i];
            if (! isset(self::FORMS[$c])) {
                $out[] = $c;
                continue;
            }
            $prev = $i > 0 ? $chars[$i - 1] : null;
            $prevConnects = $joinsNext($prev) && ! ($prev === 'ل' && false);
            if ($c === 'ل' && isset($chars[$i + 1], self::LAM_ALEF[$chars[$i + 1]])) {
                $f = self::LAM_ALEF[$chars[$i + 1]];
                $out[] = self::u($prevConnects ? $f[1] : $f[0]);
                $i++;
                continue;
            }
            $next = $chars[$i + 1] ?? null;
            $nextConnects = $joinsNext($c) && $joinable($next);
            $f = self::FORMS[$c];
            $idx = match (true) {
                count($f) === 1 => 0,
                $prevConnects && $nextConnects => 3,
                $prevConnects => 1,
                $nextConnects => 2,
                default => 0,
            };
            $out[] = self::u($f[min($idx, count($f) - 1)]);
        }

        return $out;
    }

    private static function u(int $cp): string
    {
        return mb_chr($cp, 'UTF-8');
    }

    /** Wrap logical text into lines of at most $width characters, shape each, join with <br>. HTML-escaped. */
    public static function html(string $text, int $width = 58): string
    {
        $lines = [];
        $cur = '';
        foreach (preg_split('/\s+/u', trim($text)) ?: [] as $w) {
            if ($cur !== '' && mb_strlen($cur.' '.$w) > $width) {
                $lines[] = $cur;
                $cur = $w;
            } else {
                $cur = $cur === '' ? $w : $cur.' '.$w;
            }
        }
        $lines[] = $cur;

        return implode('<br>', array_map(fn ($l) => e(self::visual($l)), $lines));
    }
}
