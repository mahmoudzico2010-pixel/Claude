<?php

declare(strict_types=1);

namespace App\Support\Admin;

use Filament\Facades\Filament;
use Filament\Navigation\NavigationBuilder;
use Filament\Navigation\NavigationGroup;
use Filament\Navigation\NavigationItem;
use Filament\Pages\Dashboard;

/**
 * The control-panel sidebar, by workflow. One canonical place per screen; routes, URLs and permissions are untouched (this only
 * decides GROUP and ORDER). A screen missing from the map still appears — at the end of System Settings — so nothing can vanish.
 * Entries the user may not open are never listed (same canAccess() as the routes), and a group with no visible entry is not drawn.
 */
final class NavigationMap
{
    /** group key => [classes in display order] */
    public const MAP = [
        'sales' => [
            \App\Filament\Resources\QuoteRequests\QuoteRequestResource::class,
            \App\Filament\Resources\ContactMessages\ContactMessageResource::class,
        ],
        'catalogue' => [
            \App\Filament\Resources\Products\ProductResource::class,
            \App\Filament\Resources\Classifications\CategoriesResource::class,
            \App\Filament\Resources\Classifications\VarietiesResource::class,
            \App\Filament\Resources\Classifications\ProductFormsResource::class,
            \App\Filament\Resources\Classifications\CalibersResource::class,
            \App\Filament\Pages\PackagingCatalog::class,
            \App\Filament\Pages\PhotoReviewQueue::class,
            \App\Filament\Pages\ManageProductFrame::class,
            \App\Filament\Resources\ProductFrames\ProductFramesResource::class,
        ],
        'content' => [
            \App\Filament\Resources\Content\PageResource::class,
            \App\Filament\Pages\HomepageManager::class,
            \App\Filament\Pages\PageHeaderEditor::class,
            \App\Filament\Resources\Content\NavigationItemResource::class,
            \App\Filament\Pages\NavigationManager::class,
            \App\Filament\Resources\Media\MediaAssetResource::class,
            \App\Filament\Pages\UploadLargeFiles::class,
            \App\Filament\Resources\Documents\DocumentResource::class,
            \App\Filament\Resources\News\NewsPostResource::class,
            \App\Filament\Resources\Classifications\NewsCategoriesResource::class,
            \App\Filament\Resources\Content\ContentBlockResource::class,
            \App\Filament\Resources\Team\TeamMemberResource::class,
            \App\Filament\Resources\Team\TeamDepartmentResource::class,
            \App\Filament\Pages\TeamStructure::class,
            \App\Filament\Resources\Company\CompanyLocationResource::class,
            \App\Filament\Resources\Classifications\ExportMarketsResource::class,
            \App\Filament\Resources\Classifications\CertificationsResource::class,
        ],
        'analytics' => [
            \App\Filament\Pages\Analytics\AnalyticsOverview::class,
            \App\Filament\Pages\Analytics\AnalyticsAudience::class,
            \App\Filament\Pages\Analytics\AnalyticsContent::class,
            \App\Filament\Pages\Analytics\AnalyticsAcquisition::class,
            \App\Filament\Pages\Analytics\AnalyticsSaved::class,
        ],
        'security' => [
            \App\Filament\Resources\Users\UserResource::class,
            \App\Filament\Resources\System\AuditLogResource::class,
        ],
        'system' => [
            \App\Filament\Pages\ManageSettings::class,
            \App\Filament\Pages\Languages::class,
            \App\Filament\Pages\ContentTranslations::class,
            \App\Filament\Pages\InterfaceTexts::class,
            \App\Filament\Pages\AutomaticLanguage::class,
            \App\Filament\Pages\ManageTheme::class,
            \App\Filament\Pages\EmailSettings::class,
            \App\Filament\Pages\UploadLimitsSettings::class,
            \App\Filament\Pages\Analytics\TrackingSettings::class,
            \App\Filament\Resources\Modules\ModuleResource::class,
            \App\Filament\Pages\LaunchChecklist::class,
            \App\Filament\Pages\DatabaseBackups::class,
            \App\Filament\Pages\Diagnostics::class,
        ],
    ];

    /** Groups that start collapsed (everyone's own choice is remembered by the browser afterwards). */
    private const COLLAPSED = ['security', 'system'];

    /** @return array<class-string, array{0: string, 1: int}> class => [group, order] */
    public static function placement(): array
    {
        $out = [];
        foreach (self::MAP as $group => $classes) {
            foreach (array_values($classes) as $i => $class) {
                $out[$class] = [$group, $i + 1];
            }
        }

        return $out;
    }

    public static function build(NavigationBuilder $builder): NavigationBuilder
    {
        $panel = Filament::getCurrentPanel() ?? Filament::getPanel('admin');
        $place = self::placement();
        $buckets = array_fill_keys(array_keys(self::MAP), []);
        $extra = [];

        $dashboard = [];
        foreach (array_merge($panel->getResources(), $panel->getPages()) as $class) {
            if ($class === Dashboard::class) {
                $dashboard = $class::getNavigationItems();
                continue;
            }
            if (! $class::shouldRegisterNavigation() || ! $class::canAccess()) {
                continue;
            }
            foreach ($class::getNavigationItems() as $item) {
                if (isset($place[$class])) {
                    $buckets[$place[$class][0]][] = [$place[$class][1], $item];
                } else {
                    $extra[] = $item;        // never lose a screen the map does not know (e.g. one added later)
                }
            }
        }
        foreach ($panel->getNavigationItems() as $item) {   // plugin shortcuts
            $extra[] = $item;
        }
        foreach ($extra as $i => $item) {
            $buckets['system'][] = [1000 + $i, $item];
        }

        foreach ($dashboard as $item) {
            $builder->item($item->label(__('nav.dashboard'))->icon('heroicon-o-home')->activeIcon('heroicon-s-home')->sort(-10));
        }
        $groups = [];
        foreach ($buckets as $key => $rows) {
            if ($rows === []) {
                continue;
            }
            usort($rows, fn ($a, $b) => $a[0] <=> $b[0]);
            $groups[] = NavigationGroup::make(__('nav.groups.'.$key))->items(array_map(fn ($r) => $r[1], $rows))->collapsible()->collapsed(in_array($key, self::COLLAPSED, true));
        }

        return $builder->groups($groups);
    }
}
