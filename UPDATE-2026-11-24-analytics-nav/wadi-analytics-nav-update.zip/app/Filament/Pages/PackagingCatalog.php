<?php

declare(strict_types=1);

namespace App\Filament\Pages;

use App\Filament\Forms\Components\MediaPicker;
use App\Models\Packaging\PackagingRevision;
use App\Models\PackagingType;
use App\Models\Product;
use App\Packaging\Admin\CopyFields;
use App\Packaging\Admin\FormState;
use App\Packaging\Admin\TranslationRows;
use App\Packaging\Catalog\DraftConflictException;
use App\Packaging\Catalog\ImageProbe;
use App\Packaging\Catalog\PackagingValidationException;
use App\Packaging\Catalog\PasswordConfirmationRequired;
use App\Packaging\Catalog\PublishBlockedException;
use App\Packaging\Catalog\RecentPassword;
use App\Packaging\Catalog\Snapshot;
use App\Packaging\Catalog\TranslationStatus;
use App\Packaging\Catalog\Workflow;
use App\Packaging\Data\Image;
use App\Packaging\Legacy\LegacyReconciler;
use App\Packaging\PackagingImages;
use App\Support\Locales;
use App\Support\Permissions;
use BackedEnum;
use Filament\Actions\Action;
use Filament\Forms\Components\Hidden;
use Filament\Forms\Components\Repeater;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Notifications\Notification;
use Filament\Pages\Page;
use Filament\Schemas\Components\Actions;
use Filament\Schemas\Components\EmbeddedSchema;
use Filament\Schemas\Components\Form;
use Filament\Schemas\Components\Grid;
use Filament\Schemas\Components\Html;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Tabs;
use Filament\Schemas\Components\Tabs\Tab;
use Filament\Schemas\Components\Utilities\Get;
use Filament\Schemas\Components\View;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\HtmlString;
use Illuminate\Support\Str;

/**
 * Packaging Catalog: the one place catalog-owned Packaging data is edited.
 *
 * It edits the DRAFT only. Nothing here touches the live tables until a user with
 * packaging.publish confirms their password and publishes; the public pages, product
 * pages, quotation form, quote PDF, homepage, navigation and sitemap all keep reading the
 * published catalog meanwhile. Every operation goes through Workflow, which re-checks
 * authorization on the server, so hiding a button is never the only protection.
 *
 * @property-read Schema $form
 */
class PackagingCatalog extends Page
{
    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedArchiveBox;

    protected static ?int $navigationSort = 6;

    protected static ?string $slug = 'packaging-catalog';

    public static function getNavigationLabel(): string
    {
        return __('nav.packaging_catalog');
    }

    protected string $view = 'filament-panels::pages.page';

    /** @var array<string, mixed> */
    public ?array $data = [];

    public static function getNavigationGroup(): ?string
    {
        return __('nav.groups.catalogue');
    }

    public function getTitle(): string
    {
        return 'Packaging Catalog';
    }

    public function getSubheading(): ?string
    {
        return 'Packs, specifications, images and page text for the Packaging pages. Changes are saved to a draft and go live only when published.';
    }

    public static function canAccess(): bool
    {
        return self::may(Permissions::PACKAGING_VIEW);
    }

    private static function may(string $permission): bool
    {
        $user = Auth::user();

        return $user !== null && $user->is_active && $user->can($permission);
    }

    private function flow(): Workflow
    {
        return app(Workflow::class);
    }

    public function mount(): void
    {
        abort_unless(self::may(Permissions::PACKAGING_VIEW), 403);
        $this->refill();
    }

    private function refill(): void
    {
        $user = Auth::user();

        if (self::may(Permissions::PACKAGING_MANAGE)) {
            $draft = $this->flow()->start($user);
            $snapshot = $draft->data();
            $state = FormState::fromSnapshot($snapshot) + ['draft_version' => $draft->lock_version];
        } else {
            // Read-only users see the draft if one exists, else what is published; they never create one.
            $revision = PackagingRevision::query()->where('kind', PackagingRevision::DRAFT)->first()
                ?? $this->flow()->revisions($user, 1)[0] ?? null;
            $snapshot = $revision?->data() ?? Snapshot::empty();
            $state = FormState::fromSnapshot($snapshot) + ['draft_version' => 0];
        }

        // No language until one is chosen: the editor's rows only load on demand.
        $locale = (string) ($this->data['tr_locale'] ?? '');
        $locale = array_key_exists($locale, $this->translationLocales()) ? $locale : '';
        $group = (string) ($this->data['tr_group'] ?? '');
        $group = array_key_exists($group, self::TRANSLATION_GROUPS) ? $group : 'page';
        $this->trEdits = [];
        $this->trSource = $snapshot;
        $state['tr_locale'] = $locale;
        $state['tr_group'] = $group;
        $state['tr'] = $locale !== '' ? $this->translationGroup($locale, $group) : [];

        $this->form->fill($this->splitPacks($state));
    }

    /** @return array<string, string> key => name, from what is on screen (unsaved edits included) */
    private function choices(string $list, string $keyField = 'key'): array
    {
        return collect((array) ($this->data[$list] ?? []))
            ->filter(fn ($row) => filled($row[$keyField] ?? $row['_orig'] ?? null))
            ->mapWithKeys(fn ($row) => [(string) (($row['_orig'] ?? null) ?: $row[$keyField]) => (string) (($row['name'] ?? '') ?: ($row[$keyField] ?? ''))])
            ->all();
    }

    /** @return array<string, string> */
    public function familyChoices(): array
    {
        return $this->choices('families');
    }

    /** @return array<string, string> */
    public function productChoices(): array
    {
        return $this->choices('products');
    }

    /** @return array<string, string> */
    public function packChoices(): array
    {
        return $this->choices('pack_list', 'slug');
    }

    /** The pack the details editor shows; the other packs' details wait here, out of the page. @var array<string, array<string, mixed>> */
    public array $details = [];

    /** Packs are edited one at a time: a list row each (order, name, family, visibility) plus detail kept server-side. */
    private function splitPacks(array $state): array
    {
        $this->details = [];
        $list = [];

        foreach ($state['packs'] ?? [] as $p) {
            $id = (string) $p['_orig'];
            $list[] = ['_id' => $id, '_orig' => $id, 'slug' => $p['slug'], 'name' => $p['name'], 'family' => $p['family'], 'is_active' => $p['is_active']];
            $this->details[$id] = array_diff_key($p, array_flip(['slug', 'name', 'family', 'is_active']));
        }

        unset($state['packs']);
        $first = $list[0]['_id'] ?? null;

        return $state + ['pack_list' => $list, 'edit_pack' => $first, 'pack' => $first ? $this->details[$first] : []];
    }

    /** Called when another pack is chosen: keep what was typed for the old one, show the new one. */
    public function switchPack(?string $old, ?string $new): void
    {
        if (filled($old) && isset($this->data['pack'])) {
            $this->details[$old] = $this->data['pack'];
        }

        $this->data['pack'] = filled($new) ? ($this->details[$new] ?? []) : [];
    }

    // ------------------------------------------------------------- translations

    /** Texts are edited one group at a time: all of them at once would be a 7 MB page. */
    private const TRANSLATION_GROUPS = [
        'page' => 'Page text',
        'packs' => 'Packs and models',
        'catalog' => 'Families and products',
        'other' => 'Olive-oil packs and navigation',
    ];

    /** Every row of each language touched since the last save (on screen or not), kept until the save. @var array<string, list<array<string, mixed>>> */
    public array $trEdits = [];

    /** The snapshot the translation rows were built from (the draft, or what read-only users see). */
    private ?array $trSource = null;

    /** @return array<string, string> every supported language except the source (English) */
    public function translationLocales(): array
    {
        return collect(Locales::supported())->except(Locales::default())
            ->mapWithKeys(fn (array $c, string $code): array => [$code => $c['name'].' — '.$c['native'].(Locales::isPublished($code) ? '' : ' (not published)')])
            ->all();
    }

    private function translationRows(string $locale): array
    {
        $source = $this->trSource ?? (self::may(Permissions::PACKAGING_MANAGE)
            ? $this->flow()->draft(Auth::user())->data()
            : (PackagingRevision::query()->where('kind', PackagingRevision::DRAFT)->first()
                ?? PackagingRevision::query()->published()->where('is_current', true)->first())?->data() ?? Snapshot::empty());
        $live = PackagingRevision::query()->published()->where('is_current', true)->first()?->data();

        return TranslationRows::rows($source, $locale, $live);
    }

    private static function groupOf(string $entity): string
    {
        return match (strstr($entity, ':', true)) {
            'copy' => 'page',
            'pack', 'model' => 'packs',
            'family', 'product' => 'catalog',
            default => 'other',
        };
    }

    /** @return list<array<string, mixed>> the rows of one group, edits included */
    private function translationGroup(string $locale, string $group): array
    {
        $all = $this->trEdits[$locale] ?? $this->translationRows($locale);

        return array_values(array_filter($all, fn (array $r): bool => self::groupOf((string) $r['entity']) === $group));
    }

    /** Puts the rows on screen back into the language's full list. */
    private function stashTranslations(string $locale): void
    {
        if ($locale === '' || ! isset($this->data['tr'])) {
            return;
        }

        $all = $this->trEdits[$locale] ?? $this->translationRows($locale);
        $byKey = [];
        foreach ((array) $this->data['tr'] as $row) {
            $byKey[$row['entity'].'|'.$row['field']] = $row;
        }

        $this->trEdits[$locale] = array_map(fn (array $r): array => $byKey[$r['entity'].'|'.$r['field']] ?? $r, $all);
    }

    public function switchTranslationLocale(?string $old, ?string $new): void
    {
        $this->stashTranslations((string) $old);
        $this->data['tr'] = filled($new) ? $this->translationGroup($new, (string) ($this->data['tr_group'] ?? 'page')) : [];
    }

    public function switchTranslationGroup(?string $old, ?string $new): void
    {
        if ($this->translationLocale() === '') {
            return;
        }

        $this->stashTranslations($this->translationLocale());
        $this->data['tr'] = $this->translationGroup($this->translationLocale(), (string) ($new ?: 'page'));
    }

    private function translationLocale(): string
    {
        return (string) ($this->data['tr_locale'] ?? '');
    }

    /** @return array<string, mixed> form state with the packs list rebuilt for FormState */
    private function stateWithPacks(): array
    {
        $state = $this->form->getState();
        $current = (string) ($this->data['edit_pack'] ?? '');

        if ($current !== '') {
            $this->details[$current] = $state['pack'] ?? [];
        }

        $state['packs'] = array_map(fn (array $row): array => $row + (array) ($this->details[(string) ($row['_id'] ?? '')] ?? []), array_values((array) ($state['pack_list'] ?? [])));
        unset($state['pack'], $state['pack_list'], $state['edit_pack']);

        return $state;
    }

    // ================================================================ form

    public function form(Schema $schema): Schema
    {
        return $schema
            ->statePath('data')
            ->disabled(! self::may(Permissions::PACKAGING_MANAGE))
            ->components([
                Hidden::make('draft_version'),
                Tabs::make('packaging')->columnSpanFull()->persistTabInQueryString()->tabs([
                    $this->overviewTab(),
                    $this->generalTab(),
                    $this->familiesTab(),
                    $this->packsTab(),
                    $this->oilTab(),
                    $this->galleryTab(),
                    $this->faqTab(),
                    $this->navigationTab(),
                    $this->disclaimerTab(),
                    $this->revisionsTab(),
                    $this->legacyTab(),
                    $this->translationsTab(),
                ]),
            ]);
    }

    private function overviewTab(): Tab
    {
        return Tab::make('overview')->label('Overview')->icon(Heroicon::OutlinedChartBar)->schema([
            View::make('filament.pages.packaging-catalog.overview')
                ->viewData(fn (): array => ['o' => $this->flow()->overview(Auth::user())]),
        ]);
    }

    private function generalTab(): Tab
    {
        $groups = [
            'general' => 'Overview page and general text',
            'pack_pages' => 'Pack pages',
            'gallery' => 'Gallery text',
            'cta' => 'Call to action',
            'faq' => 'FAQ heading',
            'oil' => 'Olive oil page',
            'interface' => 'Interface labels (buttons, table headings, units)',
        ];
        $sections = [];

        foreach ($groups as $group => $title) {
            $fields = [];
            foreach (CopyFields::groups()[$group] as $key => [$label, $type, $help]) {
                $name = 'copy.'.CopyFields::field($key);
                $fields[] = ($type === 'text' ? Textarea::make($name)->rows(3) : TextInput::make($name))
                    ->label($label)->maxLength($type === 'text' ? 1200 : 255)->helperText($help);
            }
            $sections[] = Section::make($title)->collapsible()->collapsed($group !== 'general')->columns(2)->schema($fields);
        }

        array_splice($sections, 1, 0, [Section::make('Overview hero image')->collapsible()->schema([
            ...$this->imageFields('hero.image', 'hero.media_id', 'Overview hero image'),
        ])]);

        return Tab::make('general')->label('General content & SEO')->icon(Heroicon::OutlinedDocumentText)->schema($sections);
    }

    private function familiesTab(): Tab
    {
        return Tab::make('families')->label('Families')->icon(Heroicon::OutlinedSquares2x2)->schema([
            Repeater::make('families')->hiddenLabel()->reorderable()->collapsible()->collapsed()->deletable(false)
                ->addActionLabel('Add family')
                ->itemLabel(fn (array $state): string => ($state['name'] ?? '') ?: 'New family')
                ->schema([
                    Hidden::make('_orig'),
                    Grid::make(['default' => 1, 'md' => 3])->schema([
                        TextInput::make('name')->label('Name')->required()->maxLength(120),
                        TextInput::make('key')->label('Key')->required()->maxLength(60)->rules(['regex:/^[a-z0-9]+(?:-[a-z0-9]+)*$/'])
                            ->readOnly(fn (Get $get): bool => filled($get('_orig')))->helperText('Fixed once created.'),
                        Toggle::make('is_active')->label('Visible')->inline(false),
                        TextInput::make('nav_label')->label('Navigation label')->maxLength(120),
                        TextInput::make('page_slug')->label('Page URL')->maxLength(120)->rules(['nullable', 'regex:/^[a-z0-9]+(?:-[a-z0-9]+)*$/'])
                            ->helperText('/packaging/{this}. Changing it changes the public URL.'),
                        TextInput::make('title')->label('Page title')->maxLength(255),
                    ]),
                    ...$this->imageFields('hero_image', 'hero_media_id', 'Family image'),
                ]),
        ]);
    }

    private function packsTab(): Tab
    {
        $familyOptions = fn (): array => $this->familyChoices();
        $productOptions = fn (): array => $this->productChoices();
        $packOptions = fn (): array => collect((array) ($this->data['pack_list'] ?? []))->filter(fn ($p) => filled($p['_id'] ?? null))->mapWithKeys(fn ($p) => [$p['_id'] => ($p['name'] ?? '') ?: ($p['slug'] ?? 'New pack')])->all();

        return Tab::make('packs')->label('Packs & specifications')->icon(Heroicon::OutlinedCube)->schema([
            Section::make('Packs')->description('Order, name, family and visibility of every pack. Pick one below to edit its details.')->collapsible()->schema([
                Repeater::make('pack_list')->hiddenLabel()->reorderable()->addActionLabel('Add pack')->deletable()
                    ->deleteAction(fn (Action $action) => $action->requiresConfirmation()->modalDescription('A pack that products or quotations use cannot be removed when you publish; set it to inactive instead.'))
                    ->itemLabel(fn (array $state): string => ($state['name'] ?? '') ?: 'New pack')
                    ->schema([
                        Hidden::make('_id')->default(fn (): string => (string) Str::uuid()),
                        Hidden::make('_orig'),
                        Grid::make(['default' => 1, 'md' => 4])->schema([
                            TextInput::make('name')->label('Name')->required()->maxLength(160),
                            TextInput::make('slug')->label('URL slug')->maxLength(120)->rules(['nullable', 'regex:/^[a-z0-9]+(?:-[a-z0-9]+)*$/'])
                                ->readOnly(fn (Get $get): bool => filled($get('_orig')))->helperText('Fixed once created: it is the public URL and the quotation link.'),
                            Select::make('family')->label('Family')->required()->native(false)->options($familyOptions),
                            Toggle::make('is_active')->label('Offered')->inline(false)->helperText('Off hides it from pages, the quotation form and the sitemap.'),
                        ]),
                    ]),
            ]),

            Select::make('edit_pack')->label('Edit the details of')->native(false)->searchable()->live()->options($packOptions)
                ->afterStateUpdated(fn ($state, $old) => $this->switchPack($old, $state)),

            Tabs::make('pack')->visible(fn (Get $get): bool => filled($get('edit_pack')))->tabs([
                Tab::make('details')->label('Details')->schema([
                    Grid::make(['default' => 1, 'md' => 3])->schema([
                        Select::make('pack.weight_unit')->label('Weight unit')->options(['g' => 'grams', 'kg' => 'kilograms'])->native(false)->required(),
                        TextInput::make('pack.illustrated_label')->label('Illustrated product label')->required()->maxLength(160),
                        Select::make('pack.illustrated_product')->label('Illustrated product')->native(false)->searchable()->options($productOptions),
                    ]),
                    Textarea::make('pack.notes')->label('Notes (one per line)')->rows(3),
                    Grid::make(['default' => 1, 'md' => 2])->schema([
                        Select::make('pack.sibling_slug')->label('Related pack')->native(false)->searchable()
                            ->options(fn (): array => $this->packChoices()),
                        TextInput::make('pack.sibling_label')->label('Related pack link text')->maxLength(160),
                    ]),
                    Textarea::make('pack.after_offerings_note')->label('Note after the product list')->rows(2),
                ]),
                Tab::make('specs')->label('Physical specifications')->schema([
                    Grid::make(['default' => 1, 'md' => 3])->schema([
                        TextInput::make('pack.specs.drained_whole_g')->label('Drained weight, whole (g)')->numeric()->minValue(0),
                        TextInput::make('pack.specs.drained_pitted_sliced_g')->label('Drained weight, pitted/sliced (g)')->numeric()->minValue(0),
                        TextInput::make('pack.specs.net_g')->label('Net weight (g)')->numeric()->minValue(0),
                        TextInput::make('pack.specs.gross_g')->label('Gross weight (g)')->numeric()->minValue(0),
                        TextInput::make('pack.specs.units_per_carton')->label('Units per carton')->numeric()->minValue(0),
                    ]),
                    Html::make(fn (): HtmlString => new HtmlString('<p class="text-xs text-gray-500">Weights are the published figures; leave blank when not confirmed. Nothing is estimated or filled in for you.</p>')),
                ]),
                Tab::make('image')->label('Pack image')->schema($this->imageFields('pack.hero_image', 'pack.hero_media_id', 'Pack image')),
                Tab::make('offerings')->label('Offerings')->schema([
                    Repeater::make('pack.offerings')->hiddenLabel()->reorderable()->collapsible()->collapsed()->addActionLabel('Offer a product in this pack')
                        ->itemLabel(fn (array $state): string => (string) ($state['product'] ?? 'New offering'))
                        ->schema([
                            Grid::make(['default' => 1, 'md' => 2])->schema([
                                Select::make('product')->label('Product')->required()->native(false)->searchable()->options($productOptions),
                                Toggle::make('is_active')->label('Offered')->inline(false),
                            ]),
                            ...$this->imageFields('image', 'media_id', 'Product in this pack'),
                        ]),
                ]),
                Tab::make('models')->label('Models / variants')->schema([
                    Repeater::make('pack.models')->hiddenLabel()->reorderable()->collapsible()->collapsed()->addActionLabel('Add model')
                        ->itemLabel(fn (array $state): string => ($state['name'] ?? '') ?: 'New model')
                        ->schema([
                            Hidden::make('_orig'),
                            Grid::make(['default' => 1, 'md' => 3])->schema([
                                TextInput::make('name')->label('Name')->required()->maxLength(160),
                                TextInput::make('key')->label('Key')->required()->maxLength(60)->rules(['regex:/^[a-z0-9]+(?:-[a-z0-9]+)*$/'])
                                    ->readOnly(fn (Get $get): bool => filled($get('_orig'))),
                                Toggle::make('is_active')->label('Offered')->inline(false),
                            ]),
                            Textarea::make('description')->label('Description')->rows(2),
                            ...$this->imageFields('image', 'media_id', 'Model image'),
                        ]),
                ]),
                Tab::make('loading')->label('Loading / containers')->schema([
                    Repeater::make('pack.loading')->hiddenLabel()->reorderable()->addActionLabel('Add container row')
                        ->schema([
                            Grid::make(['default' => 1, 'md' => 3])->schema([
                                TextInput::make('container')->label('Container')->required()->maxLength(80),
                                TextInput::make('quantity')->label('Quantity')->numeric()->minValue(0)->required(),
                                TextInput::make('arrangement')->label('Arrangement')->required()->maxLength(255),
                            ]),
                        ]),
                    Textarea::make('pack.loading_note')->label('Loading note')->rows(2),
                ]),
                Tab::make('reference')->label('Reference image')->schema([
                    Toggle::make('pack.has_reference')->label('This pack has a reference image')->live(),
                    Grid::make(['default' => 1, 'md' => 2])->visible(fn (Get $get): bool => (bool) $get('pack.has_reference'))->schema([
                        TextInput::make('pack.reference.summary')->label('Summary line')->maxLength(255),
                        TextInput::make('pack.reference.alt')->label('Image description')->maxLength(255),
                    ]),
                    Grid::make(1)->visible(fn (Get $get): bool => (bool) $get('pack.has_reference'))
                        ->schema($this->imageFields('pack.reference.image', 'pack.reference.media_id', 'Reference image')),
                ]),
            ]),

            Section::make('Products (names used in the packaging pages)')->collapsible()->collapsed()->schema([
                Repeater::make('products')->hiddenLabel()->reorderable()->collapsible()->collapsed()->addActionLabel('Add product')
                    ->itemLabel(fn (array $state): string => ($state['name'] ?? '') ?: 'New product')
                    ->schema([
                        Hidden::make('_orig'),
                        Grid::make(['default' => 1, 'md' => 4])->schema([
                            TextInput::make('name')->label('Name')->required()->maxLength(160),
                            TextInput::make('key')->label('Key')->required()->maxLength(80)->rules(['regex:/^[a-z0-9]+(?:-[a-z0-9]+)*$/'])
                                ->readOnly(fn (Get $get): bool => filled($get('_orig'))),
                            Select::make('group')->label('Group')->options(['olives' => 'Olives', 'peppers' => 'Peppers', 'oil' => 'Olive oil'])->native(false)->required(),
                            Toggle::make('is_active')->label('Active')->inline(false),
                            Toggle::make('oxidised_black')->label('Oxidised black')->inline(false),
                        ]),
                        Select::make('website_product')->label('Website product for quotation links')->native(false)->searchable()->placeholder('Use the default')
                            ->options(fn (): array => $this->websiteProductOptions())
                            ->helperText(fn (Get $get): string => 'The product the quotation form pre-selects when a visitor follows this variant from a Packaging page. Left empty, the default mapping is used'
                                .(($d = config('packaging.variant_products.'.$get('key'))) ? ' ('.$d.')' : ' (none: only the pack is pre-selected)').'. Must be a published product of a matching category.'),
                    ]),
            ]),
        ]);
    }

    /** @return array<string, string> published website products, slug => name */
    private function websiteProductOptions(): array
    {
        return Product::query()->published()->orderBy('slug')->get()
            ->mapWithKeys(fn (Product $p): array => [$p->slug => ($p->t('name', 'en') ?: $p->slug).' ('.$p->slug.')'])->all();
    }

    private function oilTab(): Tab
    {
        return Tab::make('oil')->label('Olive-oil packs')->icon(Heroicon::OutlinedBeaker)->schema([
            Repeater::make('oil_packs')->hiddenLabel()->reorderable()->collapsible()->collapsed()->addActionLabel('Add olive-oil pack')
                ->itemLabel(fn (array $state): string => ($state['name'] ?? '') ?: 'New olive-oil pack')
                ->schema([
                    Hidden::make('_orig'),
                    Grid::make(['default' => 1, 'md' => 3])->schema([
                        TextInput::make('name')->label('Name')->required()->maxLength(160),
                        TextInput::make('slug')->label('Key')->maxLength(120)->rules(['regex:/^[a-z0-9]+(?:-[a-z0-9]+)*$/'])
                            ->readOnly(fn (Get $get): bool => filled($get('_orig'))),
                        TextInput::make('material')->label('Material')->required()->maxLength(80),
                        TextInput::make('capacity_ml')->label('Capacity (ml)')->numeric()->minValue(0),
                        TextInput::make('product')->label('Product key')->required()->maxLength(80),
                        Toggle::make('is_active')->label('Offered')->inline(false),
                    ]),
                    ...$this->imageFields('image', 'media_id', 'Bottle image'),
                ]),
        ]);
    }

    private function galleryTab(): Tab
    {
        return Tab::make('gallery')->label('Gallery')->icon(Heroicon::OutlinedPhoto)->schema([
            Repeater::make('gallery')->hiddenLabel()->reorderable()->collapsible()->addActionLabel('Add gallery image')
                ->itemLabel(fn (array $state): string => (string) (($state['alt'] ?? '') ?: ($state['image'] ?? 'New image')))
                ->schema([
                    TextInput::make('alt')->label('Image description')->required()->maxLength(255),
                    ...$this->imageFields('image', 'media_id', 'Gallery image'),
                ]),
        ]);
    }

    private function faqTab(): Tab
    {
        return Tab::make('faq')->label('FAQ')->icon(Heroicon::OutlinedQuestionMarkCircle)->schema([
            Repeater::make('faq')->hiddenLabel()->reorderable()->collapsible()->addActionLabel('Add question')
                ->itemLabel(fn (array $state): string => (string) (($state['q'] ?? '') ?: 'New question'))
                ->schema([
                    TextInput::make('q')->label('Question')->required()->maxLength(255),
                    Textarea::make('a')->label('Answer')->required()->rows(3)->maxLength(2000),
                ]),
        ]);
    }

    private function navigationTab(): Tab
    {
        return Tab::make('navigation')->label('Navigation & CTA')->icon(Heroicon::OutlinedLink)->schema([
            Html::make(fn (): HtmlString => new HtmlString('<p class="text-sm text-gray-500">The sub-navigation bar on every Packaging page. The call-to-action text is under General content.</p>')),
            Repeater::make('nav')->hiddenLabel()->reorderable()->collapsible()->addActionLabel('Add link')
                ->itemLabel(fn (array $state): string => (string) (($state['label'] ?? '') ?: 'New link'))
                ->schema([
                    Hidden::make('_orig'),
                    Grid::make(['default' => 1, 'md' => 4])->schema([
                        TextInput::make('label')->label('Label')->required()->maxLength(120),
                        Select::make('type')->label('Goes to')->native(false)->required()->live()
                            ->options(['index' => 'All packaging', 'family' => 'A family page', 'pack' => 'A pack page', 'oil' => 'Olive oil page']),
                        Select::make('family')->label('Family')->native(false)->visible(fn (Get $get): bool => $get('type') === 'family')
                            ->options(fn (): array => $this->familyChoices()),
                        Select::make('pack')->label('Pack')->native(false)->searchable()->visible(fn (Get $get): bool => $get('type') === 'pack')
                            ->options(fn (): array => $this->packChoices()),
                        Toggle::make('is_active')->label('Shown')->inline(false),
                    ]),
                ]),
        ]);
    }

    private function disclaimerTab(): Tab
    {
        return Tab::make('disclaimer')->label('Disclaimer')->icon(Heroicon::OutlinedShieldExclamation)->schema([
            Textarea::make('disclaimer')->label('Disclaimer lines (one per line)')->rows(5)
                ->helperText('Shown at the bottom of every Packaging page.'),
        ]);
    }

    private function revisionsTab(): Tab
    {
        return Tab::make('revisions')->label('Revision history')->icon(Heroicon::OutlinedClock)->schema([
            View::make('filament.pages.packaging-catalog.revisions')->viewData(fn (): array => [
                'revisions' => $this->flow()->revisions(Auth::user()),
                'currentId' => PackagingRevision::query()->published()->where('is_current', true)->value('id'),
            ]),
        ]);
    }

    private function legacyTab(): Tab
    {
        return Tab::make('legacy')->label('Legacy mapping')->icon(Heroicon::OutlinedArrowsRightLeft)->schema([
            View::make('filament.pages.packaging-catalog.legacy')->viewData(fn (): array => [
                'rows' => app(LegacyReconciler::class)->report(),
                'blockers' => app(LegacyReconciler::class)->blockers(),
            ]),
        ]);
    }

    private function translationsTab(): Tab
    {
        $states = fn (): array => collect(TranslationStatus::EDITABLE)
            ->reject(fn (string $s): bool => $s === TranslationStatus::REVIEWED && ! self::may(Permissions::LANGUAGES_REVIEW))
            ->mapWithKeys(fn (string $s): array => [$s => TranslationStatus::label($s)])->all();
        $input = fn (): array => ['dir' => Locales::dir($this->translationLocale()), 'lang' => $this->translationLocale()];

        return Tab::make('translations')->label('Translations')->icon(Heroicon::OutlinedLanguage)->schema([
            View::make('filament.pages.packaging-catalog.translations')
                ->viewData(fn (): array => ['o' => $this->flow()->overview(Auth::user())]),
            Select::make('tr_locale')->label('Language')->native(false)->placeholder('Choose a language to edit its texts')->live()
                ->options(fn (): array => $this->translationLocales())
                ->afterStateUpdated(fn (?string $old, ?string $state) => $this->switchTranslationLocale($old, $state))
                ->helperText('Edits are kept when you switch language or group and saved together with the draft. Only Reviewed texts count towards publishing the language; Draft texts are never shown to visitors.'),
            Select::make('tr_group')->label('Texts')->native(false)->selectablePlaceholder(false)->live()
                ->options(self::TRANSLATION_GROUPS)
                ->afterStateUpdated(fn (?string $old, ?string $state) => $this->switchTranslationGroup($old, $state)),
            Repeater::make('tr')->hiddenLabel()->addable(false)->deletable(false)->reorderable(false)->collapsible()
                ->itemLabel(fn (array $state): string => ($state['label'] ?? '').' — '.TranslationStatus::label((string) ($state['state'] ?? '')))
                ->schema([
                    Hidden::make('entity'), Hidden::make('field'), Hidden::make('label'), Hidden::make('state'),
                    Repeater::make('parts')->hiddenLabel()->addable(false)->deletable(false)->reorderable(false)
                        ->schema([
                            Hidden::make('path'), Hidden::make('src'), Hidden::make('long'),
                            Textarea::make('val')->hiddenLabel()->autosize()->rows(fn (Get $get): int => $get('long') ? 3 : 1)
                                ->extraInputAttributes($input)
                                ->helperText(fn (Get $get): HtmlString => new HtmlString('<span lang="en" dir="ltr">English: '.e((string) $get('src')).'</span>')),
                        ]),
                    Select::make('status')->label('State')->selectablePlaceholder(false)->options($states)
                        ->helperText(fn (): ?string => self::may(Permissions::LANGUAGES_REVIEW) ? 'Changing the text resets it to Needs review; mark it Reviewed again in a later save.' : 'Marking Reviewed needs the languages.review permission.'),
                ]),
        ]);
    }

    /**
     * Image controls for one reference: the verified legacy file (kept as the fallback), an
     * optional library/upload replacement that wins when set, and the status of what would be served.
     *
     * @return list<mixed>
     */
    private function imageFields(string $key, string $media, string $label): array
    {
        return [
            Grid::make(['default' => 1, 'md' => 3])->schema([
                // No option list in the page: ~280 files x hundreds of fields would be megabytes of HTML. Options come from search.
                Select::make($key)->label($label.' — approved file')->native(false)->searchable()->live()->placeholder('None')
                    ->getSearchResultsUsing(fn (string $search): array => collect(app(ImageProbe::class)->approvedKeys())
                        ->filter(fn (string $k): bool => $search === '' || str_contains($k, strtolower($search)))->take(40)->mapWithKeys(fn (string $k): array => [$k => $k])->all())
                    ->getOptionLabelUsing(fn ($value): ?string => filled($value) ? (string) $value : null)
                    ->helperText('The verified file from the approved package. Kept as the fallback when a replacement is chosen.'),
                MediaPicker::make($media, 'Replacement from the media library', 'packaging')->live()
                    ->helperText('Choose an existing image or upload one. It replaces the approved file on the site.'),
                Html::make(fn (Get $get): HtmlString => $this->imageStatus($get($key), $get($media))),
            ]),
        ];
    }

    private function imageStatus(?string $legacy, mixed $mediaId): HtmlString
    {
        $probe = app(ImageProbe::class);
        $mediaId = filled($mediaId) ? (int) (is_array($mediaId) ? ($mediaId[0] ?? 0) : $mediaId) : null;
        $problem = $mediaId ? $probe->media($mediaId) : (filled($legacy) ? $probe->key((string) $legacy) : 'no image selected');
        $src = null;

        if ($problem === null) {
            try {
                $src = app(PackagingImages::class)->src(new Image((string) $legacy, '', $mediaId), 320);
            } catch (\Throwable) {
                $src = null;
            }
        }

        $status = $problem === null
            ? '<span style="color:#15803d;font-weight:600">Ready to publish</span>'
            : '<span style="color:#b91c1c;font-weight:600">'.e($problem).'</span>';
        $img = $src ? '<img src="'.e($src).'" alt="" loading="lazy" style="max-width:160px;max-height:120px;border:1px solid #e5e7eb;border-radius:6px;margin-top:6px">' : '';

        return new HtmlString('<div class="text-sm">'.$status.'<div style="font-size:12px;color:#6b7280">'.($mediaId ? 'Using library image #'.$mediaId : (filled($legacy) ? 'Using approved file' : '')).'</div>'.$img.'</div>');
    }

    // ============================================================ layout

    public function content(Schema $schema): Schema
    {
        return $schema->components([
            Form::make([EmbeddedSchema::make('form')])
                ->id('packaging-form')
                ->livewireSubmitHandler('save')
                ->footer([Actions::make([
                    Action::make('save')->label('Save draft')->submit('packaging-form')->keyBindings(['mod+s'])
                        ->visible(self::may(Permissions::PACKAGING_MANAGE)),
                ])]),
        ]);
    }

    /** @return array<int, Action> */
    protected function getHeaderActions(): array
    {
        $needsPassword = fn (): bool => ! RecentPassword::isRecent();
        $password = fn (): TextInput => TextInput::make('password')->label('Your password')->password()->revealable()
            ->visible($needsPassword)->required($needsPassword)->helperText('Confirm it is you. Not asked again for 10 minutes.');

        return [
            Action::make('preview')->label('Preview draft')->icon(Heroicon::OutlinedEye)->color('gray')
                ->action(function (): void {
                    if ($this->saveDraft(false) === false) {
                        return;
                    }
                    $url = $this->flow()->previewUrl(Auth::user());
                    $this->js('window.open('.json_encode($url).', "_blank", "noopener")');
                    Notification::make()->title('Preview opened')->body('The link works for 30 minutes and only for signed-in staff.')->success()->send();
                }),

            Action::make('validate')->label('Validate')->icon(Heroicon::OutlinedCheckCircle)->color('gray')
                ->visible(self::may(Permissions::PACKAGING_VIEW))
                ->action(function (): void {
                    if (self::may(Permissions::PACKAGING_MANAGE) && $this->saveDraft(false) === false) {
                        return;
                    }
                    $errors = $this->flow()->validate(Auth::user());
                    $errors === []
                        ? Notification::make()->success()->title('The draft can be published.')->send()
                        : Notification::make()->danger()->persistent()->title(count($errors).' problem(s) stop publication')->body($this->list($errors))->send();
                }),

            Action::make('compare')->label('Compare')->icon(Heroicon::OutlinedArrowsRightLeft)->color('gray')
                ->modalHeading('Compare revisions')->modalWidth('5xl')->modalSubmitAction(false)->modalCancelActionLabel('Close')
                ->schema([
                    Select::make('from')->label('From')->native(false)->required()->live()
                        ->options(fn (): array => collect($this->flow()->revisions(Auth::user(), 50))->mapWithKeys(fn ($r) => [$r->id => 'Published #'.$r->number.($r->is_current ? ' (live)' : '')])->all()),
                    Select::make('to')->label('To')->native(false)->live()->default('draft')
                        ->options(fn (): array => ['draft' => 'Current draft'] + collect($this->flow()->revisions(Auth::user(), 50))->mapWithKeys(fn ($r) => [$r->id => 'Published #'.$r->number])->all()),
                    Html::make(fn (Get $get): HtmlString => $this->diffHtml($get('from'), $get('to'))),
                ]),

            Action::make('rollback')->label('Roll back')->icon(Heroicon::OutlinedArrowUturnLeft)->color('warning')
                ->visible(self::may(Permissions::PACKAGING_PUBLISH))
                ->modalHeading('Roll back to an earlier revision')
                ->modalDescription('Publishes that earlier revision again as a new revision. Nothing is deleted, and the current one stays in the history.')
                ->schema([
                    Select::make('revision')->label('Revision')->native(false)->required()
                        ->options(fn (): array => collect($this->flow()->revisions(Auth::user(), 50))->reject(fn ($r) => $r->is_current)->mapWithKeys(fn ($r) => [$r->id => 'Published #'.$r->number.' — '.($r->published_at?->format('Y-m-d H:i'))])->all()),
                    $password(),
                ])
                ->action(function (array $data): void {
                    $this->guarded(fn () => $this->flow()->rollback(Auth::user(), (int) $data['revision'], $data['password'] ?? null), 'Rolled back: the earlier revision is live again.');
                }),

            Action::make('discard')->label('Reset draft')->icon(Heroicon::OutlinedTrash)->color('gray')
                ->visible(self::may(Permissions::PACKAGING_MANAGE))
                ->requiresConfirmation()
                ->modalDescription('Throws away every unpublished change and starts again from what is live.')
                ->action(function (): void {
                    $this->guarded(fn () => $this->flow()->discard(Auth::user()), 'Draft reset to the published catalog.');
                    $this->refill();
                }),

            Action::make('publish')->label('Publish')->icon(Heroicon::OutlinedRocketLaunch)
                ->visible(self::may(Permissions::PACKAGING_PUBLISH))
                ->modalHeading('Publish the draft')
                ->modalDescription('Replaces the live Packaging catalog, quotation options, sitemap and homepage Packaging section in one step. If anything is invalid nothing changes.')
                ->schema([
                    TextInput::make('note')->label('Note for the history')->maxLength(180),
                    $password(),
                ])
                ->action(function (array $data): void {
                    if ($this->saveDraft(false) === false) {
                        return;
                    }
                    $this->guarded(fn () => $this->flow()->publish(Auth::user(), $data['password'] ?? null, $data['note'] ?? null), 'Published. The new catalog is live.');
                    $this->refill();
                }),

            Action::make('decideLegacy')->label('Decide legacy pack')->icon(Heroicon::OutlinedArrowsRightLeft)->color('gray')
                ->visible(self::may(Permissions::PACKAGING_MANAGE))
                ->modalDescription('Map an old packaging record to an approved pack (its products move across and history is kept), or retire it. Nothing is ever deleted.')
                ->schema([
                    Select::make('legacy')->label('Legacy record')->native(false)->searchable()->required()
                        ->options(fn (): array => PackagingType::query()->where('in_catalog', false)->withTranslation()->orderBy('id')->get()->mapWithKeys(fn (PackagingType $t) => [$t->id => ($t->t('name') ?? $t->slug).' ('.$t->slug.')'])->all()),
                    Select::make('decision')->label('Decision')->native(false)->required()->live()
                        ->options(['map' => 'Map to an approved pack', 'retire' => 'Retire (stop offering)', 'reset' => 'Undo the decision']),
                    Select::make('target')->label('Approved pack')->native(false)->searchable()
                        ->visible(fn (Get $get): bool => $get('decision') === 'map')->required(fn (Get $get): bool => $get('decision') === 'map')
                        ->options(fn (): array => PackagingType::query()->where('in_catalog', true)->orderBy('display_order')->pluck('slug', 'slug')->all()),
                    TextInput::make('note')->label('Note')->maxLength(180),
                ])
                ->action(fn (array $data) => $this->guarded(fn () => $this->flow()->decideLegacy(Auth::user(), (int) $data['legacy'], $data['decision'], $data['target'] ?? null, $data['note'] ?? null), 'Decision recorded.')),

            Action::make('acceptUnique')->label('Accept unique matches')->icon(Heroicon::OutlinedCheck)->color('gray')
                ->visible(self::may(Permissions::PACKAGING_MANAGE))
                ->requiresConfirmation()
                ->modalDescription('Maps every legacy record that matches exactly one approved pack (same kind and capacity). Ambiguous and unmatched records are left for you.')
                ->action(function (): void {
                    $n = 0;
                    $this->guarded(function () use (&$n): void {
                        $n = $this->flow()->acceptUniqueLegacy(Auth::user());
                    }, 'Accepted.');
                }),
        ];
    }

    // ============================================================ actions

    public function save(): void
    {
        $this->saveDraft(true);
    }

    /** @return bool|null false when it did not save */
    private function saveDraft(bool $notify): ?bool
    {
        abort_unless(self::may(Permissions::PACKAGING_MANAGE), 403);

        $user = Auth::user();
        $base = $this->flow()->draft($user)->data();

        try {
            $state = $this->stateWithPacks();
            $this->stashTranslations((string) ($state['tr_locale'] ?? ''));
            $edits = $this->trEdits;
            unset($state['tr'], $state['tr_locale'], $state['tr_group']);

            $snapshot = FormState::intoSnapshot($base, $state);
            $reports = [];
            foreach ($edits as $locale => $rows) {
                if (array_key_exists((string) $locale, $this->translationLocales())) {
                    // Marking a text Reviewed is its own permission, checked here on the server.
                    $r = TranslationRows::applyWithReport($snapshot, (string) $locale, $rows, self::may(Permissions::LANGUAGES_REVIEW));
                    $snapshot = $r['snapshot'];
                    $reports[(string) $locale] = array_diff_key($r, ['snapshot' => 1]);
                }
            }
            $this->flow()->save($user, $snapshot, (int) ($this->data['draft_version'] ?? 0));
            $this->flow()->recordTranslationReviews($user, $reports);
        } catch (DraftConflictException) {
            Notification::make()->danger()->persistent()
                ->title('Someone else changed the draft')
                ->body('Your changes were not saved so theirs are not overwritten. The page has been reloaded with the latest draft; re-apply your edit.')
                ->send();
            $this->refill();

            return false;
        }

        $this->refill();
        $notify && Notification::make()->success()->title('Draft saved. The live site is unchanged.')->send();

        return true;
    }

    private function guarded(callable $operation, string $success): void
    {
        try {
            $operation();
        } catch (AuthorizationException) {
            abort(403);
        } catch (PasswordConfirmationRequired|PackagingValidationException|PublishBlockedException|DraftConflictException $e) {
            Notification::make()->danger()->persistent()->title($this->title($e))->body($this->body($e))->send();

            return;
        } catch (\RuntimeException $e) {
            Notification::make()->danger()->title($e->getMessage())->send();

            return;
        }

        Notification::make()->success()->title($success)->send();
    }

    private function title(\Throwable $e): string
    {
        return match (true) {
            $e instanceof PasswordConfirmationRequired => 'Password not confirmed',
            $e instanceof PackagingValidationException => 'Not published: the catalog has problems',
            $e instanceof PublishBlockedException => 'Not published: legacy packaging is undecided',
            default => 'Not saved',
        };
    }

    private function body(\Throwable $e): string
    {
        if ($e instanceof PackagingValidationException) {
            return $this->list($e->errors);
        }

        if ($e instanceof PublishBlockedException) {
            return $this->list(array_map(fn (string $r): array => ['path' => 'legacy packaging', 'message' => $r], $e->reasons));
        }

        return $e->getMessage();
    }

    /** @param list<array{path: string, message: string}> $errors */
    private function list(array $errors): string
    {
        return collect($errors)->take(12)->map(fn (array $e): string => $e['path'].': '.$e['message'])->implode(' • ')
            .(count($errors) > 12 ? ' • …and '.(count($errors) - 12).' more' : '');
    }

    private function diffHtml(mixed $from, mixed $to): HtmlString
    {
        if (blank($from)) {
            return new HtmlString('<p class="text-sm text-gray-500">Choose a revision to compare.</p>');
        }

        $diff = $this->flow()->compare(Auth::user(), (int) $from, $to === 'draft' || blank($to) ? null : (int) $to);

        if ($diff === []) {
            return new HtmlString('<p class="text-sm">No differences.</p>');
        }

        $rows = collect($diff)->take(300)->map(function (array $d): string {
            $fmt = fn ($v): string => e(is_scalar($v) || $v === null ? (string) ($v ?? '—') : json_encode($v, JSON_UNESCAPED_UNICODE));

            return '<tr style="border-top:1px solid #e5e7eb"><td style="padding:4px 8px;font-family:monospace;font-size:12px">'.e($d['path']).'</td>'
                .'<td style="padding:4px 8px;color:#b91c1c">'.$fmt($d['from']).'</td><td style="padding:4px 8px;color:#15803d">'.$fmt($d['to']).'</td></tr>';
        })->implode('');

        return new HtmlString('<div style="max-height:50vh;overflow:auto"><table style="width:100%;font-size:13px"><thead><tr><th align="left">Field</th><th align="left">Before</th><th align="left">After</th></tr></thead><tbody>'.$rows.'</tbody></table>'
            .(count($diff) > 300 ? '<p>…and '.(count($diff) - 300).' more changes.</p>' : '').'</div>');
    }
}
