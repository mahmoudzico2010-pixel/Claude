<?php

declare(strict_types=1);

namespace App\Filament\Pages\Analytics;

use App\Services\Analytics\ReportFilters;
use Filament\Support\Icons\Heroicon;

class AnalyticsSaved extends AnalyticsPage
{
    protected static string|\BackedEnum|null $navigationIcon = Heroicon::OutlinedBookmark;

    protected static ?int $navigationSort = 5;

    protected static ?string $slug = 'analytics/saved';

    protected string $view = 'filament.pages.analytics.saved';

    public static function getNavigationLabel(): string
    {
        return __('analytics.nav.saved');
    }

    public function reportKey(): string
    {
        return 'saved';
    }

    /** @return list<array<string, mixed>> */
    protected function exportReports(string $which): array
    {
        return [];
    }

    /** Where a preset opens: the page it was saved on, with its filters in the address. */
    public function reportUrl(object $preset): string
    {
        $page = ['overview' => AnalyticsOverview::class, 'audience' => AnalyticsAudience::class, 'content' => AnalyticsContent::class, 'acquisition' => AnalyticsAcquisition::class][$preset->report] ?? AnalyticsOverview::class;

        $q = ReportFilters::fromArray((array) json_decode((string) $preset->filters, true))->toArray();
        if (isset($q['locale'])) {
            $q['lang'] = $q['locale'];
            unset($q['locale']);
        }

        return $page::getUrl($q);
    }
}
