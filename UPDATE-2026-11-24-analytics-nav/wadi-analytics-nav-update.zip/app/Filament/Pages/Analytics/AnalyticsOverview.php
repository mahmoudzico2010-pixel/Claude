<?php

declare(strict_types=1);

namespace App\Filament\Pages\Analytics;

use Filament\Support\Icons\Heroicon;

class AnalyticsOverview extends AnalyticsPage
{
    protected static string|\BackedEnum|null $navigationIcon = Heroicon::OutlinedChartBar;

    protected static ?int $navigationSort = 1;

    protected static ?string $slug = 'analytics';

    protected string $view = 'filament.pages.analytics.overview';

    public static function getNavigationLabel(): string
    {
        return __('analytics.nav.overview');
    }

    public function reportKey(): string
    {
        return 'overview';
    }

    /** @return list<array<string, mixed>> */
    protected function exportReports(string $which): array
    {
        $svc = $this->service();
        $o = $svc->overview($this->grain);

        return $which === 'summary' ? $svc->summary() : [$o['trend'], $o['countries'], $o['products'], $o['rfq_days']];
    }
}
