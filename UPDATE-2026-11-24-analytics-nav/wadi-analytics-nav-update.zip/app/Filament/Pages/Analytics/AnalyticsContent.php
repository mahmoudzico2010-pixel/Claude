<?php

declare(strict_types=1);

namespace App\Filament\Pages\Analytics;

use Filament\Support\Icons\Heroicon;

class AnalyticsContent extends AnalyticsPage
{
    protected static string|\BackedEnum|null $navigationIcon = Heroicon::OutlinedDocumentChartBar;

    protected static ?int $navigationSort = 3;

    protected static ?string $slug = 'analytics/content';

    protected string $view = 'filament.pages.analytics.content';

    public static function getNavigationLabel(): string
    {
        return __('analytics.nav.content');
    }

    public function reportKey(): string
    {
        return 'content';
    }

    /** @return list<array<string, mixed>> */
    protected function exportReports(string $which): array
    {
        $s = $this->service();

        return match ($this->tab ?: 'pages') {
            'products' => [$s->products()],
            'categories' => [$s->categories(), $s->varieties()],
            'packs' => [$s->packs(), $s->requestedPacks()],
            default => [$s->pages($this->byLanguage)],
        };
    }
}
