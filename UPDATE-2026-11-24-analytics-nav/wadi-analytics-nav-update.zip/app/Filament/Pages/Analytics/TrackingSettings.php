<?php

declare(strict_types=1);

namespace App\Filament\Pages\Analytics;

use App\Services\Analytics\AnalyticsSettings;
use App\Services\Analytics\Audit;
use App\Support\Permissions;
use Filament\Notifications\Notification;
use Filament\Pages\Page;
use Filament\Support\Icons\Heroicon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

/** System Settings → Visitor analytics. Viewing the settings and changing them are both gated by analytics.configure; every change is audited. */
class TrackingSettings extends Page
{
    protected static string|\BackedEnum|null $navigationIcon = Heroicon::OutlinedChartPie;

    protected static ?int $navigationSort = 4;

    protected static ?string $slug = 'analytics/settings';

    protected string $view = 'filament.pages.analytics.settings';

    /** @var array<string, mixed> */
    public array $data = [];

    public string $ageBands = '';

    public string $ageSource = '';

    public string $ageCoverage = '';

    public string $ageFrom = '';

    public string $ageTo = '';

    public static function getNavigationGroup(): ?string
    {
        return __('nav.groups.system');
    }

    public static function getNavigationLabel(): string
    {
        return __('analytics.nav.settings');
    }

    public function getTitle(): string
    {
        return __('analytics.set.title');
    }

    public static function canAccess(): bool
    {
        return Auth::user()?->can(Permissions::ANALYTICS_CONFIGURE) ?? false;
    }

    public function mount(): void
    {
        abort_unless(static::canAccess(), 403);
        foreach (array_keys(AnalyticsSettings::DEFAULTS) as $k) {
            $this->data[$k] = AnalyticsSettings::get($k);
        }
    }

    public function save(): void
    {
        abort_unless(static::canAccess(), 403);
        $old = [];
        $new = [];
        $rules = ['enabled' => 'bool', 'consent_required' => 'bool', 'session_timeout_min' => [5, 240], 'events_days' => [7, 1095], 'sessions_days' => [30, 1095], 'min_cohort' => [1, 1000]];
        foreach (AnalyticsSettings::DEFAULTS as $k => $_) {
            $v = $this->data[$k] ?? AnalyticsSettings::get($k);
            if (isset($rules[$k]) && is_array($rules[$k])) {
                $v = max($rules[$k][0], min($rules[$k][1], (int) $v));
            } elseif ($k === 'timezone') {
                $v = in_array((string) $v, \DateTimeZone::listIdentifiers(), true) ? (string) $v : AnalyticsSettings::timezone();
            } elseif ($k === 'geo_headers') {
                $v = implode(',', array_filter(array_map(fn ($h) => preg_match('/^[A-Za-z0-9-]{2,40}$/', trim($h)) ? trim($h) : null, explode(',', (string) $v))));
            } elseif ($k === 'campaign_fields') {
                $v = implode(',', array_values(array_intersect(['utm_source', 'utm_medium', 'utm_campaign'], array_map('trim', explode(',', (string) $v)))));
            } elseif (is_bool(AnalyticsSettings::DEFAULTS[$k])) {
                $v = (bool) $v;
            }
            $cur = AnalyticsSettings::get($k);
            if ($cur !== $v) {
                $old[$k] = $cur;
                $new[$k] = $v;
                AnalyticsSettings::set($k, $v);
            }
        }
        if ($new !== []) {
            Audit::log('analytics.settings', 'tracking settings', $old, $new);
        }
        Notification::make()->title(__('analytics.set.saved'))->success()->send();
    }

    /** Aggregate age bands from a consent-aware provider (e.g. a GA4 export). One "band,sessions" line each; never per person. */
    public function importAge(): void
    {
        abort_unless(static::canAccess(), 403);
        $from = preg_match('/^\d{4}-\d{2}-\d{2}$/', $this->ageFrom) ? $this->ageFrom : null;
        $to = preg_match('/^\d{4}-\d{2}-\d{2}$/', $this->ageTo) ? $this->ageTo : null;
        $source = trim(mb_substr($this->ageSource, 0, 80));
        if (! $from || ! $to || $source === '') {
            return;
        }
        $rows = [];
        foreach (preg_split('/\R/', $this->ageBands) ?: [] as $line) {
            if (preg_match('/^\s*(\d{2}-\d{2}|\d{2}\+|unknown)\s*[,;\t]\s*(\d{1,9})\s*$/i', $line, $m)) {
                $rows[] = ['period_start' => $from, 'period_end' => $to, 'band' => strtolower($m[1]), 'sessions' => (int) $m[2], 'source' => $source,
                    'coverage_pct' => is_numeric($this->ageCoverage) ? max(0, min(100, (float) $this->ageCoverage)) : null, 'imported_by' => Auth::id(), 'created_at' => now(), 'updated_at' => now()];
            }
        }
        if ($rows !== []) {
            DB::table('analytics_age_bands')->insert($rows);
            Audit::log('analytics.age_import', $source, [], ['bands' => count($rows), 'period' => $from.'→'.$to]);
        }
        $this->ageBands = '';
        Notification::make()->title(__('analytics.set.age_imported', ['n' => count($rows)]))->success()->send();
    }
}
