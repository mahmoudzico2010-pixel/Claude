<?php

declare(strict_types=1);

namespace App\Filament\Pages\Analytics;

use Filament\Support\Icons\Heroicon;

class AnalyticsAudience extends AnalyticsPage
{
    protected static string|\BackedEnum|null $navigationIcon = Heroicon::OutlinedUsers;

    protected static ?int $navigationSort = 2;

    protected static ?string $slug = 'analytics/audience';

    protected string $view = 'filament.pages.analytics.audience';

    public static function getNavigationLabel(): string
    {
        return __('analytics.nav.audience');
    }

    public function reportKey(): string
    {
        return 'audience';
    }

    /** @return list<array<string, mixed>> */
    protected function exportReports(string $which): array
    {
        $s = $this->service();

        return match ($this->tab ?: 'countries') {
            'languages' => [$s->languages(), $s->browserLanguages()],
            'devices' => [$s->browsers(), $s->systems(), $s->devices()],
            'age' => [$s->age()],
            default => [$s->countries()],
        };
    }
}
