<?php

declare(strict_types=1);

namespace App\Filament\Pages\Analytics;

use Filament\Support\Icons\Heroicon;

class AnalyticsAcquisition extends AnalyticsPage
{
    protected static string|\BackedEnum|null $navigationIcon = Heroicon::OutlinedFunnel;

    protected static ?int $navigationSort = 4;

    protected static ?string $slug = 'analytics/acquisition';

    protected string $view = 'filament.pages.analytics.acquisition';

    public static function getNavigationLabel(): string
    {
        return __('analytics.nav.acquisition');
    }

    public function reportKey(): string
    {
        return 'acquisition';
    }

    /** @return list<array<string, mixed>> */
    protected function exportReports(string $which): array
    {
        $s = $this->service();

        return ($this->tab ?: 'sources') === 'funnel' ? [$s->funnel(), $s->rfqSummary(), $s->rfqByDay()] : [$s->sources(), $s->referrers(), $s->campaigns()];
    }
}
