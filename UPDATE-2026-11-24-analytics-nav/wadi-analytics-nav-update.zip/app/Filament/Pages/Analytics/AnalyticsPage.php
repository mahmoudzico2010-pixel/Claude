<?php

declare(strict_types=1);

namespace App\Filament\Pages\Analytics;

use App\Filament\Concerns\InteractsWithAnalyticsFilters;
use App\Support\Permissions;
use BackedEnum;
use Filament\Pages\Page;
use Illuminate\Support\Facades\Auth;

/** Base of the five analytics pages (Analytics & Reports). Viewing needs analytics.view; exporting and configuring are separate. */
abstract class AnalyticsPage extends Page
{
    use InteractsWithAnalyticsFilters;

    protected static string|BackedEnum|null $navigationIcon = null;

    abstract public function reportKey(): string;

    public static function getNavigationGroup(): ?string
    {
        return __('nav.groups.analytics');
    }

    public static function canAccess(): bool
    {
        return Auth::user()?->can(Permissions::ANALYTICS_VIEW) ?? false;
    }

    public function mount(): void
    {
        abort_unless(static::canAccess(), 403);
    }

    public function getTitle(): string
    {
        return static::getNavigationLabel();
    }
}
