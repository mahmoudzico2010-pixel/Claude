<?php

declare(strict_types=1);

namespace App\Filament\Concerns;

use App\Models\Product;
use App\Services\Analytics\Audit;
use App\Services\Analytics\ReportExporter;
use App\Services\Analytics\ReportFilters;
use App\Services\Analytics\ReportService;
use App\Support\Permissions;
use Filament\Notifications\Notification;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Livewire\Attributes\Url;
use Symfony\Component\HttpFoundation\StreamedResponse;

/** Shared filter bar, presets and exports of every analytics page. Authorization is re-checked on the server for each action. */
trait InteractsWithAnalyticsFilters
{
    #[Url(as: 'range')]
    public string $range = '30d';

    #[Url(as: 'from')]
    public string $from = '';

    #[Url(as: 'to')]
    public string $to = '';

    #[Url(as: 'compare')]
    public bool $compare = false;

    #[Url(as: 'country')]
    public string $country = '';

    #[Url(as: 'lang')]
    public string $locale = '';

    #[Url(as: 'device')]
    public string $device = '';

    #[Url(as: 'source')]
    public string $source = '';

    #[Url(as: 'page')]
    public string $pageKey = '';

    #[Url(as: 'product')]
    public string $product = '';

    #[Url(as: 'category')]
    public string $category = '';

    #[Url(as: 'pack')]
    public string $pack = '';

    #[Url(as: 'tab')]
    public string $tab = '';

    public string $grain = 'day';

    public bool $byLanguage = false;

    public string $presetName = '';

    /** @return array<string, mixed> */
    public function filterArray(): array
    {
        return ['range' => $this->range, 'from' => $this->from, 'to' => $this->to, 'compare' => $this->compare, 'country' => $this->country, 'locale' => $this->locale, 'device' => $this->device,
            'source' => $this->source, 'page' => $this->pageKey, 'product' => $this->product, 'category' => $this->category, 'pack' => $this->pack];
    }

    public function filters(): ReportFilters
    {
        return ReportFilters::fromArray($this->filterArray());
    }

    public function service(): ReportService
    {
        return new ReportService($this->filters());
    }

    public function resetFilters(): void
    {
        foreach (['from', 'to', 'country', 'locale', 'device', 'source', 'pageKey', 'product', 'category', 'pack'] as $p) {
            $this->{$p} = '';
        }
        $this->range = '30d';
        $this->compare = false;
    }

    public function canExport(): bool
    {
        return (bool) Auth::user()?->can(Permissions::ANALYTICS_EXPORT);
    }

    public function canConfigure(): bool
    {
        return (bool) Auth::user()?->can(Permissions::ANALYTICS_CONFIGURE);
    }

    // ------------------------------------------------------------------ choices for the filter bar (cheap lookups)

    /** @return array<string, string> */
    public function countryChoices(): array
    {
        $out = ['unknown' => __('analytics.unknown')];
        foreach (DB::table('analytics_sessions')->whereNotNull('country')->where('country', '<>', '')->where('country', '<>', 'unknown')->distinct()->pluck('country') as $c) {
            $out[$c] = \App\Services\Analytics\Labels::country($c);
        }
        asort($out);
        $out = ['unknown' => $out['unknown']] + array_diff_key($out, ['unknown' => 1]);

        return $out;
    }

    /** @return array<string, string> */
    public function productChoices(): array
    {
        return Product::query()->published()->with('translations')->orderBy('display_order')->limit(300)->get()->mapWithKeys(fn (Product $p) => [(string) $p->id => (string) ($p->t('name') ?: $p->slug)])->all();
    }

    /** @return array<string, string> */
    public function categoryChoices(): array
    {
        return \App\Models\Category::query()->with('translations')->orderBy('display_order')->get()->mapWithKeys(fn ($c) => [(string) $c->id => (string) ($c->t('name') ?: $c->slug)])->all();
    }

    /** @return array<string, string> */
    public function packChoices(): array
    {
        try {
            return collect(app(\App\Packaging\PackagingCatalog::class)->packs())->mapWithKeys(fn ($p) => [$p->slug => $p->name])->all();
        } catch (\Throwable) {
            return [];
        }
    }

    /** @return array<string, string> */
    public function pageChoices(): array
    {
        return DB::table('analytics_events')->where('type', 'pageview')->selectRaw('page_key k, COUNT(*) n')->groupBy('page_key')->orderByDesc('n')->limit(80)->pluck('k')
            ->mapWithKeys(fn ($k) => [$k => \App\Services\Analytics\Labels::page($k)])->all();
    }

    // ------------------------------------------------------------------ presets (own, view permission)

    public function savePreset(string $report): void
    {
        abort_unless(Auth::user()?->can(Permissions::ANALYTICS_VIEW), 403);
        $name = trim(mb_substr($this->presetName, 0, 80));
        if ($name === '') {
            return;
        }
        $f = $this->filters();
        DB::table('analytics_presets')->insert(['user_id' => Auth::id(), 'name' => $name, 'report' => preg_replace('/[^a-z_]/', '', $report) ?: 'overview', 'filters' => json_encode($f->toArray()), 'created_at' => now(), 'updated_at' => now()]);
        $this->presetName = '';
        Notification::make()->title(__('analytics.ui.save_preset'))->success()->send();
    }

    public function applyPreset(int $id): void
    {
        $row = DB::table('analytics_presets')->where('id', $id)->where('user_id', Auth::id())->first();
        abort_unless($row !== null && Auth::user()?->can(Permissions::ANALYTICS_VIEW), 403);
        $f = ReportFilters::fromArray((array) json_decode((string) $row->filters, true));
        $this->range = $f->range;
        $this->from = $f->range === 'custom' ? $f->from : '';
        $this->to = $f->range === 'custom' ? $f->to : '';
        $this->compare = $f->compare;
        $this->country = (string) $f->country;
        $this->locale = (string) $f->locale;
        $this->device = (string) $f->device;
        $this->source = (string) $f->source;
        $this->pageKey = (string) $f->page;
        $this->product = (string) ($f->product ?? '');
        $this->category = (string) ($f->category ?? '');
        $this->pack = (string) $f->pack;
    }

    public function deletePreset(int $id): void
    {
        abort_unless(Auth::user()?->can(Permissions::ANALYTICS_VIEW), 403);
        DB::table('analytics_presets')->where('id', $id)->where('user_id', Auth::id())->delete();
    }

    /** @return \Illuminate\Support\Collection<int, object> */
    public function presets()
    {
        return DB::table('analytics_presets')->where('user_id', Auth::id())->orderBy('name')->get();
    }

    // ------------------------------------------------------------------ exports (separate permission, audited)

    /** @return list<array<string, mixed>> */
    abstract protected function exportReports(string $which): array;

    public function exportCsv(string $which): StreamedResponse
    {
        abort_unless($this->canExport(), 403);
        $svc = $this->service();
        $reports = $this->exportReports($which);
        Audit::log('analytics.export.csv', $which, [], ['filters' => $svc->filters()->toArray()]);
        $csv = ReportExporter::csv($reports, $svc->filters());

        return response()->streamDownload(fn () => print ($csv), 'wadi-analytics-'.$which.'-'.now()->format('Ymd-His').'.csv', ['Content-Type' => 'text/csv; charset=UTF-8']);
    }

    public function exportPdf(string $which, string $locale = 'ar'): StreamedResponse
    {
        abort_unless($this->canExport(), 403);
        $locale = in_array($locale, ['ar', 'en'], true) ? $locale : 'en';
        $svc = $this->service();
        Audit::log('analytics.export.pdf', $which, [], ['filters' => $svc->filters()->toArray(), 'language' => $locale]);
        $pdf = ReportExporter::pdf($which === 'summary' ? $svc->summary() : $this->exportReports($which), $svc->filters(), $locale)->output();

        return response()->streamDownload(fn () => print ($pdf), 'wadi-analytics-'.$which.'-'.$locale.'-'.now()->format('Ymd').'.pdf', ['Content-Type' => 'application/pdf']);
    }
}
