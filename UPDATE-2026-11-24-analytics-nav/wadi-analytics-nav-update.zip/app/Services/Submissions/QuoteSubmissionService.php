<?php

declare(strict_types=1);

namespace App\Services\Submissions;

use App\Enums\RfqStatus;
use App\Services\Rfq\RfqNotifier;
use App\Models\Caliber;
use App\Models\PackagingType;
use App\Models\Product;
use App\Models\ProductForm;
use App\Models\QuoteRequest;
use App\Models\QuoteRequestItem;
use App\Models\QuoteRequestItemOption;
use Illuminate\Http\Request;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

/**
 * Turns a validated public form submission into a QuoteRequest.
 *
 * The persistence step and the notification step are deliberately separate:
 * the inquiry is committed first, and mail is attempted afterwards. If SMTP
 * is down or misconfigured the buyer's request is still recorded and visible
 * in the panel — losing business to a mail failure is not acceptable.
 */
class QuoteSubmissionService
{
    /**
     * @param  array<string, mixed>  $data
     */
    public function store(array $data, Request $request): QuoteRequest
    {
        /** @var list<\App\Models\RfqNotification> $notifications */
        $notifications = [];

        $quote = DB::transaction(function () use ($data, $request, &$notifications): QuoteRequest {
            $quote = QuoteRequest::create([
                'reference' => QuoteRequest::nextReference(),
                'company_name' => $data['company_name'],
                'contact_person' => $data['contact_person'],
                'email' => $data['email'],
                'phone' => $data['phone'] ?? null,
                'whatsapp' => $data['whatsapp'] ?? null,
                'country_code' => $data['country_code'] ?? null,
                'company_type' => $data['company_type'] ?? null,
                'destination_port' => $data['destination_port'] ?? null,
                'containers_count' => $data['containers_count'] ?? null,
                'required_delivery_date' => $data['required_delivery_date'] ?? null,
                'private_label' => (bool) ($data['private_label'] ?? false),
                'message' => $data['message'] ?? null,
                'status' => RfqStatus::New,
                'locale' => app()->getLocale(),
                'source_ip' => $request->ip(),
                'user_agent' => Str::limit((string) $request->userAgent(), 500, ''),
                'source_page' => $request->headers->get('referer'),
                'submitted_at' => now(),
            ]);

            $this->storeItems($quote, $data['items'] ?? []);
            $this->storeAttachments($quote, $request->file('attachments', []));

            // The opening status is part of the audit trail from the start.
            $quote->statusHistory()->create([
                'from_status' => null,
                'to_status' => RfqStatus::New->value,
                'user_id' => null,
                'note' => null,
                'created_at' => now(),
            ]);

            // The e-mails owed for this request are recorded in the SAME transaction (with a snapshot of what they say):
            // if anything above fails, nothing was recorded and nothing is ever sent.
            $quote->load('items.options', 'items.product.translations', 'items.packagingType.translations', 'items.form', 'items.caliber');
            try {
                $notifications = app(RfqNotifier::class)->recordInitial($quote);
            } catch (\Throwable $e) {
                // Never lose the request because the e-mail bookkeeping failed.
                report($e);
            }

            return $quote;
        });

        // Only now, after the commit, and after the response has gone out. A mail failure can neither undo the request
        // nor delay or fail the customer's confirmation page; it is recorded and visible on the request.
        app(RfqNotifier::class)->sendAfterResponse($notifications);

        // Measurement is strictly secondary: it runs after the request is saved and can never fail or delay it.
        try {
            app(\App\Services\Analytics\Collector::class)->recordRfq($quote, $request);
        } catch (\Throwable $e) {
            report($e);
        }

        return $quote;
    }

    /**
     * @param  array<int, array<string, mixed>>  $items
     */
    private function storeItems(QuoteRequest $quote, array $items): void
    {
        $order = 0;
        $max = (int) config('wadi.rfq.max_items', 20);

        foreach ($items as $item) {
            if ($order >= $max) {
                break;
            }

            $productId = $item['product_id'] ?? null;
            $quantity = $item['quantity'] ?? null;

            // A row with neither a product nor a quantity is an empty repeater
            // row the buyer left behind; skip it silently.
            if (blank($productId) && blank($quantity)) {
                continue;
            }

            $product = $productId ? Product::query()->withTranslation()->find($productId) : null;

            // Each attribute's full selection, merged from the multi-select
            // list and the singular field so a post from either shape works.
            $calibers = $this->selectedIds($item, 'caliber_ids', 'caliber_id');
            $forms = $this->selectedIds($item, 'product_form_ids', 'product_form_id');
            $packaging = $this->selectedIds($item, 'packaging_type_ids', 'packaging_type_id');
            $modelKey = count($packaging) === 1 && filled($item['packaging_model'] ?? null) && app(\App\Packaging\QuoteOptions::class)->hasModel($packaging[0], (string) $item['packaging_model'])
                ? (string) $item['packaging_model'] : null;

            $record = $quote->items()->create([
                'product_id' => $product?->id,
                // Snapshot the name so renaming or archiving the product later
                // never rewrites what the buyer actually asked for.
                'product_name_snapshot' => $product?->name(),

                // The legacy columns keep the FIRST selected value of each
                // attribute. Everything that read these before multi-select
                // existed — the admin table, the CSV export, the notification
                // e-mail — keeps returning a sensible answer without being
                // changed, while the complete selection lives in the options
                // table alongside it.
                'product_form_id' => $forms[0] ?? null,
                'caliber_id' => $calibers[0] ?? null,
                'packaging_type_id' => $packaging[0] ?? null,
                'packaging_label_snapshot' => isset($packaging[0])
                    ? mb_substr((string) PackagingType::query()->find($packaging[0])?->localized('name'), 0, 190) ?: null
                    : null,

                // The packaging model/variant (for example a drum model) — recorded with a snapshot of its label.
                'packaging_model_key' => $modelKey,
                'packaging_model_label_snapshot' => $modelKey !== null ? mb_substr((string) app(\App\Packaging\QuoteOptions::class)->modelLabel($packaging[0] ?? null, $modelKey), 0, 190) ?: null : null,

                'quantity' => $quantity !== null && $quantity !== '' ? (float) $quantity : null,
                'unit' => $item['unit'] ?? 'kg',
                'notes' => $item['notes'] ?? null,
                'display_order' => $order++,
            ]);

            $this->storeItemOptions($record, [
                QuoteRequestItemOption::ATTRIBUTE_CALIBER => [Caliber::class, $calibers],
                QuoteRequestItemOption::ATTRIBUTE_FORM => [ProductForm::class, $forms],
                QuoteRequestItemOption::ATTRIBUTE_PACKAGING => [PackagingType::class, $packaging],
            ]);
        }
    }

    /**
     * The ids chosen for one attribute, from either the multi-select list or
     * the singular field, de-duplicated and in the order they were sent.
     *
     * Accepting both is what keeps this backward compatible: a cached page, a
     * browser with JavaScript disabled, or anything posting to this endpoint
     * from outside still submits the singular field and still works.
     *
     * @param  array<string, mixed>  $item
     * @return array<int, int>
     */
    private function selectedIds(array $item, string $pluralKey, string $singularKey): array
    {
        $ids = [];

        foreach ((array) ($item[$pluralKey] ?? []) as $id) {
            if (is_numeric($id)) {
                $ids[] = (int) $id;
            }
        }

        $single = $item[$singularKey] ?? null;

        if (is_numeric($single)) {
            $ids[] = (int) $single;
        }

        return array_values(array_unique($ids));
    }

    /**
     * Write the option rows for one line.
     *
     * The label is resolved and stored now, not looked up later. A caliber can
     * be renamed or deleted long after an inquiry is answered, and a quotation
     * has to keep saying what the customer actually asked for — the same
     * reasoning that already snapshots the product name above.
     *
     * Labels are read in one query per attribute rather than one per id, so a
     * line with eight calibers costs three queries, not eight.
     *
     * @param  array<string, array{0: class-string, 1: array<int, int>}>  $selections
     */
    private function storeItemOptions(QuoteRequestItem $item, array $selections): void
    {
        $rows = [];

        foreach ($selections as $attribute => [$modelClass, $ids]) {
            // A single value is not a multi-select; leaving it out keeps the
            // options table to the rows that actually add information, and the
            // accessor falls back to the legacy column for the rest.
            if (count($ids) < 2) {
                continue;
            }

            $labels = $modelClass::query()
                ->whereIn('id', $ids)
                ->get()
                ->keyBy('id');

            $order = 0;

            foreach ($ids as $id) {
                $label = $labels->get($id)?->localized('name');

                if ($label === null || $label === '') {
                    continue;
                }

                $rows[] = [
                    'quote_request_item_id' => $item->id,
                    'attribute' => $attribute,
                    'option_id' => $id,
                    'label_snapshot' => mb_substr($label, 0, 190),
                    'display_order' => $order++,
                ];
            }
        }

        if ($rows !== []) {
            QuoteRequestItemOption::insert($rows);
        }
    }

    /**
     * Attachments go to the private `local` disk, outside the web root, and
     * are streamed back only through an authorised controller action.
     *
     * @param  array<int, UploadedFile>|UploadedFile|null  $files
     */
    private function storeAttachments(QuoteRequest $quote, mixed $files): void
    {
        if (blank($files)) {
            return;
        }

        $files = is_array($files) ? $files : [$files];
        $max = (int) config('wadi.rfq.max_attachments', 5);

        foreach (array_slice($files, 0, $max) as $file) {
            if (! $file instanceof UploadedFile || ! $file->isValid()) {
                continue;
            }

            $extension = strtolower($file->getClientOriginalExtension() ?: 'bin');
            $safeName = Str::limit(Str::slug(pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME)), 50, '')
                ?: 'attachment';
            $filename = $safeName.'-'.Str::lower(Str::random(8)).'.'.$extension;

            $path = $file->storeAs('rfq-attachments/'.$quote->reference, $filename, 'local');

            if ($path === false) {
                continue;
            }

            $quote->attachments()->create([
                'disk' => 'local',
                'path' => $path,
                'original_filename' => $file->getClientOriginalName(),
                'mime_type' => $file->getClientMimeType(),
                'size' => Storage::disk('local')->size($path),
            ]);
        }
    }
}
