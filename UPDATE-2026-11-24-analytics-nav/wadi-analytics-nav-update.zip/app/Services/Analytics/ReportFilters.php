<?php

declare(strict_types=1);

namespace App\Services\Analytics;

use Carbon\CarbonImmutable;

/** The shared filter set. Every chart, table, CSV and PDF of a report is produced from one instance, so their totals reconcile. */
final class ReportFilters
{
    public const RANGES = ['today', 'yesterday', '7d', '30d', '90d', 'custom'];

    public function __construct(
        public string $range = '30d',
        public string $from = '',
        public string $to = '',
        public bool $compare = false,
        public ?string $country = null,    // ISO-2, or 'unknown'
        public ?string $locale = null,
        public ?string $device = null,
        public ?string $source = null,
        public ?string $page = null,       // page_key
        public ?int $product = null,
        public ?int $category = null,
        public ?string $pack = null,       // pack slug
    ) {
        $this->resolve();
    }

    /** @param array<string, mixed> $a */
    public static function fromArray(array $a): self
    {
        $s = fn (string $k, ?array $allow = null): ?string => isset($a[$k]) && is_scalar($a[$k]) && trim((string) $a[$k]) !== '' && ($allow === null || in_array((string) $a[$k], $allow, true)) ? trim((string) $a[$k]) : null;
        $i = fn (string $k): ?int => isset($a[$k]) && is_numeric($a[$k]) && (int) $a[$k] > 0 ? (int) $a[$k] : null;
        $country = $s('country');

        return new self(
            range: $s('range', self::RANGES) ?? '30d',
            from: preg_match('/^\d{4}-\d{2}-\d{2}$/', (string) ($a['from'] ?? '')) ? (string) $a['from'] : '',
            to: preg_match('/^\d{4}-\d{2}-\d{2}$/', (string) ($a['to'] ?? '')) ? (string) $a['to'] : '',
            compare: filter_var($a['compare'] ?? false, FILTER_VALIDATE_BOOLEAN),
            country: $country !== null && (strtolower($country) === 'unknown' || preg_match('/^[A-Za-z]{2}$/', $country)) ? (strtolower($country) === 'unknown' ? 'unknown' : strtoupper($country)) : null,
            locale: $s('locale'),
            device: $s('device', ['mobile', 'tablet', 'desktop', 'unknown']),
            source: $s('source', ['direct', 'organic', 'referral', 'paid', 'social', 'email']),
            page: ($p = $s('page')) !== null && preg_match('/^[a-z]+:[A-Za-z0-9._\-]{1,70}$/', $p) ? $p : null,
            product: $i('product'),
            category: $i('category'),
            pack: ($k = $s('pack')) !== null && preg_match('/^[A-Za-z0-9._\-]{1,60}$/', $k) ? $k : null,
        );
    }

    private function resolve(): void
    {
        $today = CarbonImmutable::parse(AnalyticsSettings::localDay());
        [$f, $t] = match ($this->range) {
            'today' => [$today, $today],
            'yesterday' => [$today->subDay(), $today->subDay()],
            '7d' => [$today->subDays(6), $today],
            '90d' => [$today->subDays(89), $today],
            'custom' => [CarbonImmutable::parse($this->from ?: $today->subDays(29)->toDateString()), CarbonImmutable::parse($this->to ?: $today->toDateString())],
            default => [$today->subDays(29), $today],
        };
        if ($f->gt($t)) {
            [$f, $t] = [$t, $f];
        }
        if ($f->diffInDays($t) > 800) {
            $f = $t->subDays(800);
        }
        $this->from = $f->toDateString();
        $this->to = $t->toDateString();
    }

    public function days(): int
    {
        return (int) CarbonImmutable::parse($this->from)->diffInDays(CarbonImmutable::parse($this->to)) + 1;
    }

    /** The equally long period immediately before. */
    public function previous(): self
    {
        $n = $this->days();
        $to = CarbonImmutable::parse($this->from)->subDay();
        $c = clone $this;
        $c->range = 'custom';
        $c->to = $to->toDateString();
        $c->from = $to->subDays($n - 1)->toDateString();
        $c->compare = false;

        return $c;
    }

    /** @return array<string, mixed> only whitelisted keys, ready for a saved preset or an export URL */
    public function toArray(): array
    {
        return array_filter([
            'range' => $this->range, 'from' => $this->range === 'custom' ? $this->from : null, 'to' => $this->range === 'custom' ? $this->to : null,
            'compare' => $this->compare ?: null, 'country' => $this->country, 'locale' => $this->locale, 'device' => $this->device, 'source' => $this->source,
            'page' => $this->page, 'product' => $this->product, 'category' => $this->category, 'pack' => $this->pack,
        ], fn ($v) => $v !== null && $v !== '');
    }

    /** Human description for the report header / PDF. @return list<string> */
    public function describe(): array
    {
        $out = [$this->from.' → '.$this->to.' ('.AnalyticsSettings::timezone().')'];
        foreach (['country' => $this->country, 'locale' => $this->locale, 'device' => $this->device, 'source' => $this->source, 'page' => $this->page, 'product' => $this->product, 'category' => $this->category, 'pack' => $this->pack] as $k => $v) {
            if ($v !== null && $v !== '') {
                $out[] = __('analytics.filters.'.$k).': '.$v;
            }
        }

        return $out;
    }
}
