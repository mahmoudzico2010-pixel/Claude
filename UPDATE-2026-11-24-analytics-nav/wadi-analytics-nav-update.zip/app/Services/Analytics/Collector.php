<?php

declare(strict_types=1);

namespace App\Services\Analytics;

use App\Models\QuoteRequest;
use App\Support\Locales;
use Carbon\CarbonImmutable;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

/**
 * Ingests beacons from the storefront script and the server-side RFQ hook.
 *
 * Privacy contract: nothing here stores an IP, a User-Agent string, a full referrer URL, a query string other than the
 * allow-listed campaign fields, form values or any identity. Without consent (when required) or after a refusal nothing is recorded
 * and nothing is reconstructed.
 */
final class Collector
{
    public const COOKIE_SESSION = 'wr_as';

    public const COOKIE_CONSENT = 'wr_consent';

    private const CLICK_EVENTS = ['rfq_click', 'rfq_start', 'brochure', 'mail_click', 'whatsapp_click'];

    /** Why a request is not measured (null = measure it). */
    public function excluded(Request $request): ?string
    {
        if (! AnalyticsSettings::enabled()) {
            return 'disabled';
        }
        if (UserAgent::isBot($request->userAgent())) {
            return 'bot';
        }
        if (Auth::check()) {
            return 'staff';          // the storefront has no customer accounts: any signed-in user is staff
        }
        if ($request->hasHeader('X-WR-Preview') || $request->boolean('preview')) {
            return 'preview';
        }
        $purpose = strtolower((string) ($request->headers->get('Sec-Purpose') ?: $request->headers->get('Purpose') ?: $request->headers->get('X-Purpose')));
        if (str_contains($purpose, 'prefetch') || str_contains($purpose, 'prerender')) {
            return 'prefetch';
        }
        if (app()->isDownForMaintenance() || (bool) \App\Models\SiteSetting::get('site.maintenance_mode', false)) {
            return 'maintenance';
        }
        $consent = (string) $request->cookie(self::COOKIE_CONSENT, '');
        if ($consent === 'denied' || (AnalyticsSettings::get('consent_required') && $consent !== 'granted')) {
            return 'no-consent';
        }

        return null;
    }

    /** Handle one beacon. @return array{sid: ?string, status: string} */
    public function handle(Request $request, array $p): array
    {
        if ($why = $this->excluded($request)) {
            return ['sid' => null, 'status' => 'skipped:'.$why];
        }
        $ctx = (array) ($p['ctx'] ?? []);
        $sig = (string) ($ctx['sig'] ?? '');
        unset($ctx['sig']);
        if (! isset($ctx['k'], $ctx['loc']) || ! PageContext::verify($ctx, $sig) || ! Locales::isSupported((string) $ctx['loc'])) {
            return ['sid' => null, 'status' => 'rejected:context'];
        }

        $now = CarbonImmutable::now('UTC');
        $type = (string) ($p['type'] ?? '');
        $sid = $this->activeSession((string) ($request->cookie(self::COOKIE_SESSION) ?: ($p['sid'] ?? '')), $now);

        if ($type === 'pv') {
            $uid = $this->uid($p['uid'] ?? null);
            if ($uid === null) {
                return ['sid' => $sid?->session_uid, 'status' => 'rejected:uid'];
            }
            $sid ??= $this->newSession($request, $p, $ctx, $now);
            $this->pageview($sid, $uid, $ctx, $now);

            return ['sid' => $sid->session_uid, 'status' => 'ok'];
        }
        if ($sid === null) {
            return ['sid' => null, 'status' => 'skipped:no-session'];
        }

        if ($type === 'hb') {
            $this->heartbeat($sid, $this->uid($p['pv'] ?? null), (int) ($p['ms'] ?? 0), $now);
        } elseif ($type === 'ev' && in_array((string) ($p['ev'] ?? ''), self::CLICK_EVENTS, true)) {
            $uid = $this->uid($p['uid'] ?? null);
            if ($uid !== null) {
                $this->event($sid, $uid, (string) $p['ev'], $ctx, $now);
            }
        }

        return ['sid' => $sid->session_uid, 'status' => 'ok'];
    }

    // ------------------------------------------------------------------ RFQ (server side, after the request is saved)

    /** Called only AFTER the quote request is durably saved. Deduplicated by a privacy-safe hash of its reference. */
    public function recordRfq(QuoteRequest $quote, Request $request): bool
    {
        if ($this->excluded($request) !== null) {
            return false;                                   // transaction totals still come from the quote table itself
        }
        $sid = $this->activeSession((string) $request->cookie(self::COOKIE_SESSION, ''), CarbonImmutable::now('UTC'));
        if ($sid === null) {
            return false;
        }
        $now = CarbonImmutable::now('UTC');
        $uid = substr(hash('sha256', 'rfq|'.$quote->reference), 0, 32);
        $id = $this->insertEvent($sid->id, $uid, 'rfq_submit', $now, ['page_key' => 'route:quote.create', 'locale' => $quote->locale]);
        if ($id === null) {
            return false;                                   // already recorded: retry, reload or second click
        }
        foreach ($quote->items()->with('product')->get() as $item) {
            DB::table('analytics_event_items')->insert([
                'event_id' => $id, 'product_id' => $item->product_id ?: null,
                'category_id' => $item->product?->category_id, 'variety_id' => $item->product?->variety_id,
                'packaging_type_id' => $item->packaging_type_id ?: null,
            ]);
        }
        DB::table('analytics_sessions')->where('id', $sid->id)->update(['rfq_submits' => DB::raw('rfq_submits + 1'), 'last_seen_at' => $now]);

        return true;
    }

    // ------------------------------------------------------------------ internals

    private function uid(mixed $v): ?string
    {
        return is_string($v) && preg_match('/^[a-f0-9]{32}$/', $v) === 1 ? $v : null;
    }

    private function activeSession(string $uid, CarbonImmutable $now): ?object
    {
        if ($this->uid($uid) === null) {
            return null;
        }
        $cut = $now->subMinutes(max(5, (int) AnalyticsSettings::get('session_timeout_min')));

        return DB::table('analytics_sessions')->where('session_uid', $uid)->where('last_seen_at', '>=', $cut->toDateTimeString())->first();
    }

    private function newSession(Request $request, array $p, array $ctx, CarbonImmutable $now): object
    {
        $ua = UserAgent::parse($request->userAgent());
        $utm = (array) ($p['utm'] ?? []);
        $allowed = AnalyticsSettings::campaignFields();
        $ref = (string) ($p['ref'] ?? '');
        if (Sources::cleanHost($ref) === Sources::cleanHost((string) parse_url((string) config('app.url'), PHP_URL_HOST))) {
            $ref = '';   // our own domain (as configured) is internal navigation
        }
        $src = Sources::classify($ref, $allowed && in_array('utm_medium', $allowed, true) ? ($utm['utm_medium'] ?? null) : null, (string) Sources::cleanHost($request->getHost()));
        $bl = strtolower((string) ($p['bl'] ?? ''));
        $bid = is_string($p['bid'] ?? null) && preg_match('/^[a-f0-9]{32}$/', $p['bid']) === 1 ? substr(hash_hmac('sha256', $p['bid'], (string) config('app.key')), 0, 40) : null;
        $uid = bin2hex(random_bytes(16));

        $row = [
            'session_uid' => $uid, 'browser_hash' => $bid,
            'started_at' => $now->toDateTimeString(), 'last_seen_at' => $now->toDateTimeString(), 'local_day' => AnalyticsSettings::localDay($now),
            'country' => Geo::country($request), 'locale' => (string) $ctx['loc'],
            'browser_lang' => preg_match('/^[a-z]{2,3}(-[a-z]{2})?$/', $bl) === 1 ? $bl : null,
            'device' => $ua['device'], 'browser' => $ua['browser'], 'os' => $ua['os'],
            'source_type' => $src['type'], 'referrer_domain' => $src['domain'],
            'utm_source' => in_array('utm_source', $allowed, true) ? Sources::cleanCampaign($utm['utm_source'] ?? null) : null,
            'utm_medium' => in_array('utm_medium', $allowed, true) ? Sources::cleanCampaign($utm['utm_medium'] ?? null) : null,
            'utm_campaign' => in_array('utm_campaign', $allowed, true) ? Sources::cleanCampaign($utm['utm_campaign'] ?? null) : null,
            'landing_page' => $ctx['k'],
        ];
        $id = DB::table('analytics_sessions')->insertGetId($row);
        AnalyticsSettings::markCoverageStart();

        return (object) ($row + ['id' => $id]);
    }

    private function pageview(object $s, string $uid, array $ctx, CarbonImmutable $now): void
    {
        $last = DB::table('analytics_events')->where('session_id', $s->id)->where('type', 'pageview')->orderByDesc('id')->first();
        // The same page again within a few seconds is a reload / double render / tab restore, not a new view.
        if ($last && $last->page_key === $ctx['k'] && CarbonImmutable::parse($last->occurred_at, 'UTC')->diffInSeconds($now, true) < 10) {
            return;
        }
        $first = $last === null;
        $id = $this->insertEvent($s->id, $uid, 'pageview', $now, $this->pageFields($ctx) + ['is_entrance' => $first, 'is_exit' => true]);
        if ($id === null) {
            return;                                          // duplicate event uid (retry)
        }
        if ($last) {
            DB::table('analytics_events')->where('id', $last->id)->update(['is_exit' => false, 'next_page_key' => $ctx['k']]);
        }
        $upd = ['last_seen_at' => $now->toDateTimeString(), 'pageviews' => DB::raw('pageviews + 1'), 'exit_page' => $ctx['k']];
        if (($ctx['et'] ?? null) === 'product' || ($ctx['et'] ?? null) === 'pack') {
            $kind = $ctx['et'] === 'product' ? 'product_view' : 'pack_view';
            if ($this->insertEvent($s->id, substr(hash('sha256', $uid.'|'.$kind), 0, 32), $kind, $now, $this->pageFields($ctx)) && $kind === 'product_view') {
                $upd['product_views'] = DB::raw('product_views + 1');
            }
        }
        DB::table('analytics_sessions')->where('id', $s->id)->update($upd);
    }

    /** @return array<string, mixed> */
    private function pageFields(array $ctx): array
    {
        $type = $ctx['et'] ?? null;

        return [
            'page_key' => (string) $ctx['k'], 'locale' => (string) $ctx['loc'],
            'entity_type' => $type !== null ? substr((string) $type, 0, 10) : null,
            'entity_id' => isset($ctx['ei']) ? (int) $ctx['ei'] : null,
            'category_id' => isset($ctx['cat']) ? (int) $ctx['cat'] : null,
            'variety_id' => isset($ctx['var']) ? (int) $ctx['var'] : null,
        ];
    }

    private function event(object $s, string $uid, string $type, array $ctx, CarbonImmutable $now): void
    {
        if ($this->insertEvent($s->id, $uid, $type, $now, $this->pageFields($ctx)) === null) {
            return;
        }
        $col = ['rfq_click' => 'rfq_clicks', 'rfq_start' => 'rfq_starts'][$type] ?? null;
        DB::table('analytics_sessions')->where('id', $s->id)->update(['last_seen_at' => $now->toDateTimeString()] + ($col ? [$col => DB::raw($col.' + 1')] : []));
    }

    /**
     * Engaged time = time the page was visible, focused and not idle (decided by the browser script). The server credits only the
     * part of the claimed interval that is not already credited in this session, so two visible tabs never add overlapping time.
     */
    private function heartbeat(object $s, ?string $pvUid, int $ms, CarbonImmutable $now): void
    {
        $ms = max(0, min($ms, 20000));                       // a missing interval is capped, never extrapolated
        if ($ms === 0) {
            return;
        }
        $to = (int) round($now->getPreciseTimestamp(3));
        $fresh = DB::table('analytics_sessions')->where('id', $s->id)->first(['engaged_until']);
        $from = max($to - $ms, (int) ($fresh->engaged_until ?? 0));
        $credit = $to - $from;
        $upd = ['last_seen_at' => $now->toDateTimeString()];
        if ($credit > 0) {
            $upd['engaged_ms'] = DB::raw('COALESCE(engaged_ms, 0) + '.(int) $credit);
            $upd['engaged_until'] = $to;
        } else {
            $upd['engaged_ms'] = DB::raw('COALESCE(engaged_ms, 0)');   // a timing signal arrived: 0 means "measured, nothing new", not unknown
        }
        DB::table('analytics_sessions')->where('id', $s->id)->update($upd);
        if ($credit > 0 && $pvUid) {
            DB::table('analytics_events')->where('session_id', $s->id)->where('event_uid', $pvUid)->where('type', 'pageview')
                ->update(['engaged_ms' => DB::raw('COALESCE(engaged_ms, 0) + '.(int) $credit)]);
        }
    }

    /** @param array<string, mixed> $fields @return int|null new event id, or null when the uid already exists */
    private function insertEvent(int $sessionId, string $uid, string $type, CarbonImmutable $now, array $fields): ?int
    {
        $row = ['session_id' => $sessionId, 'event_uid' => $uid, 'occurred_at' => $now->toDateTimeString(), 'local_day' => AnalyticsSettings::localDay($now), 'type' => $type] + $fields;
        if (DB::table('analytics_events')->where('event_uid', $uid)->exists()) {
            return null;
        }
        try {
            return (int) DB::table('analytics_events')->insertGetId($row);
        } catch (\Illuminate\Database\UniqueConstraintViolationException) {
            return null;                                     // lost a race with an identical beacon
        }
    }
}
