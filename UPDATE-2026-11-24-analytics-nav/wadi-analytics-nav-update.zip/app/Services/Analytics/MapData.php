<?php

declare(strict_types=1);

namespace App\Services\Analytics;

/** Local world-map outlines (CC BY 4.0, @svg-maps/world). Nothing is fetched from the network. */
final class MapData
{
    /** @return array<string, string> ISO-2 => SVG path */
    public static function paths(): array
    {
        static $p = null;

        return $p ??= (array) json_decode((string) @file_get_contents(database_path('data/world-map.json')), true);
    }
}
