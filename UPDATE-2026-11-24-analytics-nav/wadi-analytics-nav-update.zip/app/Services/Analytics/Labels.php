<?php

declare(strict_types=1);

namespace App\Services\Analytics;

use App\Models\Category;
use App\Models\Document;
use App\Models\NewsPost;
use App\Models\Page;
use App\Models\PackagingType;
use App\Models\Product;
use App\Models\Variety;
use App\Support\Countries;

/** Names for stable ids, resolved in the viewer's language (a renamed slug or translation never splits a row). */
final class Labels
{
    /** @var array<string, string> */
    private static array $memo = [];

    public static function flush(): void
    {
        self::$memo = [];
    }

    public static function country(?string $code, ?string $locale = null): string
    {
        return $code === null || $code === '' || $code === 'unknown' ? __('analytics.unknown') : (Countries::name($code, $locale ?? app()->getLocale()) ?: $code);
    }

    public static function page(?string $key): string
    {
        if ($key === null || $key === '') {
            return __('analytics.unknown');
        }

        return self::$memo['p:'.$key] ??= self::resolvePage($key);
    }

    private static function resolvePage(string $key): string
    {
        [$type, $id] = array_pad(explode(':', $key, 2), 2, '');
        $l = app()->getLocale();
        try {
            $label = match ($type) {
                'product' => ($m = Product::query()->with('translations')->find((int) $id)) ? (string) ($m->t('name') ?: $m->slug) : null,
                'page' => ($m = Page::query()->with('translations')->find((int) $id)) ? (string) ($m->t('title') ?: $m->slug) : null,
                'category' => ($m = Category::query()->with('translations')->find((int) $id)) ? (string) ($m->t('name') ?: $m->slug) : null,
                'variety' => ($m = Variety::query()->find((int) $id)) ? (string) ($m->localized('name') ?: $m->slug) : null,
                'news' => ($m = NewsPost::query()->with('translations')->find((int) $id)) ? (string) ($m->t('title') ?: $m->slug) : null,
                'document' => ($m = Document::query()->with('translations')->find((int) $id)) ? (string) ($m->t('title') ?: $m->slug) : null,
                'pack' => self::pack($id),
                'team' => __('analytics.routes.team.show').' · '.$id,
                'route' => trans()->has('analytics.routes.'.$id) ? __('analytics.routes.'.$id) : \Illuminate\Support\Str::headline(str_replace(['.', '-'], ' ', $id)),
                default => null,
            };
        } catch (\Throwable) {
            $label = null;
        }

        return ($label !== null && $label !== '' ? $label : $key).($type === 'product' || $type === 'pack' ? '' : '');
    }

    public static function product(?int $id): string
    {
        return $id ? self::page('product:'.$id) : __('analytics.unknown');
    }

    public static function category(?int $id): string
    {
        return $id ? self::page('category:'.$id) : __('analytics.unknown');
    }

    public static function variety(?int $id): string
    {
        return $id ? self::page('variety:'.$id) : __('analytics.unknown');
    }

    public static function pack(string $slug): string
    {
        try {
            $p = app(\App\Packaging\PackagingCatalog::class)->pack($slug);

            return $p ? $p->name : $slug;
        } catch (\Throwable) {
            return $slug;
        }
    }

    public static function packagingType(?int $id): string
    {
        return $id ? (string) (PackagingType::query()->with('translations')->find($id)?->t('name') ?: '#'.$id) : __('analytics.unknown');
    }

    public static function locale(string $code): string
    {
        $c = (array) (config('wadi.locales')[$code] ?? []);

        return isset($c['native']) ? $c['native'].' ('.strtoupper($code).')' : strtoupper($code);
    }

    public static function enum(string $group, ?string $v): string
    {
        $v = $v === null || $v === '' ? 'unknown' : $v;

        return trans()->has('analytics.'.$group.'.'.$v) ? __('analytics.'.$group.'.'.$v) : ($v === 'unknown' ? __('analytics.unknown') : $v);
    }
}
