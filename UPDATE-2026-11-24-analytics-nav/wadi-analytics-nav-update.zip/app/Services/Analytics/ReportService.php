<?php

declare(strict_types=1);

namespace App\Services\Analytics;

use Carbon\CarbonImmutable;
use Illuminate\Database\Query\Builder;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

/**
 * Builds every report from ONE filtered session set, so charts, tables, CSV and PDF reconcile by construction.
 * A report is a plain array: key, title, columns[{k,label,type}], rows[], chart{type,...}|null, note, denominator.
 * Cell types: text · int · pct (value + n + of) · dur (ms, null = unknown) · country (code) · day.
 */
final class ReportService
{
    public function __construct(private readonly ReportFilters $f) {}

    public static function for(array $filters): self
    {
        return new self(ReportFilters::fromArray($filters));
    }

    public function filters(): ReportFilters
    {
        return $this->f;
    }

    /** Short-lived cache: reports are admin-only and never run on storefront requests. */
    public function cached(string $name, callable $build): array
    {
        $key = 'wr-an:'.$name.':'.md5(json_encode($this->f->toArray()).AnalyticsSettings::timezone().(string) DB::table('analytics_sessions')->max('last_seen_at'));

        return Cache::remember($key, 120, $build);
    }

    // ------------------------------------------------------------------ the filtered set

    private function sessions(?ReportFilters $f = null, string $alias = 's'): Builder
    {
        $f ??= $this->f;
        $q = DB::table('analytics_sessions as '.$alias)->whereBetween($alias.'.local_day', [$f->from, $f->to]);
        if ($f->country === 'unknown') {
            $q->whereNull($alias.'.country');
        } elseif ($f->country) {
            $q->where($alias.'.country', $f->country);
        }
        foreach (['locale' => 'locale', 'device' => 'device', 'source' => 'source_type'] as $prop => $col) {
            if ($f->{$prop}) {
                $q->where($alias.'.'.$col, $f->{$prop});
            }
        }
        $exists = function (callable $cond) use ($q, $alias): void {
            $q->whereExists(function ($sub) use ($cond, $alias): void {
                $sub->select(DB::raw(1))->from('analytics_events as fe')->whereColumn('fe.session_id', $alias.'.id');
                $cond($sub);
            });
        };
        if ($f->page) {
            $exists(fn ($s) => $s->where('fe.type', 'pageview')->where('fe.page_key', $f->page));
        }
        if ($f->product) {
            $exists(fn ($s) => $s->where('fe.type', 'product_view')->where('fe.entity_id', $f->product));
        }
        if ($f->category) {
            $exists(fn ($s) => $s->where('fe.type', 'product_view')->where('fe.category_id', $f->category));
        }
        if ($f->pack) {
            $exists(fn ($s) => $s->where('fe.type', 'pack_view')->where('fe.page_key', 'pack:'.$f->pack));
        }

        return $q;
    }

    private function events(?ReportFilters $f = null): Builder
    {
        return DB::table('analytics_events as e')->whereIn('e.session_id', $this->sessions($f)->select('s.id'));
    }

    // ------------------------------------------------------------------ shared aggregate

    private const AGG = 'COUNT(*) sessions, COUNT(DISTINCT s.browser_hash) browsers, SUM(CASE WHEN s.browser_hash IS NULL THEN 1 ELSE 0 END) nobid, SUM(s.pageviews) pv, SUM(s.product_views) prod, SUM(s.rfq_submits) rfq, SUM(CASE WHEN s.rfq_submits > 0 THEN 1 ELSE 0 END) conv, SUM(CASE WHEN s.engaged_ms IS NULL THEN 0 ELSE s.engaged_ms END) eng, SUM(CASE WHEN s.engaged_ms IS NULL THEN 0 ELSE 1 END) engn';

    /** @return array<string, array<string, mixed>> keyed by group value ('' = null) */
    private function grouped(string $expr, ?ReportFilters $f = null): array
    {
        $out = [];
        foreach ($this->sessions($f)->selectRaw($expr.' as k, '.self::AGG)->groupByRaw($expr)->orderByDesc('sessions')->get() as $r) {
            $out[(string) $r->k] = (array) $r;
        }

        return $out;
    }

    private function cell(array $r, string $col): mixed
    {
        return match ($col) {
            'sessions' => (int) $r['sessions'],
            'browsers' => (int) $r['browsers'],
            'pageviews' => (int) $r['pv'],
            'product_views' => (int) $r['prod'],
            'rfqs' => (int) $r['rfq'],
            'engaged' => (int) $r['engn'] > 0 ? (int) round($r['eng'] / $r['engn']) : null,
            'conversion' => ['v' => $r['sessions'] > 0 ? round(100 * $r['conv'] / $r['sessions'], 1) : null, 'n' => (int) $r['conv'], 'of' => (int) $r['sessions']],
        };
    }

    private function audienceColumns(string $first, string $firstType): array
    {
        return [
            ['k' => 'name', 'label' => $first, 'type' => $firstType],
            ['k' => 'sessions', 'label' => __('analytics.cols.sessions'), 'type' => 'int'],
            ['k' => 'browsers', 'label' => __('analytics.cols.browsers'), 'type' => 'int'],
            ['k' => 'engaged', 'label' => __('analytics.cols.engaged'), 'type' => 'dur'],
            ['k' => 'product_views', 'label' => __('analytics.cols.product_views'), 'type' => 'int'],
            ['k' => 'rfqs', 'label' => __('analytics.cols.rfqs'), 'type' => 'int'],
            ['k' => 'conversion', 'label' => __('analytics.cols.conversion'), 'type' => 'pct'],
        ];
    }

    /** @param array<string, array<string, mixed>> $g */
    private function audienceRows(array $g, callable $name): array
    {
        $rows = [];
        foreach ($g as $k => $r) {
            $rows[] = ['name' => $name($k), 'key' => $k] + array_combine(['sessions', 'browsers', 'engaged', 'product_views', 'rfqs', 'conversion'], array_map(fn ($c) => $this->cell($r, $c), ['sessions', 'browsers', 'engaged', 'product_views', 'rfqs', 'conversion']));
        }

        return $rows;
    }

    private function report(string $key, string $title, array $columns, array $rows, ?array $chart = null, string $note = '', ?string $denominator = null): array
    {
        return ['key' => $key, 'title' => $title, 'columns' => $columns, 'rows' => $rows, 'chart' => $chart, 'note' => $note, 'denominator' => $denominator, 'filters' => $this->f->toArray(), 'generated_at' => now()->toIso8601String(), 'timezone' => AnalyticsSettings::timezone()];
    }

    // ------------------------------------------------------------------ OVERVIEW

    /** @return array<string, mixed> */
    public function overview(string $grain = 'day'): array
    {
        $cur = $this->totals($this->f);
        $prev = $this->f->compare ? $this->totals($this->f->previous()) : null;
        $trend = $this->trend($grain, $this->f);
        $prevTrend = $this->f->compare ? $this->trend($grain, $this->f->previous()) : null;

        $from = CarbonImmutable::parse($this->f->from, AnalyticsSettings::timezone())->startOfDay()->utc();
        $to = CarbonImmutable::parse($this->f->to, AnalyticsSettings::timezone())->endOfDay()->utc();
        $txn = (int) DB::table('quote_requests')->whereBetween('submitted_at', [$from->toDateTimeString(), $to->toDateTimeString()])->whereNull('deleted_at')->count();

        $cards = [
            ['k' => 'sessions', 'label' => __('analytics.cols.sessions'), 'v' => $cur['sessions'], 'prev' => $prev['sessions'] ?? null, 'note' => __('analytics.def.sessions')],
            ['k' => 'browsers', 'label' => __('analytics.cols.browsers'), 'v' => $cur['browsers'], 'prev' => $prev['browsers'] ?? null, 'note' => __('analytics.def.browsers', ['n' => $cur['nobid']])],
            ['k' => 'pageviews', 'label' => __('analytics.cols.pageviews'), 'v' => $cur['pv'], 'prev' => $prev['pv'] ?? null, 'note' => ''],
            ['k' => 'product_views', 'label' => __('analytics.cols.product_views'), 'v' => $cur['prod'], 'prev' => $prev['prod'] ?? null, 'note' => __('analytics.def.product_views')],
            ['k' => 'engaged', 'label' => __('analytics.cols.engaged'), 'v' => $cur['engaged'], 'type' => 'dur', 'prev' => $prev['engaged'] ?? null, 'note' => __('analytics.def.engaged', ['n' => $cur['engn'], 'of' => $cur['sessions']])],
            ['k' => 'rfqs', 'label' => __('analytics.cols.rfqs_attributed'), 'v' => $cur['rfq'], 'prev' => $prev['rfq'] ?? null, 'note' => __('analytics.def.rfq_total', ['n' => $txn])],
            ['k' => 'conversion', 'label' => __('analytics.cols.conversion'), 'v' => $cur['conversion'], 'type' => 'pct', 'prev' => $prev['conversion'] ?? null, 'note' => __('analytics.def.conversion', ['n' => $cur['conv'], 'of' => $cur['sessions']])],
        ];

        return [
            'cards' => $cards, 'transactions' => $txn,
            'trend' => $this->report('trend', __('analytics.trend'), [
                ['k' => 'label', 'label' => __('analytics.cols.period'), 'type' => 'text'],
                ['k' => 'sessions', 'label' => __('analytics.cols.sessions'), 'type' => 'int'], ['k' => 'browsers', 'label' => __('analytics.cols.browsers'), 'type' => 'int'],
                ['k' => 'pageviews', 'label' => __('analytics.cols.pageviews'), 'type' => 'int'], ['k' => 'product_views', 'label' => __('analytics.cols.product_views'), 'type' => 'int'],
                ['k' => 'rfqs', 'label' => __('analytics.cols.rfqs_attributed'), 'type' => 'int'],
            ], $trend, ['type' => 'line', 'x' => 'label', 'series' => ['sessions', 'browsers', 'pageviews', 'product_views'], 'compare' => $prevTrend], '', __('analytics.def.trend', ['grain' => __('analytics.grain.'.$grain)])),
            'countries' => $this->countries(8),
            'products' => $this->products(8),
            'rfq_days' => $this->rfqByDay(),
            'coverage' => $this->coverage(),
        ];
    }

    /** @return array<string, mixed> */
    private function totals(ReportFilters $f): array
    {
        $r = (array) $this->sessions($f)->selectRaw(self::AGG)->first();
        $r = array_map(fn ($v) => $v === null ? 0 : (int) $v, $r);

        return $r + [
            'engaged' => $r['engn'] > 0 ? (int) round($r['eng'] / $r['engn']) : null,
            'conversion' => $r['sessions'] > 0 ? round(100 * $r['conv'] / $r['sessions'], 1) : null,
        ];
    }

    /** Unique browsers per bucket are counted over the WHOLE bucket (never summed from days). @return list<array<string, mixed>> */
    private function trend(string $grain, ReportFilters $f): array
    {
        $buckets = [];
        for ($d = CarbonImmutable::parse($f->from); $d->toDateString() <= $f->to; $d = $d->addDay()) {
            $start = match ($grain) { 'week' => $d->startOfWeek(), 'month' => $d->startOfMonth(), default => $d };
            $buckets[$start->toDateString()] ??= ['label' => $start->toDateString(), 'from' => max($start->toDateString(), $f->from), 'to' => $d->toDateString()];
            $buckets[$start->toDateString()]['to'] = $d->toDateString();
        }
        $rows = [];
        foreach ($buckets as $b) {
            $sub = clone $f;
            $sub->from = $b['from'];
            $sub->to = $b['to'];
            $r = (array) $this->sessions($sub)->selectRaw(self::AGG)->first();
            $rows[] = ['label' => $b['label'], 'sessions' => (int) $r['sessions'], 'browsers' => (int) $r['browsers'], 'pageviews' => (int) $r['pv'], 'product_views' => (int) $r['prod'], 'rfqs' => (int) $r['rfq']];
        }

        return $rows;
    }

    /** Live panel: aggregate only, no filters, no individual rows. @return array<string, mixed> */
    public function live(): array
    {
        $since = CarbonImmutable::now('UTC')->subMinutes(5)->toDateTimeString();
        $active = DB::table('analytics_sessions')->where('last_seen_at', '>=', $since);
        $countries = (clone $active)->selectRaw('country k, COUNT(*) n')->groupBy('country')->orderByDesc('n')->limit(8)->get()->map(fn ($r) => ['name' => Labels::country($r->k), 'code' => $r->k, 'n' => (int) $r->n])->all();
        $pages = DB::table('analytics_events')->where('type', 'pageview')->where('is_exit', true)->whereIn('session_id', (clone $active)->select('id'))->selectRaw('page_key k, COUNT(*) n')->groupBy('page_key')->orderByDesc('n')->limit(8)->get()->map(fn ($r) => ['name' => Labels::page($r->k), 'n' => (int) $r->n])->all();

        return ['active' => (clone $active)->count(), 'countries' => $countries, 'pages' => $pages, 'at' => now()->toIso8601String()];
    }

    /** @return array<string, mixed> */
    public function coverage(): array
    {
        $last = DB::table('analytics_sessions')->max('last_seen_at');

        return ['start' => AnalyticsSettings::coverageStart(), 'last_refresh' => $last ? CarbonImmutable::parse($last, 'UTC')->setTimezone(AnalyticsSettings::timezone())->toDateTimeString() : null, 'timezone' => AnalyticsSettings::timezone(), 'consent_required' => (bool) AnalyticsSettings::get('consent_required')];
    }

    // ------------------------------------------------------------------ AUDIENCE

    public function countries(?int $limit = null): array
    {
        $rows = $this->audienceRows($this->grouped("COALESCE(s.country, 'unknown')"), fn ($k) => $k);
        $rows = array_map(fn ($r) => ['code' => $r['key'] === 'unknown' ? null : $r['key'], 'name' => Labels::country($r['key'])] + $r, $rows);
        $total = array_sum(array_column($rows, 'sessions'));
        if ($limit) {
            $rows = array_slice($rows, 0, $limit);
        }
        $cols = $this->audienceColumns(__('analytics.cols.country'), 'country');
        array_splice($cols, 2, 0, [['k' => 'share', 'label' => __('analytics.cols.share'), 'type' => 'pct']]);
        foreach ($rows as &$r) {
            $r['share'] = ['v' => $total > 0 ? round(100 * $r['sessions'] / $total, 1) : null, 'n' => $r['sessions'], 'of' => $total];
        }

        return $this->report('countries', __('analytics.reports.countries'), $cols, $rows, ['type' => 'map', 'key' => 'code', 'value' => 'sessions'], __('analytics.def.country'), __('analytics.def.share', ['of' => $total]));
    }

    public function languages(): array
    {
        $rows = $this->audienceRows($this->grouped('s.locale'), fn ($k) => Labels::locale($k));

        return $this->report('languages', __('analytics.reports.languages'), $this->audienceColumns(__('analytics.cols.site_language'), 'text'), $rows, ['type' => 'bar', 'label' => 'name', 'value' => 'sessions'], __('analytics.def.site_language'));
    }

    public function browserLanguages(): array
    {
        $rows = $this->audienceRows($this->grouped("COALESCE(s.browser_lang, 'unknown')"), fn ($k) => $k === 'unknown' ? __('analytics.unknown') : $k);

        return $this->report('browser_languages', __('analytics.reports.browser_languages'), $this->audienceColumns(__('analytics.cols.browser_language'), 'text'), $rows, ['type' => 'bar', 'label' => 'name', 'value' => 'sessions'], __('analytics.def.browser_language'));
    }

    public function browsers(): array
    {
        return $this->simple('browsers', 'browser', 's.browser', fn ($k) => $k === 'Other' ? __('analytics.other') : $k);
    }

    public function systems(): array
    {
        return $this->simple('systems', 'os', 's.os', fn ($k) => $k === 'Other' ? __('analytics.other') : $k);
    }

    public function devices(): array
    {
        return $this->simple('devices', 'device', 's.device', fn ($k) => Labels::enum('device', $k));
    }

    private function simple(string $key, string $colLabel, string $expr, callable $name): array
    {
        $rows = $this->audienceRows($this->grouped($expr), $name);

        return $this->report($key, __('analytics.reports.'.$key), $this->audienceColumns(__('analytics.cols.'.$colLabel), 'text'), $rows, ['type' => 'bar', 'label' => 'name', 'value' => 'sessions'], __('analytics.def.aggregate_only'));
    }

    // ------------------------------------------------------------------ ACQUISITION

    public function sources(): array
    {
        $rows = $this->audienceRows($this->grouped('s.source_type'), fn ($k) => Labels::enum('source', $k));

        return $this->report('sources', __('analytics.reports.sources'), $this->audienceColumns(__('analytics.cols.source'), 'text'), $rows, ['type' => 'bar', 'label' => 'name', 'value' => 'sessions'], __('analytics.def.attribution'));
    }

    public function referrers(): array
    {
        $g = [];
        foreach ($this->grouped("COALESCE(s.referrer_domain, '')") as $k => $r) {
            if ($k !== '') {
                $g[$k] = $r;
            }
        }

        return $this->report('referrers', __('analytics.reports.referrers'), $this->audienceColumns(__('analytics.cols.referrer'), 'text'), $this->audienceRows($g, fn ($k) => $k), ['type' => 'bar', 'label' => 'name', 'value' => 'sessions'], __('analytics.def.referrer_note'));
    }

    public function campaigns(): array
    {
        $g = [];
        foreach ($this->grouped("COALESCE(s.utm_campaign, '')") as $k => $r) {
            if ($k !== '') {
                $g[$k] = $r;
            }
        }

        return $this->report('campaigns', __('analytics.reports.campaigns'), $this->audienceColumns(__('analytics.cols.campaign'), 'text'), $this->audienceRows($g, fn ($k) => $k), null, __('analytics.def.campaign_note', ['fields' => implode(', ', AnalyticsSettings::campaignFields())]));
    }

    // ------------------------------------------------------------------ PAGES

    public function pages(bool $byLanguage = false): array
    {
        $q = $this->events()->where('e.type', 'pageview')->selectRaw('e.page_key k'.($byLanguage ? ', e.locale loc' : '').', COUNT(*) views, SUM(CASE WHEN e.is_entrance THEN 1 ELSE 0 END) entr, SUM(CASE WHEN e.is_exit THEN 1 ELSE 0 END) exits, COALESCE(SUM(e.engaged_ms),0) eng, SUM(CASE WHEN e.engaged_ms IS NULL THEN 0 ELSE 1 END) engn')
            ->groupBy('e.page_key')->when($byLanguage, fn ($q) => $q->groupBy('e.locale'))->orderByDesc('views')->limit(200);
        $next = [];
        foreach ($this->events()->where('e.type', 'pageview')->whereNotNull('e.next_page_key')->selectRaw('e.page_key k, e.next_page_key nk, COUNT(*) n')->groupBy('e.page_key', 'e.next_page_key')->orderByDesc('n')->get() as $r) {
            if (count($next[$r->k] ?? []) < 3) {
                $next[$r->k][] = Labels::page($r->nk).' ('.$r->n.')';
            }
        }
        $rows = [];
        foreach ($q->get() as $r) {
            $rows[] = ['name' => Labels::page($r->k), 'key' => $r->k, 'locale' => $byLanguage ? $r->loc : null, 'views' => (int) $r->views, 'entrances' => (int) $r->entr, 'exits' => (int) $r->exits,
                'engaged' => (int) $r->engn > 0 ? (int) round($r->eng / $r->engn) : null, 'next' => implode(' · ', $next[$r->k] ?? [])];
        }
        $cols = [['k' => 'name', 'label' => __('analytics.cols.page'), 'type' => 'text']];
        if ($byLanguage) {
            $cols[] = ['k' => 'locale', 'label' => __('analytics.cols.site_language'), 'type' => 'text'];
        }
        $cols = array_merge($cols, [
            ['k' => 'views', 'label' => __('analytics.cols.views'), 'type' => 'int'], ['k' => 'entrances', 'label' => __('analytics.cols.entrances'), 'type' => 'int'], ['k' => 'exits', 'label' => __('analytics.cols.exits'), 'type' => 'int'],
            ['k' => 'engaged', 'label' => __('analytics.cols.engaged'), 'type' => 'dur'], ['k' => 'next', 'label' => __('analytics.cols.next'), 'type' => 'text'],
        ]);

        return $this->report('pages', __('analytics.reports.pages'), $cols, $rows, ['type' => 'bar', 'label' => 'name', 'value' => 'views'], __('analytics.def.pages'), __('analytics.def.pages_denominator'));
    }

    // ------------------------------------------------------------------ PRODUCTS & PACKAGING

    public function products(?int $limit = null): array
    {
        $views = $this->events()->where('e.type', 'product_view')->selectRaw('e.entity_id k, COUNT(*) views, COUNT(DISTINCT e.session_id) sess')->groupBy('e.entity_id')->orderByDesc('views')->get()->keyBy('k');
        $clicks = $this->events()->where('e.type', 'rfq_click')->whereNotNull('e.entity_id')->selectRaw('e.entity_id k, COUNT(*) n')->groupBy('e.entity_id')->pluck('n', 'k');
        $subs = DB::table('analytics_event_items as i')->join('analytics_events as ev', 'ev.id', '=', 'i.event_id')->whereIn('ev.session_id', $this->sessions()->select('s.id'))->whereNotNull('i.product_id')->selectRaw('i.product_id k, COUNT(DISTINCT ev.id) n')->groupBy('i.product_id')->pluck('n', 'k');
        $ids = collect($views->keys())->merge($subs->keys())->unique();
        $rows = [];
        foreach ($ids as $id) {
            $rows[] = ['name' => Labels::product((int) $id), 'key' => (string) $id, 'views' => (int) ($views[$id]->views ?? 0), 'sessions' => (int) ($views[$id]->sess ?? 0), 'rfq_clicks' => (int) ($clicks[$id] ?? 0), 'rfqs' => (int) ($subs[$id] ?? 0)];
        }
        usort($rows, fn ($a, $b) => [$b['views'], $b['rfqs']] <=> [$a['views'], $a['rfqs']]);
        if ($limit) {
            $rows = array_slice($rows, 0, $limit);
        }

        return $this->report('products', __('analytics.reports.products'), [
            ['k' => 'name', 'label' => __('analytics.cols.product'), 'type' => 'text'], ['k' => 'views', 'label' => __('analytics.cols.detail_views'), 'type' => 'int'], ['k' => 'sessions', 'label' => __('analytics.cols.sessions'), 'type' => 'int'],
            ['k' => 'rfq_clicks', 'label' => __('analytics.cols.rfq_clicks'), 'type' => 'int'], ['k' => 'rfqs', 'label' => __('analytics.cols.rfq_lines'), 'type' => 'int'],
        ], $rows, ['type' => 'bar', 'label' => 'name', 'value' => 'views'], __('analytics.def.products'), __('analytics.def.products_denominator'));
    }

    public function categories(): array
    {
        return $this->entityViews('categories', 'e.category_id', 'category', fn ($id) => Labels::category((int) $id), 'category_id');
    }

    public function varieties(): array
    {
        return $this->entityViews('varieties', 'e.variety_id', 'variety', fn ($id) => Labels::variety((int) $id), 'variety_id');
    }

    private function entityViews(string $key, string $col, string $label, callable $name, string $itemCol): array
    {
        $views = $this->events()->where('e.type', 'product_view')->whereNotNull($col)->selectRaw($col.' k, COUNT(*) views, COUNT(DISTINCT e.session_id) sess')->groupBy($col)->orderByDesc('views')->get();
        $subs = DB::table('analytics_event_items as i')->join('analytics_events as ev', 'ev.id', '=', 'i.event_id')->whereIn('ev.session_id', $this->sessions()->select('s.id'))->whereNotNull('i.'.$itemCol)->selectRaw('i.'.$itemCol.' k, COUNT(DISTINCT ev.id) n')->groupBy('i.'.$itemCol)->pluck('n', 'k');
        $rows = $views->map(fn ($r) => ['name' => $name($r->k), 'key' => (string) $r->k, 'views' => (int) $r->views, 'sessions' => (int) $r->sess, 'rfqs' => (int) ($subs[$r->k] ?? 0)])->all();

        return $this->report($key, __('analytics.reports.'.$key), [
            ['k' => 'name', 'label' => __('analytics.cols.'.$label), 'type' => 'text'], ['k' => 'views', 'label' => __('analytics.cols.detail_views'), 'type' => 'int'],
            ['k' => 'sessions', 'label' => __('analytics.cols.sessions'), 'type' => 'int'], ['k' => 'rfqs', 'label' => __('analytics.cols.rfq_lines'), 'type' => 'int'],
        ], $rows, ['type' => 'bar', 'label' => 'name', 'value' => 'views'], __('analytics.def.products'), __('analytics.def.products_denominator'));
    }

    public function packs(): array
    {
        $views = $this->events()->where('e.type', 'pack_view')->selectRaw('e.page_key k, COUNT(*) views, COUNT(DISTINCT e.session_id) sess')->groupBy('e.page_key')->orderByDesc('views')->get();
        $rows = $views->map(fn ($r) => ['name' => Labels::page($r->k), 'key' => (string) $r->k, 'views' => (int) $r->views, 'sessions' => (int) $r->sess])->all();

        return $this->report('packs', __('analytics.reports.packs'), [
            ['k' => 'name', 'label' => __('analytics.cols.pack'), 'type' => 'text'], ['k' => 'views', 'label' => __('analytics.cols.detail_views'), 'type' => 'int'], ['k' => 'sessions', 'label' => __('analytics.cols.sessions'), 'type' => 'int'],
        ], $rows, ['type' => 'bar', 'label' => 'name', 'value' => 'views'], __('analytics.def.packs'));
    }

    public function requestedPacks(): array
    {
        $rows = DB::table('analytics_event_items as i')->join('analytics_events as ev', 'ev.id', '=', 'i.event_id')->whereIn('ev.session_id', $this->sessions()->select('s.id'))->whereNotNull('i.packaging_type_id')
            ->selectRaw('i.packaging_type_id k, COUNT(DISTINCT ev.id) n')->groupBy('i.packaging_type_id')->orderByDesc('n')->get()->map(fn ($r) => ['name' => Labels::packagingType((int) $r->k), 'key' => (string) $r->k, 'rfqs' => (int) $r->n])->all();

        return $this->report('requested_packs', __('analytics.reports.requested_packs'), [['k' => 'name', 'label' => __('analytics.cols.pack'), 'type' => 'text'], ['k' => 'rfqs', 'label' => __('analytics.cols.rfq_lines'), 'type' => 'int']], $rows, ['type' => 'bar', 'label' => 'name', 'value' => 'rfqs'], __('analytics.def.requested_packs'));
    }

    // ------------------------------------------------------------------ FUNNEL / RFQ

    public function funnel(): array
    {
        $base = fn () => $this->sessions();
        $n = [
            'product' => (clone $base())->where('s.product_views', '>', 0)->count(),
            'click' => (clone $base())->where('s.product_views', '>', 0)->where('s.rfq_clicks', '>', 0)->count(),
            'start' => (clone $base())->where('s.product_views', '>', 0)->where('s.rfq_clicks', '>', 0)->where('s.rfq_starts', '>', 0)->count(),
            'saved' => (clone $base())->where('s.product_views', '>', 0)->where('s.rfq_clicks', '>', 0)->where('s.rfq_starts', '>', 0)->where('s.rfq_submits', '>', 0)->count(),
        ];
        $total = (clone $base())->count();
        $steps = [['k' => 'product', 'label' => __('analytics.funnel.product')], ['k' => 'click', 'label' => __('analytics.funnel.click')], ['k' => 'start', 'label' => __('analytics.funnel.start')], ['k' => 'saved', 'label' => __('analytics.funnel.saved')]];
        $rows = [];
        $prev = null;
        foreach ($steps as $s) {
            $v = $n[$s['k']];
            $rows[] = ['name' => $s['label'], 'sessions' => $v, 'step' => ['v' => $prev ? ($prev > 0 ? round(100 * $v / $prev, 1) : null) : ($total > 0 ? round(100 * $v / $total, 1) : null), 'n' => $v, 'of' => $prev ?? $total]];
            $prev = $v;
        }

        return $this->report('funnel', __('analytics.reports.funnel'), [
            ['k' => 'name', 'label' => __('analytics.cols.step'), 'type' => 'text'], ['k' => 'sessions', 'label' => __('analytics.cols.sessions'), 'type' => 'int'], ['k' => 'step', 'label' => __('analytics.cols.step_rate'), 'type' => 'pct'],
        ], $rows, ['type' => 'funnel', 'label' => 'name', 'value' => 'sessions'], __('analytics.def.funnel'), __('analytics.def.funnel_denominator', ['of' => $total]));
    }

    /** All successful requests, however they started — separate from the product funnel. */
    public function rfqSummary(): array
    {
        $from = CarbonImmutable::parse($this->f->from, AnalyticsSettings::timezone())->startOfDay()->utc()->toDateTimeString();
        $to = CarbonImmutable::parse($this->f->to, AnalyticsSettings::timezone())->endOfDay()->utc()->toDateTimeString();
        $txn = (int) DB::table('quote_requests')->whereBetween('submitted_at', [$from, $to])->whereNull('deleted_at')->count();
        $att = (int) $this->events()->where('e.type', 'rfq_submit')->count();
        $viaProduct = (int) $this->events()->where('e.type', 'rfq_submit')->whereIn('e.session_id', $this->sessions()->where('s.product_views', '>', 0)->select('s.id'))->count();
        $multi = (int) DB::table('analytics_event_items as i')->join('analytics_events as ev', 'ev.id', '=', 'i.event_id')->whereIn('ev.session_id', $this->sessions()->select('s.id'))->groupBy('ev.id')->havingRaw('COUNT(*) > 1')->selectRaw('ev.id')->get()->count();
        $sec = $this->events()->whereIn('e.type', ['brochure', 'mail_click', 'whatsapp_click'])->selectRaw('e.type k, COUNT(*) n')->groupBy('e.type')->pluck('n', 'k');
        $rows = [
            ['name' => __('analytics.rfq.transactions'), 'value' => $txn, 'note' => __('analytics.rfq.transactions_note')],
            ['name' => __('analytics.rfq.attributed'), 'value' => $att, 'note' => __('analytics.rfq.attributed_note')],
            ['name' => __('analytics.rfq.after_product'), 'value' => $viaProduct, 'note' => __('analytics.rfq.after_product_note')],
            ['name' => __('analytics.rfq.direct'), 'value' => $att - $viaProduct, 'note' => __('analytics.rfq.direct_note')],
            ['name' => __('analytics.rfq.multi'), 'value' => $multi, 'note' => __('analytics.rfq.multi_note')],
            ['name' => __('analytics.rfq.brochure'), 'value' => (int) ($sec['brochure'] ?? 0), 'note' => __('analytics.rfq.secondary_note')],
            ['name' => __('analytics.rfq.mail'), 'value' => (int) ($sec['mail_click'] ?? 0), 'note' => __('analytics.rfq.secondary_note')],
            ['name' => __('analytics.rfq.whatsapp'), 'value' => (int) ($sec['whatsapp_click'] ?? 0), 'note' => __('analytics.rfq.secondary_note')],
        ];

        return $this->report('rfq', __('analytics.reports.rfq'), [['k' => 'name', 'label' => __('analytics.cols.measure'), 'type' => 'text'], ['k' => 'value', 'label' => __('analytics.cols.count'), 'type' => 'int'], ['k' => 'note', 'label' => __('analytics.cols.explanation'), 'type' => 'text']], $rows, null, __('analytics.def.rfq'));
    }

    public function rfqByDay(): array
    {
        $rows = $this->events()->where('e.type', 'rfq_submit')->selectRaw('e.local_day d, COUNT(*) n')->groupBy('e.local_day')->orderBy('e.local_day')->get()->map(fn ($r) => ['name' => $r->d, 'value' => (int) $r->n])->all();

        return $this->report('rfq_days', __('analytics.reports.rfq_days'), [['k' => 'name', 'label' => __('analytics.cols.day'), 'type' => 'text'], ['k' => 'value', 'label' => __('analytics.cols.rfqs_attributed'), 'type' => 'int']], $rows, ['type' => 'bar', 'label' => 'name', 'value' => 'value'], __('analytics.def.rfq_days'));
    }

    // ------------------------------------------------------------------ AGE (never inferred)

    public function age(): array
    {
        $min = max(1, (int) AnalyticsSettings::get('min_cohort'));
        $bands = DB::table('analytics_age_bands')->where('period_end', '>=', $this->f->from)->where('period_start', '<=', $this->f->to)->get();
        $rows = [];
        $source = null;
        $coverage = null;
        foreach ($bands->groupBy('band') as $band => $g) {
            $sum = (int) $g->sum('sessions');
            $source = $g->first()->source;
            $coverage = $g->first()->coverage_pct;
            $rows[] = ['name' => $band, 'sessions' => $sum >= $min ? $sum : null, 'status' => $sum >= $min ? __('analytics.age.reported') : __('analytics.age.withheld', ['n' => $min])];
        }
        $note = $bands->isEmpty() ? __('analytics.age.unavailable') : __('analytics.age.source', ['source' => $source, 'coverage' => $coverage !== null ? $coverage.'%' : __('analytics.unknown')]);

        return $this->report('age', __('analytics.reports.age'), [['k' => 'name', 'label' => __('analytics.cols.age_band'), 'type' => 'text'], ['k' => 'sessions', 'label' => __('analytics.cols.sessions'), 'type' => 'int'], ['k' => 'status', 'label' => __('analytics.cols.status'), 'type' => 'text']],
            $rows, $rows ? ['type' => 'bar', 'label' => 'name', 'value' => 'sessions'] : null, $note, __('analytics.age.rule'));
    }

    /** Everything the PDF / print view shows. @return array<int, array<string, mixed>> */
    public function summary(): array
    {
        $o = $this->overview('day');

        return [$o['trend'], $o['countries'], $o['products'], $this->funnel(), $this->rfqSummary(), $this->sources(), $this->devices(), $this->pages()];
    }
}
