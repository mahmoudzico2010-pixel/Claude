<?php

declare(strict_types=1);

namespace App\Services\Analytics;

use Barryvdh\DomPDF\Facade\Pdf;

/** CSV and PDF are produced from the same report arrays the screen tables use, so their numbers cannot differ. */
final class ReportExporter
{
    /** Display text of one cell (the screen table and the PDF use this too). */
    public static function text(array $col, mixed $v): string
    {
        return match ($col['type']) {
            'int' => $v === null ? '—' : number_format((int) $v),
            'dur' => $v === null ? __('analytics.unknown') : self::dur((int) $v),
            'pct' => is_array($v) ? ($v['v'] === null ? '—' : $v['v'].'% ('.number_format((int) $v['n']).' / '.number_format((int) $v['of']).')') : '—',
            default => $v === null ? '—' : (string) $v,
        };
    }

    public static function dur(int $ms): string
    {
        $s = (int) round($ms / 1000);

        return intdiv($s, 60).':'.str_pad((string) ($s % 60), 2, '0', STR_PAD_LEFT);
    }

    /** UTF-8 with BOM (Excel-friendly). Numbers stay numbers; each percentage is three columns: %, count, base. @param list<array<string, mixed>> $reports */
    public static function csv(array $reports, ReportFilters $f): string
    {
        $fh = fopen('php://temp', 'r+');
        fwrite($fh, "\xEF\xBB\xBF");
        $put = fn (array $row) => fputcsv($fh, $row, ',', '"', '\\', "\r\n");
        $put([config('app.name').' — '.__('analytics.nav.overview')]);
        $put([__('analytics.ui.range'), implode(' | ', $f->describe())]);
        $put([__('analytics.ui.tz'), AnalyticsSettings::timezone()]);
        $put([__('analytics.ui.refreshed'), now()->setTimezone(AnalyticsSettings::timezone())->toDateTimeString()]);
        foreach ($reports as $r) {
            $put([]);
            $put([$r['title']]);
            if ($r['denominator']) {
                $put([$r['denominator']]);
            }
            $head = [];
            foreach ($r['columns'] as $c) {
                $head[] = $c['label'].($c['type'] === 'dur' ? ' (s)' : '');
                if ($c['type'] === 'pct') {
                    array_push($head, $c['label'].' — '.__('analytics.cols.count'), $c['label'].' — base');
                }
                if ($c['type'] === 'country') {
                    $head[] = $c['label'].' — ISO';
                }
            }
            $put($head);
            foreach ($r['rows'] as $row) {
                $line = [];
                foreach ($r['columns'] as $c) {
                    $v = $row[$c['k']] ?? null;
                    switch ($c['type']) {
                        case 'pct':
                            array_push($line, is_array($v) ? ($v['v'] ?? '') : '', is_array($v) ? $v['n'] : '', is_array($v) ? $v['of'] : '');
                            break;
                        case 'dur':
                            $line[] = $v === null ? '' : round($v / 1000);
                            break;
                        case 'country':
                            array_push($line, $v, $row['code'] ?? ($row['key'] ?? ''));
                            break;
                        default:
                            $line[] = $v ?? '';
                    }
                }
                $put($line);
            }
        }
        rewind($fh);

        return (string) stream_get_contents($fh);
    }

    /** @param list<array<string, mixed>> $reports */
    public static function pdf(array $reports, ReportFilters $f, string $locale): \Barryvdh\DomPDF\PDF
    {
        $prev = app()->getLocale();
        app()->setLocale($locale);
        try {
            return Pdf::loadView('analytics.pdf', [
                'reports' => $reports, 'filters' => $f, 'rtl' => in_array($locale, ['ar', 'ur'], true), 'locale' => $locale,
                'coverage' => (new ReportService($f))->coverage(),
            ])->setPaper('a4')->setOptions(['isRemoteEnabled' => false, 'isHtml5ParserEnabled' => true, 'defaultFont' => 'DejaVu Sans']);
        } finally {
            app()->setLocale($prev);
        }
    }
}
