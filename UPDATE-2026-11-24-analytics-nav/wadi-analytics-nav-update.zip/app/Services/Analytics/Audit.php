<?php

declare(strict_types=1);

namespace App\Services\Analytics;

use App\Models\AuditLog;
use Illuminate\Support\Facades\Auth;

/** Audit trail for analytics exports and settings changes (who, what, with which filters). Never stores report contents. */
final class Audit
{
    /** @param array<string, mixed> $old @param array<string, mixed> $new */
    public static function log(string $action, string $label, array $old = [], array $new = []): void
    {
        try {
            $u = Auth::user();
            AuditLog::create([
                'user_id' => $u?->getKey(), 'user_name' => $u?->name, 'action' => $action, 'auditable_type' => 'analytics', 'auditable_id' => 0,
                'auditable_label' => $label, 'old_values' => $old ?: null, 'new_values' => $new ?: null,
                'ip_address' => request()->ip(), 'user_agent' => substr((string) request()->userAgent(), 0, 500) ?: null, 'created_at' => now(),
            ]);
        } catch (\Throwable $e) {
            report($e);
        }
    }
}
