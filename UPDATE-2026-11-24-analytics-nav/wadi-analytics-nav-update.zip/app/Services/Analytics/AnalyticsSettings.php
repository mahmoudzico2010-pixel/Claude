<?php

declare(strict_types=1);

namespace App\Services\Analytics;

use App\Models\SiteSetting;
use Carbon\CarbonImmutable;
use DateTimeZone;

/** Tracking settings (System Settings → Visitor analytics). Stored in site_settings under the `analytics.` prefix. */
final class AnalyticsSettings
{
    public const DEFAULTS = [
        'enabled' => true,
        'consent_required' => true,
        'session_timeout_min' => 30,
        'events_days' => 90,
        'sessions_days' => 400,
        'min_cohort' => 5,
        'timezone' => 'Africa/Cairo',
        'geo_headers' => 'CF-IPCountry,CloudFront-Viewer-Country,X-Vercel-IP-Country,X-Country-Code',
        'campaign_fields' => 'utm_source,utm_medium,utm_campaign',
    ];

    public static function get(string $key): mixed
    {
        $v = SiteSetting::get('analytics.'.$key, null);
        if ($v === null || $v === '') {
            return self::DEFAULTS[$key] ?? null;
        }
        $default = self::DEFAULTS[$key] ?? null;

        return is_bool($default) ? filter_var($v, FILTER_VALIDATE_BOOLEAN) : (is_int($default) ? (int) $v : $v);
    }

    public static function set(string $key, mixed $value): void
    {
        SiteSetting::set('analytics.'.$key, is_bool($value) ? ($value ? '1' : '0') : (string) $value, SiteSetting::TYPE_STRING, false);
    }

    public static function enabled(): bool
    {
        return (bool) self::get('enabled');
    }

    public static function timezone(): string
    {
        $tz = (string) self::get('timezone');

        return in_array($tz, DateTimeZone::listIdentifiers(), true) ? $tz : 'Africa/Cairo';
    }

    /** The reporting-timezone calendar day of a UTC instant (DST-correct). */
    public static function localDay(?CarbonImmutable $utc = null): string
    {
        return ($utc ?? CarbonImmutable::now('UTC'))->setTimezone(self::timezone())->toDateString();
    }

    /** UTC start (inclusive) of a reporting-timezone day. */
    public static function dayStartUtc(string $day): CarbonImmutable
    {
        return CarbonImmutable::parse($day, self::timezone())->startOfDay()->utc();
    }

    /** @return list<string> */
    public static function geoHeaders(): array
    {
        return array_values(array_filter(array_map('trim', explode(',', (string) self::get('geo_headers')))));
    }

    /** @return list<string> */
    public static function campaignFields(): array
    {
        return array_values(array_intersect(['utm_source', 'utm_medium', 'utm_campaign'], array_map('trim', explode(',', (string) self::get('campaign_fields')))));
    }

    /** First instant a measurement was stored: "measurement coverage starts on…". Never back-dated. */
    public static function coverageStart(): ?string
    {
        $v = SiteSetting::get('analytics.coverage_start', null);

        return is_string($v) && $v !== '' ? $v : null;
    }

    public static function markCoverageStart(): void
    {
        if (self::coverageStart() === null) {
            SiteSetting::set('analytics.coverage_start', CarbonImmutable::now('UTC')->toIso8601String(), SiteSetting::TYPE_STRING, false);
        }
    }

    public static function lastAggregated(): ?string
    {
        $v = SiteSetting::get('analytics.last_aggregated_day', null);

        return is_string($v) && $v !== '' ? $v : null;
    }
}
