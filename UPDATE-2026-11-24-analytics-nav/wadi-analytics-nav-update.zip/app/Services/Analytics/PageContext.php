<?php

declare(strict_types=1);

namespace App\Services\Analytics;

use App\Models\Document;
use App\Models\NewsPost;
use App\Models\Page;
use App\Models\Product;
use Illuminate\Http\Request;

/**
 * Stable identity of a storefront page, independent of language and slug: `product:12`, `page:3`, `route:home`, `pack:glass-jar-370`.
 * The server hands each rendered page a SIGNED context; the beacon can only report contexts the server really rendered, so
 * arbitrary page keys cannot be injected. The signature carries no visitor information, so cached pages stay valid.
 */
final class PageContext
{
    /** @return array{k: string, loc: string, et?: string, ei?: int, cat?: int, var?: int}|null */
    public static function forRequest(Request $request): ?array
    {
        $route = $request->route();
        $name = $route?->getName();
        if (! $name) {
            return null;
        }
        $loc = app()->getLocale();
        $p = fn (string $k) => $route->parameter($k);

        $ctx = match (true) {
            $name === 'products.show' => self::product($p('product')),
            $name === 'products.category' => self::category((string) $p('category')),
            $name === 'products.variety' => self::variety((string) $p('variety')),
            $name === 'packaging.show' => ['k' => 'pack:'.mb_substr((string) $p('slug'), 0, 60), 'et' => 'pack'],
            $name === 'news.show' => self::byKey(NewsPost::class, 'slug', (string) $p('post'), 'news'),
            $name === 'documents.show' => self::byKey(Document::class, 'slug', (string) $p('slug'), 'document'),
            $name === 'team.show' => ['k' => 'team:'.mb_substr((string) $p('slug'), 0, 60)],
            $name === 'page.show' => self::page(Page::query()->where('slug', (string) $p('page'))->first()),
            in_array($name, ['about', 'quality', 'export', 'private-label', 'privacy', 'terms'], true) => self::page(Page::query()->where('key', $name === 'private-label' ? 'private-label' : $name)->first()) ?? ['k' => 'route:'.$name],
            default => ['k' => 'route:'.$name],
        };

        return $ctx === null ? null : ['loc' => $loc] + $ctx;
    }

    private static function product(mixed $product): ?array
    {
        if (! $product instanceof Product) {
            return null;
        }

        return ['k' => 'product:'.$product->id, 'et' => 'product', 'ei' => (int) $product->id, 'cat' => (int) $product->category_id ?: null, 'var' => (int) $product->variety_id ?: null];
    }

    private static function category(string $slug): ?array
    {
        $id = \App\Models\Category::query()->where('slug', $slug)->value('id');

        return $id ? ['k' => 'category:'.$id, 'et' => 'category', 'ei' => (int) $id] : ['k' => 'route:products.category'];
    }

    private static function variety(string $slug): ?array
    {
        $id = \App\Models\Variety::query()->where('slug', $slug)->value('id');

        return $id ? ['k' => 'variety:'.$id, 'et' => 'variety', 'ei' => (int) $id] : ['k' => 'route:products.variety'];
    }

    private static function page(?Page $page): ?array
    {
        return $page ? ['k' => 'page:'.$page->id, 'et' => 'page', 'ei' => (int) $page->id] : null;
    }

    private static function byKey(string $model, string $col, string $value, string $prefix): array
    {
        $id = $model::query()->where($col, $value)->value('id');

        return $id ? ['k' => $prefix.':'.$id, 'et' => $prefix, 'ei' => (int) $id] : ['k' => 'route:'.$prefix];
    }

    // ----------------------------------------------------------------- signing

    /** @param array<string, mixed> $ctx */
    public static function sign(array $ctx): string
    {
        return hash_hmac('sha256', self::canonical($ctx), (string) config('app.key'));
    }

    /** @param array<string, mixed> $ctx */
    public static function verify(array $ctx, string $sig): bool
    {
        return hash_equals(self::sign($ctx), $sig);
    }

    /** @param array<string, mixed> $ctx */
    private static function canonical(array $ctx): string
    {
        $keep = array_intersect_key($ctx, array_flip(['k', 'loc', 'et', 'ei', 'cat', 'var']));
        ksort($keep);

        return json_encode($keep, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }

    /** The attribute-ready JSON for the <meta> tag. @return array<string, mixed>|null */
    public static function signed(Request $request): ?array
    {
        $ctx = self::forRequest($request);

        return $ctx === null ? null : $ctx + ['sig' => self::sign($ctx)];
    }
}
