<?php

declare(strict_types=1);

namespace App\Services\Analytics;

/**
 * Acquisition attribution rule (one session = one source, decided at the FIRST page of the session):
 *  1. utm_medium cpc / ppc / paid* / display / cpm  → paid
 *  2. utm_medium email / e-mail / newsletter        → email
 *  3. utm_medium social / social-media              → social
 *  4. referrer domain is a known search engine      → organic search
 *  5. referrer domain is a known social network     → social
 *  6. any other referrer domain (not this site)     → referral
 *  7. no referrer at all                            → direct / unknown (never invented as another source)
 * Only the referring DOMAIN is kept, never the full URL.
 */
final class Sources
{
    private const SEARCH = ['google', 'bing', 'yahoo', 'duckduckgo', 'baidu', 'yandex', 'ecosia', 'startpage', 'ask.com', 'naver', 'seznam', 'qwant', 'brave.com', 'search.'];

    private const SOCIAL = ['facebook.', 'fb.com', 'instagram.', 'linkedin.', 'lnkd.in', 't.co', 'twitter.', 'x.com', 'youtube.', 'youtu.be', 'pinterest.', 'tiktok.', 'whatsapp.', 'wa.me', 'telegram.', 't.me', 'reddit.', 'snapchat.'];

    /** @return array{type: string, domain: ?string} */
    public static function classify(?string $referrerHost, ?string $medium, string $ownHost): array
    {
        $host = self::cleanHost($referrerHost);
        if ($host !== null && ($host === $ownHost || str_ends_with($host, '.'.$ownHost) || $host === 'www.'.$ownHost)) {
            $host = null; // internal navigation never decides the source
        }
        $m = strtolower(trim((string) $medium));

        if ($m !== '') {
            if (preg_match('/^(cpc|ppc|paid.*|display|cpm|cpv|paidsocial)$/', $m)) {
                return ['type' => 'paid', 'domain' => $host];
            }
            if (in_array($m, ['email', 'e-mail', 'newsletter', 'mail'], true)) {
                return ['type' => 'email', 'domain' => $host];
            }
            if (in_array($m, ['social', 'social-media', 'sm'], true)) {
                return ['type' => 'social', 'domain' => $host];
            }
        }
        if ($host === null) {
            return ['type' => 'direct', 'domain' => null];
        }
        foreach (self::SEARCH as $s) {
            if (str_contains($host, $s)) {
                return ['type' => 'organic', 'domain' => $host];
            }
        }
        foreach (self::SOCIAL as $s) {
            if (str_contains($host, $s)) {
                return ['type' => 'social', 'domain' => $host];
            }
        }

        return ['type' => 'referral', 'domain' => $host];
    }

    public static function cleanHost(?string $v): ?string
    {
        $v = strtolower(trim((string) $v));
        if ($v === '') {
            return null;
        }
        $host = parse_url(str_contains($v, '://') ? $v : 'https://'.$v, PHP_URL_HOST);
        $host = is_string($host) ? preg_replace('/^www\./', '', $host) : null;

        return $host && preg_match('/^[a-z0-9.-]{1,120}$/', $host) === 1 ? $host : null;
    }

    public static function cleanCampaign(?string $v): ?string
    {
        $v = trim((string) $v);

        return $v !== '' && preg_match('/^[\p{L}\p{N} _.\-+]{1,80}$/u', $v) === 1 ? mb_strtolower($v) : null;
    }
}
