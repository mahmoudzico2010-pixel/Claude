<?php

declare(strict_types=1);

namespace App\Services\Analytics;

/** Reduces a User-Agent string to aggregate-safe labels. The string itself is never stored. */
final class UserAgent
{
    private const BOTS = '/bot|crawl|spider|slurp|bingpreview|facebookexternalhit|embedly|quora link|outbrain|pinterest|vkshare|w3c_validator|lighthouse|pagespeed|headlesschrome|phantomjs|puppeteer|playwright|selenium|curl\/|wget|python-requests|python-urllib|java\/|libwww|httpclient|okhttp|go-http-client|monitor|uptime|pingdom|statuscake|newrelic|datadog|gtmetrix|semrush|ahrefs|mj12|dotbot|petalbot|yandex|baiduspider|duckduckbot|applebot|ia_archiver|archive\.org|node-fetch|axios|postman|insomnia|preview|scanner|checker/i';

    public static function isBot(?string $ua): bool
    {
        return $ua === null || trim($ua) === '' || preg_match(self::BOTS, $ua) === 1;
    }

    /** @return array{browser: string, os: string, device: string} */
    public static function parse(?string $ua): array
    {
        $ua = (string) $ua;
        $browser = 'Other';
        foreach ([
            'Edge' => '/\b(Edg|EdgA|EdgiOS|Edge)\//', 'Opera' => '/\b(OPR|Opera)\//', 'Samsung Internet' => '/SamsungBrowser\//', 'Firefox' => '/\b(Firefox|FxiOS)\//',
            'Chrome' => '/\b(Chrome|CriOS)\//', 'Safari' => '/Version\/[\d.]+.*Safari\//', 'Internet Explorer' => '/MSIE |Trident\//',
        ] as $name => $rx) {
            if (preg_match($rx, $ua)) {
                $browser = $name;
                break;
            }
        }

        $os = match (true) {
            (bool) preg_match('/Windows/i', $ua) => 'Windows',
            (bool) preg_match('/Android/i', $ua) => 'Android',
            (bool) preg_match('/iPhone|iPad|iPod|iOS/i', $ua) => 'iOS',
            (bool) preg_match('/Mac OS X|Macintosh/i', $ua) => 'macOS',
            (bool) preg_match('/CrOS/i', $ua) => 'ChromeOS',
            (bool) preg_match('/Linux|X11/i', $ua) => 'Linux',
            default => 'Other',
        };

        $device = match (true) {
            (bool) preg_match('/iPad|Tablet|PlayBook|Silk|Kindle|Android(?!.*Mobile)/i', $ua) => 'tablet',
            (bool) preg_match('/Mobi|iPhone|iPod|Android.*Mobile|Windows Phone|BlackBerry/i', $ua) => 'mobile',
            $ua === '' => 'unknown',
            default => 'desktop',
        };

        return ['browser' => $browser, 'os' => $os, 'device' => $device];
    }
}
