<?php

declare(strict_types=1);

namespace App\Services\Analytics;

use App\Models\SiteSetting;
use Carbon\CarbonImmutable;
use Illuminate\Support\Facades\DB;

/**
 * Daily aggregates (analytics_daily): the long-term, anonymous record that survives raw-event pruning.
 * Sessions are counted on their START day, so a period total is a plain sum of days. Unique browsers are NOT stored here
 * (they cannot be added across days); they are computed from the session table while it is retained.
 * Idempotent: a day is rebuilt from scratch every time, so re-running or catching up never double-counts.
 */
final class Aggregator
{
    public function run(?string $from = null, ?string $to = null): int
    {
        $today = AnalyticsSettings::localDay();
        $to ??= $today;
        $from ??= $this->resumeFrom($to);
        $n = 0;
        for ($d = CarbonImmutable::parse($from); $d->toDateString() <= $to; $d = $d->addDay()) {
            $this->day($d->toDateString());
            $n++;
        }
        // Today is still open; "aggregated through" is the last COMPLETE day.
        $done = min($to, CarbonImmutable::parse($today)->subDay()->toDateString());
        if ($done >= $from) {
            SiteSetting::set('analytics.last_aggregated_day', $done, SiteSetting::TYPE_STRING, false);
        }

        return $n;
    }

    /** First day that still needs aggregating (catch-up after a missed cron run). */
    private function resumeFrom(string $to): string
    {
        $last = AnalyticsSettings::lastAggregated();
        if ($last !== null) {
            return CarbonImmutable::parse($last)->addDay()->toDateString();
        }
        $first = DB::table('analytics_sessions')->min('local_day');

        return $first ?: $to;
    }

    public function day(string $day): void
    {
        DB::transaction(function () use ($day): void {
            DB::table('analytics_daily')->where('day', $day)->delete();
            $rows = [];
            $put = function (string $dim, ?string $key, array $m) use (&$rows, $day): void {
                $k = $key === null || $key === '' ? 'unknown' : mb_substr($key, 0, 80);
                $rows[$dim.'|'.$k] = ($rows[$dim.'|'.$k] ?? ['day' => $day, 'dim' => $dim, 'dim_key' => $k, 'sessions' => 0, 'pageviews' => 0, 'product_views' => 0, 'rfq_clicks' => 0, 'rfq_starts' => 0, 'rfq_submits' => 0, 'engaged_ms' => 0, 'engaged_sessions' => 0]);
                foreach ($m as $c => $v) {
                    $rows[$dim.'|'.$k][$c] += (int) $v;
                }
            };

            $sessMetrics = fn ($r) => ['sessions' => $r->n, 'pageviews' => $r->pv, 'product_views' => $r->prod, 'rfq_clicks' => $r->clk, 'rfq_starts' => $r->st, 'rfq_submits' => $r->sub, 'engaged_ms' => $r->eng, 'engaged_sessions' => $r->engn];
            $sel = 'COUNT(*) n, SUM(pageviews) pv, SUM(product_views) prod, SUM(rfq_clicks) clk, SUM(rfq_starts) st, SUM(rfq_submits) sub, COALESCE(SUM(engaged_ms),0) eng, SUM(CASE WHEN engaged_ms IS NULL THEN 0 ELSE 1 END) engn';
            $all = DB::table('analytics_sessions')->where('local_day', $day)->selectRaw($sel)->first();
            if ($all && (int) $all->n > 0) {
                $put('all', 'all', $sessMetrics($all));
            }
            foreach (['country' => 'country', 'locale' => 'locale', 'device' => 'device', 'browser' => 'browser', 'os' => 'os', 'source' => 'source_type', 'referrer' => 'referrer_domain', 'campaign' => 'utm_campaign'] as $dim => $col) {
                foreach (DB::table('analytics_sessions')->where('local_day', $day)->selectRaw($col.' k, '.$sel)->groupBy($col)->get() as $r) {
                    $put($dim, $r->k, $sessMetrics($r));
                }
            }

            // Event-level dimensions (by the day the event happened).
            foreach (DB::table('analytics_events')->where('local_day', $day)->where('type', 'pageview')->selectRaw('page_key k, COUNT(*) n, COALESCE(SUM(engaged_ms),0) eng')->groupBy('page_key')->get() as $r) {
                $put('page', $r->k, ['pageviews' => $r->n, 'engaged_ms' => $r->eng]);
            }
            foreach (['product_view' => ['product', 'entity_id'], 'pack_view' => ['pack', 'page_key']] as $type => [$dim, $col]) {
                foreach (DB::table('analytics_events')->where('local_day', $day)->where('type', $type)->selectRaw($col.' k, COUNT(*) n')->groupBy($col)->get() as $r) {
                    $put($dim, (string) $r->k, ['product_views' => $r->n]);
                }
            }
            foreach (['category' => 'category_id', 'variety' => 'variety_id'] as $dim => $col) {
                foreach (DB::table('analytics_events')->where('local_day', $day)->where('type', 'product_view')->whereNotNull($col)->selectRaw($col.' k, COUNT(*) n')->groupBy($col)->get() as $r) {
                    $put($dim, (string) $r->k, ['product_views' => $r->n]);
                }
            }
            foreach (DB::table('analytics_events')->where('local_day', $day)->where('type', 'rfq_click')->whereNotNull('entity_id')->selectRaw('entity_id k, COUNT(*) n')->groupBy('entity_id')->get() as $r) {
                $put('product', (string) $r->k, ['rfq_clicks' => $r->n]);
            }
            foreach (DB::table('analytics_event_items as i')->join('analytics_events as e', 'e.id', '=', 'i.event_id')->where('e.local_day', $day)->whereNotNull('i.product_id')->selectRaw('i.product_id k, COUNT(DISTINCT e.id) n')->groupBy('i.product_id')->get() as $r) {
                $put('product', (string) $r->k, ['rfq_submits' => $r->n]);
            }

            foreach (array_chunk(array_values($rows), 200) as $chunk) {
                DB::table('analytics_daily')->insert($chunk);
            }
        });
    }

    /** Raw rows are removed only after their day has been aggregated. Rollups are anonymous aggregates and are kept. @return array{events: int, sessions: int} */
    public function prune(): array
    {
        $upTo = AnalyticsSettings::lastAggregated();
        if ($upTo === null) {
            return ['events' => 0, 'sessions' => 0];
        }
        $today = CarbonImmutable::parse(AnalyticsSettings::localDay());
        $evCut = min($upTo, $today->subDays(max(7, (int) AnalyticsSettings::get('events_days')))->toDateString());
        $seCut = min($upTo, $today->subDays(max(30, (int) AnalyticsSettings::get('sessions_days')))->toDateString());
        $events = 0;
        DB::table('analytics_events')->where('local_day', '<', $evCut)->orderBy('id')->select('id')->chunkById(1000, function ($chunk) use (&$events): void {
            $ids = $chunk->pluck('id')->all();
            DB::table('analytics_event_items')->whereIn('event_id', $ids)->delete();
            $events += DB::table('analytics_events')->whereIn('id', $ids)->delete();
        });
        $sessions = DB::table('analytics_sessions')->where('local_day', '<', $seCut)->delete();
        // Events of removed sessions can no longer be tied to anything.
        $orphans = DB::table('analytics_events')->whereNotIn('session_id', DB::table('analytics_sessions')->select('id'))->pluck('id')->all();
        foreach (array_chunk($orphans, 1000) as $ids) {
            DB::table('analytics_event_items')->whereIn('event_id', $ids)->delete();
            $events += DB::table('analytics_events')->whereIn('id', $ids)->delete();
        }

        return ['events' => $events, 'sessions' => $sessions];
    }

    /** After changing the reporting timezone: recompute local_day of retained rows from their UTC timestamps. */
    public function rebuildDays(): int
    {
        $n = 0;
        DB::table('analytics_sessions')->orderBy('id')->select(['id', 'started_at'])->chunkById(500, function ($rows) use (&$n): void {
            foreach ($rows as $r) {
                DB::table('analytics_sessions')->where('id', $r->id)->update(['local_day' => AnalyticsSettings::localDay(CarbonImmutable::parse($r->started_at, 'UTC'))]);
                $n++;
            }
        });
        DB::table('analytics_events')->orderBy('id')->select(['id', 'occurred_at'])->chunkById(500, function ($rows): void {
            foreach ($rows as $r) {
                DB::table('analytics_events')->where('id', $r->id)->update(['local_day' => AnalyticsSettings::localDay(CarbonImmutable::parse($r->occurred_at, 'UTC'))]);
            }
        });
        SiteSetting::set('analytics.last_aggregated_day', '', SiteSetting::TYPE_STRING, false);

        return $n;
    }
}
