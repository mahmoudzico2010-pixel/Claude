<?php

declare(strict_types=1);

namespace App\Services\Analytics;

use Illuminate\Http\Request;

/**
 * Approximate country of the CONNECTION (not nationality, company domicile or shipping destination).
 * Sources, in order: (1) a country header set by a proxy/CDN that this application already trusts (TRUSTED_PROXIES);
 * (2) an optional local MaxMind country database. Otherwise null = "Unknown". The IP is read transiently and never stored.
 */
final class Geo
{
    public static function country(Request $request): ?string
    {
        if ($request->isFromTrustedProxy()) {
            foreach (AnalyticsSettings::geoHeaders() as $header) {
                $v = strtoupper(trim((string) $request->headers->get($header)));
                if (preg_match('/^[A-Z]{2}$/', $v) === 1 && ! in_array($v, ['XX', 'T1', 'ZZ', 'A1', 'A2', 'EU', 'AP'], true)) {
                    return $v;
                }
            }
        }

        $db = storage_path('app/geoip/GeoLite2-Country.mmdb');
        if (class_exists(\MaxMind\Db\Reader::class) && is_file($db) && ($ip = $request->ip())) {
            try {
                $reader = new \MaxMind\Db\Reader($db);
                $rec = $reader->get($ip);
                $reader->close();
                $iso = strtoupper((string) ($rec['country']['iso_code'] ?? ''));
                if (preg_match('/^[A-Z]{2}$/', $iso) === 1) {
                    return $iso;
                }
            } catch (\Throwable) {
                // an unreadable database simply means Unknown
            }
        }

        return null;
    }
}
