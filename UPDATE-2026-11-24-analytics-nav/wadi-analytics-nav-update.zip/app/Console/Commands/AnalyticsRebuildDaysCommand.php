<?php

declare(strict_types=1);

namespace App\Console\Commands;

use App\Services\Analytics\Aggregator;
use Illuminate\Console\Command;

class AnalyticsRebuildDaysCommand extends Command
{
    protected $signature = 'analytics:rebuild-days';

    protected $description = 'After changing the reporting timezone: recompute the reporting day of all retained rows from their UTC timestamps.';

    public function handle(Aggregator $a): int
    {
        $this->info('Re-dated '.$a->rebuildDays().' session(s). Now run: php artisan analytics:aggregate --from=YYYY-MM-DD');

        return self::SUCCESS;
    }
}
