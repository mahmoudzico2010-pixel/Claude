<?php

declare(strict_types=1);

namespace App\Console\Commands;

use App\Services\Analytics\Aggregator;
use Illuminate\Console\Command;

class AnalyticsAggregateCommand extends Command
{
    protected $signature = 'analytics:aggregate {--from= : first reporting day (YYYY-MM-DD)} {--to= : last reporting day} {--prune : also remove raw rows past their retention}';

    protected $description = 'Build the daily analytics aggregates. Safe to re-run; with no options it catches up from the last aggregated day.';

    public function handle(Aggregator $a): int
    {
        $n = $a->run($this->option('from') ?: null, $this->option('to') ?: null);
        $this->info("Aggregated $n day(s).");
        if ($this->option('prune')) {
            $r = $a->prune();
            $this->info("Pruned {$r['events']} raw event(s) and {$r['sessions']} session(s) past retention.");
        }

        return self::SUCCESS;
    }
}
