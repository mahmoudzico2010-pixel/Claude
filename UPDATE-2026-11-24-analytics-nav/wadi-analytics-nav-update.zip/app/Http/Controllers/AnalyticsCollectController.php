<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Services\Analytics\Collector;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class AnalyticsCollectController extends Controller
{
    /** Always answers quickly with a tiny body; a measurement problem must never be visible to (or break) the visitor. */
    public function store(Request $request, Collector $collector): JsonResponse
    {
        $raw = (string) $request->getContent();
        $payload = strlen($raw) <= 4096 ? json_decode($raw, true) : null;
        if (! is_array($payload)) {
            return response()->json(['sid' => null], 202)->header('Cache-Control', 'no-store');
        }
        try {
            $out = $collector->handle($request, $payload);
        } catch (\Throwable $e) {
            report($e);
            $out = ['sid' => null, 'status' => 'error'];
        }

        return response()->json(['sid' => $out['sid']], 202)->header('Cache-Control', 'no-store');
    }
}
