<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /** Additive: first-party, pseudonymous visitor analytics. No raw IPs, user agents, full referrers or form data are ever stored. */
    public function up(): void
    {
        if (! Schema::hasTable('analytics_sessions')) {
            Schema::create('analytics_sessions', function (Blueprint $t): void {
                $t->id();
                $t->char('session_uid', 32)->unique();
                $t->char('browser_hash', 40)->nullable()->index();     // estimated browser (HMAC of a random first-party id), never a person
                $t->dateTime('started_at');
                $t->dateTime('last_seen_at');
                $t->date('local_day');                                  // reporting-timezone day, fixed at ingestion (DST-correct)
                $t->char('country', 2)->nullable();
                $t->string('locale', 5);
                $t->string('browser_lang', 5)->nullable();
                $t->string('device', 10)->default('unknown');
                $t->string('browser', 24)->default('Other');
                $t->string('os', 24)->default('Other');
                $t->string('source_type', 10)->default('direct');
                $t->string('referrer_domain', 120)->nullable();
                $t->string('utm_source', 80)->nullable();
                $t->string('utm_medium', 80)->nullable();
                $t->string('utm_campaign', 80)->nullable();
                $t->string('landing_page', 80)->nullable();
                $t->string('exit_page', 80)->nullable();
                $t->unsignedSmallInteger('pageviews')->default(0);
                $t->unsignedSmallInteger('product_views')->default(0);
                $t->unsignedInteger('engaged_ms')->nullable();         // null = unknown (no timing signal), 0 = measured and none
                $t->unsignedBigInteger('engaged_until')->nullable();    // unix ms: end of the last credited interval (overlap guard across tabs)
                $t->unsignedSmallInteger('rfq_clicks')->default(0);
                $t->unsignedSmallInteger('rfq_starts')->default(0);
                $t->unsignedSmallInteger('rfq_submits')->default(0);
                $t->index(['local_day', 'country']);
                $t->index(['local_day', 'locale']);
                $t->index('last_seen_at');
            });
        }

        if (! Schema::hasTable('analytics_events')) {
            Schema::create('analytics_events', function (Blueprint $t): void {
                $t->id();
                $t->unsignedBigInteger('session_id');
                $t->char('event_uid', 32)->unique();                    // client-generated (or hash of the RFQ reference): duplicates are ignored
                $t->dateTime('occurred_at');
                $t->date('local_day');
                $t->string('type', 16);
                $t->string('page_key', 80)->nullable();
                $t->string('locale', 5)->nullable();
                $t->string('entity_type', 10)->nullable();
                $t->unsignedBigInteger('entity_id')->nullable();
                $t->unsignedBigInteger('category_id')->nullable();
                $t->unsignedBigInteger('variety_id')->nullable();
                $t->unsignedInteger('engaged_ms')->nullable();
                $t->string('next_page_key', 80)->nullable();
                $t->boolean('is_entrance')->default(false);
                $t->boolean('is_exit')->default(true);
                $t->index(['type', 'local_day']);
                $t->index(['session_id', 'occurred_at']);
                $t->index(['entity_type', 'entity_id', 'type']);
                $t->index(['page_key', 'type', 'local_day']);
                $t->index('occurred_at');
            });
        }

        if (! Schema::hasTable('analytics_event_items')) {
            Schema::create('analytics_event_items', function (Blueprint $t): void {
                $t->id();
                $t->unsignedBigInteger('event_id')->index();
                $t->unsignedBigInteger('product_id')->nullable()->index();
                $t->unsignedBigInteger('category_id')->nullable();
                $t->unsignedBigInteger('variety_id')->nullable();
                $t->unsignedBigInteger('packaging_type_id')->nullable()->index();
            });
        }

        if (! Schema::hasTable('analytics_daily')) {
            Schema::create('analytics_daily', function (Blueprint $t): void {
                $t->id();
                $t->date('day');
                $t->string('dim', 12);
                $t->string('dim_key', 80);
                $t->unsignedInteger('sessions')->default(0);          // sessions are counted on their start day: additive across days
                $t->unsignedInteger('pageviews')->default(0);
                $t->unsignedInteger('product_views')->default(0);
                $t->unsignedInteger('rfq_clicks')->default(0);
                $t->unsignedInteger('rfq_starts')->default(0);
                $t->unsignedInteger('rfq_submits')->default(0);
                $t->unsignedBigInteger('engaged_ms')->default(0);
                $t->unsignedInteger('engaged_sessions')->default(0);
                $t->unique(['day', 'dim', 'dim_key']);
                // Unique browsers are deliberately NOT stored here: they cannot be added across days.
            });
        }

        if (! Schema::hasTable('analytics_age_bands')) {
            Schema::create('analytics_age_bands', function (Blueprint $t): void {
                $t->id();
                $t->date('period_start');
                $t->date('period_end');
                $t->string('band', 12);
                $t->unsignedInteger('sessions');
                $t->string('source', 80);
                $t->decimal('coverage_pct', 5, 2)->nullable();
                $t->unsignedBigInteger('imported_by')->nullable();
                $t->timestamps();
                $t->index(['period_start', 'period_end']);
            });
        }

        if (! Schema::hasTable('analytics_presets')) {
            Schema::create('analytics_presets', function (Blueprint $t): void {
                $t->id();
                $t->unsignedBigInteger('user_id')->index();
                $t->string('name', 80);
                $t->string('report', 20);
                $t->text('filters');                                   // JSON: only whitelisted filter keys
                $t->timestamps();
            });
        }
    }

    public function down(): void
    {
        foreach (['analytics_presets', 'analytics_age_bands', 'analytics_daily', 'analytics_event_items', 'analytics_events', 'analytics_sessions'] as $table) {
            Schema::dropIfExists($table);
        }
    }
};
