<?php

declare(strict_types=1);

use App\Support\Permissions;
use Illuminate\Database\Migrations\Migration;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Spatie\Permission\PermissionRegistrar;

return new class extends Migration
{
    /** Adds the three analytics permissions and grants them per the role matrix; existing grants and custom roles are left alone. */
    public function up(): void
    {
        if (! class_exists(Permission::class) || ! \Illuminate\Support\Facades\Schema::hasTable('permissions')) {
            return;
        }
        app(PermissionRegistrar::class)->forgetCachedPermissions();
        $mine = [Permissions::ANALYTICS_VIEW, Permissions::ANALYTICS_EXPORT, Permissions::ANALYTICS_CONFIGURE];
        foreach ($mine as $name) {
            Permission::findOrCreate($name, 'web');
        }
        foreach (Permissions::matrix() as $roleName => $perms) {
            $role = Role::query()->where('name', $roleName)->where('guard_name', 'web')->first();
            if ($role !== null) {
                $role->givePermissionTo(array_values(array_intersect($mine, $perms)));
            }
        }
        app(PermissionRegistrar::class)->forgetCachedPermissions();
    }

    public function down(): void
    {
        // Permissions are intentionally kept: removing them would silently drop grants an owner may have customised.
    }
};
