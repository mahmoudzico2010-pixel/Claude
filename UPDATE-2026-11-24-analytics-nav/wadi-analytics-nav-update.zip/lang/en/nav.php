<?php

declare(strict_types=1);

return [
    'packaging_catalog' => 'Packaging Catalog',
    'dashboard' => 'Dashboard',
    'groups' => [
        'analytics' => 'Analytics & Reports',
        'sales' => 'Sales & Enquiries',
        'catalogue' => 'Catalogue & Packaging',
        'inquiries' => 'Inquiries',
        'content' => 'Content & Design',
        'company' => 'Company & Markets',
        'languages' => 'Languages & Translations',
        'media' => 'Media',
        'settings' => 'Settings',
        'security' => 'Users & Roles',
        'maintenance' => 'Maintenance',
        'plugins' => 'Plugins',
        'system' => 'System Settings',
    ],
];
