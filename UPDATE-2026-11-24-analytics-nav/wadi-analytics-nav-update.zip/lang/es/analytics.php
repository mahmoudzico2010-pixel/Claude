<?php

return [
    'consent' => [
        'title' => 'Su privacidad',
        'text' => 'Medimos las visitas de forma agregada y seudónima para saber qué productos interesan. No guardamos su IP ni los datos de formularios y no creamos un perfil suyo. Puede rechazar o retirar su consentimiento en cualquier momento.',
        'accept' => 'Aceptar',
        'decline' => 'Rechazar',
        'reopen' => 'Opciones de privacidad',
    ],
];
