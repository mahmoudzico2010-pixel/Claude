<?php

return [
    'consent' => [
        'title' => 'La tua privacy',
        'text' => 'Misuriamo le visite in forma aggregata e pseudonima per capire quali prodotti interessano. Non conserviamo il tuo IP né i dati dei moduli e non creiamo un tuo profilo. Puoi rifiutare o revocare il consenso in qualsiasi momento.',
        'accept' => 'Accetta',
        'decline' => 'Rifiuta',
        'reopen' => 'Scelte sulla privacy',
    ],
];
