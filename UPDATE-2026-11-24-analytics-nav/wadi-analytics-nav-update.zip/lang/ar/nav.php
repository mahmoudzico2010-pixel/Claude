<?php

declare(strict_types=1);

return [
    'packaging_catalog' => 'كتالوج التعبئة',
    'dashboard' => 'الرئيسية',
    'groups' => [
        'analytics' => 'التحليلات والتقارير',
        'sales' => 'المبيعات والاستفسارات',
        'catalogue' => 'الكتالوج والتعبئة',
        'inquiries' => 'طلبات العملاء',
        'content' => 'المحتوى والتصميم',
        'company' => 'الشركة والأسواق',
        'languages' => 'اللغات والترجمات',
        'media' => 'الوسائط',
        'settings' => 'الإعدادات',
        'security' => 'المستخدمون والصلاحيات',
        'maintenance' => 'الصيانة',
        'plugins' => 'الإضافات',
        'system' => 'إعدادات النظام',
    ],
];
