<?php

return [
    'consent' => [
        'title' => 'A sua privacidade',
        'text' => 'Medimos as visitas de forma agregada e pseudonimizada para perceber que produtos interessam. Não guardamos o seu IP nem dados de formulários e não criamos um perfil seu. Pode recusar ou retirar o consentimento a qualquer momento.',
        'accept' => 'Aceitar',
        'decline' => 'Recusar',
        'reopen' => 'Opções de privacidade',
    ],
];
