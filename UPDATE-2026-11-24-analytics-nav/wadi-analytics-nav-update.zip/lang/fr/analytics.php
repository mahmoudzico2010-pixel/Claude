<?php

return [
    'consent' => [
        'title' => 'Votre vie privée',
        'text' => 'Nous mesurons les visites de façon agrégée et pseudonymisée pour savoir quels produits intéressent. Nous ne conservons ni votre IP ni les données de formulaire et ne créons pas de profil. Vous pouvez refuser ou retirer votre accord à tout moment.',
        'accept' => 'Accepter',
        'decline' => 'Refuser',
        'reopen' => 'Choix de confidentialité',
    ],
];
