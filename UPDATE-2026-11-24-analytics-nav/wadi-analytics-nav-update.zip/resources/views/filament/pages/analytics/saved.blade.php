<x-filament-panels::page>
    @php
    $presets = $this->presets();
@endphp
    <p style="font-size:.85rem;color:#4a5a52">{{ __('analytics.ui.presets') }}</p>
    <div style="display:grid;gap:.5rem">
        @forelse ($presets as $p)
            @php
    $f = \App\Services\Analytics\ReportFilters::fromArray((array) json_decode($p->filters, true));
@endphp
            <div style="background:#fff;border:1px solid #e5e0cf;border-radius:.7rem;padding:.7rem 1rem;display:flex;flex-wrap:wrap;gap:.6rem;align-items:center;justify-content:space-between" data-preset="{{ $p->id }}">
                <div><strong style="color:#14382a">{{ $p->name }}</strong><div style="font-size:.74rem;color:#6b7280">{{ __('analytics.nav.'.($p->report === 'overview' ? 'overview' : $p->report)) }} · {{ implode(' · ', $f->describe()) }}</div></div>
                <div style="display:flex;gap:.4rem">
                    <a href="{{ $this->reportUrl($p) }}" style="background:#14382a;color:#fff;border-radius:.4rem;padding:.25rem .8rem;font-size:.8rem">{{ __('analytics.ui.open') }}</a>
                    <button type="button" wire:click="deletePreset({{ $p->id }})" wire:confirm="{{ __('analytics.ui.delete') }}?" style="border:1px solid #d9d2bd;border-radius:.4rem;padding:.25rem .7rem;font-size:.8rem;color:#b91c1c">{{ __('analytics.ui.delete') }}</button>
                </div>
            </div>
        @empty
            <p style="font-size:.85rem;color:#6b7280">{{ __('analytics.ui.empty') }}</p>
        @endforelse
    </div>
</x-filament-panels::page>
