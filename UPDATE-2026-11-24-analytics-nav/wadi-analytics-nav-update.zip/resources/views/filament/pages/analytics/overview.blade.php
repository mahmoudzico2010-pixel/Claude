<x-filament-panels::page>
    @php
        $o = $this->service()->overview($this->grain);
        $rtl = in_array(app()->getLocale(), ['ar', 'ur'], true);
        $live = $this->service()->live();
    @endphp
    @include('filament.pages.analytics._bar')

    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(11.5rem,1fr));gap:.8rem" data-testid="an-cards">
        @foreach ($o['cards'] as $c)
            <div style="background:#fff;border:1px solid #e5e0cf;border-inline-start:4px solid #b8912f;border-radius:.8rem;padding:.7rem .9rem" data-card="{{ $c['k'] }}">
                <div style="font-size:.72rem;color:#5b6b63">{{ $c['label'] }}</div>
                <div style="font-size:1.6rem;font-weight:700;color:#14382a;font-variant-numeric:tabular-nums">
                    @if (($c['type'] ?? 'int') === 'dur') {{ $c['v'] === null ? __('analytics.unknown') : \App\Services\Analytics\ReportExporter::dur((int) $c['v']) }}
                    @elseif (($c['type'] ?? 'int') === 'pct') {{ $c['v'] === null ? '—' : $c['v'].'%' }}
                    @else {{ number_format((int) $c['v']) }} @endif
                </div>
                @if ($c['prev'] !== null && $this->filters()->compare)<div style="font-size:.7rem;color:#6b7280">{{ __('analytics.ui.vs') }}: {{ ($c['type'] ?? 'int') === 'dur' ? ($c['prev'] === null ? '—' : \App\Services\Analytics\ReportExporter::dur((int) $c['prev'])) : $c['prev'] }}</div>@endif
                @if ($c['note'])<div style="font-size:.68rem;color:#6b7280;margin-top:.25rem;line-height:1.4">{{ $c['note'] }}</div>@endif
            </div>
        @endforeach
    </div>

    <div style="display:grid;grid-template-columns:minmax(0,2fr) minmax(16rem,1fr);gap:1rem" class="wr-an-split">
        <div style="display:flex;flex-direction:column;gap:.5rem">
            <div class="wr-an-noprint" style="display:flex;gap:.4rem;align-items:center;font-size:.78rem">{{ __('analytics.ui.grain') }}:
                @foreach (['day' => 'daily', 'week' => 'weekly', 'month' => 'monthly'] as $g => $l)<button type="button" wire:click="$set('grain','{{ $g }}')" style="border:1px solid #d9d2bd;border-radius:.4rem;padding:.15rem .6rem;{{ $this->grain === $g ? 'background:#14382a;color:#fff' : '' }}">{{ __('analytics.ui.'.$l) }}</button>@endforeach</div>
            <x-analytics.report :report="$o['trend']" :rtl="$rtl" :export="$this->canExport()"/>
        </div>
        <section wire:poll.30s style="background:#fff;border:1px solid #e5e0cf;border-radius:.9rem;padding:1rem 1.1rem;align-self:start" data-testid="an-live" aria-live="polite">
            <h3 style="font-weight:700;color:#14382a;margin:0 0 .4rem">● {{ __('analytics.ui.live') }}</h3>
            <div style="font-size:2rem;font-weight:700;color:#14382a" data-live="active">{{ $live['active'] }}</div>
            <div style="font-size:.74rem;color:#5b6b63">{{ __('analytics.ui.active_sessions') }} · {{ __('analytics.ui.as_of') }} {{ \Illuminate\Support\Carbon::parse($live['at'])->setTimezone(\App\Services\Analytics\AnalyticsSettings::timezone())->format('H:i:s') }}</div>
            @if ($live['countries'])<h4 style="font-size:.78rem;margin:.7rem 0 .2rem;color:#14382a">{{ __('analytics.ui.live_countries') }}</h4>@foreach ($live['countries'] as $c)<div style="font-size:.78rem;display:flex;justify-content:space-between;gap:.5rem"><span>@if ($c['code'])<x-flag :code="$c['code']" :height="12" style="margin-inline-end:.3rem"/>@endif{{ $c['name'] }}</span><b>{{ $c['n'] }}</b></div>@endforeach @endif
            @if ($live['pages'])<h4 style="font-size:.78rem;margin:.7rem 0 .2rem;color:#14382a">{{ __('analytics.ui.live_pages') }}</h4>@foreach ($live['pages'] as $p)<div style="font-size:.78rem;display:flex;justify-content:space-between;gap:.5rem"><span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">{{ $p['name'] }}</span><b>{{ $p['n'] }}</b></div>@endforeach @endif
            <p style="font-size:.68rem;color:#6b7280;margin:.7rem 0 0">{{ __('analytics.ui.live_off') }}</p>
        </section>
    </div>

    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,32rem),1fr));gap:1rem">
        <x-analytics.report :report="$o['countries']" :rtl="$rtl"/>
        <x-analytics.report :report="$o['products']" :rtl="$rtl"/>
        <x-analytics.report :report="$o['rfq_days']" :rtl="$rtl"/>
    </div>
    <style>@media (max-width: 900px) { .wr-an-split { grid-template-columns: 1fr !important; } }</style>
</x-filament-panels::page>
