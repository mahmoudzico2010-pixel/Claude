<x-filament-panels::page>
@php
    $rtl = in_array(app()->getLocale(), ['ar', 'ur'], true);
    $s = $this->service();
@endphp
@include('filament.pages.analytics._bar')
@php
    $tabs = ['countries' => 'analytics.ui.tab_countries', 'languages' => 'analytics.ui.tab_languages', 'devices' => 'analytics.ui.tab_devices', 'age' => 'analytics.ui.tab_age'];
    $cur = $this->tab ?: array_key_first($tabs);
@endphp
<div role="tablist" class="wr-an-noprint" style="display:flex;gap:.3rem;flex-wrap:wrap">
    @foreach ($tabs as $k => $label)
        <button type="button" role="tab" aria-selected="{{ $cur === $k ? 'true' : 'false' }}" wire:click="$set('tab','{{ $k }}')" data-tab="{{ $k }}"
                style="border-radius:.5rem;padding:.4rem .9rem;font-size:.82rem;font-weight:600;{{ $cur === $k ? 'background:#14382a;color:#fff' : 'background:#f1ede0;color:#14382a' }}">{{ __($label) }}</button>
    @endforeach
</div>
<div style="display:grid;gap:1rem">
    @if ($cur === 'countries')<x-analytics.report :report="$s->countries()" :rtl="$rtl" :export="$this->canExport()"/>
    @elseif ($cur === 'languages')<x-analytics.report :report="$s->languages()" :rtl="$rtl"/><x-analytics.report :report="$s->browserLanguages()" :rtl="$rtl"/>
    @elseif ($cur === 'devices')<x-analytics.report :report="$s->devices()" :rtl="$rtl"/><x-analytics.report :report="$s->browsers()" :rtl="$rtl"/><x-analytics.report :report="$s->systems()" :rtl="$rtl"/>
    @else<x-analytics.report :report="$s->age()" :rtl="$rtl"/>@endif
</div>
</x-filament-panels::page>
