@php
    $cov = $this->service()->coverage();
    $sel = 'border:1px solid #d9d2bd;border-radius:.5rem;padding:.3rem .5rem;font-size:.8rem;background:#fff;max-width:11rem';
    $lbl = 'font-size:.68rem;color:#5b6b63;display:flex;flex-direction:column;gap:.15rem';
    $rtl = in_array(app()->getLocale(), ['ar', 'ur'], true);
@endphp
<div class="wr-an-bar" style="background:#fff;border:1px solid #e5e0cf;border-radius:.9rem;padding:.8rem 1rem;display:flex;flex-direction:column;gap:.7rem">
    <div style="display:flex;flex-wrap:wrap;gap:.7rem;align-items:flex-end">
        <label style="{{ $lbl }}">{{ __('analytics.ui.range') }}
            <select wire:model="range" style="{{ $sel }}">@foreach (['today', 'yesterday', '7d', '30d', '90d', 'custom'] as $r)<option value="{{ $r }}">{{ __('analytics.ui.'.$r) }}</option>@endforeach</select></label>
        @if ($this->range === 'custom')
            <label style="{{ $lbl }}">{{ __('analytics.ui.from') }}<input type="date" wire:model="from" style="{{ $sel }}"></label>
            <label style="{{ $lbl }}">{{ __('analytics.ui.to') }}<input type="date" wire:model="to" style="{{ $sel }}"></label>
        @endif
        <label style="{{ $lbl }}">{{ __('analytics.filters.country') }}
            <select wire:model="country" style="{{ $sel }}"><option value="">{{ __('analytics.ui.all') }}</option>@foreach ($this->countryChoices() as $k => $v)<option value="{{ $k }}">{{ $v }}</option>@endforeach</select></label>
        <label style="{{ $lbl }}">{{ __('analytics.filters.locale') }}
            <select wire:model="locale" style="{{ $sel }}"><option value="">{{ __('analytics.ui.all') }}</option>@foreach (config('wadi.locales') as $code => $cfg)<option value="{{ $code }}">{{ $cfg['native'] }}</option>@endforeach</select></label>
        <label style="{{ $lbl }}">{{ __('analytics.filters.device') }}
            <select wire:model="device" style="{{ $sel }}"><option value="">{{ __('analytics.ui.all') }}</option>@foreach (['mobile', 'tablet', 'desktop'] as $d)<option value="{{ $d }}">{{ __('analytics.device.'.$d) }}</option>@endforeach</select></label>
        <label style="{{ $lbl }}">{{ __('analytics.filters.source') }}
            <select wire:model="source" style="{{ $sel }}"><option value="">{{ __('analytics.ui.all') }}</option>@foreach (['direct', 'organic', 'referral', 'paid', 'social', 'email'] as $d)<option value="{{ $d }}">{{ __('analytics.source.'.$d) }}</option>@endforeach</select></label>
        <label style="{{ $lbl }}">{{ __('analytics.filters.product') }}
            <select wire:model="product" style="{{ $sel }}"><option value="">{{ __('analytics.ui.all') }}</option>@foreach ($this->productChoices() as $k => $v)<option value="{{ $k }}">{{ $v }}</option>@endforeach</select></label>
        <label style="{{ $lbl }}">{{ __('analytics.filters.category') }}
            <select wire:model="category" style="{{ $sel }}"><option value="">{{ __('analytics.ui.all') }}</option>@foreach ($this->categoryChoices() as $k => $v)<option value="{{ $k }}">{{ $v }}</option>@endforeach</select></label>
        <label style="{{ $lbl }}">{{ __('analytics.filters.pack') }}
            <select wire:model="pack" style="{{ $sel }}"><option value="">{{ __('analytics.ui.all') }}</option>@foreach ($this->packChoices() as $k => $v)<option value="{{ $k }}">{{ $v }}</option>@endforeach</select></label>
        <label style="{{ $lbl }}">{{ __('analytics.filters.page') }}
            <select wire:model="pageKey" style="{{ $sel }}"><option value="">{{ __('analytics.ui.all') }}</option>@foreach ($this->pageChoices() as $k => $v)<option value="{{ $k }}">{{ \Illuminate\Support\Str::limit($v, 28) }}</option>@endforeach</select></label>
        <label style="font-size:.78rem;display:flex;gap:.35rem;align-items:center;padding-bottom:.3rem"><input type="checkbox" wire:model="compare"> {{ __('analytics.ui.compare') }}</label>
        <button type="button" wire:click="$refresh" style="background:#14382a;color:#fff;border-radius:.5rem;padding:.4rem 1rem;font-size:.8rem;font-weight:600" data-testid="an-apply">{{ __('analytics.ui.apply') }}</button>
        <button type="button" wire:click="resetFilters" style="border:1px solid #d9d2bd;border-radius:.5rem;padding:.4rem .8rem;font-size:.8rem">{{ __('analytics.ui.reset') }}</button>
    </div>
    <div style="display:flex;flex-wrap:wrap;gap:1rem;justify-content:space-between;align-items:center;font-size:.72rem;color:#5b6b63;border-top:1px solid #efe9d6;padding-top:.5rem">
        <span>{{ __('analytics.ui.tz') }}: <strong>{{ $cov['timezone'] }}</strong> · {{ __('analytics.ui.refreshed') }}: <strong>{{ $cov['last_refresh'] ?? '—' }}</strong> · {{ __('analytics.ui.coverage') }}: <strong>{{ $cov['start'] ? \Illuminate\Support\Carbon::parse($cov['start'])->setTimezone($cov['timezone'])->toDateString() : __('analytics.ui.coverage_none') }}</strong> · {{ __('analytics.ui.consent_note', ['req' => $cov['consent_required'] ? __('analytics.ui.yes') : __('analytics.ui.no')]) }}</span>
        <span class="wr-an-noprint" style="display:flex;gap:.5rem;flex-wrap:wrap;align-items:center">
            @if ($this->canExport())
                <button type="button" wire:click="exportCsv('{{ $this->reportKey() }}')" style="border:1px solid #14382a;color:#14382a;border-radius:.4rem;padding:.2rem .6rem" data-testid="an-csv">{{ __('analytics.ui.export_csv') }}</button>
                <button type="button" wire:click="exportPdf('{{ $this->reportKey() }}', 'ar')" style="border:1px solid #14382a;color:#14382a;border-radius:.4rem;padding:.2rem .6rem" data-testid="an-pdf-ar">PDF · عربي</button>
                <button type="button" wire:click="exportPdf('{{ $this->reportKey() }}', 'en')" style="border:1px solid #14382a;color:#14382a;border-radius:.4rem;padding:.2rem .6rem" data-testid="an-pdf-en">PDF · EN</button>
            @else
                <em>{{ __('analytics.ui.no_export') }}</em>
            @endif
            <button type="button" onclick="window.print()" style="border:1px solid #d9d2bd;border-radius:.4rem;padding:.2rem .6rem">{{ __('analytics.ui.print') }}</button>
            <input type="text" wire:model="presetName" placeholder="{{ __('analytics.ui.preset_name') }}" style="border:1px solid #d9d2bd;border-radius:.4rem;padding:.2rem .5rem;width:9rem">
            <button type="button" wire:click="savePreset('{{ $this->reportKey() }}')" style="border:1px solid #b8912f;color:#7a5b00;border-radius:.4rem;padding:.2rem .6rem" data-testid="an-save-preset">{{ __('analytics.ui.save_preset') }}</button>
            @if ($this->canConfigure())<a href="{{ \App\Filament\Pages\Analytics\TrackingSettings::getUrl() }}" style="color:#14382a;text-decoration:underline">{{ __('analytics.ui.settings_link') }}</a>@endif
        </span>
    </div>
</div>
<style>
    @media print { .fi-sidebar, .fi-topbar, .wr-an-noprint, .wr-an-bar select, .fi-header-actions-ctn { display: none !important; } .fi-main { max-width: 100% !important; padding: 0 !important; } }
    .wr-an-table th:hover { background:#e9e3cd !important; }
</style>
<script>
    (function () {
        if (window.__wrAnSort) { return; } window.__wrAnSort = true;
        function sortBy(th) {
            var table = th.closest('table'), idx = Array.prototype.indexOf.call(th.parentNode.children, th), type = th.getAttribute('data-type');
            var dir = th.getAttribute('data-dir') === 'asc' ? 'desc' : 'asc'; table.querySelectorAll('th').forEach(function (t) { t.removeAttribute('data-dir'); }); th.setAttribute('data-dir', dir);
            var body = table.tBodies[0], rows = Array.prototype.slice.call(body.rows);
            rows.sort(function (a, b) {
                var x = a.cells[idx].getAttribute('data-sort'), y = b.cells[idx].getAttribute('data-sort');
                if (['int', 'dur', 'pct'].indexOf(type) !== -1) { x = parseFloat(x); y = parseFloat(y); return dir === 'asc' ? x - y : y - x; }
                return dir === 'asc' ? String(a.cells[idx].textContent).localeCompare(b.cells[idx].textContent) : String(b.cells[idx].textContent).localeCompare(a.cells[idx].textContent);
            });
            rows.forEach(function (r) { body.appendChild(r); });
        }
        document.addEventListener('click', function (e) { var th = e.target.closest && e.target.closest('table[data-sortable] th'); if (th) { sortBy(th); } });
        document.addEventListener('keydown', function (e) { if ((e.key === 'Enter' || e.key === ' ') && e.target.matches && e.target.matches('table[data-sortable] th')) { e.preventDefault(); sortBy(e.target); } });
    })();
</script>
