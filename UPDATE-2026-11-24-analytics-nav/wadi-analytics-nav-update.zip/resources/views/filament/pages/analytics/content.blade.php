<x-filament-panels::page>
@php
    $rtl = in_array(app()->getLocale(), ['ar', 'ur'], true);
    $s = $this->service();
@endphp
@include('filament.pages.analytics._bar')
@php
    $tabs = ['pages' => 'analytics.ui.tab_pages', 'products' => 'analytics.ui.tab_products', 'categories' => 'analytics.ui.tab_categories', 'packs' => 'analytics.ui.tab_packs'];
    $cur = $this->tab ?: array_key_first($tabs);
@endphp
<div role="tablist" class="wr-an-noprint" style="display:flex;gap:.3rem;flex-wrap:wrap">
    @foreach ($tabs as $k => $label)
        <button type="button" role="tab" aria-selected="{{ $cur === $k ? 'true' : 'false' }}" wire:click="$set('tab','{{ $k }}')" data-tab="{{ $k }}"
                style="border-radius:.5rem;padding:.4rem .9rem;font-size:.82rem;font-weight:600;{{ $cur === $k ? 'background:#14382a;color:#fff' : 'background:#f1ede0;color:#14382a' }}">{{ __($label) }}</button>
    @endforeach
</div>
<div style="display:grid;gap:1rem">
    @if ($cur === 'pages')
        <label class="wr-an-noprint" style="font-size:.8rem;display:flex;gap:.4rem;align-items:center"><input type="checkbox" wire:model.live="byLanguage"> {{ __('analytics.ui.by_language') }}</label>
        <x-analytics.report :report="$s->pages($this->byLanguage)" :rtl="$rtl" :export="$this->canExport()"/>
    @elseif ($cur === 'products')<x-analytics.report :report="$s->products()" :rtl="$rtl" :export="$this->canExport()"/>
    @elseif ($cur === 'categories')<x-analytics.report :report="$s->categories()" :rtl="$rtl"/><x-analytics.report :report="$s->varieties()" :rtl="$rtl"/>
    @else<x-analytics.report :report="$s->packs()" :rtl="$rtl"/><x-analytics.report :report="$s->requestedPacks()" :rtl="$rtl"/>@endif
</div>
</x-filament-panels::page>
