@props(['report', 'rtl' => false])
@php
    $chart = $report['chart'] ?? null;
    $rows = $report['rows'] ?? [];
    $type = $chart['type'] ?? null;
    $palette = ['sessions' => '#14382a', 'browsers' => '#b8912f', 'pageviews' => '#3f8f6b', 'product_views' => '#8a5a1f'];
@endphp
@if ($chart && $rows)
    @if ($type === 'line')
        @php
            $W = 760; $H = 230; $ml = 46; $mr = 14; $mt = 12; $mb = 30;
            $series = $chart['series']; $cmp = $chart['compare'] ?? null;
            $n = count($rows);
            $max = 1;
            foreach ($rows as $r) { foreach ($series as $s) { $max = max($max, (int) $r[$s]); } }
            if ($cmp) { foreach ($cmp as $r) { foreach ($series as $s) { $max = max($max, (int) $r[$s]); } } }
            $step = 10 ** max(0, strlen((string) $max) - 1); $max = (int) (ceil($max / $step) * $step);
            $px = fn ($i, $count) => ($rtl ? ($W - $mr - ($count > 1 ? ($W - $ml - $mr) * $i / ($count - 1) : 0)) : ($ml + ($count > 1 ? ($W - $ml - $mr) * $i / ($count - 1) : 0)));
            $py = fn ($v) => $mt + ($H - $mt - $mb) * (1 - $v / $max);
            $lblEvery = max(1, (int) ceil($n / 8));
        @endphp
        <svg viewBox="0 0 {{ $W }} {{ $H }}" role="img" aria-label="{{ $report['title'] }}" style="width:100%;height:auto;max-height:260px;direction:ltr">
            @foreach ([0, .5, 1] as $g)
                @php $yy = $py($max * $g); @endphp
                <line x1="{{ $ml }}" x2="{{ $W - $mr }}" y1="{{ $yy }}" y2="{{ $yy }}" stroke="#e5e0cf" stroke-width="1"/>
                <text x="{{ $rtl ? $W - $ml + 6 : $ml - 6 }}" y="{{ $yy + 4 }}" font-size="10" fill="#5b6b63" text-anchor="{{ $rtl ? 'start' : 'end' }}">{{ number_format($max * $g) }}</text>
            @endforeach
            @foreach ($series as $s)
                @if ($cmp)
                    @php $pts = []; foreach ($cmp as $i => $r) { $pts[] = round($px($i, count($cmp)), 1).','.round($py((int) $r[$s]), 1); } @endphp
                    <polyline points="{{ implode(' ', $pts) }}" fill="none" stroke="{{ $palette[$s] ?? '#14382a' }}" stroke-opacity=".45" stroke-width="1.6" stroke-dasharray="4 4"/>
                @endif
                @php $pts = []; foreach ($rows as $i => $r) { $pts[] = round($px($i, $n), 1).','.round($py((int) $r[$s]), 1); } @endphp
                <polyline points="{{ implode(' ', $pts) }}" fill="none" stroke="{{ $palette[$s] ?? '#14382a' }}" stroke-width="2.2" stroke-linejoin="round"/>
                @foreach ($rows as $i => $r)<circle cx="{{ round($px($i, $n), 1) }}" cy="{{ round($py((int) $r[$s]), 1) }}" r="2.6" fill="{{ $palette[$s] ?? '#14382a' }}"><title>{{ $r['label'] }} · {{ __('analytics.cols.'.$s) }}: {{ number_format((int) $r[$s]) }}</title></circle>@endforeach
            @endforeach
            @foreach ($rows as $i => $r)
                @if ($i % $lblEvery === 0)<text x="{{ round($px($i, $n), 1) }}" y="{{ $H - 8 }}" font-size="10" fill="#5b6b63" text-anchor="middle">{{ \Illuminate\Support\Str::after($r['label'], '-') ?: $r['label'] }}</text>@endif
            @endforeach
        </svg>
        <div style="display:flex;flex-wrap:wrap;gap:.9rem;font-size:.75rem;color:#4a5a52">
            @foreach ($series as $s)<span style="display:inline-flex;align-items:center;gap:.3rem"><i style="width:.8rem;height:.25rem;background:{{ $palette[$s] ?? '#14382a' }};display:inline-block"></i>{{ __('analytics.cols.'.$s) }}</span>@endforeach
            @if ($cmp)<span>- - - {{ __('analytics.ui.vs') }}</span>@endif
        </div>
    @elseif (in_array($type, ['bar', 'funnel'], true))
        @php $vk = $chart['value']; $lk = $chart['label']; $max = max(1, collect($rows)->max(fn ($r) => (int) ($r[$vk] ?? 0))); @endphp
        <div role="img" aria-label="{{ $report['title'] }}" style="display:flex;flex-direction:column;gap:.35rem">
            @foreach (array_slice($rows, 0, $type === 'funnel' ? 8 : 12) as $r)
                @php $v = (int) ($r[$vk] ?? 0); $w = round(100 * $v / $max); @endphp
                <div style="display:grid;grid-template-columns:minmax(7rem,28%) 1fr 4rem;gap:.6rem;align-items:center;font-size:.8rem">
                    <span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="{{ $r[$lk] }}">{{ $r[$lk] }}</span>
                    <span style="background:#f1ede0;border-radius:.3rem;height:1.05rem;display:block"><span style="display:block;height:100%;width:{{ $type === 'funnel' ? max(4, $w) : $w }}%;background:{{ $type === 'funnel' ? 'linear-gradient(90deg,#14382a,#3f8f6b)' : '#14382a' }};border-radius:.3rem;{{ $type === 'funnel' ? 'margin-inline:auto' : '' }}"></span></span>
                    <span style="text-align:end;font-variant-numeric:tabular-nums">{{ number_format($v) }}</span>
                </div>
            @endforeach
        </div>
    @elseif ($type === 'map')
        @php
            $geo = \App\Services\Analytics\MapData::paths();
            $vals = collect($rows)->filter(fn ($r) => ! empty($r['code']))->pluck('sessions', 'code');
            $max = max(1, $vals->max() ?? 1);
            $shade = fn ($v) => ['#cfe3d6', '#9ccbb0', '#5aa886', '#2f7d5b', '#14382a'][min(4, (int) floor(4 * log(1 + $v) / log(1 + $max)))];
        @endphp
        <svg viewBox="0 0 1010 666" role="img" aria-label="{{ __('analytics.ui.map') }}: {{ $report['title'] }}" style="width:100%;height:auto;max-height:420px;background:#f7f4ea;border-radius:.6rem;direction:ltr">
            <image href="{{ asset('vendor/world-map/world.svg') }}" x="0" y="0" width="1010" height="666"/>
            @foreach ($vals as $code => $v)
                @if (isset($geo[$code]))<path d="{{ $geo[$code] }}" fill="{{ $shade($v) }}" stroke="#fff" stroke-width=".5"><title>{{ \App\Services\Analytics\Labels::country($code) }}: {{ number_format($v) }}</title></path>@endif
            @endforeach
        </svg>
        <div style="display:flex;align-items:center;gap:.4rem;font-size:.72rem;color:#4a5a52">{{ __('analytics.cols.sessions') }}: 0 @foreach (['#cfe3d6', '#9ccbb0', '#5aa886', '#2f7d5b', '#14382a'] as $c)<i style="display:inline-block;width:1.4rem;height:.6rem;background:{{ $c }}"></i>@endforeach {{ number_format($max) }}</div>
    @endif
@endif
