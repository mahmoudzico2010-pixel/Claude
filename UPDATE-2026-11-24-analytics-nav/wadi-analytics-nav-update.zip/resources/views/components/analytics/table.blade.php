@props(['report'])
@php
    use App\Services\Analytics\ReportExporter as X;
    $cols = $report['columns'];
@endphp
@if (empty($report['rows']))
    <p style="font-size:.85rem;color:#6b7280;padding:.6rem 0">{{ __('analytics.ui.empty') }}</p>
@else
    <div style="overflow-x:auto">
        <table class="wr-an-table" data-sortable data-report="{{ $report['key'] }}" style="width:100%;border-collapse:collapse;font-size:.82rem">
            <thead>
                <tr>@foreach ($cols as $i => $c)
                    <th scope="col" data-col="{{ $i }}" data-type="{{ $c['type'] }}" tabindex="0" role="button" title="{{ __('analytics.ui.table') }}" style="text-align:{{ in_array($c['type'], ['int', 'dur', 'pct']) ? 'end' : 'start' }};padding:.45rem .6rem;background:#f1ede0;color:#14382a;font-weight:700;border-bottom:2px solid #b8912f;white-space:nowrap;cursor:pointer">{{ $c['label'] }}</th>
                @endforeach</tr>
            </thead>
            <tbody>
                @foreach ($report['rows'] as $row)
                    <tr style="border-bottom:1px solid #e5e0cf">
                        @foreach ($cols as $c)
                            @php $v = $row[$c['k']] ?? null; $sort = is_array($v) ? ($v['v'] ?? -1) : ($v ?? -1); @endphp
                            <td data-sort="{{ is_scalar($sort) ? $sort : '' }}" style="padding:.4rem .6rem;text-align:{{ in_array($c['type'], ['int', 'dur', 'pct']) ? 'end' : 'start' }};font-variant-numeric:tabular-nums;{{ $c['type'] === 'text' && ($c['k'] === 'next') ? 'font-size:.74rem;color:#4a5a52' : '' }}">
                                @if ($c['type'] === 'country')
                                    @if (! empty($row['code']))<x-flag :code="$row['code']" :height="13" style="margin-inline-end:.4rem;vertical-align:-2px"/>@endif{{ $v }}
                                @else
                                    <bdi dir="auto">{{ X::text($c, $v) }}</bdi>
                                @endif
                            </td>
                        @endforeach
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endif
