@php
    use App\Services\Analytics\ReportExporter as X;
    use App\Support\ArabicShaper as A;
    /* PDF: Arabic is shaped and ordered by App\Support\ArabicShaper (dompdf has neither). Visual order, right aligned. */
    $t = fn ($s) => $rtl ? A::html((string) $s, 64) : e((string) $s);
    $cell = fn ($col, $v) => $rtl ? e(A::visual(X::text($col, $v))) : e(X::text($col, $v));
@endphp
<!doctype html>
<html lang="{{ $locale }}"><head><meta charset="utf-8">
<style>
  @page { margin: 22mm 14mm 18mm; }
  body { font-family: 'DejaVu Sans', sans-serif; font-size: 9.5pt; color: #1c2a24; text-align: {{ $rtl ? 'right' : 'left' }}; }
  h1 { font-size: 17pt; color: #14382a; margin: 0 0 3pt; } h2 { font-size: 12pt; color: #14382a; border-bottom: 1.2pt solid #b8912f; padding-bottom: 2pt; margin: 14pt 0 4pt; }
  .meta { font-size: 8.5pt; color: #5b6b63; margin-bottom: 8pt; line-height: 1.5; }
  table { width: 100%; border-collapse: collapse; margin-top: 4pt; } th { background: #14382a; color: #fff; font-size: 8.5pt; padding: 3pt 4pt; }
  td { border-bottom: .5pt solid #d9d2bd; padding: 3pt 4pt; font-size: 8.5pt; white-space: nowrap; } td.n, th.n { text-align: {{ $rtl ? 'left' : 'right' }}; }
  .bar { background: #b8912f; height: 6pt; } .barbox { width: 90pt; }
  .def { font-size: 8pt; color: #5b6b63; margin-top: 2pt; line-height: 1.5; }
  .box { border: .8pt solid #b8912f; background: #faf6ec; padding: 5pt 7pt; margin-bottom: 6pt; font-size: 8.5pt; }
</style></head><body>
<h1>{!! $t(config('app.name').' — '.__('analytics.nav.overview')) !!}</h1>
<div class="meta">
  @foreach ($filters->describe() as $line)<div>{!! $t($line) !!}</div>@endforeach
  <div>{!! $t(__('analytics.ui.tz').': '.$coverage['timezone']) !!} · {!! $t(__('analytics.ui.refreshed').': '.($coverage['last_refresh'] ?? '—')) !!}</div>
  <div>{!! $t(__('analytics.ui.coverage').': '.($coverage['start'] ?? __('analytics.ui.coverage_none'))) !!}</div>
</div>
<div class="box">{!! $t(__('analytics.def.sessions').' '.__('analytics.def.country')) !!}</div>

@foreach ($reports as $r)
    @continue(empty($r['rows']))
    @php
        $cols = $rtl ? array_reverse($r['columns']) : $r['columns'];
        $chart = $r['chart'] ?? null;
        $barKey = $chart && in_array($chart['type'] ?? '', ['bar', 'funnel'], true) ? ($chart['value'] ?? null) : null;
        $max = $barKey ? max(1, max(array_map(fn ($x) => (int) ($x[$barKey] ?? 0), $r['rows']))) : 1;
    @endphp
    <h2>{!! $t($r['title']) !!}</h2>
    <table>
        <tr>@if ($rtl && $barKey)<th class="barbox"></th>@endif @foreach ($cols as $c)<th class="{{ in_array($c['type'], ['int', 'dur', 'pct']) ? 'n' : '' }}">{!! $t($c['label']) !!}</th>@endforeach @if (! $rtl && $barKey)<th class="barbox"></th>@endif</tr>
        @foreach (array_slice($r['rows'], 0, 25) as $row)
            <tr>
                @if ($rtl && $barKey)<td class="barbox"><div class="bar" style="width: {{ round(100 * (int) ($row[$barKey] ?? 0) / $max) }}%"></div></td>@endif
                @foreach ($cols as $c)<td class="{{ in_array($c['type'], ['int', 'dur', 'pct']) ? 'n' : '' }}">{!! $cell($c, $row[$c['k']] ?? null) !!}</td>@endforeach
                @if (! $rtl && $barKey)<td class="barbox"><div class="bar" style="width: {{ round(100 * (int) ($row[$barKey] ?? 0) / $max) }}%"></div></td>@endif
            </tr>
        @endforeach
    </table>
    @if ($r['denominator'])<div class="def">{!! $t($r['denominator']) !!}</div>@endif
@endforeach
</body></html>
