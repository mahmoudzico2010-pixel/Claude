@php
    use App\Services\Analytics\{AnalyticsSettings, PageContext};
    $__enabled = AnalyticsSettings::enabled() && ! auth()->check();
    $__ctx = $__enabled ? PageContext::signed(request()) : null;
    $__payload = $__ctx ? [
        'ctx' => $__ctx, 'endpoint' => route('analytics.collect'), 'consentRequired' => (bool) AnalyticsSettings::get('consent_required'),
        'timeoutMin' => (int) AnalyticsSettings::get('session_timeout_min'), 'campaignFields' => AnalyticsSettings::campaignFields(),
    ] : null;
@endphp
@if ($__payload)
    <meta name="wr-ctx" content="{{ json_encode($__payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) }}">
    <script src="{{ asset('js/wr-analytics.js') }}?v=1" defer></script>
@endif
