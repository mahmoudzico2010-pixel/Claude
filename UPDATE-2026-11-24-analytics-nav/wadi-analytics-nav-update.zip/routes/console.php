<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Schedule;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');

// Scheduled homepage versions (no queue worker needed; also promoted lazily).
Schedule::command('homepage:publish-due')->everyMinute()->withoutOverlapping(5);

// Housekeeping that needs no queue worker. On shared hosting add one cron line: * * * * * php artisan schedule:run
Schedule::command('uploads:cleanup')->daily()->withoutOverlapping(30);

// RFQ e-mails: the FIRST attempt happens right after the request is saved (no worker, no cron needed). This retries the ones
// that could not be sent. It needs the same cron line; `php artisan mail:diagnose` shows when the scheduler has never run.
Schedule::command('rfq:send-notifications')->everyFiveMinutes()->withoutOverlapping(10);
Schedule::call(function (): void {
    \App\Models\SiteSetting::set('system.scheduler_heartbeat', now()->toIso8601String(), 'string', false);
})->everyMinute()->name('scheduler-heartbeat');

// Visitor analytics: build yesterday's aggregates shortly after midnight (Cairo) and prune past-retention raw rows. Needs the same single cron line.
// A missed run is repaired automatically: with no options the command catches up from the last aggregated day.
Schedule::command('analytics:aggregate --prune')->hourlyAt(7)->withoutOverlapping(30)->name('analytics-aggregate');
