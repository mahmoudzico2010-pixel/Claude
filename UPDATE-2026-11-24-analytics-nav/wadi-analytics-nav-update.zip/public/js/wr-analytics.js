/* Wadi El Rayan first-party visitor measurement. No third party, no fingerprinting.
   Runs only when (a) the server rendered a signed page context, and (b) consent allows it. Fails silently: the site never depends on it. */
(function () {
  'use strict';
  var meta = document.querySelector('meta[name="wr-ctx"]');
  if (!meta) { return; }
  var cfg;
  try { cfg = JSON.parse(meta.getAttribute('content')); } catch (e) { return; }
  var ctx = cfg.ctx, ENDPOINT = cfg.endpoint, TIMEOUT = (cfg.timeoutMin || 30) * 60;
  var started = false, pvUid = null, acc = 0, lastTick = 0, lastInput = Date.now(), flushTimer = null, startedFormOnce = false;

  function rnd() { var a = new Uint8Array(16); (window.crypto || window.msCrypto).getRandomValues(a); return Array.prototype.map.call(a, function (b) { return ('0' + b.toString(16)).slice(-2); }).join(''); }
  function getCookie(n) { var m = document.cookie.match(new RegExp('(?:^|; )' + n + '=([^;]*)')); return m ? decodeURIComponent(m[1]) : ''; }
  function setCookie(n, v, maxAge) { document.cookie = n + '=' + encodeURIComponent(v) + '; Path=/; Max-Age=' + maxAge + '; SameSite=Lax' + (location.protocol === 'https:' ? '; Secure' : ''); }
  function allowed() { var c = getCookie('wr_consent'); if (c === 'denied') { return false; } return !(cfg.consentRequired && c !== 'granted'); }

  function post(body, beacon) {
    body.ctx = ctx; body.sid = getCookie('wr_as') || null;
    var json = JSON.stringify(body);
    try {
      if (beacon && navigator.sendBeacon) { navigator.sendBeacon(ENDPOINT, new Blob([json], { type: 'text/plain' })); return; }
      fetch(ENDPOINT, { method: 'POST', body: json, headers: { 'Content-Type': 'text/plain' }, credentials: 'same-origin', keepalive: true })
        .then(function (r) { return r.json(); })
        .then(function (d) { if (d && d.sid) { setCookie('wr_as', d.sid, TIMEOUT); } })
        .catch(function () {});
    } catch (e) { /* measurement must never break the page */ }
  }

  function host(u) { try { return new URL(u).hostname; } catch (e) { return ''; } }
  function campaign() {
    var out = {}, q = new URLSearchParams(location.search);
    (cfg.campaignFields || []).forEach(function (k) { var v = q.get(k); if (v) { out[k] = v.slice(0, 80); } });
    return out;
  }

  function start() {
    if (started || !allowed()) { return; }
    started = true;
    if (!getCookie('wr_ab')) { setCookie('wr_ab', rnd(), 60 * 60 * 24 * 365); }
    pvUid = rnd();
    var ref = host(document.referrer); if (ref === location.hostname) { ref = ''; }
    post({ type: 'pv', uid: pvUid, bid: getCookie('wr_ab') || null, ref: ref, utm: campaign(), bl: (navigator.language || '').toLowerCase() }, false);
    lastTick = Date.now();
    flushTimer = setInterval(tick, 1000);
    ['mousemove', 'keydown', 'scroll', 'touchstart', 'click'].forEach(function (e) { window.addEventListener(e, function () { lastInput = Date.now(); }, { passive: true }); });
  }

  // Engaged time: only while the tab is visible, focused and not idle (60 s). Paused otherwise; never extrapolated.
  var sinceFlush = 0;
  function tick() {
    var now = Date.now(), dt = Math.min(now - lastTick, 2000); lastTick = now;
    var active = document.visibilityState === 'visible' && document.hasFocus() && (now - lastInput) < 60000;
    if (active) { acc += dt; sinceFlush += dt; }
    if (sinceFlush >= 15000) { flush(false); }
  }
  function flush(beacon) {
    if (acc > 0 && pvUid) { post({ type: 'hb', pv: pvUid, ms: Math.min(acc, 20000) }, beacon); acc = 0; sinceFlush = 0; }
  }
  document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'hidden') { flush(true); } else { lastTick = Date.now(); } });
  window.addEventListener('pagehide', function () { flush(true); });

  function ev(name) { if (!started) { return; } post({ type: 'ev', ev: name, uid: rnd(), pv: pvUid }, true); }
  document.addEventListener('click', function (e) {
    var a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
    if (!a) { return; }
    var h = a.getAttribute('href') || '';
    if (/request-a-quote/.test(h) && !/received/.test(h)) { ev('rfq_click'); }
    else if (/^mailto:/i.test(h)) { ev('mail_click'); }
    else if (/wa\.me|api\.whatsapp\.com/i.test(h)) { ev('whatsapp_click'); }
    else if (/\/documents\/[^/]+\/download|spec-sheet|\.pdf(\?|$)/i.test(h)) { ev('brochure'); }
  }, true);
  document.addEventListener('focusin', function (e) {
    if (startedFormOnce || !e.target || !e.target.closest) { return; }
    var f = e.target.closest('form[action*="request-a-quote"]');
    if (f && /^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName)) { startedFormOnce = true; ev('rfq_start'); }
  });

  // Back/forward cache restores the same page: it is not a new view.
  window.addEventListener('pageshow', function (e) { if (e.persisted) { lastTick = Date.now(); } });

  // ---- consent -----------------------------------------------------------
  var banner = document.getElementById('wr-consent');
  var reopen = document.getElementById('wr-consent-open');
  function choose(granted) {
    setCookie('wr_consent', granted ? 'granted' : 'denied', 60 * 60 * 24 * 180);
    if (!granted) {   // withdrawal: stop, and forget the local identifiers
      started = false; if (flushTimer) { clearInterval(flushTimer); }
      setCookie('wr_as', '', 0); setCookie('wr_ab', '', 0);
    }
    if (banner) { banner.hidden = true; }
    if (reopen) { reopen.hidden = false; }
    if (granted) { start(); }
  }
  window.wrAnalytics = { setConsent: choose };
  if (banner) {
    var c = getCookie('wr_consent');
    if (cfg.consentRequired && !c) { banner.hidden = false; } else if (reopen) { reopen.hidden = false; }
    banner.querySelectorAll('[data-wr-consent]').forEach(function (b) { b.addEventListener('click', function () { choose(b.getAttribute('data-wr-consent') === 'granted'); }); });
    if (reopen) { reopen.addEventListener('click', function () { banner.hidden = false; reopen.hidden = true; }); }
  }
  start();
})();
