<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\NewsPost;
use App\Models\Page;
use App\Models\Product;
use App\Packaging\PackagingCatalog;
use App\Services\Seo\LocaleAvailability;
use App\Support\Locales;
use App\Support\PublicHost;
use Illuminate\Http\Response;

class SitemapController extends Controller
{
    /**
     * One sitemap covering every locale, with hreflang alternates so search
     * engines pair the Arabic and English versions of each URL.
     */
    public function index(): Response
    {
        $locales = Locales::publishedCodes();
        $entries = [];
        $add = function (string $route, array $params, ?\Illuminate\Database\Eloquent\Model $model, array $fields, ?string $lastmod, string $freq, string $priority) use (&$entries, $locales): void {
            foreach ($this->entries($route, $params, $model ? LocaleAvailability::for($model, $fields) : $locales, $lastmod, $freq, $priority) as $e) {
                $entries[] = $e;
            }
        };

        $staticRoutes = [
            'home' => ['priority' => '1.0', 'freq' => 'weekly'],
            'products.index' => ['priority' => '0.9', 'freq' => 'weekly'],
            'packaging.index' => ['priority' => '0.7', 'freq' => 'monthly'],
            'about' => ['priority' => '0.7', 'freq' => 'monthly'],
            'team.index' => ['priority' => '0.5', 'freq' => 'monthly'],
            'quality' => ['priority' => '0.7', 'freq' => 'monthly'],
            'export' => ['priority' => '0.7', 'freq' => 'monthly'],
            'private-label' => ['priority' => '0.7', 'freq' => 'monthly'],
            'news.index' => ['priority' => '0.6', 'freq' => 'weekly'],
            'quote.create' => ['priority' => '0.8', 'freq' => 'monthly'],
            'contact.show' => ['priority' => '0.6', 'freq' => 'monthly'],
        ];

        // Legal routes are listed only once their page has been reviewed — an unreviewed draft must not be advertised.
        foreach (Page::publiclyLinkableLegalPages() as $legalPage) {
            $staticRoutes[$legalPage['key'] === 'privacy' ? 'privacy' : 'terms'] = ['priority' => '0.3', 'freq' => 'yearly'];
        }

        // Packaging pages come from the PUBLISHED catalog only; before the first publish the section is not advertised at all.
        $packaging = app(PackagingCatalog::class);
        if ($packaging->isEmpty()) {
            unset($staticRoutes['packaging.index']);
        } else {
            foreach ($packaging->pageSlugs() as $slug) {
                $add('packaging.show', ['slug' => $slug], null, [], null, 'monthly', '0.6');
            }
        }

        if (! \App\Models\TeamMember::query()->public()->where('show_on_team', true)->exists()) {
            unset($staticRoutes['team.index']); // an empty team page is not advertised
        }

        foreach ($staticRoutes as $name => $meta) {
            $add($name, [], null, [], null, $meta['freq'], $meta['priority']);
        }

        // Categories (families and subcategories) that actually list at least one published product.
        $withProducts = Product::query()->published()->whereNotNull('category_id')->distinct()->pluck('category_id')->all();
        $categories = \App\Models\Category::query()->active()->with('translations')->get();
        $parentsWithProducts = $categories->whereIn('id', $withProducts)->pluck('parent_id')->filter()->all();
        foreach ($categories as $category) {
            if (in_array($category->id, $withProducts, true) || in_array($category->id, $parentsWithProducts, true)) {
                $add('products.category', ['category' => $category->slug], $category, ['name'], $category->updated_at?->toAtomString(), 'monthly', '0.8');
            }
        }

        Product::query()->published()->with('translations')->select(['id', 'slug', 'updated_at'])->chunk(200, function ($products) use ($add): void {
            foreach ($products as $product) {
                $add('products.show', ['product' => $product->slug], $product, ['name'], $product->updated_at?->toAtomString(), 'monthly', '0.8');
            }
        });

        // Parent pages of the varieties that have at least one published product.
        $seen = [];
        foreach (\App\Services\Catalog\CatalogTree::build() as $node) {
            foreach ($node['varieties'] as $v) {
                $slug = $v['variety']->slug;
                if (isset($seen[$slug])) {
                    continue;
                }
                $seen[$slug] = true;
                $add('products.variety', ['variety' => $slug], $v['variety'], ['name'], $v['variety']->updated_at?->toAtomString(), 'monthly', '0.8');
            }
        }

        \App\Models\TeamMember::query()->public()->with('translations')->select(['id', 'slug', 'updated_at'])->get()->each(function ($m) use ($add): void {
            $add('team.show', ['slug' => $m->slug], $m, ['name'], $m->updated_at?->toAtomString(), 'monthly', '0.4');
        });

        NewsPost::query()->published()->with('translations')->select(['id', 'slug', 'updated_at'])->chunk(200, function ($posts) use ($add): void {
            foreach ($posts as $post) {
                $add('news.show', ['post' => $post->slug], $post, ['title'], $post->updated_at?->toAtomString(), 'monthly', '0.5');
            }
        });

        Page::query()->published()->whereNull('key')->with('translations')->select(['id', 'slug', 'updated_at'])->chunk(200, function ($pages) use ($add): void {
            foreach ($pages as $page) {
                $add('page.show', ['page' => $page->slug], $page, ['title'], $page->updated_at?->toAtomString(), 'monthly', '0.5');
            }
        });

        return response()
            ->view('sitemap', ['entries' => $entries])
            ->header('Content-Type', 'application/xml; charset=UTF-8');
    }

    public function robots(): Response
    {
        // A site in maintenance mode should not be indexed at all.
        if (setting('site.maintenance_mode')) {
            return response("User-agent: *\nDisallow: /", 200, ['Content-Type' => 'text/plain; charset=UTF-8']);
        }

        $lines = [
            'User-agent: *',
            'Disallow: /admin',
            'Disallow: /'.trim((string) config('wadi.admin.path', 'admin'), '/'),
            'Disallow: /storage/rfq-attachments',
            '',
            'Sitemap: '.PublicHost::rewrite(route('sitemap')),
        ];

        return response(implode("\n", array_values(array_unique($lines)))."\n")
            ->header('Content-Type', 'text/plain; charset=UTF-8');
    }

    /**
     * One <url> per genuinely available language version, each listing every available version (itself included) and x-default,
     * so the references are reciprocal by construction. All URLs are on the preferred host.
     *
     * @param  array<string, mixed>  $params
     * @param  list<string>  $codes  languages in which this page really exists
     * @return list<array<string, mixed>>
     */
    private function entries(string $route, array $params, array $codes, ?string $lastmod, string $freq, string $priority): array
    {
        $codes = array_values(array_intersect(Locales::publishedCodes(), $codes));
        if ($codes === []) {
            $codes = [Locales::default()];
        }
        // Never advertise an address the router would answer with 404 (a slug with spaces, accents or other characters the routes refuse).
        foreach ($params as $value) {
            if (is_string($value) && preg_match('/^[A-Za-z0-9]+(?:-[A-Za-z0-9]+)*$/', $value) !== 1) {
                return [];
            }
        }
        $url = fn (string $l): string => PublicHost::rewrite(route($route, ['locale' => $l] + $params));
        $alternates = [];
        foreach ($codes as $l) {
            $alternates[(string) config('wadi.locales.'.$l.'.hreflang', $l)] = $url($l);
        }
        $alternates['x-default'] = $url(in_array(Locales::default(), $codes, true) ? Locales::default() : $codes[0]);

        $out = [];
        foreach ($codes as $l) {
            $out[] = ['loc' => $url($l), 'lastmod' => $lastmod, 'changefreq' => $freq, 'priority' => $priority, 'alternates' => $alternates];
        }

        return $out;
    }
}
