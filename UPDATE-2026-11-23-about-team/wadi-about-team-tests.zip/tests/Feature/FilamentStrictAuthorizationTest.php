<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Filament\Pages\DatabaseBackups;
use App\Filament\Pages\Diagnostics;
use App\Filament\Pages\HomepageManager;
use App\Filament\Pages\InterfaceTexts;
use App\Filament\Pages\Languages;
use App\Filament\Pages\LaunchChecklist;
use App\Filament\Pages\ManageHomepage;
use App\Filament\Pages\ManageSettings;
use App\Filament\Pages\ManageTheme;
use App\Filament\Pages\NavigationManager;
use App\Filament\Pages\PackagingCatalog;
use App\Filament\Pages\PageBuilder;
use App\Filament\Pages\UploadLargeFiles;
use App\Filament\Pages\AutomaticLanguage;
use App\Filament\Pages\ContentTranslations;
use App\Filament\Pages\EmailSettings;
use App\Filament\Pages\UploadLimitsSettings;
use App\Filament\Resources\Content\HeroSlideResource;
use App\Filament\Resources\Content\HomeSectionResource;
use App\Filament\Resources\System\AuditLogResource;
use App\Filament\Resources\Users\UserResource;
use App\Filament\Widgets\RecentInquiries;
use App\Filament\Widgets\RequestsByMonthChart;
use App\Models\AuditLog;
use App\Models\User;
use App\Support\Permissions;
use Database\Seeders\RolePermissionSeeder;
use Filament\Facades\Filament;
use Filament\Pages\Dashboard;
use Filament\Resources\Resource;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Gate;
use LogicException;
use PHPUnit\Framework\Attributes\Test;
use ReflectionMethod;
use Tests\TestCase;

/**
 * Filament runs in strict authorization mode: a resource whose model has no
 * policy, or whose policy lacks an ability Filament asks about, throws instead
 * of quietly falling back to the permissive Gate default.
 *
 * This file proves coverage rather than assuming it. It enumerates every
 * resource, page and widget registered in the panel and, for every role,
 * checks every ability Filament can ask about against an independently
 * written expectation table.
 */
class FilamentStrictAuthorizationTest extends TestCase
{
    use RefreshDatabase;

    /** Every ability a Filament resource asks the policy about. */
    private const ABILITIES = [
        'viewAny', 'view', 'create', 'update', 'delete', 'deleteAny',
        'forceDelete', 'forceDeleteAny', 'reorder', 'replicate', 'restore', 'restoreAny',
    ];

    protected function setUp(): void
    {
        parent::setUp();

        $this->seed(RolePermissionSeeder::class);
        Filament::setCurrentPanel('admin');
    }

    private function userWithRole(string $role, bool $active = true): User
    {
        $user = User::factory()->create(['is_active' => $active]);
        $user->assignRole($role);

        return $user->fresh();
    }

    /** @return array<int, class-string<resource>> */
    private function resources(): array
    {
        return array_values(Filament::getPanel('admin')->getResources());
    }

    /**
     * Resource => ability => permission that grants it (false = nobody but the
     * Super Admin hook may, null = special rule asserted elsewhere).
     *
     * Written by hand on purpose: it must not be derived from the policies it
     * checks.
     *
     * @return array<string, array<string, string|false>>
     */
    private function expectations(): array
    {
        $standard = fn (string $view, string $create, string $update, string $delete): array => [
            'viewAny' => $view, 'view' => $view,
            'create' => $create, 'replicate' => $create,
            'update' => $update, 'reorder' => $update,
            'delete' => $delete, 'deleteAny' => $delete,
            'restore' => $delete, 'restoreAny' => $delete,
            'forceDelete' => false, 'forceDeleteAny' => false,
        ];

        $classification = $standard(Permissions::CLASSIFICATIONS_VIEW, Permissions::CLASSIFICATIONS_MANAGE, Permissions::CLASSIFICATIONS_MANAGE, Permissions::CLASSIFICATIONS_MANAGE);
        $content = $standard(Permissions::CONTENT_VIEW, Permissions::CONTENT_MANAGE, Permissions::CONTENT_MANAGE, Permissions::CONTENT_MANAGE);

        $table = [];
        foreach ([
            'Classifications\CalibersResource', 'Classifications\CategoriesResource',
            'Classifications\CertificationsResource', 'Classifications\ExportMarketsResource',
            'Classifications\NewsCategoriesResource', 'Classifications\ProductFormsResource',
            'Classifications\VarietiesResource', 'ProductFrames\ProductFramesResource',
        ] as $r) {
            $table['App\Filament\Resources\\'.$r] = $classification;
        }
        foreach ([
            'Company\CompanyLocationResource', 'Content\ContentBlockResource',
            'Content\HeroSlideResource', 'Content\HomeSectionResource',
            'Content\NavigationItemResource', 'Content\PageResource',
            'Documents\DocumentResource',
        ] as $r) {
            $table['App\Filament\Resources\\'.$r] = $content;
        }

        // Team: view / edit are separate from archiving (structure). Publishing is checked on the publish action.
        $team = $standard(Permissions::TEAM_VIEW, Permissions::TEAM_EDIT, Permissions::TEAM_EDIT, Permissions::TEAM_STRUCTURE);
        $table['App\Filament\Resources\Team\TeamMemberResource'] = $team;
        $table['App\Filament\Resources\Team\TeamDepartmentResource'] = $team;

        $table['App\Filament\Resources\Products\ProductResource'] = $standard(Permissions::PRODUCTS_VIEW, Permissions::PRODUCTS_CREATE, Permissions::PRODUCTS_UPDATE, Permissions::PRODUCTS_DELETE);
        $table['App\Filament\Resources\News\NewsPostResource'] = $standard(Permissions::NEWS_VIEW, Permissions::NEWS_CREATE, Permissions::NEWS_UPDATE, Permissions::NEWS_DELETE);
        $table['App\Filament\Resources\Media\MediaAssetResource'] = $standard(Permissions::MEDIA_VIEW, Permissions::MEDIA_UPLOAD, Permissions::MEDIA_UPLOAD, Permissions::MEDIA_DELETE);

        // Messages arrive only from the public form: staff cannot create or
        // duplicate one, whatever they hold.
        $contact = $standard(Permissions::CONTACTS_VIEW, Permissions::CONTACTS_VIEW, Permissions::CONTACTS_UPDATE, Permissions::CONTACTS_DELETE);
        $contact['create'] = false;
        $contact['replicate'] = false;
        $table['App\Filament\Resources\ContactMessages\ContactMessageResource'] = $contact;

        // Inquiries arrive only from the public form as well.
        $rfq = $standard(Permissions::RFQ_VIEW, Permissions::RFQ_VIEW, Permissions::RFQ_UPDATE, Permissions::RFQ_DELETE);
        $rfq['create'] = false;
        $rfq['replicate'] = false;
        $rfq['reorder'] = false;
        $table['App\Filament\Resources\QuoteRequests\QuoteRequestResource'] = $rfq;

        // Append-only: readable by permission, nothing else for anybody.
        $audit = array_fill_keys(self::ABILITIES, false);
        $audit['viewAny'] = Permissions::AUDIT_VIEW;
        $audit['view'] = Permissions::AUDIT_VIEW;
        $table['App\Filament\Resources\System\AuditLogResource'] = $audit;

        // Plugins: Super Admin only. No role can be granted any ability (it is
        // deliberately not in the permission matrix).
        $table['App\Filament\Resources\Modules\ModuleResource'] = array_fill_keys(self::ABILITIES, false);

        $users = $standard(Permissions::USERS_VIEW, Permissions::USERS_CREATE, Permissions::USERS_UPDATE, Permissions::USERS_DELETE);
        $users['replicate'] = false;
        $users['reorder'] = false;
        $table['App\Filament\Resources\Users\UserResource'] = $users;

        return $table;
    }

    private function ask(string $resource, string $ability, ?Model $record): bool
    {
        /** @var class-string<resource> $resource */
        return $resource::can($ability, $record);
    }

    private function recordFor(string $resource): Model
    {
        $model = $resource::getModel();

        return new $model;
    }

    // ------------------------------------------------------ enumeration

    #[Test]
    public function the_admin_panel_runs_in_strict_authorization_mode(): void
    {
        $this->assertTrue(Filament::getPanel('admin')->isAuthorizationStrict());
    }

    #[Test]
    public function every_registered_resource_is_in_the_expectation_table(): void
    {
        $registered = $this->resources();
        sort($registered);
        $declared = array_keys($this->expectations());
        sort($declared);

        $this->assertSame(
            $declared,
            $registered,
            'A resource was added or removed without updating the authorization matrix.'
        );
    }

    #[Test]
    public function every_resource_model_has_a_policy_with_every_ability_filament_asks_about(): void
    {
        foreach ($this->resources() as $resource) {
            $model = $resource::getModel();
            $policy = Gate::getPolicyFor($model);

            $this->assertNotNull($policy, "{$model} (used by {$resource}) has no policy.");

            foreach (self::ABILITIES as $ability) {
                $this->assertTrue(
                    method_exists($policy, $ability),
                    $policy::class." lacks ability [{$ability}] asked about by {$resource}."
                );
            }
        }
    }

    #[Test]
    public function no_resource_overrides_its_policy_with_a_more_permissive_hand_rolled_check(): void
    {
        // The two retired homepage editors force their write abilities off
        // (the Homepage Manager replaced them). That can only restrict, so it
        // is allowed, and proven to refuse even the Super Admin below. Any
        // other override would bypass the policy.
        $retired = [
            HeroSlideResource::class,
            HomeSectionResource::class,
        ];
        $mayRestrict = ['canCreate', 'canEdit', 'canDelete', 'canDeleteAny'];

        $this->actingAs($this->userWithRole(User::ROLE_SUPER_ADMIN));

        foreach ($this->resources() as $resource) {
            foreach (['canCreate', 'canEdit', 'canDelete', 'canDeleteAny', 'canView', 'canViewAny',
                'canForceDelete', 'canForceDeleteAny', 'canRestore', 'canRestoreAny', 'canReplicate', 'canReorder'] as $method) {
                $declaring = (new ReflectionMethod($resource, $method))->getDeclaringClass()->getName();

                if ($declaring === Resource::class) {
                    continue;
                }

                $this->assertContains($resource, $retired, "{$resource} overrides {$method}(), which bypasses its policy.");
                $this->assertContains($method, $mayRestrict, "{$resource}::{$method}() is overridden.");

                $arguments = in_array($method, ['canCreate', 'canDeleteAny'], true) ? [] : [$this->recordFor($resource)];
                $this->assertFalse($resource::$method(...$arguments), "{$resource}::{$method}() must only ever refuse.");
            }
        }
    }

    // ----------------------------------------------- resource role matrix

    #[Test]
    public function every_role_gets_exactly_the_documented_answer_for_every_resource_ability(): void
    {
        $matrix = Permissions::matrix();
        $expectations = $this->expectations();
        $checked = 0;

        foreach ([User::ROLE_ADMIN, User::ROLE_SALES, User::ROLE_CONTENT_EDITOR, User::ROLE_VIEWER] as $role) {
            $this->actingAs($this->userWithRole($role));

            foreach ($this->resources() as $resource) {
                foreach (self::ABILITIES as $ability) {
                    $needs = $expectations[$resource][$ability];
                    $expected = $needs !== false && in_array($needs, $matrix[$role], true);

                    // An existing, ordinary record. User records are handled
                    // in their own test because their rules depend on the
                    // record and the actor.
                    if ($resource === UserResource::class) {
                        continue;
                    }

                    $this->assertSame(
                        $expected,
                        $this->ask($resource, $ability, $this->recordFor($resource)),
                        "{$role} / ".class_basename($resource)." / {$ability} (needs ".($needs ?: 'nobody').')'
                    );
                    $checked++;
                }
            }
        }

        $this->assertGreaterThan(500, $checked);
    }

    #[Test]
    public function the_super_admin_is_allowed_everything_except_what_policies_refuse_to_anyone(): void
    {
        $this->actingAs($this->userWithRole(User::ROLE_SUPER_ADMIN));

        foreach ($this->resources() as $resource) {
            foreach (self::ABILITIES as $ability) {
                $immutable = $resource === AuditLogResource::class
                    && ! in_array($ability, ['viewAny', 'view'], true);

                if ($resource === UserResource::class) {
                    continue;
                }

                $this->assertSame(
                    ! $immutable,
                    $this->ask($resource, $ability, $this->recordFor($resource)),
                    'Super Admin / '.class_basename($resource)." / {$ability}"
                );
            }
        }
    }

    #[Test]
    public function the_audit_trail_is_append_only_even_for_the_super_admin(): void
    {
        $super = $this->userWithRole(User::ROLE_SUPER_ADMIN);
        $log = new AuditLog;

        foreach (['create', 'update', 'delete', 'deleteAny', 'restore', 'restoreAny', 'forceDelete', 'forceDeleteAny', 'replicate', 'reorder'] as $ability) {
            $arguments = in_array($ability, ['deleteAny', 'restoreAny', 'forceDeleteAny', 'create', 'reorder'], true)
                ? [AuditLog::class] : [$log];

            $this->assertFalse(Gate::forUser($super)->allows($ability, $arguments), "Super Admin may {$ability} the audit trail.");
        }

        $this->assertTrue(Gate::forUser($super)->allows('viewAny', [AuditLog::class]));
        $this->assertTrue(Gate::forUser($super)->allows('view', [$log]));
    }

    #[Test]
    public function user_account_rules_still_hold_in_strict_mode(): void
    {
        $matrix = Permissions::matrix();
        $resource = UserResource::class;
        $target = $this->userWithRole(User::ROLE_VIEWER);

        foreach ([User::ROLE_ADMIN, User::ROLE_SALES, User::ROLE_CONTENT_EDITOR, User::ROLE_VIEWER] as $role) {
            $this->actingAs($this->userWithRole($role));

            foreach (['viewAny' => Permissions::USERS_VIEW, 'view' => Permissions::USERS_VIEW,
                'create' => Permissions::USERS_CREATE, 'update' => Permissions::USERS_UPDATE,
                'delete' => Permissions::USERS_DELETE, 'deleteAny' => Permissions::USERS_DELETE,
                'restore' => Permissions::USERS_DELETE, 'restoreAny' => Permissions::USERS_DELETE] as $ability => $needs) {
                $this->assertSame(
                    in_array($needs, $matrix[$role], true),
                    $this->ask($resource, $ability, in_array($ability, ['viewAny', 'create', 'deleteAny', 'restoreAny'], true) ? null : $target),
                    "{$role} / User / {$ability}"
                );
            }

            foreach (['forceDelete', 'forceDeleteAny', 'replicate', 'reorder'] as $ability) {
                $this->assertFalse($this->ask($resource, $ability, in_array($ability, ['forceDeleteAny', 'reorder'], true) ? null : $target), "{$role} / User / {$ability}");
            }
        }

        // Nobody deletes themselves, the Super Admin included.
        $super = $this->userWithRole(User::ROLE_SUPER_ADMIN);
        $this->userWithRole(User::ROLE_SUPER_ADMIN);
        $this->actingAs($super);
        $this->assertFalse($this->ask($resource, 'delete', $super));
        $this->assertTrue($this->ask($resource, 'delete', $target));

        // An Admin may not act on a Super Admin.
        $this->actingAs($this->userWithRole(User::ROLE_ADMIN));
        $this->assertFalse($this->ask($resource, 'update', $super));
        $this->assertFalse($this->ask($resource, 'delete', $super));
    }

    #[Test]
    public function a_deactivated_user_is_refused_everything_in_every_role(): void
    {
        foreach ([User::ROLE_SUPER_ADMIN, User::ROLE_ADMIN, User::ROLE_SALES, User::ROLE_CONTENT_EDITOR, User::ROLE_VIEWER] as $role) {
            $user = $this->userWithRole($role, active: false);
            $this->actingAs($user);

            $this->assertFalse($user->canAccessPanel(Filament::getPanel('admin')), "{$role} deactivated can enter the panel");

            foreach ($this->resources() as $resource) {
                foreach (self::ABILITIES as $ability) {
                    $this->assertFalse(
                        $this->ask($resource, $ability, $this->recordFor($resource)),
                        "Deactivated {$role} / ".class_basename($resource)." / {$ability}"
                    );
                }

                $this->assertFalse($resource::canAccess(), "Deactivated {$role} reaches ".class_basename($resource));
            }

            foreach (Permissions::all() as $permission) {
                $this->assertFalse($user->can($permission), "Deactivated {$role} holds {$permission}");
            }
        }
    }

    // ------------------------------------------------ resource navigation

    #[Test]
    public function resource_access_matches_the_view_permission_for_every_role(): void
    {
        $matrix = Permissions::matrix();
        $expectations = $this->expectations();

        foreach ([User::ROLE_ADMIN, User::ROLE_SALES, User::ROLE_CONTENT_EDITOR, User::ROLE_VIEWER] as $role) {
            $this->actingAs($this->userWithRole($role));

            foreach ($this->resources() as $resource) {
                $needs = $expectations[$resource]['viewAny'];

                $this->assertSame(
                    in_array($needs, $matrix[$role], true),
                    $resource::canAccess(),
                    "{$role} / ".class_basename($resource).' canAccess()'
                );
            }
        }
    }

    // ----------------------------------------------------- pages, widgets

    /** @return array<string, string> page => permission */
    private function pagePermissions(): array
    {
        return [
            HomepageManager::class => Permissions::HOMEPAGE_VIEW,
            ManageHomepage::class => Permissions::HOMEPAGE_VIEW,
            LaunchChecklist::class => Permissions::SETTINGS_VIEW,
            ManageSettings::class => Permissions::SETTINGS_VIEW,
            ManageTheme::class => Permissions::SETTINGS_VIEW,
            \App\Filament\Pages\ManageProductFrame::class => Permissions::SETTINGS_VIEW,
            \App\Filament\Pages\BulkProductEdit::class => Permissions::PRODUCTS_UPDATE,
            \App\Filament\Pages\PageHeaderEditor::class => Permissions::CONTENT_VIEW,
            \App\Filament\Pages\PhotoReviewQueue::class => Permissions::PRODUCTS_UPDATE,
            PageBuilder::class => Permissions::CONTENT_VIEW,
            \App\Filament\Pages\TeamStructure::class => Permissions::TEAM_VIEW,
            PackagingCatalog::class => Permissions::PACKAGING_VIEW,
            InterfaceTexts::class => Permissions::LANGUAGES_VIEW,
            NavigationManager::class => Permissions::CONTENT_MANAGE,
            DatabaseBackups::class => Permissions::SETTINGS_SENSITIVE,
            Diagnostics::class => Permissions::SETTINGS_SENSITIVE,
            UploadLargeFiles::class => Permissions::MEDIA_UPLOAD,
            UploadLimitsSettings::class => Permissions::SETTINGS_SENSITIVE,
            AutomaticLanguage::class => Permissions::SETTINGS_SENSITIVE,
            Languages::class => Permissions::LANGUAGES_VIEW,
            ContentTranslations::class => Permissions::LANGUAGES_VIEW,
            EmailSettings::class => Permissions::SETTINGS_VIEW,
        ];
    }

    #[Test]
    public function every_registered_page_is_in_the_matrix_and_gated_by_its_permission(): void
    {
        $registered = array_values(Filament::getPanel('admin')->getPages());
        $declared = array_merge(array_keys($this->pagePermissions()), [Dashboard::class]);
        sort($registered);
        sort($declared);
        $this->assertSame($declared, $registered, 'A page was added without a permission entry.');

        $matrix = Permissions::matrix();

        foreach ([User::ROLE_ADMIN, User::ROLE_SALES, User::ROLE_CONTENT_EDITOR, User::ROLE_VIEWER] as $role) {
            $this->actingAs($this->userWithRole($role));

            foreach ($this->pagePermissions() as $page => $needs) {
                $this->assertSame(in_array($needs, $matrix[$role], true), $page::canAccess(), "{$role} / {$page}");
            }
        }

        $this->actingAs($this->userWithRole(User::ROLE_SUPER_ADMIN));
        foreach ($this->pagePermissions() as $page => $needs) {
            $this->assertTrue($page::canAccess(), "Super Admin / {$page}");
        }

        $this->actingAs($this->userWithRole(User::ROLE_VIEWER, active: false));
        foreach ($this->pagePermissions() as $page => $needs) {
            $this->assertFalse($page::canAccess(), "Deactivated / {$page}");
        }
    }

    #[Test]
    public function every_dashboard_widget_is_gated_by_a_permission(): void
    {
        $widgets = Filament::getPanel('admin')->getWidgets();

        foreach ($widgets as $widget) {
            $declaring = (new ReflectionMethod($widget, 'canView'))->getDeclaringClass()->getName();
            $this->assertSame($widget, $declaring, "{$widget} relies on the default canView(), which allows everyone.");
        }

        $this->actingAs($this->userWithRole(User::ROLE_CONTENT_EDITOR));
        $this->assertFalse(RecentInquiries::canView());
        $this->assertFalse(RequestsByMonthChart::canView());

        $this->actingAs($this->userWithRole(User::ROLE_SALES));
        $this->assertTrue(RecentInquiries::canView());

        $this->actingAs($this->userWithRole(User::ROLE_VIEWER, active: false));
        foreach ($widgets as $widget) {
            $this->assertFalse($widget::canView(), "Deactivated user sees {$widget}");
        }
    }

    // ------------------------------------------------- no permissive path

    #[Test]
    public function a_model_without_a_policy_throws_in_strict_mode_instead_of_allowing(): void
    {
        $this->actingAs($this->userWithRole(User::ROLE_SUPER_ADMIN));

        $this->expectException(LogicException::class);
        $this->expectExceptionMessage('Strict authorization mode is enabled');

        \Filament\get_authorization_response('viewAny', UnpolicedModel::class)->allowed();
    }

    #[Test]
    public function a_policy_missing_an_ability_throws_in_strict_mode_instead_of_allowing(): void
    {
        $this->actingAs($this->userWithRole(User::ROLE_SUPER_ADMIN));
        Gate::policy(UnpolicedModel::class, PartialPolicy::class);

        $this->assertTrue(\Filament\get_authorization_response('viewAny', UnpolicedModel::class)->allowed());

        $this->expectException(LogicException::class);
        $this->expectExceptionMessage('no [replicate()] method');

        \Filament\get_authorization_response('replicate', UnpolicedModel::class)->allowed();
    }
}

class UnpolicedModel extends Model {}

class PartialPolicy
{
    public function viewAny(User $user): bool
    {
        return true;
    }
}
