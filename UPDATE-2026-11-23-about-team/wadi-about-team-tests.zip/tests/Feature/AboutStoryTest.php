<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Models\BuilderNode;
use App\Models\Page;
use App\Models\SiteSetting;
use App\Models\TeamMember;
use App\Services\About\AboutStory;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Cache;
use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;

final class AboutStoryTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(); // DatabaseSeeder builds the About story as its last step
        SiteSetting::setMany(['maintenance_mode' => false], 'site');
        config(['wadi.published' => array_keys(config('wadi.locales')), 'wadi.expose_unpublished_locales' => true]);
        Cache::flush();
    }

    #[Test]
    public function a_fresh_install_publishes_the_story_in_all_ten_languages_with_one_h1_and_real_links(): void
    {
        foreach (array_keys(config('wadi.locales')) as $loc) {
            $html = $this->get("/$loc/about")->assertOk()->getContent();
            $this->assertSame(1, substr_count($html, '<h1'), "$loc: exactly one H1");
            $this->assertStringContainsString(trim((string) json_decode((string) file_get_contents(database_path('data/about-story.json')), true)['ch1_title'][$loc]), $html, "$loc chapter 1");
            $this->assertStringContainsString('/'.$loc.'/team', $html, "$loc links to the team page");
            $this->assertStringContainsString('/'.$loc.'/products', $html);
            $this->assertStringContainsString('/'.$loc.'/contact', $html);
        }
        $ar = $this->get('/ar/about')->getContent();
        foreach (['جذورنا في الفيوم', 'قبل المصنع، كانت هناك شجرة زيتون', 'في الفيوم بدأت الحكاية', 'التصدير أولًا، ثم المصنع', 'وراء كل طلبية'] as $needle) {
            $this->assertStringContainsString($needle, $ar);
        }
    }

    #[Test]
    public function nothing_unverified_is_published_no_naming_line_no_capacity_claim_no_invented_facts(): void
    {
        foreach (['en', 'ar'] as $loc) {
            $html = $this->get("/$loc/about")->getContent();
            $this->assertStringNotContainsString('وادي الريان.»', $html);
            $this->assertStringNotContainsString('he carried with him the name of the place', $html, 'naming-origin paragraph stays in draft');
            $this->assertStringNotContainsString('Wadi El Natrun', $html);
            foreach (['largest', 'most capable', 'أكبر', 'Capacity'] as $claim) {
                $this->assertStringNotContainsString($claim, $html, $claim);
            }
        }
        $page = Page::query()->where('key', 'about')->first();
        $naming = BuilderNode::query()->forPage('page:'.$page->slug)->where('type', 'section')->where('is_enabled', false)->count();
        $this->assertSame(1, $naming, 'one disabled, editable naming-origin section');
    }

    #[Test]
    public function running_it_again_never_duplicates_or_replaces_editorial_content(): void
    {
        $key = 'page:about';
        $before = BuilderNode::query()->forPage($key)->count();
        $heading = BuilderNode::query()->forPage($key)->where('type', 'heading')->firstOrFail();
        $heading->translations()->updateOrCreate(['locale' => 'en'], ['content' => ['text' => 'A heading the owner rewrote']]);
        $report = app(AboutStory::class)->run();
        app(AboutStory::class)->run();
        $this->assertSame($before, BuilderNode::query()->forPage($key)->count());
        $this->assertStringContainsString('kept', $report['layout']);
        $this->assertSame('A heading the owner rewrote', $heading->fresh()->t('text', 'en'));
        $this->assertSame(1, \App\Models\PageHeader::query()->where('page_key', $key)->count());
    }

    #[Test]
    public function an_existing_site_with_its_own_about_text_gets_a_draft_and_the_live_page_is_untouched(): void
    {
        BuilderNode::query()->forPage('page:about')->get()->each->delete();
        \App\Models\BuilderRevision::query()->where('page_key', 'page:about')->delete();
        \App\Models\PageHeader::query()->where('page_key', 'page:about')->delete();
        $page = Page::query()->where('key', 'about')->first();
        $page->translations()->where('locale', 'en')->update(['body' => '<p>The owner wrote this about us himself.</p>']);
        Cache::flush();
        $report = app(AboutStory::class)->run();
        $this->assertStringContainsString('DRAFT', $report['layout']);
        $html = $this->get('/en/about')->assertOk()->getContent();
        $this->assertStringContainsString('The owner wrote this about us himself.', $html);
        $this->assertStringNotContainsString('The story began in Fayoum', $html);
    }

    #[Test]
    public function the_team_preview_shows_only_published_members_marked_for_about_and_the_evidence_block_needs_approval(): void
    {
        $a = TeamMember::create(['slug' => 'on-about', 'status' => 'published', 'show_on_about' => true]);
        $a->saveTranslations(['en' => ['name' => 'On About Person']]);
        $b = TeamMember::create(['slug' => 'not-on-about', 'status' => 'published', 'show_on_about' => false]);
        $b->saveTranslations(['en' => ['name' => 'Not On About Person']]);
        $c = TeamMember::create(['slug' => 'draft-on-about', 'status' => 'draft', 'show_on_about' => true]);
        $c->saveTranslations(['en' => ['name' => 'Draft On About Person']]);
        Cache::flush();
        $html = $this->get('/en/about')->getContent();
        $this->assertStringContainsString('On About Person', $html);
        $this->assertStringNotContainsString('Not On About Person', $html);
        $this->assertStringNotContainsString('Draft On About Person', $html);

        $node = BuilderNode::query()->forPage('page:about')->where('type', 'evidence_block')->firstOrFail();
        $node->settings = array_merge((array) $node->settings, ['approved' => 'on', 'figure' => '1,000', 'as_of' => '2026-01']);
        $node->save();
        app(\App\Services\Builder\RevisionManager::class)->publish('page:about');
        Cache::flush();
        $this->assertStringNotContainsString('1,000', $this->get('/en/about')->getContent(), 'incomplete evidence (no unit/scope/source) stays hidden');
    }

    #[Test]
    public function the_about_banner_draft_does_not_reach_visitors_until_it_is_published(): void
    {
        $svc = app(\App\Services\PageHeaders\PageHeaderService::class);
        $draft = $svc->draft('page:about');
        $s = $draft['settings'];
        $s['title']['en'] = 'A new draft headline';
        $svc->saveDraft('page:about', 'custom', $s, null);
        Cache::flush();
        $html = $this->get('/en/about')->getContent();
        $this->assertStringContainsString('Before the factory, there was an olive tree', $html);
        $this->assertStringNotContainsString('A new draft headline', $html);
        $svc->publish('page:about');
        $this->assertStringContainsString('A new draft headline', $this->get('/en/about')->getContent());
        $other = $this->get('/en/contact')->getContent();
        $this->assertStringNotContainsString('A new draft headline', $other, 'another page banner is unaffected');
    }
}
