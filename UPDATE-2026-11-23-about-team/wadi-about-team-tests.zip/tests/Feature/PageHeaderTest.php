<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Filament\Pages\PageBuilder;
use App\Models\MediaAsset;
use App\Models\Page;
use App\Models\PageHeader;
use App\Models\SiteSetting;
use App\Models\User;
use App\Services\PageHeaders\PageHeaderService;
use Filament\Facades\Filament;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Livewire\Livewire;
use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;

/** Per-page "Page Header / Hero": independent, draft/publish, opacity semantics, builder selection. */
final class PageHeaderTest extends TestCase
{
    use RefreshDatabase;

    private MediaAsset $photo;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
        Filament::setCurrentPanel('admin');
        SiteSetting::setMany(['maintenance_mode' => false], 'site');
        $this->photo = MediaAsset::create(['disk' => 'public', 'path' => 'headers/factory.webp', 'filename' => 'factory.webp', 'original_filename' => 'factory.webp', 'mime_type' => 'image/webp', 'extension' => 'webp', 'size' => 5, 'width' => 1920, 'height' => 800]);
        $u = User::factory()->create(['is_active' => true]);
        $u->assignRole(User::ROLE_ADMIN);
        $this->actingAs($u);
    }

    private function svc(): PageHeaderService
    {
        return app(PageHeaderService::class);
    }

    private function body(string $path): string
    {
        \Illuminate\Support\Facades\Cache::flush();

        $html = (string) $this->get($path)->assertOk()->getContent();

        // per-request tokens/nonces differ between any two requests; the comparison is about the page itself
        return (string) preg_replace(['/(_token"[^>]*value=")[^"]+/', '/(csrf-token" content=")[^"]+/', '/nonce="[^"]*"/', '/[A-Za-z0-9]{40}/', '/wrm[0-9a-f]{5,8}/'], ['$1X', '$1X', '', 'T', 'wrmX'], $html);
    }

    #[Test]
    public function pages_keep_their_current_banner_until_somebody_customises_one(): void
    {
        // (/about carries the seeded story banner, covered by AboutStoryTest)
        foreach (['/en/contact', '/en/export', '/ar/contact'] as $url) {
            $html = $this->body($url);
            $this->assertStringContainsString('bg-forest', $html, $url);
            $this->assertStringNotContainsString('data-page-header', $html, $url);
            $this->assertSame(1, substr_count($html, '<h1'), "$url has exactly one main title");
        }
    }

    #[Test]
    public function contact_us_gets_a_photo_and_overlay_while_export_and_about_are_untouched_and_drafts_stay_private_until_published(): void
    {
        $exportBefore = $this->body('/en/export');
        $aboutBefore = $this->body('/en/about');
        $publicBefore = $this->body('/en/contact');

        $this->svc()->saveDraft('page:contact-us', 'custom', ['image_id' => $this->photo->id, 'overlay_color' => '#0b3d2e', 'overlay_opacity' => 35, 'image_opacity' => 100], auth()->user());

        $this->assertSame($publicBefore, $this->body('/en/contact'), 'an unpublished draft is invisible to visitors');
        $this->assertSame($exportBefore, $this->body('/en/export'));

        $preview = (string) $this->get(route('admin.builder.header-preview', ['key' => 'page:contact-us', 'locale' => 'en']))->assertOk()->getContent();
        $this->assertStringContainsString('opacity:0.35', $preview);
        $this->assertStringContainsString('headers/factory.webp', $preview);
        $this->assertStringContainsString('data-builder-node="header"', $preview, 'the banner is the selectable "header" item');

        $this->svc()->publish('page:contact-us', auth()->user());
        $live = $this->body('/en/contact');
        $this->assertStringContainsString('headers/factory.webp', $live);
        $this->assertStringContainsString('data-page-header', $live);
        $this->assertSame(1, substr_count($live, '<h1'), 'one main title');
        $this->assertSame(1, substr_count($live, 'data-page-header>') + substr_count($live, 'data-page-header '), 'one banner');
        $this->assertSame($exportBefore, $this->body('/en/export'), 'Export did not change');
        $this->assertSame($aboutBefore, $this->body('/en/about'), 'About did not change');
        $this->assertStringContainsString('Contact Us', $live);
    }

    #[Test]
    public function an_explicit_zero_overlay_persists_and_never_fades_the_photo_or_the_text(): void
    {
        $this->svc()->saveDraft('page:contact-us', 'custom', ['image_id' => $this->photo->id, 'overlay_opacity' => 0, 'image_opacity' => 80], auth()->user());
        $this->svc()->publish('page:contact-us');

        $reloaded = $this->svc()->draft('page:contact-us')['settings'];
        $this->assertSame(0, $reloaded['overlay_opacity'], 'zero is kept, not replaced by a default');
        $this->assertSame(80, $reloaded['image_opacity']);

        $html = $this->body('/en/contact');
        $this->assertMatchesRegularExpression('/data-page-header-overlay style="[^"]*opacity:0[;"]/', $html);
        $this->assertStringContainsString('opacity:0.8', $html);                                  // photo only
        $this->assertDoesNotMatchRegularExpression('/<h1[^>]*opacity/', $html, 'the title is never faded');
        $this->assertStringContainsString('headers/factory.webp', $html, 'the photo is still there');
    }

    #[Test]
    public function removing_the_image_gives_a_plain_colour_and_the_default_picture_does_not_come_back(): void
    {
        $page = Page::where('slug', 'about')->first() ?? Page::where('key', 'about')->first();
        $page->update(['featured_image_id' => $this->photo->id]);                // the default banner would show this image
        $this->svc()->saveDraft('page:'.$page->slug, 'custom', ['image_id' => null, 'bg_color' => '#123456'], auth()->user());
        $this->svc()->publish('page:'.$page->slug);
        $html = $this->body('/en/about');
        $this->assertStringContainsString('#123456', $html);
        preg_match('/<section id="ph-[^>]*data-page-header.*?<\/section>/s', $html, $m);
        $this->assertNotEmpty($m, 'the customised banner is rendered');
        $this->assertStringNotContainsString('headers/factory.webp', $m[0], 'the default photo does not return inside the banner');
        $this->assertStringNotContainsString('<picture', $m[0]);
    }

    #[Test]
    public function hidden_keeps_a_single_screen_reader_title_and_other_pages_are_unaffected(): void
    {
        $this->svc()->saveDraft('page:contact-us', 'hidden', [], auth()->user());
        $this->svc()->publish('page:contact-us');
        $html = $this->body('/en/contact');
        $this->assertStringNotContainsString('eyebrow-light', $html, 'no banner markup');
        $this->assertStringNotContainsString('data-page-header', $html);
        $this->assertSame(1, substr_count($html, '<h1'));
        $this->assertStringContainsString('sr-only', $html);
    }

    #[Test]
    public function custom_text_is_per_language_and_arabic_stays_rtl(): void
    {
        $this->svc()->saveDraft('page:contact-us', 'custom', ['title' => ['en' => 'Reach the factory', 'ar' => 'تواصل مع المصنع'], 'align' => 'start'], auth()->user());
        $this->svc()->publish('page:contact-us');
        $this->assertStringContainsString('Reach the factory', $this->body('/en/contact'));
        $ar = $this->body('/ar/contact');
        $this->assertStringContainsString('تواصل مع المصنع', $ar);
        $this->assertMatchesRegularExpression('/<html[^>]*dir="rtl"/', $ar);
        $this->assertStringContainsString('text-align:start', $ar, 'logical alignment follows the language direction');
    }

    #[Test]
    public function the_builder_outline_has_the_header_item_clicking_selects_it_and_header_publishing_is_independent_of_the_page_content(): void
    {
        $page = Page::where('key', 'contact')->firstOrFail();
        $c = Livewire::withQueryParams(['page' => $page->slug, 'header' => 1])->test(PageBuilder::class)
            ->assertSet('headerSelected', true)->set('canvasView', 'outline')->assertSee('Page Header / Hero')->assertSee('data-testid="outline-header"', false);

        $c->set('headerData.mode', 'custom')->set('headerData.image_id', $this->photo->id)->set('headerData.overlay_opacity', 35)->call('saveHeader');
        $this->assertSame('custom', PageHeader::where('page_key', 'page:'.$page->slug)->value('mode'));
        $this->assertNull(PageHeader::where('page_key', 'page:'.$page->slug)->value('published_mode'), 'still a draft');

        $c->call('selectHeader')->call('publishHeader');
        $this->assertSame('custom', PageHeader::where('page_key', 'page:'.$page->slug)->value('published_mode'));
        $this->assertStringContainsString('data-page-header', $this->body('/en/contact'));
        $this->assertStringContainsString('name', strtolower($this->body('/en/contact')), 'the page content and form are intact');
    }

    #[Test]
    public function a_user_who_cannot_manage_content_cannot_save_a_header(): void
    {
        $viewer = User::factory()->create(['is_active' => true]);
        $viewer->assignRole(User::ROLE_VIEWER);
        $this->actingAs($viewer);
        $page = Page::where('key', 'contact')->firstOrFail();
        $c = Livewire::withQueryParams(['page' => $page->slug])->test(PageBuilder::class);
        $before = PageHeader::count();
        $c->set('headerData.mode', 'custom')->call('saveHeader');
        $this->assertSame($before, PageHeader::count());
    }

    #[Test]
    public function category_and_storefront_listing_banners_are_independent_too(): void
    {
        \App\Services\Catalog\CatalogHierarchy::apply();
        $this->svc()->saveDraft('category:green-olives', 'custom', ['bg_color' => '#223344', 'title' => ['en' => 'Green olives, our way']], auth()->user());
        $this->svc()->publish('category:green-olives');
        $green = $this->body('/en/products/category/green-olives');
        $this->assertStringContainsString('Green olives, our way', $green);
        $this->assertStringContainsString('#223344', $green);
        $this->assertStringNotContainsString('#223344', $this->body('/en/products/category/peppers'), 'a sibling category keeps its banner');
        $this->assertStringNotContainsString('#223344', $this->body('/en/products'));
    }
}
