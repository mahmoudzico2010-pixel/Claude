<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Filament\Pages\TeamStructure;
use App\Filament\Resources\Team\Pages\CreateTeamMember;
use App\Filament\Resources\Team\Pages\EditTeamMember;
use App\Filament\Resources\Team\Pages\ListTeamDepartments;
use App\Filament\Resources\Team\Pages\ListTeamMembers;
use App\Models\TeamDepartment;
use App\Models\TeamMember;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Livewire\Livewire;
use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;

final class TeamAdminTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
    }

    private function as(string $role): User
    {
        $u = User::factory()->create(['is_active' => true]);
        $u->assignRole($role);
        $this->actingAs($u->fresh());

        return $u;
    }

    private function m(string $name, array $a = []): TeamMember
    {
        $m = TeamMember::create($a + ['slug' => TeamMember::uniqueSlug($name), 'status' => 'draft']);
        $m->saveTranslations(['en' => ['name' => $name]]);

        return $m->fresh();
    }

    #[Test]
    public function list_screens_render_filters_work_and_the_structure_page_loads(): void
    {
        $this->as(User::ROLE_ADMIN);
        $d = TeamDepartment::create(['slug' => 'qa']);
        $d->saveTranslations(['en' => ['name' => 'QA']]);
        $a = $this->m('Alpha Person', ['department_id' => $d->id]);
        $this->m('Beta Person');
        Livewire::test(ListTeamMembers::class)->loadTable()->assertSuccessful()->assertCanSeeTableRecords([$a])
            ->filterTable('department_id', $d->id)->assertCanSeeTableRecords([$a])->assertCountTableRecords(1)
            ->resetTableFilters()->filterTable('missing_portrait')->assertCountTableRecords(2);
        Livewire::test(ListTeamDepartments::class)->loadTable()->assertSuccessful();
        Livewire::test(TeamStructure::class)->assertSuccessful()->assertSee('Alpha Person');
    }

    #[Test]
    public function the_edit_form_saves_translations_and_links_and_never_changes_status(): void
    {
        $this->as(User::ROLE_ADMIN);
        $m = $this->m('Gamma Person');
        Livewire::test(EditTeamMember::class, ['record' => $m->getRouteKey()])
            ->fillForm(['translations.en.name' => 'Gamma Renamed', 'translations.ar.name' => 'غاما', 'email' => 'g@example.test', 'show_email' => true, 'status' => 'published'])
            ->call('save')->assertHasNoFormErrors();
        $m = $m->fresh();
        $this->assertSame('Gamma Renamed', $m->t('name', 'en'));
        $this->assertSame('غاما', $m->t('name', 'ar'));
        $this->assertSame('draft', $m->status, 'publishing is its own permissioned action');
    }

    #[Test]
    public function publish_unpublish_move_and_archive_actions_are_permission_checked_on_the_server(): void
    {
        $boss = $this->m('Boss', ['status' => 'published']);
        $kid = $this->m('Kid', ['reports_to_id' => $boss->id]);

        $this->as(User::ROLE_CONTENT_EDITOR);   // may edit, may not publish or restructure
        Livewire::test(ListTeamMembers::class)->loadTable()
            ->assertTableActionHidden('publish', $kid)->assertTableActionHidden('move', $kid)->assertTableActionHidden('archive', $kid);
        $this->assertSame('draft', $kid->fresh()->status);
        Livewire::test(CreateTeamMember::class)
            ->fillForm(['translations.en.name' => 'Edited By Editor', 'reports_to_id' => $boss->id, 'department_id' => null])->call('create');
        $created = TeamMember::query()->where('slug', 'edited-by-editor')->first();
        $this->assertNotNull($created);
        $this->assertNull($created->reports_to_id, 'a content editor cannot place people in the structure');
        $this->assertSame('draft', $created->status);

        $this->as(User::ROLE_ADMIN);
        Livewire::test(ListTeamMembers::class)->loadTable()->callTableAction('publish', $kid)->assertHasNoTableActionErrors();
        $this->assertSame('published', $kid->fresh()->status);
        Livewire::test(ListTeamMembers::class)->loadTable()->callTableAction('publish', $kid);
        $this->assertSame('draft', $kid->fresh()->status);
        $other = $this->m('Other Boss');
        Livewire::test(ListTeamMembers::class)->loadTable()->callTableAction('move', $kid, ['reports_to_id' => $other->id, 'department_id' => null]);
        $this->assertSame($other->id, $kid->fresh()->reports_to_id);
        Livewire::test(ListTeamMembers::class)->loadTable()->callTableAction('archive', $other);   // has a report: refused, not removed
        $this->assertNull($other->fresh()->deleted_at);
        Livewire::test(ListTeamMembers::class)->loadTable()->callTableAction('archive', $kid);
        $this->assertTrue($kid->fresh()->trashed());
    }

    #[Test]
    public function viewers_cannot_open_the_team_resources_for_editing(): void
    {
        $m = $this->m('Delta Person');
        $this->as(User::ROLE_VIEWER);
        $this->get('/admin/team/team-members')->assertOk();
        $this->get('/admin/team/team-members/create')->assertForbidden();
        $this->get('/admin/team/team-members/'.$m->id.'/edit')->assertForbidden();
    }

    #[Test]
    public function publishing_never_creates_a_login_or_grants_permissions(): void
    {
        $this->as(User::ROLE_ADMIN);
        $before = User::count();
        $m = $this->m('No Login Person', ['email' => 'nologin@example.test']);
        Livewire::test(ListTeamMembers::class)->loadTable()->callTableAction('publish', $m);
        $this->assertSame($before, User::count());
        $this->assertNull(User::query()->where('email', 'nologin@example.test')->first());
    }
}
