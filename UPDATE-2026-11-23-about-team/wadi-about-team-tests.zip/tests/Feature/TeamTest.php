<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Models\SiteSetting;
use App\Models\TeamDepartment;
use App\Models\TeamMember;
use App\Models\User;
use App\Services\Team\TeamHierarchy;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Validation\ValidationException;
use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;

final class TeamTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
        SiteSetting::setMany(['maintenance_mode' => false], 'site');
        config(['wadi.published' => array_keys(config('wadi.locales')), 'wadi.expose_unpublished_locales' => true]);
    }

    private function member(string $en, array $attr = [], array $tr = []): TeamMember
    {
        $m = TeamMember::create($attr + ['slug' => TeamMember::uniqueSlug($en), 'status' => 'published', 'show_on_team' => true]);
        $m->saveTranslations(['en' => ['name' => $en, 'job_title' => 'Role of '.$en, 'short_bio' => 'Short bio of '.$en] + ($tr['en'] ?? []), 'ar' => ['name' => 'ع '.$en, 'job_title' => 'دور'] + ($tr['ar'] ?? [])]);

        return $m->fresh();
    }

    private function dept(string $en, array $attr = []): TeamDepartment
    {
        $d = TeamDepartment::create($attr + ['slug' => \Illuminate\Support\Str::slug($en), 'is_visible' => true]);
        $d->saveTranslations(['en' => ['name' => $en], 'ar' => ['name' => 'قسم '.$en]]);

        return $d->fresh();
    }

    #[Test]
    public function self_reporting_and_indirect_cycles_are_refused_for_members_and_departments(): void
    {
        $a = $this->member('Alpha');
        $b = $this->member('Bravo', ['reports_to_id' => $a->id]);
        $c = $this->member('Charlie', ['reports_to_id' => $b->id]);
        foreach ([fn () => $a->update(['reports_to_id' => $a->id]), fn () => $a->update(['reports_to_id' => $c->id])] as $try) {
            try {
                $try();
                $this->fail('expected a refusal');
            } catch (ValidationException) {
                $this->assertTrue(true);
            }
        }
        $this->assertNull($a->fresh()->reports_to_id);
        $d1 = $this->dept('One');
        $d2 = $this->dept('Two', ['parent_id' => $d1->id]);
        $this->expectException(ValidationException::class);
        $d1->update(['parent_id' => $d2->id]);
    }

    #[Test]
    public function several_roots_are_allowed_and_a_manager_with_reports_cannot_be_archived_until_they_are_moved(): void
    {
        $r1 = $this->member('Root One');
        $r2 = $this->member('Root Two');
        $kid = $this->member('Kid', ['reports_to_id' => $r1->id]);
        $this->assertCount(2, app(TeamHierarchy::class)->tree(true));
        try {
            $r1->delete();
            $this->fail('archiving a manager with reports must be refused');
        } catch (ValidationException) {
        }
        $this->assertNull($r1->fresh()->deleted_at);
        app(TeamHierarchy::class)->reassignReports($r1, $r2);
        $this->assertSame($r2->id, $kid->fresh()->reports_to_id);
        $r1->delete();
        $this->assertTrue($r1->fresh()->trashed());
        $r1->restore();
        $this->assertFalse($r1->fresh()->trashed());
    }

    #[Test]
    public function the_public_page_never_shows_drafts_or_archived_people_and_a_hidden_manager_leaves_no_trace(): void
    {
        $boss = $this->member('Hidden Boss', ['status' => 'draft']);
        $kid = $this->member('Visible Kid', ['reports_to_id' => $boss->id]);
        $old = $this->member('Archived Person');
        $old->delete();
        $html = $this->get('/en/team')->assertOk()->getContent();
        $this->assertStringContainsString('Visible Kid', $html);
        $this->assertStringNotContainsString('Hidden Boss', $html);
        $this->assertStringNotContainsString('Archived Person', $html);
        $this->get('/en/team/'.$boss->slug)->assertNotFound();
        $this->get('/en/team/'.$old->slug)->assertNotFound();
        $profile = $this->get('/en/team/'.$kid->slug)->assertOk()->getContent();
        $this->assertStringNotContainsString('Hidden Boss', $profile);
        $this->assertSame(1, substr_count($profile, '<h1'), 'exactly one H1');
    }

    #[Test]
    public function contact_channels_are_private_until_switched_on_and_leak_nowhere_including_json_ld_and_the_sitemap(): void
    {
        $m = $this->member('Contact Person', ['email' => 'secret.person@example.com', 'phone' => '+20 100 123 4567', 'whatsapp' => '+20 100 765 4321']);
        $m->links()->create(['network' => 'linkedin', 'url' => 'https://www.linkedin.com/in/contactperson', 'is_visible' => false]);
        $html = $this->get('/en/team/'.$m->slug)->assertOk()->getContent();
        foreach (['secret.person@example.com', '1234567', '+201001234567', 'wa.me', 'linkedin.com', 'mailto:', 'tel:'] as $needle) {
            $this->assertStringNotContainsString($needle, $html, "hidden: $needle");
        }
        $this->assertStringNotContainsString('secret.person', $this->get('/en/team')->getContent());
        $this->assertStringNotContainsString('secret.person', $this->get('/sitemap.xml')->getContent());

        $m->update(['show_email' => true, 'show_phone' => true, 'show_whatsapp' => true]);
        $m->links()->update(['is_visible' => true]);
        $html = $this->get('/en/team/'.$m->slug)->getContent();
        $this->assertStringContainsString('mailto:secret.person@example.com', $html);
        $this->assertStringContainsString('tel:+201001234567', $html);
        $this->assertStringContainsString('https://wa.me/201007654321', $html);
        $this->assertStringContainsString('https://www.linkedin.com/in/contactperson', $html);
        $this->assertStringContainsString('"@type":"Person"', $html);

        $m->update(['show_email' => false]);
        $this->assertStringNotContainsString('secret.person@example.com', $this->get('/en/team/'.$m->slug)->getContent());
    }

    #[Test]
    public function javascript_and_non_http_social_links_are_never_rendered(): void
    {
        $m = $this->member('Link Person');
        $m->links()->create(['network' => 'website', 'url' => 'javascript:alert(1)', 'is_visible' => true]);
        $m->links()->create(['network' => 'x', 'url' => 'https://x.com/ok', 'is_visible' => true]);
        $html = $this->get('/en/team/'.$m->slug)->getContent();
        $this->assertStringNotContainsString('javascript:', $html);
        $this->assertStringContainsString('https://x.com/ok', $html);
    }

    #[Test]
    public function all_ten_locales_render_the_team_and_a_profile_with_the_right_direction_and_no_duplicate_h1(): void
    {
        $this->dept('Quality');
        $d = TeamDepartment::first();
        $a = $this->member('Lead One', ['department_id' => $d->id]);
        $b = $this->member('Second One', ['reports_to_id' => $a->id, 'department_id' => $d->id]);
        foreach (array_keys(config('wadi.locales')) as $loc) {
            $team = $this->get("/$loc/team")->assertOk()->getContent();
            $this->assertSame(1, substr_count($team, '<h1'), "$loc team h1");
            $this->assertStringContainsString(__('team.page_title', [], $loc), $team);
            $dir = in_array($loc, ['ar', 'ur'], true) ? 'rtl' : 'ltr';
            $this->assertStringContainsString('dir="'.$dir.'"', $team, $loc);
            $this->get("/$loc/team/".$b->slug)->assertOk();
        }
    }

    #[Test]
    public function the_department_filter_and_unknown_departments_behave(): void
    {
        $d = $this->dept('Quality');
        $this->member('In Dept', ['department_id' => $d->id]);
        $this->member('Elsewhere');
        $html = $this->get('/en/team?department='.$d->slug)->assertOk()->getContent();
        $this->assertStringContainsString('In Dept', $html);
        $this->get('/en/team?department=nope')->assertNotFound();
        $d->update(['is_visible' => false]);
        $this->get('/en/team?department='.$d->slug)->assertNotFound();
    }

    #[Test]
    public function staff_with_the_view_permission_can_preview_drafts_but_the_public_cannot(): void
    {
        $m = $this->member('Draft Person', ['status' => 'draft']);
        $this->get('/en/team/'.$m->slug.'?preview=1')->assertNotFound();
        $admin = User::factory()->create(['is_active' => true]);
        $admin->assignRole(User::ROLE_ADMIN);
        $this->actingAs($admin->fresh());
        $r = $this->get('/en/team/'.$m->slug.'?preview=1')->assertOk();
        $this->assertStringContainsString('noindex', $r->getContent());
    }

    #[Test]
    public function running_the_migrations_twice_changes_nothing_and_never_duplicates_people(): void
    {
        $this->member('Stays Once');
        foreach (['2026_11_22_000100_create_team_tables', '2026_11_22_000150_sync_team_permissions', '2026_11_22_000200_seed_about_story'] as $name) {
            $m = require database_path('migrations/'.$name.'.php');
            $m->up();
            $m->up();
        }
        $this->assertSame(1, TeamMember::count());
        $this->assertSame(1, \App\Models\BuilderNode::query()->forPage('page:about')->where('type', 'evidence_block')->count(), 'About story not duplicated');
        $this->assertTrue(\Spatie\Permission\Models\Permission::where('name', 'team.structure')->exists());
    }
}
