<?php

declare(strict_types=1);

namespace App\Services\About;

use App\Models\BuilderNode;
use App\Models\Page;
use App\Models\PageHeader;
use App\Services\Builder\PageConverter;
use App\Services\Builder\RevisionManager;
use App\Services\Builder\TreeImporter;
use App\Services\PageHeaders\PageHeaderService;
use Illuminate\Support\Facades\Schema;

/**
 * Seeds the About Us story (page builder layout + the page banner texts) from database/data/about-story.json.
 *
 * Idempotent and non-destructive: nothing that already exists is replaced. A page that already has a layout keeps it; a banner
 * that was already customised keeps its texts. The layout is PUBLISHED automatically only when the About page still carries the
 * installer placeholder text and has never been published from the builder; otherwise it is left as a draft for the owner to review.
 */
final class AboutStory
{
    /** @var array<string, array<string, string>> */
    private array $s;

    public function __construct(private readonly TreeImporter $importer, private readonly RevisionManager $revisions, private readonly PageHeaderService $headers)
    {
        $this->s = (array) json_decode((string) file_get_contents(database_path('data/about-story.json')), true);
    }

    /** @return array<string, string> what happened, for the console / migration log */
    public function run(bool $forcePublish = false): array
    {
        $report = [];
        if (! Schema::hasTable('builder_nodes') || ! Schema::hasTable('pages')) {
            return ['skipped' => 'builder tables missing'];
        }
        $page = Page::query()->where('key', 'about')->first();
        if ($page === null) {
            return ['skipped' => 'no About page'];
        }
        $key = PageConverter::key($page);
        $neverPublished = $this->revisions->latestPublished($key) === null;
        $placeholder = $this->bodyIsPlaceholder($page);
        $publish = $neverPublished && ($placeholder || $forcePublish);

        if (BuilderNode::hasTreeFor($key)) {
            $report['layout'] = 'kept (a layout already exists)';
        } else {
            $this->importer->import($key, null, $this->tree());
            $report['layout'] = 'created';
            if ($publish) {
                $this->revisions->publish($key, 'About story');
                $report['layout'] .= ' and published';
            } else {
                $report['layout'] .= ' as a DRAFT — review it in the page editor, then Publish';
            }
        }

        if (Schema::hasTable('page_headers') && PageHeader::query()->where('page_key', $key)->doesntExist()) {
            $this->headers->saveDraft($key, 'custom', [
                'eyebrow' => $this->all('hero_eyebrow'), 'title' => $this->all('hero_title'), 'subtitle' => $this->all('hero_subtitle'),
                'bg_color' => '#14382a', 'text_color' => '#faf6ec', 'overlay_color' => '#0b2a1f', 'overlay_opacity' => 0,
            ], null);
            $report['banner'] = 'created';
            if ($publish) {
                $this->headers->publish($key, null);
                $report['banner'] .= ' and published';
            }
        } else {
            $report['banner'] = 'kept';
        }

        BuilderNode::flushCache($key);

        return $report;
    }

    private function bodyIsPlaceholder(Page $page): bool
    {
        $body = trim(strip_tags((string) $page->t('body', 'en')));

        return $body === '' || str_contains($body, 'Replace this');
    }

    /** @return array<string, string> */
    private function all(string $k): array
    {
        return array_intersect_key($this->s[$k] ?? [], (array) config('wadi.locales', []));
    }

    /** @return array<string, array<string, string>> locale => [field => text] */
    private function tr(array $fields): array
    {
        $out = [];
        foreach (array_keys((array) config('wadi.locales', [])) as $l) {
            foreach ($fields as $field => $key) {
                if (isset($this->s[$key][$l])) {
                    $out[$l][$field] = $this->s[$key][$l];
                }
            }
        }

        return $out;
    }

    private function n(string $type, array $settings = [], array $tr = [], array $children = [], bool $enabled = true, array $style = []): array
    {
        return ['type' => $type, 'enabled' => $enabled, 'settings' => $settings, 'style' => $style, 'responsive' => [], 'translations' => $tr, 'children' => $children];
    }

    private function section(array $children, string $bg = '', string $pad = '4rem', bool $enabled = true, string $width = 'standard'): array
    {
        return $this->n('section', $bg === '' ? [] : ['background_color' => $bg], [], [
            $this->n('container', ['columns' => '1', 'width' => $width], [], [$this->n('column', [], [], $children)]),
        ], $enabled, ['padding_top' => $pad, 'padding_bottom' => $pad]);
    }

    private function h2(string $key, string $color = ''): array
    {
        return $this->n('heading', ['level' => 'h2', 'size' => 'h2'] + ($color ? ['color' => $color] : []), $this->tr(['text' => $key]));
    }

    /** @return list<array> */
    private function tree(): array
    {
        $t = [];
        foreach ([1, 2, 3, 4] as $i) {
            // The image slot stays empty until the owner chooses a real photograph; an empty slot renders nothing.
            $t[] = $this->section([
                $this->n('image', ['ratio' => 'wide', 'fit' => 'cover'], ['en' => ['caption' => ''], 'ar' => ['caption' => '']]),
                $this->h2("ch{$i}_title"),
                $this->n('text', [], $this->tr(['body' => "ch{$i}_body"])),
            ], $i % 2 ? '#faf6ec' : '', '3.5rem', true, 'narrow');
        }

        $items = [];
        foreach (['m1', 'm2', 'm3', 'm4', 'm5', 'm6'] as $m) {
            $items[] = $this->n('timeline_item', $m === 'm6' ? ['ongoing' => 'on'] : [], $this->tr(['title' => $m.'_title', 'text' => $m.'_text']));
        }
        $t[] = $this->section([$this->h2('journey_h'), $this->n('timeline', [], [], $items)], '', '3.5rem', true, 'narrow');

        $t[] = $this->section([
            $this->h2('ops_h'),
            $this->n('text', [], $this->tr(['body' => 'ops_intro'])),
            $this->n('evidence_block', ['approved' => 'off'], $this->tr(['label' => 'evidence_h'])),
        ], '#faf6ec', '3.5rem');
        $cols = [];
        foreach ([['o1', 'sprout'], ['o2', 'handshake'], ['o3', 'badge-check']] as [$o, $icon]) {
            $cols[] = $this->n('column', [], [], [
                $this->n('image', ['ratio' => 'landscape', 'fit' => 'cover'], ['en' => ['caption' => '']]),
                $this->n('icon_box', ['name' => $icon, 'style' => 'circle', 'card' => 'on'], $this->tr(['title' => $o.'_title', 'text' => $o.'_text'])),
            ]);
        }
        $t[] = $this->n('section', ['background_color' => '#faf6ec'], [], [$this->n('container', ['columns' => '3', 'gap' => '1.5rem'], [], $cols)], true, ['padding_top' => '0', 'padding_bottom' => '3.5rem']);

        $t[] = $this->section([
            $this->h2('team_heading'),
            $this->n('text', [], $this->tr(['body' => 'team_intro'])),
            $this->n('team_preview', ['limit' => '6', 'show_link' => 'off']),
            $this->n('buttons', [], [], [$this->n('button', ['destination' => 'route', 'route_name' => 'team.index', 'style' => 'primary'], $this->tr(['label' => 'team_about_cta']))]),
        ], '', '3.5rem');

        $t[] = $this->section([
            $this->n('buttons', [], [], [
                $this->n('button', ['destination' => 'route', 'route_name' => 'products.index', 'style' => 'primary'], $this->tr(['label' => 'team_products_cta'])),
                $this->n('button', ['destination' => 'route', 'route_name' => 'contact.show', 'style' => 'secondary'], $this->tr(['label' => 'team_export_cta'])),
            ]),
        ], '#faf6ec', '3rem');

        // Held back: the owner must say which place inspired the name. DISABLED, so it is never published until enabled on purpose.
        $t[] = $this->section([$this->n('text', [], ['ar' => ['body' => $this->s['naming_line']['ar']], 'en' => ['body' => $this->s['naming_line']['en']]])], '', '2.5rem', false);

        return $t;
    }
}
