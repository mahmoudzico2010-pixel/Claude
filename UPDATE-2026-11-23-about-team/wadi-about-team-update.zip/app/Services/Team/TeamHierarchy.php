<?php

declare(strict_types=1);

namespace App\Services\Team;

use App\Models\TeamDepartment;
use App\Models\TeamMember;
use Illuminate\Support\Collection;
use Illuminate\Validation\ValidationException;

/**
 * The reporting structure. Reporting lines come from data (reports_to_id / parent_id), never from job-title text or order.
 * Several roots are allowed. Cycles (direct or indirect) and self-reporting are refused here, on the server, for every caller.
 */
final class TeamHierarchy
{
    // ---------------------------------------------------------------- rules

    public function assertManager(TeamMember $member, int $managerId): void
    {
        if ($member->exists && $member->getKey() === $managerId) {
            throw ValidationException::withMessages(['reports_to_id' => __('team.errors.self')]);
        }
        $seen = [];
        $cursor = $managerId;
        while ($cursor !== null) {
            if ($member->exists && $cursor === (int) $member->getKey()) {
                throw ValidationException::withMessages(['reports_to_id' => __('team.errors.cycle')]);
            }
            if (isset($seen[$cursor])) {
                break; // pre-existing loop elsewhere: do not spin
            }
            $seen[$cursor] = true;
            $cursor = TeamMember::withTrashed()->whereKey($cursor)->value('reports_to_id');
            $cursor = $cursor === null ? null : (int) $cursor;
        }
        $manager = TeamMember::withTrashed()->find($managerId);
        if ($manager === null || $manager->trashed()) {
            throw ValidationException::withMessages(['reports_to_id' => __('team.errors.manager_archived')]);
        }
    }

    public function assertDepartmentParent(TeamDepartment $dept, int $parentId): void
    {
        if ($dept->exists && $dept->getKey() === $parentId) {
            throw ValidationException::withMessages(['parent_id' => __('team.errors.self')]);
        }
        $seen = [];
        $cursor = $parentId;
        while ($cursor !== null) {
            if ($dept->exists && $cursor === (int) $dept->getKey()) {
                throw ValidationException::withMessages(['parent_id' => __('team.errors.cycle')]);
            }
            if (isset($seen[$cursor])) {
                break;
            }
            $seen[$cursor] = true;
            $cursor = TeamDepartment::withTrashed()->whereKey($cursor)->value('parent_id');
            $cursor = $cursor === null ? null : (int) $cursor;
        }
    }

    /** Archiving never silently orphans people: reassign the direct reports first. */
    public function assertCanArchive(TeamMember $m): void
    {
        if (TeamMember::query()->where('reports_to_id', $m->getKey())->exists()) {
            throw ValidationException::withMessages(['reports_to_id' => __('team.errors.has_reports')]);
        }
    }

    public function assertCanArchiveDepartment(TeamDepartment $d): void
    {
        if (TeamMember::query()->where('department_id', $d->getKey())->exists() || TeamDepartment::query()->where('parent_id', $d->getKey())->exists()) {
            throw ValidationException::withMessages(['department' => __('team.errors.dept_in_use')]);
        }
    }

    // ------------------------------------------------------------- actions

    /** Explicit "Move to manager / department" with validation. Pass the sentinel false to leave a value unchanged. */
    public function move(TeamMember $m, int|null|false $managerId = false, int|null|false $departmentId = false): TeamMember
    {
        if ($managerId !== false) {
            if ($managerId !== null) {
                $this->assertManager($m, $managerId);
            }
            $m->reports_to_id = $managerId;
        }
        if ($departmentId !== false) {
            $m->department_id = $departmentId;
        }
        $m->save();

        return $m;
    }

    /** Re-home every direct report of $from onto $to (or to the top level), then the caller can archive $from. */
    public function reassignReports(TeamMember $from, ?TeamMember $to): int
    {
        $n = 0;
        foreach (TeamMember::query()->where('reports_to_id', $from->getKey())->get() as $r) {
            $this->move($r, $to?->getKey(), false);
            $n++;
        }

        return $n;
    }

    /** Move one step among the siblings that share the same manager. */
    public function nudge(TeamMember $m, int $dir): void
    {
        $sibs = TeamMember::query()->where('reports_to_id', $m->reports_to_id)->orderBy('display_order')->orderBy('id')->pluck('id')->map(fn ($v) => (int) $v)->values()->all();
        $i = array_search((int) $m->getKey(), $sibs, true);
        $j = $i === false ? false : $i + ($dir < 0 ? -1 : 1);
        if ($i === false || $j < 0 || $j >= count($sibs)) {
            return;
        }
        [$sibs[$i], $sibs[$j]] = [$sibs[$j], $sibs[$i]];
        foreach ($sibs as $order => $id) {
            TeamMember::query()->whereKey($id)->update(['display_order' => $order]);
        }
    }

    // ---------------------------------------------------------------- trees

    /**
     * Nested tree of members. `$publicOnly` shows only published, unarchived people and attaches each to its nearest PUBLIC
     * ancestor, so a hidden manager leaves neither an empty card nor a name; a person whose managers are all hidden becomes a root.
     *
     * @return list<array{member: TeamMember, children: list<array>}>
     */
    public function tree(bool $publicOnly, ?callable $filter = null): array
    {
        $all = TeamMember::withTrashed()->with(['translations', 'department.translations', 'portrait', 'links'])->orderBy('display_order')->orderBy('id')->get()->keyBy('id');
        $visible = $all->filter(fn (TeamMember $m) => ! $publicOnly || ($m->isPublic() && (! $filter || $filter($m))));
        if (! $publicOnly) {
            $visible = $all->filter(fn (TeamMember $m) => ! $m->trashed());
        }

        $parentOf = function (TeamMember $m) use ($all, $visible): ?int {
            $cur = $m->reports_to_id;
            $guard = 0;
            while ($cur !== null && $guard++ < 200) {
                if ($visible->has($cur)) {
                    return (int) $cur;
                }
                $cur = $all->get($cur)?->reports_to_id;
            }

            return null;
        };

        $children = [];
        foreach ($visible as $m) {
            $children[$parentOf($m) ?? 0][] = $m;
        }
        $build = function (int $key, int $depth) use (&$build, &$children): array {
            if ($depth > 50) {
                return [];
            }

            return array_map(fn (TeamMember $m) => ['member' => $m, 'children' => $build((int) $m->getKey(), $depth + 1)], $children[$key] ?? []);
        };

        return $build(0, 0);
    }

    /** @param list<array> $tree @return Collection<int, TeamMember> */
    public function flatten(array $tree): Collection
    {
        $out = collect();
        $walk = function (array $nodes) use (&$walk, $out): void {
            foreach ($nodes as $n) {
                $out->push($n['member']);
                $walk($n['children']);
            }
        };
        $walk($tree);

        return $out;
    }
}
