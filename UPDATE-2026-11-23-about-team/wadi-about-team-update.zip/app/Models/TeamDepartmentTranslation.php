<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TeamDepartmentTranslation extends Model
{
    public $timestamps = false;

    protected $fillable = ['team_department_id', 'locale', 'name', 'description'];
}
