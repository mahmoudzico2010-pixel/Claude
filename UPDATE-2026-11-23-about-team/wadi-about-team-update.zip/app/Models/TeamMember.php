<?php

declare(strict_types=1);

namespace App\Models;

use App\Models\Concerns\Auditable;
use App\Models\Concerns\HasTranslations;
use App\Services\Team\TeamHierarchy;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

/** A public staff profile. Deliberately NOT a login account: publishing a member never creates a user or grants a permission. */
class TeamMember extends Model
{
    use Auditable;
    use HasTranslations;
    use SoftDeletes;

    public const DRAFT = 'draft';

    public const PUBLISHED = 'published';

    public array $translatedAttributes = ['name', 'job_title', 'short_bio', 'full_bio', 'portrait_alt'];

    protected $fillable = [
        'slug', 'department_id', 'reports_to_id', 'portrait_id', 'portrait_focal_x', 'portrait_focal_y', 'status', 'published_at',
        'show_on_about', 'show_on_team', 'display_order', 'email', 'phone', 'whatsapp', 'show_email', 'show_phone', 'show_whatsapp',
        'created_by', 'updated_by',
    ];

    protected function casts(): array
    {
        return [
            'show_on_about' => 'boolean', 'show_on_team' => 'boolean', 'show_email' => 'boolean', 'show_phone' => 'boolean',
            'show_whatsapp' => 'boolean', 'published_at' => 'datetime', 'display_order' => 'integer',
        ];
    }

    protected static function booted(): void
    {
        static::saving(function (self $m): void {
            if ($m->reports_to_id !== null && ($m->isDirty('reports_to_id') || ! $m->exists)) {
                app(TeamHierarchy::class)->assertManager($m, (int) $m->reports_to_id);
            }
        });
        static::deleting(fn (self $m) => app(TeamHierarchy::class)->assertCanArchive($m));
    }

    public function translationModel(): string
    {
        return TeamMemberTranslation::class;
    }

    public function department(): BelongsTo
    {
        return $this->belongsTo(TeamDepartment::class, 'department_id')->withTrashed();
    }

    public function manager(): BelongsTo
    {
        return $this->belongsTo(self::class, 'reports_to_id')->withTrashed();
    }

    public function reports(): HasMany
    {
        return $this->hasMany(self::class, 'reports_to_id')->orderBy('display_order')->orderBy('id');
    }

    public function portrait(): BelongsTo
    {
        return $this->belongsTo(MediaAsset::class, 'portrait_id');
    }

    public function links(): HasMany
    {
        return $this->hasMany(TeamMemberLink::class)->orderBy('display_order');
    }

    public function isPublic(): bool
    {
        return $this->status === self::PUBLISHED && ! $this->trashed();
    }

    /** Published, not archived. Department visibility does not hide a person (it only hides the department label). */
    public function scopePublic(Builder $q): Builder
    {
        return $q->where('status', self::PUBLISHED)->whereNull('deleted_at');
    }

    public function displayName(?string $locale = null): string
    {
        return (string) ($this->t('name', $locale) ?: $this->slug);
    }

    public function initials(?string $locale = null): string
    {
        $words = array_values(array_filter(preg_split('/\s+/u', trim($this->displayName($locale))) ?: [], fn ($w) => preg_match('/^\p{L}/u', $w) === 1));
        if ($words === []) {
            return '·';
        }

        return mb_strtoupper(mb_substr($words[0], 0, 1).(count($words) > 1 ? mb_substr((string) end($words), 0, 1) : ''));
    }

    /** Public department (visible and not archived) or null. */
    public function publicDepartment(): ?TeamDepartment
    {
        $d = $this->department;

        return $d !== null && $d->is_visible && ! $d->trashed() ? $d : null;
    }

    public function publicEmail(): ?string
    {
        return $this->show_email && filter_var($this->email, FILTER_VALIDATE_EMAIL) ? (string) $this->email : null;
    }

    public function publicPhone(): ?string
    {
        return $this->show_phone && $this->telClean($this->phone) ? (string) $this->phone : null;
    }

    public function publicWhatsapp(): ?string
    {
        return $this->show_whatsapp && $this->telClean($this->whatsapp) ? (string) $this->whatsapp : null;
    }

    /** Digits (and a leading +) only; the value used in tel: / wa.me links. */
    public function telClean(?string $v): ?string
    {
        $d = preg_replace('/[^\d+]/', '', (string) $v);
        $d = $d !== null && str_starts_with($d, '+') ? '+'.preg_replace('/\D/', '', $d) : preg_replace('/\D/', '', (string) $d);

        return strlen((string) $d) >= 7 ? (string) $d : null;
    }

    public function telHref(): ?string
    {
        $t = $this->telClean($this->phone);

        return $t ? 'tel:'.$t : null;
    }

    public function whatsappHref(): ?string
    {
        $t = $this->telClean($this->whatsapp);

        return $t ? 'https://wa.me/'.ltrim($t, '+') : null;
    }

    /** @return \Illuminate\Support\Collection<int, TeamMemberLink> */
    public function publicLinks()
    {
        return $this->links->filter(fn (TeamMemberLink $l) => $l->is_visible && $l->safeUrl() !== null)->values();
    }

    public static function uniqueSlug(string $base, ?int $ignoreId = null): string
    {
        $slug = \Illuminate\Support\Str::slug($base) ?: 'member';
        $i = 1;
        $try = $slug;
        while (self::withTrashed()->where('slug', $try)->when($ignoreId, fn ($q) => $q->where('id', '!=', $ignoreId))->exists()) {
            $try = $slug.'-'.(++$i);
        }

        return $try;
    }
}
