<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TeamMemberTranslation extends Model
{
    public $timestamps = false;

    protected $fillable = ['team_member_id', 'locale', 'name', 'job_title', 'short_bio', 'full_bio', 'portrait_alt'];
}
