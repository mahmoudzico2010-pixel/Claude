<?php

declare(strict_types=1);

namespace App\Models;

use App\Support\Builder\SafeLink;
use Illuminate\Database\Eloquent\Model;

class TeamMemberLink extends Model
{
    public $timestamps = false;

    public const NETWORKS = ['linkedin', 'x', 'facebook', 'instagram', 'youtube', 'website'];

    protected $fillable = ['team_member_id', 'network', 'url', 'label', 'is_visible', 'display_order'];

    protected function casts(): array
    {
        return ['is_visible' => 'boolean'];
    }

    /** Only absolute http(s) URLs are ever rendered. */
    public function safeUrl(): ?string
    {
        $u = SafeLink::href($this->url);

        return $u !== null && preg_match('#^https?://#i', $u) ? $u : null;
    }
}
