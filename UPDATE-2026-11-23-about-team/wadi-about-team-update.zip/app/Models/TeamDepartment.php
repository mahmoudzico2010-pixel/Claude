<?php

declare(strict_types=1);

namespace App\Models;

use App\Models\Concerns\Auditable;
use App\Models\Concerns\HasTranslations;
use App\Services\Team\TeamHierarchy;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class TeamDepartment extends Model
{
    use Auditable;
    use HasTranslations;
    use SoftDeletes;

    public array $translatedAttributes = ['name', 'description'];

    protected $fillable = ['slug', 'parent_id', 'display_order', 'is_visible', 'contact_url'];

    protected function casts(): array
    {
        return ['is_visible' => 'boolean', 'display_order' => 'integer'];
    }

    protected static function booted(): void
    {
        static::deleting(fn (self $d) => app(TeamHierarchy::class)->assertCanArchiveDepartment($d));

        // Server-side rule, independent of any form: no self-parent, no cycles.
        static::saving(function (self $d): void {
            if ($d->isDirty('parent_id') && $d->parent_id !== null) {
                app(TeamHierarchy::class)->assertDepartmentParent($d, (int) $d->parent_id);
            }
        });
    }

    public function translationModel(): string
    {
        return TeamDepartmentTranslation::class;
    }

    public function parent(): BelongsTo
    {
        return $this->belongsTo(self::class, 'parent_id');
    }

    public function children(): HasMany
    {
        return $this->hasMany(self::class, 'parent_id')->orderBy('display_order');
    }

    public function members(): HasMany
    {
        return $this->hasMany(TeamMember::class, 'department_id');
    }

    public function scopePublic(Builder $q): Builder
    {
        return $q->where('is_visible', true);
    }

    public function label(?string $locale = null): string
    {
        return (string) ($this->t('name', $locale) ?: $this->slug);
    }
}
