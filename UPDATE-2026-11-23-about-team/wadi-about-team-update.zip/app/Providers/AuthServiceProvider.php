<?php

declare(strict_types=1);

namespace App\Providers;

use App\Models\AuditLog;
use App\Models\Caliber;
use App\Models\Category;
use App\Models\Certification;
use App\Models\CompanyLocation;
use App\Models\ContactMessage;
use App\Models\ContentBlock;
use App\Models\Document;
use App\Models\ExportMarket;
use App\Models\HeroSlide;
use App\Models\HomeSection;
use App\Models\MediaAsset;
use App\Models\Module;
use App\Models\NavigationItem;
use App\Models\NewsCategory;
use App\Models\NewsPost;
use App\Models\PackagingType;
use App\Models\Page;
use App\Models\Product;
use App\Models\ProductForm;
use App\Models\QuoteRequest;
use App\Models\SiteSetting;
use App\Models\User;
use App\Models\Variety;
use App\Policies\AuditLogPolicy;
use App\Policies\ClassificationPolicy;
use App\Policies\ContactMessagePolicy;
use App\Policies\ContentPolicy;
use App\Policies\MediaAssetPolicy;
use App\Policies\ModulePolicy;
use App\Policies\NewsPostPolicy;
use App\Policies\PackagingTypePolicy;
use App\Policies\ProductPolicy;
use App\Models\RfqNotification;
use App\Policies\QuoteRequestPolicy;
use App\Policies\RfqNotificationPolicy;
use App\Policies\SiteSettingPolicy;
use App\Policies\UserPolicy;
use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Gate;

class AuthServiceProvider extends ServiceProvider
{
    /** @var array<class-string, class-string> */
    protected $policies = [
        Product::class => ProductPolicy::class,
        QuoteRequest::class => QuoteRequestPolicy::class,
        RfqNotification::class => RfqNotificationPolicy::class,
        ContactMessage::class => ContactMessagePolicy::class,
        NewsPost::class => NewsPostPolicy::class,
        MediaAsset::class => MediaAssetPolicy::class,
        PackagingType::class => PackagingTypePolicy::class,
        User::class => UserPolicy::class,
        SiteSetting::class => SiteSettingPolicy::class,
        AuditLog::class => AuditLogPolicy::class,
        Module::class => ModulePolicy::class,

        // Everything under "classifications" shares one policy.
        Category::class => ClassificationPolicy::class,
        Variety::class => ClassificationPolicy::class,
        ProductForm::class => ClassificationPolicy::class,
        Caliber::class => ClassificationPolicy::class,
        Certification::class => ClassificationPolicy::class,
        ExportMarket::class => ClassificationPolicy::class,
        \App\Models\ProductFrame::class => ClassificationPolicy::class,
        NewsCategory::class => ClassificationPolicy::class,

        // Editable website content.
        HeroSlide::class => ContentPolicy::class,
        HomeSection::class => ContentPolicy::class,
        Page::class => ContentPolicy::class,
        ContentBlock::class => ContentPolicy::class,
        NavigationItem::class => ContentPolicy::class,

        // These two had no policy, so every check silently passed through the
        // Gate default. They follow the same content permissions as the rest
        // of the content group, which is what their resources already used
        // for navigation.
        Document::class => ContentPolicy::class,
        CompanyLocation::class => ContentPolicy::class,

        // Public staff profiles and the reporting structure.
        \App\Models\TeamMember::class => \App\Policies\TeamPolicy::class,
        \App\Models\TeamDepartment::class => \App\Policies\TeamPolicy::class,
    ];

    public function boot(): void
    {
        // The Super Admin bypasses every check, so adding a new permission
        // never silently locks the owner out of a new feature.
        //
        // Two exceptions defer to the policy instead: an inactive account is
        // never granted anything, and nobody — the Super Admin included — may
        // delete their own account, which would lock the site's owner out.
        Gate::before(function (User $user, string $ability, array $arguments = []) {
            if (! $user->is_active) {
                return false;
            }

            // Deleting a user account is always decided by UserPolicy, for
            // the Super Admin too: the policy is what refuses self-deletion
            // and removing the last active Super Admin.
            if (in_array($ability, ['delete', 'forceDelete', 'restore'], true)
                && ($arguments[0] ?? null) instanceof User) {
                return null;
            }

            // The audit trail is append-only for everybody, the Super Admin
            // included: anything other than reading it is decided by the
            // policy, which refuses. (Class-string arguments cover the
            // collection-level abilities such as deleteAny.)
            $subject = $arguments[0] ?? null;
            if (($subject instanceof AuditLog || $subject === AuditLog::class)
                && ! in_array($ability, ['viewAny', 'view'], true)) {
                return null;
            }

            return $user->hasRole(User::ROLE_SUPER_ADMIN) ? true : null;
        });

        // A deactivated account can hold roles but must not act.
        Gate::after(function (User $user, string $ability, ?bool $result) {
            return $user->is_active ? $result : false;
        });
    }
}
