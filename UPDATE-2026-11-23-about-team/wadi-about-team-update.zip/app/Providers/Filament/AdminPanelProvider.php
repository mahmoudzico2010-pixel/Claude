<?php

declare(strict_types=1);

namespace App\Providers\Filament;

use App\Filament\AvatarProviders\InitialsAvatarProvider;
use App\Filament\Pages\Auth\Login;
use App\Http\Middleware\EnsureAccountIsActive;
use App\Http\Middleware\EnsureInstalled;
use App\Http\Middleware\RestrictAdminByIp;
use App\Http\Middleware\SecurityHeaders;
use App\Support\PublicMediaUrl;
use Filament\Enums\ThemeMode;
use Filament\FontProviders\LocalFontProvider;
use Filament\Http\Middleware\Authenticate;
use Filament\Http\Middleware\AuthenticateSession;
use Filament\Http\Middleware\DisableBladeIconComponents;
use Filament\Http\Middleware\DispatchServingFilamentEvent;
use Filament\Navigation\NavigationGroup;
use Filament\Pages\Dashboard;
use Filament\Panel;
use Filament\PanelProvider;
use Filament\Support\Colors\Color;
use Filament\Support\Enums\Width;
use Illuminate\Cookie\Middleware\AddQueuedCookiesToResponse;
use Illuminate\Cookie\Middleware\EncryptCookies;
use Illuminate\Foundation\Http\Middleware\PreventRequestForgery;
use Illuminate\Routing\Middleware\SubstituteBindings;
use Illuminate\Session\Middleware\StartSession;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\Middleware\ShareErrorsFromSession;

class AdminPanelProvider extends PanelProvider
{
    public function panel(Panel $panel): Panel
    {
        return $panel
            ->default()
            ->id('admin')
            ->path(config('wadi.admin.path', 'admin'))
            ->login(Login::class)
            // No silent fallback to permissive access: a resource whose model has
            // no policy, or whose policy lacks an ability Filament asks about,
            // throws instead of passing through the Gate default.
            ->strictAuthorization()
            ->passwordReset()
            ->profile(isSimple: false)

            // Brand palette. Primary is the deep olive green; gold is kept
            // as the warning/accent slot so it stays a highlight rather than
            // a dominant colour.
            //
            // The ramps are written out in full rather than handed to
            // Color::hex(). Given a single very dark, low-chroma colour like
            // #173F35, Filament generates the lighter shades by raising
            // lightness at constant hue and chroma — which drifts the
            // mid-shades (the ones buttons actually use) towards teal. Buttons
            // came out bright teal-green instead of olive. Explicit shades
            // keep 600 — the solid-button shade — exactly on brand.
            ->colors([
                'primary' => [
                    50 => '#f2f7f5',
                    100 => '#deeae5',
                    200 => '#bfd5cd',
                    300 => '#94b8ac',
                    400 => '#5e9183',
                    500 => '#22574a',
                    600 => '#173f35',  // Deep Olive Green — solid buttons
                    700 => '#123128',
                    800 => '#0e2e27',  // Dark Forest Green
                    900 => '#0a211c',
                    950 => '#06120f',
                ],
                'gray' => [
                    50 => '#f7f7f6',
                    100 => '#eeefed',
                    200 => '#dcdedb',
                    300 => '#bcc0bc',
                    400 => '#949a95',
                    500 => '#737a75',
                    600 => '#5a635c',
                    700 => '#484f4a',
                    800 => '#343936',
                    900 => '#202521',  // Charcoal
                    950 => '#141715',
                ],
                'success' => Color::hex('#4B7A52'),
                'warning' => Color::hex('#C6A15B'),
                'danger' => Color::hex('#B4472F'),
                'info' => Color::hex('#3E6B7D'),
            ])

            ->brandName(fn (): string => (string) (setting('company.short_name_'.app()->getLocale())
                ?? setting('company.short_name_en')
                ?? config('app.name')))
            ->brandLogo(fn (): ?string => $this->logoUrl())
            ->darkModeBrandLogo(fn (): ?string => $this->logoUrl(dark: true))
            ->brandLogoHeight('2.25rem')
            ->favicon(fn (): ?string => $this->faviconUrl())

            // Fonts are self-hosted: the admin theme imports the same
            // @fontsource files as the public site. LocalFontProvider with no
            // URL emits nothing — `provider: null` would fall back to Bunny
            // Fonts for a custom family and request fonts.bunny.net.
            ->font('Manrope', provider: LocalFontProvider::class)
            // Initials rendered locally; the default sends names to ui-avatars.com.
            ->defaultAvatarProvider(InitialsAvatarProvider::class)
            ->viteTheme('resources/css/filament/admin/theme.css')

            ->defaultThemeMode(ThemeMode::Light)
            ->maxContentWidth(Width::Full)
            ->sidebarCollapsibleOnDesktop()
            ->databaseNotifications()
            ->databaseTransactions()
            ->unsavedChangesAlerts()

            ->navigationGroups([
                // Day-to-day work first, set-up and housekeeping last.
                NavigationGroup::make()->label(fn (): string => __('nav.groups.catalogue')),
                NavigationGroup::make()->label(fn (): string => __('nav.groups.inquiries')),
                NavigationGroup::make()->label(fn (): string => __('nav.groups.content')),
                NavigationGroup::make()->label(fn (): string => __('nav.groups.media')),
                NavigationGroup::make()->label(fn (): string => __('nav.groups.company'))->collapsed(),
                NavigationGroup::make()->label(fn (): string => __('nav.groups.languages')),
                NavigationGroup::make()->label(fn (): string => __('nav.groups.settings'))->collapsed(),
                NavigationGroup::make()->label(fn (): string => __('nav.groups.security'))->collapsed(),
                NavigationGroup::make()->label(fn (): string => __('nav.groups.maintenance'))->collapsed(),
                NavigationGroup::make()->label(fn (): string => __('nav.groups.plugins'))->collapsed(),
            ])

            ->discoverResources(in: app_path('Filament/Resources'), for: 'App\Filament\Resources')
            ->discoverPages(in: app_path('Filament/Pages'), for: 'App\Filament\Pages')
            ->discoverWidgets(in: app_path('Filament/Widgets'), for: 'App\Filament\Widgets')
            ->pages([Dashboard::class])
            ->navigationItems(\App\Plugins\PluginNavigation::items())

            ->middleware([
                // First in the stack. The panel has its own middleware list,
                // so the web group's copy never reaches /admin — without this,
                // opening the panel before installation boots Filament against
                // a database that does not exist yet.
                EnsureInstalled::class,
                EncryptCookies::class,
                AddQueuedCookiesToResponse::class,
                StartSession::class,
                AuthenticateSession::class,
                // The panel does not run the web group, so the deactivated-
                // account check is listed here too.
                EnsureAccountIsActive::class,
                ShareErrorsFromSession::class,
                // CSRF for the panel's own non-Livewire routes (POST logout).
                // Livewire's update endpoint runs the web group, which has it.
                PreventRequestForgery::class,
                SubstituteBindings::class,
                DisableBladeIconComponents::class,
                DispatchServingFilamentEvent::class,
                RestrictAdminByIp::class,
                // The web group's copy never reaches the panel's routes.
                SecurityHeaders::class,
            ])
            ->authMiddleware([
                Authenticate::class,
            ])
            ->authGuard('web');
    }

    /**
     * Logo chosen from Settings, so the company can change it without a
     * deploy. Falls back to null, which renders the brand name as text.
     */
    private function logoUrl(bool $dark = false): ?string
    {
        $key = $dark ? 'company.logo_dark' : 'company.logo_light';

        try {
            $asset = setting_media($key) ?? setting_media('company.logo_light');

            return $asset?->url();
        } catch (\Throwable) {
            return null;
        }
    }

    private function faviconUrl(): ?string
    {
        try {
            $asset = setting_media('company.favicon');

            if ($asset !== null) {
                return $asset->url();
            }

            return Storage::disk('public')->exists('branding/favicon.png')
                ? PublicMediaUrl::for('branding/favicon.png')
                : null;
        } catch (\Throwable) {
            return null;
        }
    }
}
