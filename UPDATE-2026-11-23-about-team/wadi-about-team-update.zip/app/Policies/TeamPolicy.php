<?php

declare(strict_types=1);

namespace App\Policies;

use App\Policies\Concerns\ChecksPermissions;
use App\Support\Permissions;

/** Team members and departments: view / edit are separate from publishing and from changing the structure. */
class TeamPolicy
{
    use ChecksPermissions;

    protected function viewPermission(): string
    {
        return Permissions::TEAM_VIEW;
    }

    protected function createPermission(): string
    {
        return Permissions::TEAM_EDIT;
    }

    protected function updatePermission(): string
    {
        return Permissions::TEAM_EDIT;
    }

    /** Archiving changes the structure. */
    protected function deletePermission(): string
    {
        return Permissions::TEAM_STRUCTURE;
    }
}
