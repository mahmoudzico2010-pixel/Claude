<?php

declare(strict_types=1);

namespace App\Filament\Pages;

use App\Filament\Resources\Team\TeamMemberResource;
use App\Models\TeamMember;
use App\Services\Team\TeamHierarchy;
use App\Support\Permissions;
use BackedEnum;
use Filament\Notifications\Notification;
use Filament\Pages\Page;
use Filament\Support\Icons\Heroicon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;

/** Website Content → Team structure: the whole reporting tree (drafts included), reorder inside a branch, move to a manager. */
class TeamStructure extends Page
{
    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedShare;

    protected static ?int $navigationSort = 12;

    protected string $view = 'filament.pages.team-structure';

    public static function getNavigationGroup(): ?string
    {
        return __('nav.groups.content');
    }

    public static function getNavigationLabel(): string
    {
        return __('team.admin.structure');
    }

    public function getTitle(): string
    {
        return __('team.admin.structure');
    }

    public static function canAccess(): bool
    {
        return Auth::user()?->can(Permissions::TEAM_VIEW) ?? false;
    }

    public function canStructure(): bool
    {
        return Auth::user()?->can(Permissions::TEAM_STRUCTURE) ?? false;
    }

    /** @return list<array> */
    public function tree(): array
    {
        return app(TeamHierarchy::class)->tree(false);
    }

    /** @return array<int, string> */
    public function managers(): array
    {
        return TeamMemberResource::managerOptions(null);
    }

    public function nudge(int $id, int $dir): void
    {
        abort_unless($this->canStructure(), 403);
        app(TeamHierarchy::class)->nudge(TeamMember::query()->findOrFail($id), $dir < 0 ? -1 : 1);
    }

    public function moveTo(int $id, ?string $managerId): void
    {
        abort_unless($this->canStructure(), 403);
        try {
            app(TeamHierarchy::class)->move(TeamMember::query()->findOrFail($id), $managerId === null || $managerId === '' ? null : (int) $managerId, false);
            Notification::make()->title(__('team.admin.move_done'))->success()->send();
        } catch (ValidationException $e) {
            Notification::make()->title(collect($e->errors())->flatten()->first())->danger()->send();
        }
    }
}
