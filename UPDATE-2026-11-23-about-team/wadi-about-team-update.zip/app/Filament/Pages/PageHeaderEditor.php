<?php

declare(strict_types=1);

namespace App\Filament\Pages;

use App\Filament\Concerns\ManagesPageHeader;
use App\Services\PageHeaders\PageHeaderService;
use App\Support\Permissions;
use BackedEnum;
use Filament\Pages\Page;
use Filament\Support\Icons\Heroicon;
use Illuminate\Support\Facades\Auth;

/** Stand-alone page-header editor for banners that are not CMS pages (categories, product listing, news, quote) — and a list of every banner. */
class PageHeaderEditor extends Page
{
    use ManagesPageHeader;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedPhoto;

    protected static ?int $navigationSort = 3;

    protected static ?string $slug = 'page-headers';

    protected string $view = 'filament.pages.page-header-editor';

    public static function getNavigationGroup(): ?string
    {
        return __('nav.groups.content');
    }

    public static function getNavigationLabel(): string
    {
        return __('pageheader.nav');
    }

    public function getTitle(): string
    {
        return __('pageheader.title');
    }

    public static function canAccess(): bool
    {
        return Auth::user()?->can(Permissions::CONTENT_VIEW) ?? false;
    }

    public function mount(): void
    {
        $key = (string) request()->query('key', '');
        if ($key !== '' && preg_match('/^(page|category|route):[A-Za-z0-9._-]+$/', $key) === 1) {
            $this->loadHeader($key);
        }
    }

    /** @return list<array{key: string, label: string, kind: string}> */
    public function keys(): array
    {
        return app(PageHeaderService::class)->allKeys();
    }

    public static function urlFor(string $key): string
    {
        return static::getUrl(['key' => $key]);
    }
}
