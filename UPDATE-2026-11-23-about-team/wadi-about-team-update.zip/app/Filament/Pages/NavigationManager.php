<?php

declare(strict_types=1);

namespace App\Filament\Pages;

use App\Filament\Resources\Content\NavigationItemResource;
use App\Models\NavigationItem;
use App\Support\Locales;
use App\Support\Permissions;
use BackedEnum;
use Filament\Notifications\Notification;
use Filament\Pages\Page;
use Filament\Support\Icons\Heroicon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/**
 * Content → Menu structure: the nested menu as a tree. Drag an item to reorder it or drop it into another item to
 * nest it; the buttons do the same from a keyboard. The model refuses cycles and menus deeper than the configured limit,
 * so a bad drop is rejected rather than saved. Label edits (and their language sign-off) stay in the item form.
 */
class NavigationManager extends Page
{
    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedQueueList;

    protected static ?int $navigationSort = 6;

    protected static ?string $slug = 'menu-structure';

    protected string $view = 'filament.pages.navigation-manager';

    public string $location = 'header';

    public string $previewLocale = 'en';

    public static function getNavigationGroup(): ?string
    {
        return __('nav.groups.content');
    }

    public static function getNavigationLabel(): string
    {
        return __('admin.navigation.manager.title');
    }

    public function getTitle(): string
    {
        return __('admin.navigation.manager.title');
    }

    public static function canAccess(): bool
    {
        return (bool) Auth::user()?->can(Permissions::CONTENT_MANAGE);
    }

    private function authorizeManage(): void
    {
        abort_unless(static::canAccess(), 403);
    }

    /** @return array<string, string> */
    public function locations(): array
    {
        return NavigationItemResource::locationOptions();
    }

    /** @return array<string, string> code => native name (every supported language; unpublished ones are previewable only here) */
    public function previewLocales(): array
    {
        return collect(Locales::supported())->map(fn (array $c): string => $c['native'])->all();
    }

    /** The menu as nested arrays (active and inactive). @return list<array<string, mixed>> */
    public function tree(): array
    {
        $items = NavigationItem::query()->where('location', $this->location)
            ->orderBy('display_order')->orderBy('id')->get();
        $byParent = $items->groupBy(fn (NavigationItem $i): string => (string) ($i->parent_id ?? 0));

        $build = function (string $parent, int $level) use (&$build, $byParent): array {
            return $byParent->get($parent, collect())->map(fn (NavigationItem $i): array => [
                'id' => (int) $i->id,
                'label' => $i->getAttribute('label_'.$this->previewLocale) ?: $i->label_en,
                'fallback' => blank($i->getAttribute('label_'.$this->previewLocale)),
                'active' => (bool) $i->is_active,
                'href' => $i->href($this->previewLocale),
                'new_tab' => (bool) $i->open_in_new_tab,
                'level' => $level,
                'can_nest' => $level < NavigationItem::maxDepth(),
                'children' => $build((string) $i->id, $level + 1),
            ])->values()->all();
        };

        return $build('0', 1);
    }

    public function editUrl(int $id): string
    {
        return NavigationItemResource::getUrl('index').'?tableAction=edit&tableActionRecord='.$id;
    }

    /** Called by the drag-and-drop list: move item $item to $position inside the list whose parent is $group (0 = top level). */
    public function reorder(int|string $item, int $position, int|string $group = 0): void
    {
        $this->authorizeManage();
        $this->place((int) $item, (int) $group ?: null, $position);
    }

    public function moveUp(int $id): void
    {
        $this->authorizeManage();
        $node = NavigationItem::findOrFail($id);
        $siblings = $this->siblings($node)->pluck('id')->all();
        $at = array_search($id, $siblings, true);
        if ($at > 0) {
            $this->place($id, $node->parent_id, $at - 1);
        }
    }

    public function moveDown(int $id): void
    {
        $this->authorizeManage();
        $node = NavigationItem::findOrFail($id);
        $siblings = $this->siblings($node)->pluck('id')->all();
        $at = array_search($id, $siblings, true);
        if ($at !== false && $at < count($siblings) - 1) {
            $this->place($id, $node->parent_id, $at + 1);
        }
    }

    /** Make the item a child of the sibling just above it. */
    public function indent(int $id): void
    {
        $this->authorizeManage();
        $node = NavigationItem::findOrFail($id);
        $siblings = $this->siblings($node)->pluck('id')->all();
        $at = array_search($id, $siblings, true);
        if ($at > 0) {
            $newParent = (int) $siblings[$at - 1];
            $this->place($id, $newParent, NavigationItem::query()->where('parent_id', $newParent)->count());
        }
    }

    /** Move the item up one level, to just after its former parent. */
    public function outdent(int $id): void
    {
        $this->authorizeManage();
        $node = NavigationItem::findOrFail($id);
        if ($node->parent_id === null) {
            return;
        }
        $parent = NavigationItem::findOrFail($node->parent_id);
        $siblings = $this->siblings($parent)->pluck('id')->all();
        $this->place($id, $parent->parent_id, ((int) array_search($parent->id, $siblings, true)) + 1);
    }

    public function toggleActive(int $id): void
    {
        $this->authorizeManage();
        $node = NavigationItem::findOrFail($id);
        $node->update(['is_active' => ! $node->is_active]);
    }

    private function siblings(NavigationItem $node)
    {
        return NavigationItem::query()->where('location', $node->location)
            ->where('parent_id', $node->parent_id)->orderBy('display_order')->orderBy('id')->get();
    }

    private function place(int $id, ?int $parentId, int $position): void
    {
        $node = NavigationItem::findOrFail($id);

        try {
            DB::transaction(function () use ($node, $parentId, $position): void {
                if ((int) $node->parent_id !== (int) $parentId) {
                    $node->parent_id = $parentId;
                    if ($parentId === null) {
                        $node->location = $this->location;
                    }
                    $node->save(); // runs the cycle / depth / location guards
                }

                $ids = NavigationItem::query()->where('location', $node->location)
                    ->where('parent_id', $parentId)->whereKeyNot($node->id)
                    ->orderBy('display_order')->orderBy('id')->pluck('id')->all();
                array_splice($ids, max(0, min($position, count($ids))), 0, [$node->id]);

                foreach ($ids as $order => $siblingId) {
                    $row = NavigationItem::find($siblingId);
                    if ($row !== null && (int) $row->display_order !== $order) {
                        $row->display_order = $order;
                        $row->save();
                    }
                }
            });
        } catch (ValidationException $e) {
            Notification::make()->danger()->title(collect($e->errors())->flatten()->first())->send();
        }
    }
}
