<?php

declare(strict_types=1);

namespace App\Filament\Resources\Team\Pages;

use App\Filament\Concerns\HandlesTranslations;
use App\Filament\Concerns\OffersAiTranslation;
use App\Filament\Resources\Team\TeamDepartmentResource;
use App\Models\TeamDepartment;
use App\Support\Permissions;
use Filament\Resources\Pages\EditRecord;
use Illuminate\Support\Facades\Auth;

class EditTeamDepartment extends EditRecord
{
    use HandlesTranslations;
    use OffersAiTranslation;

    protected static string $resource = TeamDepartmentResource::class;

    protected function getHeaderActions(): array
    {
        return [$this->aiTranslateAction()];
    }

    protected function mutateFormDataBeforeSave(array $data): array
    {
        if (blank($data['slug'] ?? null)) {
            unset($data['slug']);

        }
        if (! Auth::user()?->can(Permissions::TEAM_STRUCTURE)) {
            unset($data['parent_id'], $data['display_order']);
        }

        return $this->extractTranslations($data);
    }
}
