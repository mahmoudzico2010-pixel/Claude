<?php

declare(strict_types=1);

namespace App\Filament\Resources\Team\Pages;

use App\Filament\Concerns\HandlesTranslations;
use App\Filament\Concerns\OffersAiTranslation;
use App\Filament\Resources\Team\TeamMemberResource;
use App\Models\TeamMember;
use App\Support\Permissions;
use Filament\Resources\Pages\CreateRecord;
use Illuminate\Support\Facades\Auth;

class CreateTeamMember extends CreateRecord
{
    use HandlesTranslations;
    use OffersAiTranslation;

    protected static string $resource = TeamMemberResource::class;

    protected function getHeaderActions(): array
    {
        return [$this->aiTranslateAction()];
    }

    protected function mutateFormDataBeforeCreate(array $data): array
    {
        // New people are always drafts: publishing is a separate permission and a separate action.
        $data['status'] = TeamMember::DRAFT;
        $data['created_by'] = Auth::id();
        $data['updated_by'] = Auth::id();
        $data['slug'] = TeamMember::uniqueSlug((string) ($data['slug'] ?: ($this->data['translations']['en']['name'] ?? 'member')));
        if (! Auth::user()?->can(Permissions::TEAM_STRUCTURE)) {
            unset($data['department_id'], $data['reports_to_id'], $data['display_order']);
        }

        return $this->extractTranslations($data);
    }
}
