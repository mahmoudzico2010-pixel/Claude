<?php

declare(strict_types=1);

namespace App\Filament\Resources\Team\Pages;

use App\Filament\Concerns\HandlesTranslations;
use App\Filament\Concerns\OffersAiTranslation;
use App\Filament\Resources\Team\TeamDepartmentResource;
use App\Models\TeamDepartment;
use App\Support\Permissions;
use Filament\Resources\Pages\CreateRecord;
use Illuminate\Support\Facades\Auth;

class CreateTeamDepartment extends CreateRecord
{
    use HandlesTranslations;
    use OffersAiTranslation;

    protected static string $resource = TeamDepartmentResource::class;

    protected function getHeaderActions(): array
    {
        return [$this->aiTranslateAction()];
    }

    protected function mutateFormDataBeforeCreate(array $data): array
    {
        if (blank($data['slug'] ?? null)) {
            unset($data['slug']);
            $data['slug'] = \Illuminate\Support\Str::slug((string) ($this->data['translations']['en']['name'] ?? 'department')).'-'.substr(md5((string) microtime(true)), 0, 4);
        }
        if (! Auth::user()?->can(Permissions::TEAM_STRUCTURE)) {
            unset($data['parent_id'], $data['display_order']);
        }

        return $this->extractTranslations($data);
    }
}
