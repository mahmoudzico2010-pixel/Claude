<?php

declare(strict_types=1);

namespace App\Filament\Resources\Team\Pages;

use App\Filament\Resources\Team\TeamDepartmentResource;
use Filament\Actions\CreateAction;
use Filament\Resources\Pages\ListRecords;

class ListTeamDepartments extends ListRecords
{
    protected static string $resource = TeamDepartmentResource::class;

    protected function getHeaderActions(): array
    {
        return [CreateAction::make()];
    }
}
