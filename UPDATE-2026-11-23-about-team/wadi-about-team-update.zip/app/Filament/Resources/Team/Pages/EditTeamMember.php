<?php

declare(strict_types=1);

namespace App\Filament\Resources\Team\Pages;

use App\Filament\Concerns\HandlesTranslations;
use App\Filament\Concerns\OffersAiTranslation;
use App\Filament\Resources\Team\TeamMemberResource;
use App\Support\Permissions;
use Filament\Resources\Pages\EditRecord;
use Illuminate\Support\Facades\Auth;

class EditTeamMember extends EditRecord
{
    use HandlesTranslations;
    use OffersAiTranslation;

    protected static string $resource = TeamMemberResource::class;

    protected function getHeaderActions(): array
    {
        return [$this->aiTranslateAction()];
    }

    protected function mutateFormDataBeforeSave(array $data): array
    {
        $data['updated_by'] = Auth::id();
        unset($data['status'], $data['published_at']); // only the Publish action changes these
        if (! Auth::user()?->can(Permissions::TEAM_STRUCTURE)) {
            unset($data['department_id'], $data['reports_to_id'], $data['display_order']);
        }
        if (blank($data['slug'] ?? null)) {
            unset($data['slug']);
        }

        return $this->extractTranslations($data);
    }
}
