<?php

declare(strict_types=1);

namespace App\Filament\Resources\Team;

use App\Filament\Forms\Components\AiTranslateButton;
use App\Filament\Resources\Team\Pages\CreateTeamDepartment;
use App\Filament\Resources\Team\Pages\EditTeamDepartment;
use App\Filament\Resources\Team\Pages\ListTeamDepartments;
use App\Models\TeamDepartment;
use App\Support\Permissions;
use BackedEnum;
use Filament\Actions\Action;
use Filament\Actions\EditAction;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Notifications\Notification;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Tabs;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\TrashedFilter;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;

class TeamDepartmentResource extends Resource
{
    protected static ?string $model = TeamDepartment::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedBuildingOffice2;

    protected static ?int $navigationSort = 11;

    public static function getNavigationGroup(): ?string
    {
        return __('nav.groups.content');
    }

    public static function getNavigationLabel(): string
    {
        return __('team.admin.departments');
    }

    public static function getModelLabel(): string
    {
        return __('team.admin.department');
    }

    public static function getPluralModelLabel(): string
    {
        return __('team.admin.departments');
    }

    public static function canStructure(): bool
    {
        return (bool) Auth::user()?->can(Permissions::TEAM_STRUCTURE);
    }

    public static function form(Schema $schema): Schema
    {
        $structure = fn (): bool => static::canStructure();

        return $schema->components([
            Section::make()->columns(2)->schema([
                TextInput::make('slug')->label('Slug')->maxLength(120)->alphaDash()->helperText(__('team.admin.slug_hint'))
                    ->unique(ignoreRecord: true, modifyRuleUsing: fn ($rule) => $rule->whereNull('deleted_at')),
                Select::make('parent_id')->label(__('team.admin.parent_dept'))->placeholder(__('team.admin.roots'))->native(false)->searchable()
                    ->options(fn (?TeamDepartment $record) => TeamDepartment::query()->with('translations')->when($record, fn ($q) => $q->where('id', '!=', $record->id))->get()->mapWithKeys(fn ($d) => [$d->id => $d->label()])->all())
                    ->disabled(fn () => ! $structure())->dehydrated(fn () => $structure()),
                TextInput::make('display_order')->label(__('team.admin.order'))->numeric()->default(0)->disabled(fn () => ! $structure())->dehydrated(fn () => $structure()),
                Toggle::make('is_visible')->label(__('team.admin.visible'))->default(true),
                TextInput::make('contact_url')->label(__('team.admin.contact_url'))->url()->maxLength(500)->columnSpanFull(),
            ]),
            AiTranslateButton::make(['name', 'description'], 'dotted'),
            Tabs::make('locales')->columnSpanFull()->tabs(
                collect(config('wadi.locales'))->map(fn (array $c, string $l) => Tabs\Tab::make($c['native'])->schema([
                    TextInput::make("translations.$l.name")->label(__('team.admin.name'))->maxLength(160)->required($l === 'en')->extraInputAttributes(['dir' => $c['dir'] ?? 'ltr']),
                    Textarea::make("translations.$l.description")->label(__('admin.fields.description'))->rows(3)->maxLength(1000)->extraInputAttributes(['dir' => $c['dir'] ?? 'ltr']),
                ]))->values()->all()
            ),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->modifyQueryUsing(fn (Builder $query) => $query->with(['translations', 'parent.translations'])->withCount('members'))
            ->defaultSort('display_order')
            ->columns([
                TextColumn::make('name')->label(__('team.admin.name'))->getStateUsing(fn (TeamDepartment $record) => $record->label())->description(fn (TeamDepartment $record) => $record->slug)->weight('medium'),
                TextColumn::make('parent_label')->label(__('team.admin.parent_dept'))->getStateUsing(fn (TeamDepartment $record) => $record->parent?->label())->placeholder('—'),
                TextColumn::make('members_count')->label(__('team.admin.members'))->badge()->color('gray'),
                IconColumn::make('is_visible')->label(__('team.admin.visible'))->boolean(),
            ])
            ->filters([TrashedFilter::make()->label(__('team.admin.archive'))])
            ->recordActions([
                EditAction::make(),
                Action::make('archive')->label(__('team.admin.archive'))->icon('heroicon-m-archive-box')->color('danger')->visible(fn (TeamDepartment $record) => ! $record->trashed() && static::canStructure())
                    ->requiresConfirmation()->modalDescription(__('team.errors.dept_in_use'))
                    ->action(function (TeamDepartment $record): void {
                        abort_unless(static::canStructure(), 403);
                        try {
                            $record->delete();
                        } catch (ValidationException $e) {
                            Notification::make()->title(collect($e->errors())->flatten()->first())->danger()->send();
                        }
                    }),
                Action::make('restore')->label(__('team.admin.restore'))->icon('heroicon-m-arrow-uturn-left')->visible(fn (TeamDepartment $record) => $record->trashed() && static::canStructure())
                    ->action(function (TeamDepartment $record): void {
                        abort_unless(static::canStructure(), 403);
                        $record->restore();
                    }),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => ListTeamDepartments::route('/'),
            'create' => CreateTeamDepartment::route('/create'),
            'edit' => EditTeamDepartment::route('/{record}/edit'),
        ];
    }

}
