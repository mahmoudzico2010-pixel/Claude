<?php

declare(strict_types=1);

namespace App\Filament\Resources\Team;

use App\Filament\Forms\Components\AiTranslateButton;
use App\Filament\Forms\Components\MediaPicker;
use App\Filament\Resources\Team\Pages\CreateTeamMember;
use App\Filament\Resources\Team\Pages\EditTeamMember;
use App\Filament\Resources\Team\Pages\ListTeamMembers;
use App\Models\TeamDepartment;
use App\Models\TeamMember;
use App\Models\TeamMemberLink;
use App\Services\Team\TeamHierarchy;
use App\Support\Permissions;
use BackedEnum;
use Filament\Actions\Action;
use Filament\Actions\EditAction;
use Filament\Forms\Components\Placeholder;
use Filament\Forms\Components\Repeater;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Notifications\Notification;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Tabs;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\ImageColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\Filter;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Filters\TrashedFilter;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;

class TeamMemberResource extends Resource
{
    protected static ?string $model = TeamMember::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedUserGroup;

    protected static ?int $navigationSort = 10;

    public static function getNavigationGroup(): ?string
    {
        return __('nav.groups.content');
    }

    public static function getNavigationLabel(): string
    {
        return __('team.admin.members');
    }

    public static function getModelLabel(): string
    {
        return __('team.admin.member');
    }

    public static function getPluralModelLabel(): string
    {
        return __('team.admin.members');
    }

    public static function canStructure(): bool
    {
        return (bool) Auth::user()?->can(Permissions::TEAM_STRUCTURE);
    }

    public static function canPublish(): bool
    {
        return (bool) Auth::user()?->can(Permissions::TEAM_PUBLISH);
    }

    /** Everyone who could be chosen as a manager: not archived, not the person themself, nobody who already reports (even indirectly) to them. */
    public static function managerOptions(?TeamMember $self): array
    {
        $blocked = [];
        if ($self?->exists) {
            $blocked[] = (int) $self->getKey();
            $queue = [(int) $self->getKey()];
            while ($queue) {
                $kids = TeamMember::query()->whereIn('reports_to_id', $queue)->pluck('id')->map(fn ($v) => (int) $v)->all();
                $kids = array_diff($kids, $blocked);
                $blocked = array_merge($blocked, $kids);
                $queue = $kids;
            }
        }

        return TeamMember::query()->with('translations')->whereNotIn('id', $blocked ?: [0])->orderBy('display_order')->get()
            ->mapWithKeys(fn (TeamMember $m) => [$m->id => $m->displayName().($m->t('job_title') ? ' — '.$m->t('job_title') : '')])->all();
    }

    public static function departmentOptions(): array
    {
        return TeamDepartment::query()->with('translations')->orderBy('display_order')->get()->mapWithKeys(fn (TeamDepartment $d) => [$d->id => $d->label()])->all();
    }

    public static function form(Schema $schema): Schema
    {
        $locales = (array) config('wadi.locales', []);
        $structure = fn (): bool => static::canStructure();

        return $schema->components([
            Placeholder::make('note')->hiddenLabel()->content(__('team.admin.private_note'))->columnSpanFull(),

            Tabs::make('member')->columnSpanFull()->persistTabInQueryString()->tabs([
                Tabs\Tab::make(__('team.admin.tab_details'))->schema([
                    Section::make()->columns(2)->schema([
                        MediaPicker::make('portrait_id', __('team.admin.portrait'), 'team'),
                        Section::make()->columns(2)->columnSpanFull(false)->schema([
                            TextInput::make('portrait_focal_x')->label(__('team.admin.focal_x'))->numeric()->minValue(0)->maxValue(100)->default(50),
                            TextInput::make('portrait_focal_y')->label(__('team.admin.focal_y'))->numeric()->minValue(0)->maxValue(100)->default(35),
                        ]),
                        Select::make('department_id')->label(__('team.admin.department'))->options(fn () => static::departmentOptions())->searchable()->native(false)
                            ->placeholder(__('team.admin.nobody'))->disabled(fn () => ! $structure())->dehydrated(fn () => $structure()),
                        Select::make('reports_to_id')->label(__('team.admin.reports_to'))->options(fn (?TeamMember $record) => static::managerOptions($record))->searchable()->native(false)
                            ->placeholder(__('team.admin.nobody'))->disabled(fn () => ! $structure())->dehydrated(fn () => $structure()),
                        TextInput::make('slug')->label('Slug')->helperText(__('team.admin.slug_hint'))->maxLength(120)->alphaDash()
                            ->unique(ignoreRecord: true, modifyRuleUsing: fn ($rule) => $rule->whereNull('deleted_at')),
                        TextInput::make('display_order')->label(__('team.admin.order'))->numeric()->default(0)->disabled(fn () => ! $structure())->dehydrated(fn () => $structure()),
                        Toggle::make('show_on_about')->label(__('team.admin.show_about')),
                        Toggle::make('show_on_team')->label(__('team.admin.show_team'))->default(true),
                    ]),
                ]),

                Tabs\Tab::make(__('team.admin.tab_texts'))->schema([
                    AiTranslateButton::make(['name', 'job_title', 'short_bio', 'full_bio', 'portrait_alt'], 'dotted'),
                    Tabs::make('locales')->tabs(
                        collect($locales)->map(fn (array $c, string $l) => Tabs\Tab::make($c['native'])->schema([
                            TextInput::make("translations.$l.name")->label(__('team.admin.name'))->maxLength(160)->required($l === 'en')->extraInputAttributes(['dir' => $c['dir'] ?? 'ltr']),
                            TextInput::make("translations.$l.job_title")->label(__('team.admin.job_title'))->maxLength(160)->extraInputAttributes(['dir' => $c['dir'] ?? 'ltr']),
                            Textarea::make("translations.$l.short_bio")->label(__('team.admin.short_bio'))->rows(2)->maxLength(400)->extraInputAttributes(['dir' => $c['dir'] ?? 'ltr']),
                            Textarea::make("translations.$l.full_bio")->label(__('team.admin.full_bio'))->rows(6)->maxLength(6000)->extraInputAttributes(['dir' => $c['dir'] ?? 'ltr']),
                            TextInput::make("translations.$l.portrait_alt")->label(__('team.admin.alt'))->maxLength(255)->extraInputAttributes(['dir' => $c['dir'] ?? 'ltr']),
                        ]))->values()->all()
                    ),
                ]),

                Tabs\Tab::make(__('team.admin.tab_contact'))->schema([
                    Placeholder::make('hint')->hiddenLabel()->content(__('team.admin.contact_hint')),
                    Section::make()->columns(2)->schema([
                        TextInput::make('email')->label(__('team.admin.email'))->email()->maxLength(190),
                        Toggle::make('show_email')->label(__('team.admin.show_email')),
                        TextInput::make('phone')->label(__('team.admin.phone'))->tel()->maxLength(40)->placeholder('+20 …')
                            ->regex('/^\+?[0-9 ()\-\.]{7,40}$/'),
                        Toggle::make('show_phone')->label(__('team.admin.show_phone')),
                        TextInput::make('whatsapp')->label(__('team.admin.whatsapp'))->tel()->maxLength(40)->placeholder('+20 …')
                            ->regex('/^\+?[0-9 ()\-\.]{7,40}$/'),
                        Toggle::make('show_whatsapp')->label(__('team.admin.show_whatsapp')),
                    ]),
                    Repeater::make('links')->relationship('links')->defaultItems(0)->addActionLabel(__('team.admin.links'))->label(__('team.admin.links'))->orderColumn('display_order')->collapsible()->columns(2)->schema([
                        Select::make('network')->label(__('team.admin.network'))->options(array_combine(TeamMemberLink::NETWORKS, array_map('ucfirst', TeamMemberLink::NETWORKS)))->required()->native(false),
                        TextInput::make('url')->label(__('team.admin.url'))->url()->required()->maxLength(500)->rule('starts_with:https://,http://'),
                        TextInput::make('label')->label(__('team.admin.label'))->maxLength(80),
                        Toggle::make('is_visible')->label(__('team.admin.visible'))->default(true),
                    ]),
                ]),
            ]),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->modifyQueryUsing(fn (Builder $query) => $query->with(['translations', 'department.translations', 'manager.translations', 'portrait']))
            ->defaultSort('display_order')
            ->columns([
                ImageColumn::make('portrait_img')->label('')->circular()->getStateUsing(fn (TeamMember $record) => $record->portrait?->url())->defaultImageUrl(null),
                TextColumn::make('name')->label(__('team.admin.name'))->getStateUsing(fn (TeamMember $record) => $record->displayName())->description(fn (TeamMember $record) => $record->t('job_title'))->weight('medium')
                    ->searchable(query: fn (Builder $q, string $s) => $q->where(fn ($w) => $w->where('slug', 'like', "%$s%")->orWhereHas('translations', fn ($t) => $t->where('name', 'like', "%$s%")->orWhere('job_title', 'like', "%$s%")))),
                TextColumn::make('dept_label')->label(__('team.admin.department'))->getStateUsing(fn (TeamMember $record) => $record->department?->label())->placeholder('—'),
                TextColumn::make('manager_label')->label(__('team.admin.reports_to'))->getStateUsing(fn (TeamMember $record) => $record->manager?->displayName())->placeholder('—'),
                TextColumn::make('status')->label(__('team.admin.status'))->badge()
                    ->getStateUsing(fn (TeamMember $record) => $record->trashed() ? __('team.admin.archive') : ($record->status === TeamMember::PUBLISHED ? __('team.admin.published') : __('team.admin.draft')))
                    ->color(fn (TeamMember $record) => $record->trashed() ? 'gray' : ($record->status === TeamMember::PUBLISHED ? 'success' : 'warning')),
                TextColumn::make('portrait_state')->label(__('team.admin.portrait'))->badge()->getStateUsing(fn (TeamMember $record) => $record->portrait_id ? '✓' : __('team.admin.missing_portrait'))->color(fn (TeamMember $record) => $record->portrait_id ? 'success' : 'warning'),
                TextColumn::make('translated')->label('🌐')->getStateUsing(fn (TeamMember $record) => $record->translations->filter(fn ($t) => filled($t->name))->count().'/10')->badge()->color('gray'),
            ])
            ->filters([
                SelectFilter::make('department_id')->label(__('team.admin.filter_dept'))->options(fn () => static::departmentOptions()),
                SelectFilter::make('reports_to_id')->label(__('team.admin.filter_manager'))->options(fn () => static::managerOptions(null)),
                SelectFilter::make('status')->label(__('team.admin.filter_visibility'))->options([TeamMember::DRAFT => __('team.admin.draft'), TeamMember::PUBLISHED => __('team.admin.published')]),
                Filter::make('missing_portrait')->label(__('team.admin.missing_portrait'))->query(fn (Builder $query) => $query->whereNull('portrait_id')),
                Filter::make('missing_translation')->label(__('team.admin.missing_translation'))
                    ->query(fn (Builder $query) => $query->where(fn ($w) => $w->has('translations', '<', count((array) config('wadi.locales', []))))),
                TrashedFilter::make()->label(__('team.admin.archive')),
            ])
            ->recordActions([
                EditAction::make(),
                Action::make('publish')->label(fn (TeamMember $record) => $record->status === TeamMember::PUBLISHED ? __('team.admin.unpublish') : __('team.admin.publish'))
                    ->icon('heroicon-m-globe-alt')->visible(fn (TeamMember $record) => ! $record->trashed() && static::canPublish())
                    ->requiresConfirmation()
                    ->action(function (TeamMember $record): void {
                        abort_unless(static::canPublish(), 403);
                        $publish = $record->status !== TeamMember::PUBLISHED;
                        $record->update(['status' => $publish ? TeamMember::PUBLISHED : TeamMember::DRAFT, 'published_at' => $publish ? now() : $record->published_at]);
                        Notification::make()->title(__($publish ? 'team.admin.published_ok' : 'team.admin.unpublished_ok'))->success()->send();
                    }),
                \Filament\Actions\ActionGroup::make([
                Action::make('move')->label(__('team.admin.move'))->icon('heroicon-m-arrows-right-left')->visible(fn (TeamMember $record) => ! $record->trashed() && static::canStructure())
                    ->fillForm(fn (TeamMember $record) => ['reports_to_id' => $record->reports_to_id, 'department_id' => $record->department_id])
                    ->schema(fn (TeamMember $record) => [
                        Select::make('reports_to_id')->label(__('team.admin.reports_to'))->options(static::managerOptions($record))->searchable()->native(false)->placeholder(__('team.admin.nobody')),
                        Select::make('department_id')->label(__('team.admin.department'))->options(static::departmentOptions())->searchable()->native(false)->placeholder(__('team.admin.nobody')),
                    ])
                    ->action(function (TeamMember $record, array $data): void {
                        abort_unless(static::canStructure(), 403);
                        try {
                            app(TeamHierarchy::class)->move($record, $data['reports_to_id'] ? (int) $data['reports_to_id'] : null, $data['department_id'] ? (int) $data['department_id'] : null);
                        } catch (ValidationException $e) {
                            Notification::make()->title(collect($e->errors())->flatten()->first())->danger()->send();

                            return;
                        }
                        Notification::make()->title(__('team.admin.move_done'))->success()->send();
                    }),
                Action::make('preview')->label(__('team.admin.preview'))->icon('heroicon-m-eye')->visible(fn (TeamMember $record) => ! $record->trashed())
                    ->url(fn (TeamMember $record) => route('team.show', ['locale' => app()->getLocale(), 'slug' => $record->slug, 'preview' => 1]))->openUrlInNewTab(),
                Action::make('archive')->label(__('team.admin.archive'))->icon('heroicon-m-archive-box')->color('danger')->visible(fn (TeamMember $record) => ! $record->trashed() && static::canStructure())
                    ->requiresConfirmation()->modalDescription(__('team.admin.reassign_first'))
                    ->action(function (TeamMember $record): void {
                        abort_unless(static::canStructure(), 403);
                        try {
                            $record->delete();
                        } catch (ValidationException $e) {
                            Notification::make()->title(collect($e->errors())->flatten()->first())->danger()->send();
                        }
                    }),
                Action::make('restore')->label(__('team.admin.restore'))->icon('heroicon-m-arrow-uturn-left')->visible(fn (TeamMember $record) => $record->trashed() && static::canStructure())
                    ->action(function (TeamMember $record): void {
                        abort_unless(static::canStructure(), 403);
                        $record->restore();
                    }),
                ]),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => ListTeamMembers::route('/'),
            'create' => CreateTeamMember::route('/create'),
            'edit' => EditTeamMember::route('/{record}/edit'),
        ];
    }

}
