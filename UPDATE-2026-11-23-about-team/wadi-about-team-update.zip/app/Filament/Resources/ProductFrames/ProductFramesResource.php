<?php

declare(strict_types=1);

namespace App\Filament\Resources\ProductFrames;

use App\Filament\Forms\Components\MediaPicker;
use App\Filament\Resources\ProductFrames\Pages\ManageProductFrames;
use App\Models\MediaAsset;
use App\Models\ProductFrame;
use App\Support\ProductFrames;
use BackedEnum;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteAction;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\ImageColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

/** Saved frame designs: upload a transparent PNG/WebP in the media library, then pick it here. Originals are never edited. */
class ProductFramesResource extends Resource
{
    protected static ?string $model = ProductFrame::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedSquare2Stack;

    protected static ?int $navigationSort = 9;

    public static function getNavigationGroup(): ?string
    {
        return __('nav.groups.catalogue');
    }

    public static function getModelLabel(): string
    {
        return __('frames.admin.label');
    }

    public static function getPluralModelLabel(): string
    {
        return __('frames.admin.plural');
    }

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            Section::make()->columns(2)->schema([
                TextInput::make('name')->label(__('frames.admin.name'))->required()->maxLength(120),
                TextInput::make('padding_pct')->label(__('frames.admin.padding'))->helperText(__('frames.admin.padding_hint'))
                    ->numeric()->minValue(0)->maxValue(30)->suffix('%')->default(9)->required(),
                MediaPicker::make('media_id', __('frames.admin.artwork'), 'frames')->helperText(__('frames.admin.artwork_hint'))->columnSpanFull(),
                Toggle::make('is_active')->label(__('frames.admin.active'))->default(true)->inline(false),
                TextInput::make('display_order')->label(__('admin.fields.display_order'))->numeric()->default(0),
            ]),
        ]);
    }

    /** Fill source/ratio from the chosen artwork; built-in rows keep their file. */
    public static function prepare(array $data, ?ProductFrame $record = null): array
    {
        if (($record?->source) === 'builtin' && empty($data['media_id'])) {
            return $data;
        }
        $media = ! empty($data['media_id']) ? MediaAsset::query()->find($data['media_id']) : null;
        $data['source'] = 'media';
        $data['ratio'] = ProductFrame::ratioOf($media);
        if ($media && ! in_array(strtolower((string) pathinfo((string) $media->path, PATHINFO_EXTENSION)), ['png', 'webp', 'svg', 'gif'], true)) {
            $data['is_active'] = false; // JPEG cannot be transparent: kept but never drawn
        }

        return $data;
    }

    public static function table(Table $table): Table
    {
        return $table
            ->defaultSort('display_order')
            ->columns([
                ImageColumn::make('preview')->label('')->getStateUsing(fn (ProductFrame $r): ?string => $r->url())->size(48),
                TextColumn::make('name')->label(__('frames.admin.name'))->searchable()->weight('medium'),
                TextColumn::make('padding_pct')->label(__('frames.admin.padding'))->suffix('%'),
                TextColumn::make('source')->label(__('frames.admin.source'))->formatStateUsing(fn (string $s): string => __('frames.admin.source_'.$s)),
                IconColumn::make('is_active')->label(__('admin.fields.is_active'))->boolean(),
            ])
            ->recordActions([
                EditAction::make()->mutateDataUsing(fn (array $data, ProductFrame $record): array => static::prepare($data, $record))->after(fn () => ProductFrames::forget()),
                DeleteAction::make()->after(fn () => ProductFrames::forget()),
            ])
            ->toolbarActions([BulkActionGroup::make([DeleteBulkAction::make()])]);
    }

    public static function getPages(): array
    {
        return ['index' => ManageProductFrames::route('/')];
    }
}
