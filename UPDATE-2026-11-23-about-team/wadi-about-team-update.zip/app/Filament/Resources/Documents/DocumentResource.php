<?php

declare(strict_types=1);

namespace App\Filament\Resources\Documents;

use App\Filament\Forms\Components\MediaPicker;
use App\Filament\Resources\Documents\Pages\CreateDocument;
use App\Filament\Resources\Documents\Pages\EditDocument;
use App\Filament\Resources\Documents\Pages\ListDocuments;
use App\Models\Document;
use App\Support\Permissions;
use BackedEnum;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteAction;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Tabs;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Columns\ToggleColumn;
use Filament\Tables\Columns\ViewColumn;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;

/**
 * Publishable documents — catalogues, company profile, brochures.
 *
 * The PDF is chosen from the media library rather than uploaded here, so a file
 * exists once and every reference to it points at the same asset. Replacing the
 * file updates the menu item, the homepage button and the catalogue listing
 * together, which is the whole reason this model wraps a media asset instead of
 * storing its own copy.
 */
class DocumentResource extends Resource
{
    protected static ?string $model = Document::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedDocumentText;

    protected static ?int $navigationSort = 9;

    public static function getNavigationGroup(): ?string
    {
        return __('nav.groups.content');
    }

    public static function getModelLabel(): string
    {
        return __('documents.resource.label');
    }

    public static function getPluralModelLabel(): string
    {
        return __('documents.resource.plural');
    }

    public static function canAccess(): bool
    {
        return Auth::user()?->can(Permissions::CONTENT_VIEW) ?? false;
    }

    public static function form(Schema $schema): Schema
    {
        return $schema->components([

            Section::make(__('documents.sections.file'))
                ->description(__('documents.hints.file'))
                ->columns(2)
                ->schema([
                    // `document` restricts the picker to PDFs — the grid, the
                    // upload control and the server-side MIME check all narrow
                    // together, so a renamed executable is refused in
                    // MediaManager whatever the browser offered.
                    MediaPicker::document('media_asset_id', __('documents.fields.file'))
                        ->required()
                        ->columnSpanFull(),

                    MediaPicker::make('cover_image_id', __('documents.fields.cover'), 'branding')
                        ->helperText(__('documents.hints.cover')),

                    Select::make('kind')
                        ->label(__('documents.fields.kind'))
                        ->options(collect(Document::KINDS)
                            ->mapWithKeys(fn (string $k): array => [$k => __('documents.kinds.'.$k)])
                            ->all())
                        ->default('catalogue')
                        ->required()
                        ->native(false),
                ]),

            Section::make(__('documents.sections.content'))
                ->schema([
                    Tabs::make('locales')->tabs(
                        collect(config('wadi.locales'))
                            ->map(fn (array $config, string $locale) => Tabs\Tab::make($config['native'])->schema([
                                TextInput::make("translations.{$locale}.title")
                                    ->label(__('documents.fields.title'))
                                    ->maxLength(180),

                                Textarea::make("translations.{$locale}.description")
                                    ->label(__('documents.fields.description'))
                                    ->rows(3)
                                    ->maxLength(600),
                            ]))
                            ->values()
                            ->all()
                    ),
                ]),

            Section::make(__('documents.sections.behaviour'))
                ->columns(2)
                ->schema([
                    Toggle::make('allow_download')
                        ->label(__('documents.fields.allow_download'))
                        ->default(true)
                        ->inline(false)
                        ->helperText(__('documents.hints.allow_download')),

                    Toggle::make('open_in_new_tab')
                        ->label(__('documents.fields.open_in_new_tab'))
                        ->inline(false)
                        ->helperText(__('documents.hints.open_in_new_tab')),

                    Toggle::make('is_active')
                        ->label(__('admin.fields.is_active'))
                        ->default(true)
                        ->inline(false),

                    TextInput::make('display_order')
                        ->label(__('admin.fields.display_order'))
                        ->numeric()
                        ->default(0),

                    TextInput::make('slug')
                        ->label(__('admin.fields.slug'))
                        ->maxLength(120)
                        ->unique(ignoreRecord: true)
                        ->helperText(__('documents.hints.slug'))
                        // Generated from the English title when left blank, so
                        // the URL is readable without anyone having to think
                        // about it.
                        ->default(fn (): string => 'document-'.Str::lower(Str::random(6)))
                        ->columnSpanFull(),
                ]),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->modifyQueryUsing(fn (Builder $query) => $query->withTranslation()->with(['file', 'coverImage']))
            ->defaultSort('display_order')
            ->reorderable('display_order')
            ->columns([
                ViewColumn::make('cover')
                    ->label('')
                    ->view('filament.tables.columns.document-cover'),

                TextColumn::make('title')
                    ->label(__('documents.fields.title'))
                    ->getStateUsing(fn (Document $record): string => $record->t('title') ?: $record->slug)
                    ->description(fn (Document $record): ?string => $record->file?->original_filename)
                    ->weight('medium')
                    ->searchable(['slug'])
                    ->wrap(),

                TextColumn::make('kind')
                    ->label(__('documents.fields.kind'))
                    ->badge()
                    ->color('gray')
                    ->formatStateUsing(fn (Document $record): string => $record->kindLabel()),

                TextColumn::make('size')
                    ->label(__('media.fields.size'))
                    ->getStateUsing(fn (Document $record): ?string => $record->file?->humanSize())
                    ->color('gray')
                    ->size('sm'),

                IconColumn::make('allow_download')
                    ->label(__('documents.fields.allow_download'))
                    ->boolean()
                    ->toggleable(),

                ToggleColumn::make('is_active')
                    ->label(__('admin.fields.is_active'))
                    ->disabled(fn (): bool => ! (Auth::user()?->can(Permissions::CONTENT_MANAGE) ?? false)),
            ])
            ->filters([
                SelectFilter::make('kind')
                    ->label(__('documents.fields.kind'))
                    ->multiple()
                    ->options(collect(Document::KINDS)
                        ->mapWithKeys(fn (string $k): array => [$k => __('documents.kinds.'.$k)])
                        ->all()),
            ])
            ->recordActions([
                EditAction::make(),
                DeleteAction::make(),
            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ])
            ->emptyStateHeading(__('documents.empty.heading'))
            ->emptyStateDescription(__('documents.empty.description'));
    }

    public static function getPages(): array
    {
        return [
            'index' => ListDocuments::route('/'),
            'create' => CreateDocument::route('/create'),
            'edit' => EditDocument::route('/{record}/edit'),
        ];
    }
}
