<?php

declare(strict_types=1);

namespace App\Console\Commands;

use App\Services\About\AboutStory;
use Illuminate\Console\Command;

class AboutStoryCommand extends Command
{
    protected $signature = 'about:story {--publish : publish even if the About page has been edited (only when it was never published from the builder)}';

    protected $description = 'Create the About Us story layout and banner texts once; never replaces an existing layout or customised banner (safe to re-run).';

    public function handle(AboutStory $story): int
    {
        foreach ($story->run((bool) $this->option('publish')) as $what => $result) {
            $this->line(str_pad($what, 8).' '.$result);
        }

        return self::SUCCESS;
    }
}
