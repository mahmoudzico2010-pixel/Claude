<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\TeamDepartment;
use App\Models\TeamMember;
use App\Services\Seo\SeoData;
use App\Services\Team\TeamHierarchy;
use App\Support\Permissions;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

/**
 * Public team pages. Only published, unarchived people are ever read here; contact channels pass through the member's
 * public*() accessors, which return null for anything the editor has not switched on. Nothing here serialises a model.
 */
class TeamController extends Controller
{
    /** Staff with team.view may preview drafts (never indexed, clearly marked). */
    private function preview(): bool
    {
        return request()->boolean('preview') && (bool) Auth::user()?->is_active && (bool) Auth::user()?->can(Permissions::TEAM_VIEW);
    }

    public function index(): View
    {
        $preview = $this->preview();
        $hier = app(TeamHierarchy::class);
        $filter = fn (TeamMember $m): bool => $m->show_on_team;
        $tree = $preview ? $hier->tree(false) : $hier->tree(true, $filter);
        $members = $hier->flatten($tree);

        $departments = TeamDepartment::query()->with('translations')->public()->orderBy('display_order')->get();
        $slug = (string) request()->query('department', '');
        $currentDept = $slug !== '' ? $departments->firstWhere('slug', $slug) : null;
        abort_if($slug !== '' && $currentDept === null, 404);

        $groups = [];
        foreach ($departments as $d) {
            $in = $members->filter(fn (TeamMember $m) => $m->publicDepartment()?->id === $d->id)->values();
            if ($in->isNotEmpty() && (! $currentDept || $currentDept->id === $d->id)) {
                $groups[] = ['department' => $d, 'members' => $in];
            }
        }
        $unassigned = $members->filter(fn (TeamMember $m) => $m->publicDepartment() === null)->values();
        if ($unassigned->isNotEmpty() && ! $currentDept) {
            $groups[] = ['department' => null, 'members' => $unassigned];
        }

        $seo = SeoData::make()
            ->title(__('team.page_title'))
            ->description(__('team.intro'))
            ->noindex($preview || $members->isEmpty())
            ->breadcrumbs([
                ['label' => __('site.home'), 'url' => route('home')],
                ['label' => __('site.nav.about'), 'url' => route('about')],
                ['label' => __('team.page_title'), 'url' => null],
            ]);

        return view('team.index', compact('seo', 'tree', 'members', 'groups', 'departments', 'currentDept', 'preview'));
    }

    public function show(string $locale, string $slug): View
    {
        $preview = $this->preview();
        $member = TeamMember::query()->with(['translations', 'department.translations', 'portrait', 'links', 'manager.translations'])->where('slug', $slug)->first();
        abort_if($member === null || (! $preview && ! $member->isPublic()), 404);
        abort_if($preview && $member->trashed(), 404);

        // Reporting context only when BOTH people are public; never name a hidden manager.
        $manager = $member->manager && ($member->manager->isPublic() || $preview) ? $member->manager : null;
        $reports = $member->reports()->with(['translations', 'portrait'])->get()->filter(fn (TeamMember $r) => $r->isPublic() || $preview)->values();
        $department = $member->publicDepartment() ?? ($preview ? $member->department : null);
        $name = $member->displayName();

        $person = array_filter([
            '@context' => 'https://schema.org',
            '@type' => 'Person',
            'name' => $name,
            'jobTitle' => $member->t('job_title'),
            'description' => $member->t('short_bio') ?: null,
            'image' => $member->portrait?->url(),
            'url' => route('team.show', ['locale' => app()->getLocale(), 'slug' => $member->slug]),
            'worksFor' => ['@type' => 'Organization', 'name' => setting('company.name_'.app()->getLocale()) ?? setting('company.name_en') ?? config('app.name')],
            // Only channels the editor switched on.
            'email' => $member->publicEmail(),
            'telephone' => $member->publicPhone(),
            'sameAs' => $member->publicLinks()->map->safeUrl()->all() ?: null,
        ]);

        $seo = SeoData::make()
            ->title($name.($member->t('job_title') ? ' — '.$member->t('job_title') : ''))
            ->description($member->t('short_bio') ?: $member->t('job_title'))
            ->image($member->portrait)
            ->noindex($preview)
            ->breadcrumbs([
                ['label' => __('site.home'), 'url' => route('home')],
                ['label' => __('team.page_title'), 'url' => route('team.index')],
                ['label' => $name, 'url' => null],
            ]);
        if (! $preview) {
            $seo->schema($person);
        }

        return view('team.show', compact('seo', 'member', 'manager', 'reports', 'department', 'preview'));
    }
}
