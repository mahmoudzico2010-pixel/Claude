<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\NewsPost;
use App\Models\Page;
use App\Models\Product;
use App\Packaging\PackagingCatalog;
use App\Support\Locales;
use Illuminate\Http\Response;

class SitemapController extends Controller
{
    /**
     * One sitemap covering every locale, with hreflang alternates so search
     * engines pair the Arabic and English versions of each URL.
     */
    public function index(): Response
    {
        $locales = Locales::publishedCodes();

        $entries = [];

        $staticRoutes = [
            'home' => ['priority' => '1.0', 'freq' => 'weekly'],
            'products.index' => ['priority' => '0.9', 'freq' => 'weekly'],
            'packaging.index' => ['priority' => '0.7', 'freq' => 'monthly'],
            'about' => ['priority' => '0.7', 'freq' => 'monthly'],
            'team.index' => ['priority' => '0.5', 'freq' => 'monthly'],
            'quality' => ['priority' => '0.7', 'freq' => 'monthly'],
            'export' => ['priority' => '0.7', 'freq' => 'monthly'],
            'private-label' => ['priority' => '0.7', 'freq' => 'monthly'],
            'news.index' => ['priority' => '0.6', 'freq' => 'weekly'],
            'quote.create' => ['priority' => '0.8', 'freq' => 'monthly'],
            'contact.show' => ['priority' => '0.6', 'freq' => 'monthly'],
        ];

        // Legal routes are listed only once their page has been reviewed —
        // an unreviewed draft must not be advertised to search engines.
        foreach (Page::publiclyLinkableLegalPages() as $legalPage) {
            $staticRoutes[$legalPage['key'] === 'privacy' ? 'privacy' : 'terms'] =
                ['priority' => '0.3', 'freq' => 'yearly'];
        }

        // Packaging pages come from the PUBLISHED catalog only, so an unpublished draft pack
        // never appears; before the first publish the section is not advertised at all.
        $packaging = app(PackagingCatalog::class);
        if ($packaging->isEmpty()) {
            unset($staticRoutes['packaging.index']);
        } else {
            foreach ($packaging->pageSlugs() as $slug) {
                $entries[] = $this->entry(
                    fn (string $locale): string => route('packaging.show', ['locale' => $locale, 'slug' => $slug]),
                    $locales,
                    null,
                    'monthly',
                    '0.6',
                );
            }
        }

        if (! \App\Models\TeamMember::query()->public()->where('show_on_team', true)->exists()) {
            unset($staticRoutes['team.index']); // an empty team page is not advertised
        }

        foreach ($staticRoutes as $name => $meta) {
            $entries[] = $this->entry(
                fn (string $locale): string => route($name, ['locale' => $locale]),
                $locales,
                null,
                $meta['freq'],
                $meta['priority'],
            );
        }

        Product::query()->published()->select(['slug', 'updated_at'])->chunk(200, function ($products) use (&$entries, $locales): void {
            foreach ($products as $product) {
                $entries[] = $this->entry(
                    fn (string $locale): string => route('products.show', ['locale' => $locale, 'product' => $product->slug]),
                    $locales,
                    $product->updated_at?->toAtomString(),
                    'monthly',
                    '0.8',
                );
            }
        });

        // Parent pages of the varieties that have at least one published product.
        foreach (\App\Services\Catalog\CatalogTree::build() as $node) {
            foreach ($node['varieties'] as $v) {
                $slug = $v['variety']->slug;
                $entries[$slug.'#variety'] = $this->entry(
                    fn (string $locale): string => route('products.variety', ['locale' => $locale, 'variety' => $slug]),
                    $locales, $v['variety']->updated_at?->toAtomString(), 'monthly', '0.8',
                );
            }
        }
        $entries = array_values($entries);

        \App\Models\TeamMember::query()->public()->select(['slug', 'updated_at'])->get()->each(function ($m) use (&$entries, $locales): void {
            $entries[] = $this->entry(fn (string $locale): string => route('team.show', ['locale' => $locale, 'slug' => $m->slug]), $locales, $m->updated_at?->toAtomString(), 'monthly', '0.4');
        });

        NewsPost::query()->published()->select(['slug', 'updated_at'])->chunk(200, function ($posts) use (&$entries, $locales): void {
            foreach ($posts as $post) {
                $entries[] = $this->entry(
                    fn (string $locale): string => route('news.show', ['locale' => $locale, 'post' => $post->slug]),
                    $locales,
                    $post->updated_at?->toAtomString(),
                    'monthly',
                    '0.5',
                );
            }
        });

        Page::query()->published()->whereNull('key')->select(['slug', 'updated_at'])->chunk(200, function ($pages) use (&$entries, $locales): void {
            foreach ($pages as $page) {
                $entries[] = $this->entry(
                    fn (string $locale): string => route('page.show', ['locale' => $locale, 'page' => $page->slug]),
                    $locales,
                    $page->updated_at?->toAtomString(),
                    'monthly',
                    '0.5',
                );
            }
        });

        return response()
            ->view('sitemap', ['entries' => $entries])
            ->header('Content-Type', 'application/xml; charset=UTF-8');
    }

    public function robots(): Response
    {
        $lines = [
            'User-agent: *',
            'Disallow: /admin',
            'Disallow: /'.config('wadi.admin.path', 'admin'),
            'Disallow: /storage/rfq-attachments',
            '',
            'Sitemap: '.route('sitemap'),
        ];

        // A site in maintenance mode should not be indexed at all.
        if (setting('site.maintenance_mode')) {
            $lines = ['User-agent: *', 'Disallow: /'];
        }

        return response(implode("\n", $lines))
            ->header('Content-Type', 'text/plain; charset=UTF-8');
    }

    /**
     * @param  array<int, string>  $locales
     * @return array<string, mixed>
     */
    private function entry(callable $urlFor, array $locales, ?string $lastmod, string $freq, string $priority): array
    {
        $alternates = [];

        foreach ($locales as $locale) {
            $alternates[config('wadi.locales.'.$locale.'.hreflang')] = $urlFor($locale);
        }

        return [
            'loc' => $urlFor(Locales::default()),
            'lastmod' => $lastmod,
            'changefreq' => $freq,
            'priority' => $priority,
            'alternates' => $alternates,
        ];
    }
}
