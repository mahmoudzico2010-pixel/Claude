<?php

declare(strict_types=1);

namespace App\Support;

use App\Models\User;

/**
 * Single source of truth for permission names and the role matrix.
 *
 * The seeder builds the database from this class, and the policies check
 * against it, so the interface and the server-side gate can never drift
 * apart. Hiding a button is never the authorisation mechanism.
 */
final class Permissions
{
    // Catalogue
    public const PRODUCTS_VIEW = 'products.view';

    public const PRODUCTS_CREATE = 'products.create';

    public const PRODUCTS_UPDATE = 'products.update';

    public const PRODUCTS_DELETE = 'products.delete';

    public const PRODUCTS_PUBLISH = 'products.publish';

    // Classifications: categories, varieties, forms, calibers, certifications,
    // export markets, news categories, tags.
    public const CLASSIFICATIONS_VIEW = 'classifications.view';

    public const CLASSIFICATIONS_MANAGE = 'classifications.manage';

    // Packaging
    public const PACKAGING_VIEW = 'packaging.view';

    public const PACKAGING_MANAGE = 'packaging.manage';

    /** Publishing and rolling back the Packaging catalog change the live site: stronger than editing a draft. */
    public const PACKAGING_PUBLISH = 'packaging.publish';

    // Languages (System → Languages): seeing readiness, signing an area off, and making a
    // language public are three different levels of trust.
    public const LANGUAGES_VIEW = 'languages.view';

    /** Writing draft translations of the shared interface text (never publishes or reviews). */
    public const LANGUAGES_EDIT = 'languages.edit';

    public const LANGUAGES_REVIEW = 'languages.review';

    public const LANGUAGES_PUBLISH = 'languages.publish';

    // Quote requests
    public const RFQ_VIEW = 'rfq.view';

    public const RFQ_UPDATE = 'rfq.update';

    public const RFQ_ASSIGN = 'rfq.assign';

    public const RFQ_EXPORT = 'rfq.export';

    public const RFQ_DELETE = 'rfq.delete';

    // Contact messages
    public const CONTACTS_VIEW = 'contacts.view';

    public const CONTACTS_UPDATE = 'contacts.update';

    public const CONTACTS_DELETE = 'contacts.delete';

    // News and exhibitions
    public const NEWS_VIEW = 'news.view';

    public const NEWS_CREATE = 'news.create';

    public const NEWS_UPDATE = 'news.update';

    public const NEWS_DELETE = 'news.delete';

    public const NEWS_PUBLISH = 'news.publish';

    // Media library
    public const MEDIA_VIEW = 'media.view';

    public const MEDIA_UPLOAD = 'media.upload';

    public const MEDIA_DELETE = 'media.delete';

    // Website content: pages, content blocks, navigation
    public const CONTENT_VIEW = 'content.view';

    public const CONTENT_MANAGE = 'content.manage';

    // Team (public staff profiles and the reporting structure). Never grants a login.
    public const TEAM_VIEW = 'team.view';

    /** Create/edit members and departments (drafts only). */
    public const TEAM_EDIT = 'team.edit';

    /** Make a member visible on the public site, or take them off it. */
    public const TEAM_PUBLISH = 'team.publish';

    /** Change who reports to whom, move people between departments, reorder, archive and restore. */
    public const TEAM_STRUCTURE = 'team.structure';

    // Settings
    public const SETTINGS_VIEW = 'settings.view';

    public const SETTINGS_UPDATE = 'settings.update';

    /** SMTP credentials, upload limits, login security. */
    public const SETTINGS_SENSITIVE = 'settings.sensitive';

    // Users and roles
    // Homepage Manager — one canonical editor for the public homepage.
    public const HOMEPAGE_VIEW = 'homepage.view';

    public const HOMEPAGE_EDIT = 'homepage.edit';

    public const HOMEPAGE_MEDIA = 'homepage.media';

    public const HOMEPAGE_PREVIEW = 'homepage.preview';

    public const HOMEPAGE_SCHEDULE = 'homepage.schedule';

    public const HOMEPAGE_PUBLISH = 'homepage.publish';

    public const HOMEPAGE_ROLLBACK = 'homepage.rollback';

    public const USERS_VIEW = 'users.view';

    public const USERS_CREATE = 'users.create';

    public const USERS_UPDATE = 'users.update';

    public const USERS_DELETE = 'users.delete';

    // Audit trail
    public const AUDIT_VIEW = 'audit.view';

    /**
     * Every permission the application knows about.
     *
     * @return array<int, string>
     */
    public static function all(): array
    {
        return [
            self::PRODUCTS_VIEW, self::PRODUCTS_CREATE, self::PRODUCTS_UPDATE,
            self::PRODUCTS_DELETE, self::PRODUCTS_PUBLISH,
            self::CLASSIFICATIONS_VIEW, self::CLASSIFICATIONS_MANAGE,
            self::PACKAGING_VIEW, self::PACKAGING_MANAGE, self::PACKAGING_PUBLISH,
            self::LANGUAGES_VIEW, self::LANGUAGES_EDIT, self::LANGUAGES_REVIEW, self::LANGUAGES_PUBLISH,
            self::RFQ_VIEW, self::RFQ_UPDATE, self::RFQ_ASSIGN, self::RFQ_EXPORT, self::RFQ_DELETE,
            self::CONTACTS_VIEW, self::CONTACTS_UPDATE, self::CONTACTS_DELETE,
            self::NEWS_VIEW, self::NEWS_CREATE, self::NEWS_UPDATE, self::NEWS_DELETE, self::NEWS_PUBLISH,
            self::MEDIA_VIEW, self::MEDIA_UPLOAD, self::MEDIA_DELETE,
            self::CONTENT_VIEW, self::CONTENT_MANAGE,
            self::TEAM_VIEW, self::TEAM_EDIT, self::TEAM_PUBLISH, self::TEAM_STRUCTURE,
            self::SETTINGS_VIEW, self::SETTINGS_UPDATE, self::SETTINGS_SENSITIVE,
            self::HOMEPAGE_VIEW, self::HOMEPAGE_EDIT, self::HOMEPAGE_MEDIA, self::HOMEPAGE_PREVIEW,
            self::HOMEPAGE_SCHEDULE, self::HOMEPAGE_PUBLISH, self::HOMEPAGE_ROLLBACK,
            self::USERS_VIEW, self::USERS_CREATE, self::USERS_UPDATE, self::USERS_DELETE,
            self::AUDIT_VIEW,
        ];
    }

    /**
     * Permissions granted to each role.
     *
     * Super Admin is intentionally absent: it is granted everything through
     * a Gate::before hook so a newly added permission is never accidentally
     * withheld from the owner of the system.
     *
     * @return array<string, array<int, string>>
     */
    public static function matrix(): array
    {
        $viewOnly = [
            self::PRODUCTS_VIEW, self::CLASSIFICATIONS_VIEW, self::PACKAGING_VIEW,
            self::RFQ_VIEW, self::CONTACTS_VIEW, self::NEWS_VIEW,
            self::MEDIA_VIEW, self::CONTENT_VIEW, self::SETTINGS_VIEW,
            self::HOMEPAGE_VIEW, self::LANGUAGES_VIEW, self::TEAM_VIEW,
        ];

        $contentEditor = [
            self::PRODUCTS_VIEW, self::PRODUCTS_CREATE, self::PRODUCTS_UPDATE, self::PRODUCTS_PUBLISH,
            self::CLASSIFICATIONS_VIEW, self::CLASSIFICATIONS_MANAGE,
            self::PACKAGING_VIEW, self::PACKAGING_MANAGE,
            // Sees what each language still needs; signing off and publishing stay with Admin.
            self::LANGUAGES_VIEW, self::LANGUAGES_EDIT,
            self::NEWS_VIEW, self::NEWS_CREATE, self::NEWS_UPDATE, self::NEWS_PUBLISH,
            self::MEDIA_VIEW, self::MEDIA_UPLOAD,
            self::CONTENT_VIEW, self::CONTENT_MANAGE,
            self::TEAM_VIEW, self::TEAM_EDIT,
            self::SETTINGS_VIEW,
            // Drafts and preview only: publishing, scheduling and rollback
            // change the live homepage and stay with Admin / Super Admin.
            self::HOMEPAGE_VIEW, self::HOMEPAGE_EDIT, self::HOMEPAGE_MEDIA, self::HOMEPAGE_PREVIEW,
        ];

        $sales = [
            self::PRODUCTS_VIEW,
            self::CLASSIFICATIONS_VIEW,
            self::PACKAGING_VIEW,
            self::RFQ_VIEW, self::RFQ_UPDATE, self::RFQ_ASSIGN, self::RFQ_EXPORT,
            self::CONTACTS_VIEW, self::CONTACTS_UPDATE,
            self::MEDIA_VIEW,
        ];

        // Admin gets everything except the sensitive settings block and the
        // ability to delete user accounts; both stay with the Super Admin.
        $admin = array_values(array_diff(
            self::all(),
            [self::SETTINGS_SENSITIVE, self::USERS_DELETE]
        ));

        return [
            User::ROLE_ADMIN => $admin,
            User::ROLE_SALES => $sales,
            User::ROLE_CONTENT_EDITOR => $contentEditor,
            User::ROLE_VIEWER => $viewOnly,
        ];
    }

    /**
     * Permissions grouped by module, for the role editing screen.
     *
     * @return array<string, array<int, string>>
     */
    public static function grouped(): array
    {
        $groups = [];

        foreach (self::all() as $permission) {
            $module = explode('.', $permission)[0];
            $groups[$module][] = $permission;
        }

        return $groups;
    }
}
