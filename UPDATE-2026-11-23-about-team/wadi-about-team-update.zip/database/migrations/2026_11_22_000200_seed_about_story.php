<?php

declare(strict_types=1);

use App\Services\About\AboutStory;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /** One-time, non-destructive. See App\Services\About\AboutStory. A failure here must never block the upgrade. */
    public function up(): void
    {
        try {
            app(AboutStory::class)->run();
        } catch (\Throwable $e) {
            report($e);
        }
    }

    public function down(): void
    {
        // Editorial content is never deleted by a rollback.
    }
};
