<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /** Additive only: public staff profiles and the reporting structure. Never touches users / login accounts. */
    public function up(): void
    {
        if (! Schema::hasTable('team_departments')) {
            Schema::create('team_departments', function (Blueprint $table): void {
                $table->id();
                $table->string('slug', 120)->unique();
                $table->foreignId('parent_id')->nullable()->constrained('team_departments')->restrictOnDelete();
                $table->unsignedInteger('display_order')->default(0);
                $table->boolean('is_visible')->default(true);
                $table->string('contact_url', 500)->nullable();
                $table->softDeletes();
                $table->timestamps();
            });
        }

        if (! Schema::hasTable('team_department_translations')) {
            Schema::create('team_department_translations', function (Blueprint $table): void {
                $table->id();
                $table->foreignId('team_department_id')->constrained('team_departments')->cascadeOnDelete();
                $table->string('locale', 5);
                $table->string('name', 160)->nullable();
                $table->text('description')->nullable();
                $table->unique(['team_department_id', 'locale'], 'team_dept_tr_unique');
            });
        }

        if (! Schema::hasTable('team_members')) {
            Schema::create('team_members', function (Blueprint $table): void {
                $table->id();
                $table->string('slug', 120)->unique();
                $table->foreignId('department_id')->nullable()->constrained('team_departments')->restrictOnDelete();
                $table->foreignId('reports_to_id')->nullable()->constrained('team_members')->restrictOnDelete();
                $table->unsignedBigInteger('portrait_id')->nullable();
                $table->unsignedTinyInteger('portrait_focal_x')->default(50);
                $table->unsignedTinyInteger('portrait_focal_y')->default(35);
                $table->string('status', 12)->default('draft');
                $table->timestamp('published_at')->nullable();
                $table->boolean('show_on_about')->default(false);
                $table->boolean('show_on_team')->default(true);
                $table->unsignedInteger('display_order')->default(0);
                $table->string('email', 190)->nullable();
                $table->string('phone', 40)->nullable();
                $table->string('whatsapp', 40)->nullable();
                $table->boolean('show_email')->default(false);
                $table->boolean('show_phone')->default(false);
                $table->boolean('show_whatsapp')->default(false);
                $table->unsignedBigInteger('created_by')->nullable();
                $table->unsignedBigInteger('updated_by')->nullable();
                $table->softDeletes();
                $table->timestamps();
                $table->index(['status', 'show_on_team']);
                $table->index(['reports_to_id', 'display_order']);
            });
        }

        if (! Schema::hasTable('team_member_translations')) {
            Schema::create('team_member_translations', function (Blueprint $table): void {
                $table->id();
                $table->foreignId('team_member_id')->constrained('team_members')->cascadeOnDelete();
                $table->string('locale', 5);
                $table->string('name', 160)->nullable();
                $table->string('job_title', 160)->nullable();
                $table->text('short_bio')->nullable();
                $table->text('full_bio')->nullable();
                $table->string('portrait_alt', 255)->nullable();
                $table->unique(['team_member_id', 'locale'], 'team_member_tr_unique');
            });
        }

        if (! Schema::hasTable('team_member_links')) {
            Schema::create('team_member_links', function (Blueprint $table): void {
                $table->id();
                $table->foreignId('team_member_id')->constrained('team_members')->cascadeOnDelete();
                $table->string('network', 24);
                $table->string('url', 500);
                $table->string('label', 80)->nullable();
                $table->boolean('is_visible')->default(true);
                $table->unsignedInteger('display_order')->default(0);
            });
        }
    }

    public function down(): void
    {
        foreach (['team_member_links', 'team_member_translations', 'team_members', 'team_department_translations', 'team_departments'] as $t) {
            Schema::dropIfExists($t);
        }
    }
};
