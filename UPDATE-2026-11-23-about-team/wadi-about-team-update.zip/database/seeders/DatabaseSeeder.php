<?php

declare(strict_types=1);

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Order matters: roles before the owner account, classifications before
     * products, pages before navigation.
     */
    public function run(): void
    {
        $this->call([
            RolePermissionSeeder::class,
            SettingsSeeder::class,
            ClassificationSeeder::class,
            PackagingSeeder::class,
            PackagingCatalogSeeder::class,
            ProductSeeder::class,
            ContentBlockSeeder::class,
            PageSeeder::class,
            NavigationSeeder::class,
            CatalogContentSeeder::class,
            HomeSectionSeeder::class,
            // After SettingsSeeder: it reads the contact settings to
            // build the first location from the address already on the site.
            CompanyLocationSeeder::class,
        ]);

        // After PageSeeder: the About story is built into the About page (non-destructive, idempotent).
        try {
            app(\App\Services\About\AboutStory::class)->run();
        } catch (\Throwable $e) {
            report($e); // the story is optional: it must never stop an installation
        }
    }
}
