<?php

declare(strict_types=1);

use App\Http\Controllers\Admin\BuilderPreviewController;
use App\Http\Controllers\Admin\HomepagePreviewController;
use App\Http\Controllers\Admin\NetworkDiagnosticController;
use App\Http\Controllers\Admin\QuoteDocumentController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\DocumentController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\Install\WizardController;
use App\Http\Controllers\LegacyPackagingRedirectController;
use App\Http\Controllers\MediaFileController;
use App\Http\Controllers\NewsController;
use App\Http\Controllers\PackagingController;
use App\Http\Controllers\PackagingPreviewController;
use App\Http\Controllers\PageController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\QuoteRequestController;
use App\Http\Controllers\SitemapController;
use App\Http\Middleware\SetLocale;
use App\Models\CompanyLocation;
use App\Support\Locales;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Public site
|--------------------------------------------------------------------------
|
| Every public page lives under a locale prefix (/en/..., /ar/...) so each
| language has a stable, indexable URL and hreflang has something to point
| at. The bare root redirects to the default locale.
|
*/

/*
|--------------------------------------------------------------------------
| Installer
|--------------------------------------------------------------------------
|
| Reachable only until the site is installed. EnsureInstalled redirects every
| other request here in the meantime, and 404s these routes afterwards.
|
*/

Route::prefix('install')->group(function (): void {
    Route::get('/', [WizardController::class, 'show'])->name('install.show');
    Route::post('owner', [WizardController::class, 'owner'])->middleware('throttle:30,1')->name('install.owner');
    Route::post('api/lang', [WizardController::class, 'setLang']);

    Route::middleware('throttle:900,1')->prefix('api')->group(function (): void {
        Route::get('checks', [WizardController::class, 'checks']);
        Route::get('probe-plan', [WizardController::class, 'probePlan']);
        Route::post('probe-result', [WizardController::class, 'probeResult']);
        Route::post('db/test', [WizardController::class, 'dbTest']);
        Route::post('smtp/test', [WizardController::class, 'smtpTest']);
        Route::post('config', [WizardController::class, 'saveConfig']);

        Route::post('upload/init', [WizardController::class, 'uploadInit']);
        Route::put('upload/{id}/chunk/{index}', [WizardController::class, 'uploadChunk'])->where(['id' => '[a-f0-9]{24}', 'index' => '[0-9]+']);
        Route::get('upload/{id}', [WizardController::class, 'uploadStatus'])->where('id', '[a-f0-9]{24}');
        Route::post('upload/{id}/finish', [WizardController::class, 'uploadFinish'])->where('id', '[a-f0-9]{24}');
        Route::delete('upload/{id}', [WizardController::class, 'uploadDiscard'])->where('id', '[a-f0-9]{24}');

        Route::post('analyze/start', [WizardController::class, 'analyzeStart']);
        Route::post('analyze/step', [WizardController::class, 'analyzeStep']);
        Route::post('analyze/retry', [WizardController::class, 'analyzeRetry']);
        Route::post('restore/key', [WizardController::class, 'keyCheck']);

        Route::post('run/start', [WizardController::class, 'runStart']);
        Route::post('run/step', [WizardController::class, 'runStep']);
        Route::get('run/status', [WizardController::class, 'runStatus']);
        Route::post('run/retry', [WizardController::class, 'runRetry']);
        Route::get('report', [WizardController::class, 'report']);
    });
});

// The installation report (no secrets) for the Super Admin, after installation: System → download.
Route::get(config('wadi.admin.path', 'admin').'/install-report', function () {
    abort_unless(auth()->check() && auth()->user()->can(\App\Support\Permissions::SETTINGS_SENSITIVE), 403);
    $r = \App\Support\Installer\Wizard\Report::load();
    abort_if($r === null, 404);

    return response()->json($r, 200, ['Content-Disposition' => 'attachment; filename="wadi-install-report.json"', 'Cache-Control' => 'private, no-store']);
})->middleware(['web', 'auth', 'admin.ip'])->name('install.report');

// Resumable large-file uploader (signed-in staff with media.upload only; same IP allowlist as the panel).
// Backup archives are streamed from private storage (never through Livewire); see BackupDownloadController.
Route::get(config('wadi.admin.path', 'admin').'/backup-download/{token}', \App\Http\Controllers\Admin\BackupDownloadController::class)
    ->middleware(['web', 'auth', 'admin.ip', 'throttle:30,1'])->where('token', '[A-Za-z0-9]{48}')->name('backups.download');

// Language choice on the maintenance page: remembers the visitor's language and keeps them inside the maintenance notice.
// Any of the supported languages may be chosen, whether or not it is published for the full site.
Route::get('maintenance/language/{locale}', function (\Illuminate\Http\Request $request, string $locale) {
    $locale = strtolower($locale);
    abort_unless(\App\Support\Locales::isSupported($locale), 404);

    return redirect('/'.$locale)->withCookie(cookie(
        (string) config('wadi.locale_detection.cookie', 'wr_locale'), $locale,
        60 * 24 * (int) config('wadi.locale_detection.cookie_days', 365), '/', null, $request->isSecure(), true, false, 'lax',
    ))->header('Cache-Control', 'no-store, private')->header('X-Robots-Tag', 'noindex, nofollow');
})->where('locale', '[A-Za-z]{2,3}')->name('maintenance.language');

// Preview of the visitor maintenance page in one language and state (`?state=countdown|final`). Signed-in staff with content access
// only; always private and never indexed. This is the page anonymous visitors see; it does not change anything.
Route::get(config('wadi.admin.path', 'admin').'/maintenance-preview/{locale}', function (\Illuminate\Http\Request $request, string $locale) {
    abort_unless(auth()->check() && (bool) auth()->user()->is_active && auth()->user()->can(\App\Support\Permissions::CONTENT_VIEW) && \App\Support\Locales::isSupported($locale), 403);
    app()->setLocale($locale);
    $state = in_array($request->query('state'), ['countdown', 'final'], true) ? (string) $request->query('state') : 'countdown';

    return response()->view('errors.maintenance', \App\Http\Middleware\MaintenanceMode::pageData($locale, $state))
        ->header('Cache-Control', 'private, no-store, max-age=0')->header('X-Robots-Tag', 'noindex, nofollow');
})->middleware(['web', 'auth', 'admin.ip'])->where('locale', '[a-z]{2,3}')->name('maintenance.preview');

Route::prefix('admin/large-uploads')->middleware(['auth', 'admin.ip', 'throttle:900,1'])->name('large-uploads.')->group(function (): void {
    Route::post('/', [\App\Http\Controllers\Admin\LargeUploadController::class, 'start'])->name('start');
    Route::get('find', [\App\Http\Controllers\Admin\LargeUploadController::class, 'find'])->name('find');
    Route::get('{id}', [\App\Http\Controllers\Admin\LargeUploadController::class, 'show'])->name('show');
    Route::put('{id}/chunk', [\App\Http\Controllers\Admin\LargeUploadController::class, 'chunk'])->name('chunk');
    Route::post('{id}/complete', [\App\Http\Controllers\Admin\LargeUploadController::class, 'complete'])->name('complete');
    Route::delete('{id}', [\App\Http\Controllers\Admin\LargeUploadController::class, 'cancel'])->name('cancel');
});

// Pages registered by active plugins (see App\Plugins\PluginContext). Generic routes: nothing is registered
// dynamically, so route caching keeps working and a plugin can never add a route of its own.
Route::get('plugins/{plugin}/assets/{path}', [\App\Http\Controllers\PluginPageController::class, 'asset'])
    ->where(['plugin' => '[a-z0-9][a-z0-9._-]{2,63}', 'path' => '.+'])->name('plugins.asset');
Route::post('plugins/{plugin}/hook/{slug}', [\App\Http\Controllers\PluginPageController::class, 'webhook'])
    ->middleware('throttle:'.(int) config('modules.plugins.webhook_rate_per_minute', 120).',1')
    ->where(['plugin' => '[a-z0-9][a-z0-9._-]{2,63}', 'slug' => '[a-z0-9][a-z0-9-]{0,60}'])->name('plugins.webhook');
Route::get('plugins/{plugin}/{slug?}', [\App\Http\Controllers\PluginPageController::class, 'public'])
    ->where(['plugin' => '[a-z0-9][a-z0-9._-]{2,63}', 'slug' => '[a-z0-9][a-z0-9-]{0,60}'])->name('plugins.page');
Route::match(['get', 'post'], config('wadi.admin.path', 'admin').'/plugin-pages/{plugin}/{slug}', [\App\Http\Controllers\PluginPageController::class, 'admin'])
    ->middleware(['web', 'auth', 'admin.ip'])
    ->where(['plugin' => '[a-z0-9][a-z0-9._-]{2,63}', 'slug' => '[a-z0-9][a-z0-9-]{0,60}'])->name('plugins.admin');

// Automatic language selection happens HERE (and for unlocalized paths below), never on a localized page.
Route::get('/', [\App\Http\Controllers\LocaleEntryController::class, 'entry'])->name('root');
Route::get('language/{locale}', [\App\Http\Controllers\LocaleEntryController::class, 'switch'])
    ->where('locale', implode('|', Locales::supportedCodes()))->name('locale.switch');

// The old standalone Packaging editor is gone: the Packaging Catalog manager is the only one.
Route::redirect('admin/packaging-types/{path?}', '/admin/packaging-catalog', 301)->where('path', '.*');

// Crawler files must not be locale-prefixed.
Route::get('sitemap.xml', [SitemapController::class, 'index'])->name('sitemap');
Route::get('robots.txt', [SitemapController::class, 'robots'])->name('robots');

/*
| Legacy packaging URLs (the approved package's static and WordPress
| addresses) — 301 to the localized pages. No locale prefix, so they cannot
| collide with /{locale}/… routes. Unknown slugs 404; never an open redirect.
*/
Route::get('packaging/{path?}', LegacyPackagingRedirectController::class)
    ->where('path', '[A-Za-z0-9._/-]*')
    ->name('packaging.legacy');
Route::get('packing/{path?}', LegacyPackagingRedirectController::class)
    ->where('path', '[A-Za-z0-9._/-]*')
    ->name('packing.legacy');

/*
| LOCAL DEVELOPMENT ONLY (Phase 2): approved packaging images straight from an
| extracted package, for comparing pages with the approved HTML before the
| media pipeline exists. Not registered in production or when unconfigured.
*/
if (filled(config('packaging.dev_assets_path')) && ! app()->isProduction()) {
    Route::get('_dev/packaging-assets/{path}', function (string $path) {
        $root = realpath((string) config('packaging.dev_assets_path'));
        $file = $root ? realpath($root.'/'.$path) : false;
        abort_unless($file && str_starts_with($file, $root.DIRECTORY_SEPARATOR) && is_file($file), 404);
        abort_unless(in_array(strtolower(pathinfo($file, PATHINFO_EXTENSION)), ['png', 'jpg', 'jpeg', 'webp'], true), 404);

        return response()->file($file);
    })->where('path', '[A-Za-z0-9._/-]+')->name('dev.packaging-asset');
}

// Media delivered through PHP, for hosts where the storage symlink cannot be
// created or Apache will not follow it. Registered only when enabled, so the
// route table stays minimal on a normal install.
if (config('wadi.media.public_fallback')) {
    Route::get('media/{path}', [MediaFileController::class, 'show'])
        ->where('path', '.*')
        ->name('media.file');
}

Route::prefix('{locale}')
    ->where(['locale' => implode('|', Locales::supportedCodes())])
    ->middleware(SetLocale::class)
    ->group(function (): void {

        Route::get('/', [HomeController::class, 'index'])->name('home');

        // --- Catalogue ---------------------------------------------------
        Route::get('products', [ProductController::class, 'index'])->name('products.index');
        Route::get('products/variety/{variety}', [ProductController::class, 'variety'])
            ->where('variety', '[a-z0-9]+(?:-[a-z0-9]+)*')->name('products.variety');
        Route::get('products/category/{category}', [ProductController::class, 'category'])
            ->where('category', '[a-z0-9]+(?:-[a-z0-9]+)*')->name('products.category');
        Route::get('products/{product}', [ProductController::class, 'show'])->name('products.show');
        Route::get('products/{product}/spec-sheet', [ProductController::class, 'specSheet'])
            ->name('products.spec-sheet');

        Route::get('packaging', [PackagingController::class, 'index'])->name('packaging.index');
        // One resolver for family, pack and olive-oil pages: slugs are unique
        // across all three, so the URI pattern is registered exactly once.
        Route::get('packaging/{slug}', [PackagingController::class, 'show'])
            ->where('slug', '[a-z0-9]+(?:-[a-z0-9]+)*')
            ->name('packaging.show');

        // Admin preview of a catalog revision: signed + expiring + signed-in (see controller).
        Route::middleware(['signed', 'auth'])->group(function (): void {
            Route::get('packaging-preview/{revision}', [PackagingPreviewController::class, 'index'])
                ->whereNumber('revision')->name('packaging.preview.index');
            Route::get('packaging-preview/{revision}/{slug}', [PackagingPreviewController::class, 'show'])
                ->whereNumber('revision')->where('slug', '[a-z0-9]+(?:-[a-z0-9]+)*')->name('packaging.preview.show');
        });

        // --- News and exhibitions ---------------------------------------
        Route::get('news', [NewsController::class, 'index'])->name('news.index');
        Route::get('news/{post}', [NewsController::class, 'show'])->name('news.show');

        // --- Forms -------------------------------------------------------
        Route::get('request-a-quote', [QuoteRequestController::class, 'create'])->name('quote.create');
        Route::post('request-a-quote', [QuoteRequestController::class, 'store'])
            ->middleware('throttle:rfq')
            ->name('quote.store');
        Route::get('request-a-quote/{reference}/received', [QuoteRequestController::class, 'thanks'])
            ->name('quote.thanks');

        Route::get('contact', [ContactController::class, 'show'])->name('contact.show');
        Route::post('contact', [ContactController::class, 'store'])
            ->middleware('throttle:contact')
            ->name('contact.store');

        // --- Editable pages ----------------------------------------------
        // Named system pages resolve by key so a slug rename never 404s a
        // menu item; the catch-all below serves any other published page.
        Route::get('about', [PageController::class, 'about'])->name('about');
        Route::get('team', [\App\Http\Controllers\TeamController::class, 'index'])->name('team.index');
        Route::get('team/{slug}', [\App\Http\Controllers\TeamController::class, 'show'])->where('slug', '[a-z0-9\-]+')->name('team.show');
        Route::get('quality', [PageController::class, 'quality'])->name('quality');
        Route::get('export', [PageController::class, 'export'])->name('export');
        Route::get('private-label', [PageController::class, 'privateLabel'])->name('private-label');
        Route::get('privacy-policy', [PageController::class, 'privacy'])->name('privacy');
        Route::get('terms', [PageController::class, 'terms'])->name('terms');

        /*
         | Documents.
         |
         | Registered BEFORE the catch-all `{page}` route below, which would
         | otherwise swallow /documents/... and look for a page with that slug.
         */
        Route::get('documents/{slug}', [DocumentController::class, 'show'])
            ->name('documents.show');
        Route::get('documents/{slug}/download', [DocumentController::class, 'download'])
            ->name('documents.download');

        Route::get('{page}', [PageController::class, 'show'])->name('page.show');
    });

/*
|--------------------------------------------------------------------------
| Authenticated admin documents
|--------------------------------------------------------------------------
|
| Quote attachments are stored on the private disk and streamed through an
| authorised action, never served directly from the web root.
|
*/

/*
|--------------------------------------------------------------------------
| Builder preview
|--------------------------------------------------------------------------
|
| Renders the page builder's *draft* through the real public templates, for
| the preview pane inside the builder.
|
| Behind `auth` and checked again for the content permission in the controller:
| this serves unpublished work, so it must never be reachable by a visitor. It
| renders only — nothing here writes a node or touches the published cache, so
| opening a preview cannot change what the public site shows.
|
| The prefix matches the admin panel's so it sits behind the same path in a
| deployment that has moved the panel, and the iframe is same-origin, which is
| what lets the preview and the builder talk to each other at all.
|
*/

Route::middleware(['web', 'auth'])
    ->prefix(config('wadi.admin.path', 'admin').'/builder')
    ->name('admin.builder.')
    ->group(function (): void {
        Route::get('preview/{pageKey?}', BuilderPreviewController::class)->name('preview');
        Route::get('header-preview', \App\Http\Controllers\Admin\PageHeaderPreviewController::class)->name('header-preview');
    });

// Homepage Manager preview: the draft (or a stored version) through the real
// homepage templates. Authenticated, permission-checked, noindex, never cached.
Route::middleware(['web', 'auth', 'admin.ip'])
    ->prefix(config('wadi.admin.path', 'admin').'/homepage')
    ->name('admin.homepage.')
    ->group(function (): void {
        Route::get('preview', HomepagePreviewController::class)->name('preview');
        Route::get('preview-frame', [HomepagePreviewController::class, 'frame'])->name('preview-frame');
    });

// Admin-only downloads (the Filament "Export PDF" action and the attachment
// links on the quote view page are their only consumers; there is no customer
// portal). They sit behind the same network allowlist as the panel itself.
Route::middleware(['web', 'auth', 'admin.ip'])
    ->prefix('admin/documents')
    ->name('admin.')
    ->group(function (): void {
        Route::get('rfq/{quoteRequest}/pdf', [QuoteDocumentController::class, 'pdf'])
            ->name('rfq.pdf');
        Route::get('rfq/attachment/{attachment}', [QuoteDocumentController::class, 'attachment'])
            ->name('rfq.attachment');
    });

/*
|--------------------------------------------------------------------------
| Map diagnostics
|--------------------------------------------------------------------------
|
| A temporary page that loads the same map several different ways, so a
| "the map does not work" report can be narrowed to which way fails.
|
| Registered ONLY when MAP_DIAGNOSTICS_TOKEN is set, and only matches when the
| token is presented. With no token in .env the route does not exist at all —
| a diagnostics page that quietly stays reachable after the problem is solved
| is a liability, not a convenience.
|
| Outside the locale group: it must render when a locale or a layout is the
| thing that is broken.
|
*/

// STAGING-ONLY network diagnostic (REMOTE_ADDR / proxy / HTTPS / client IP).
// Registered only when NETWORK_DIAGNOSTIC_ENABLED=true; Super Admin only; no
// forwarded header is trusted to produce it. Remove after staging verification.
// BEGIN network-diagnostic
if (config('wadi.diagnostics.network')) {
    Route::middleware(['web', 'auth'])
        ->get('_diagnostics/network', NetworkDiagnosticController::class)
        ->name('diagnostics.network');
}
// END network-diagnostic

if (filled(config('wadi.diagnostics.token'))) {
    Route::get('_diagnostics/map', function (): View {
        abort_unless(
            hash_equals(
                (string) config('wadi.diagnostics.token'),
                (string) request()->query('token', '')
            ),
            404
        );

        return view('diagnostics.map', [
            'locations' => CompanyLocation::liveFor(),
            'pasted' => setting('contact.map_embed'),
            'mapsEnabled' => (bool) config('wadi.maps.enabled', true),
            'hasKey' => filled(config('wadi.maps.api_key')),
            // A well-known point, so this block is independent of the site's
            // own data: if it renders, iframes to Google work here.
            'control' => 'https://maps.google.com/maps?'.http_build_query([
                'q' => '30.0444,31.2357',
                'z' => 12,
                'hl' => 'en',
                'output' => 'embed',
            ]),
        ]);
    })->middleware('web')->name('diagnostics.map');
}

// Unlocalized public paths ("/request-a-quote?pack=…") go to the visitor's language when that page exists; everything else stays a 404.
Route::fallback([\App\Http\Controllers\LocaleEntryController::class, 'fallback']);
