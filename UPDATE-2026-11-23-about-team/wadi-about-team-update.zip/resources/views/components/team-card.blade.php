@props(['m', 'preview' => false])
@php
    $name = $m->displayName();
    $img = $m->portrait;
    $alt = $m->t('portrait_alt') ?: __('team.portrait_of', ['name' => $name]);
    $dept = $m->publicDepartment() ?? ($preview ? $m->department : null);
@endphp
<article class="tm-card">
    <div class="tm-photo">
        @if ($img)
            <img src="{{ $img->urlFor(240) }}" alt="{{ $alt }}" loading="lazy" decoding="async" width="240" height="240" style="object-position:{{ (int) $m->portrait_focal_x }}% {{ (int) $m->portrait_focal_y }}%">
        @else
            <span class="tm-init" aria-hidden="true">{{ $m->initials() }}</span>
        @endif
    </div>
    <div class="tm-body">
        <h3 class="tm-name"><a href="{{ route('team.show', ['locale' => app()->getLocale(), 'slug' => $m->slug] + ($preview ? ['preview' => 1] : [])) }}">{{ $name }}</a></h3>
        @if (filled($m->t('job_title')))<p class="tm-role">{{ $m->t('job_title') }}</p>@endif
        @if ($dept)<p class="tm-dept">{{ $dept->label() }}</p>@endif
        @if ($preview && $m->status !== 'published')<p class="tm-draft">{{ __('team.admin.draft') }}</p>@endif
    </div>
</article>
