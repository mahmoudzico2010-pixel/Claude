<x-filament-panels::page>
    <p style="font-size:.85rem;color:#4b5563">{{ __('team.admin.structure_help') }}</p>
    @php $canMove = $this->canStructure(); $managers = $this->managers(); @endphp

    @php
        $render = function (array $nodes, int $depth = 0) use (&$render, $canMove, $managers) {
            foreach ($nodes as $n) {
                $m = $n['member'];
                echo view('filament.pages.team-structure-row', ['m' => $m, 'depth' => $depth, 'canMove' => $canMove, 'managers' => $managers])->render();
                $render($n['children'], $depth + 1);
            }
        };
    @endphp

    <div data-testid="team-structure" style="display:flex;flex-direction:column;gap:.4rem">
        @forelse ($this->tree() as $root)
            @php $render([$root]); @endphp
        @empty
            <p>{{ __('team.no_members') }}</p>
        @endforelse
    </div>
</x-filament-panels::page>
