<div wire:key="row-{{ $m->id }}" style="margin-inline-start:{{ $depth * 1.6 }}rem;display:flex;flex-wrap:wrap;gap:.6rem;align-items:center;border:1px solid #e5e7eb;border-radius:.6rem;padding:.45rem .7rem;background:#fff;border-inline-start:4px solid {{ $m->status === 'published' ? '#16a34a' : '#d97706' }}">
    <strong style="min-width:10rem">{{ $m->displayName() }}</strong>
    <span style="color:#6b7280;font-size:.8rem">{{ $m->t('job_title') }}</span>
    <span style="font-size:.72rem;background:#f1f5f9;border-radius:.3rem;padding:.1rem .4rem">{{ $m->department?->label() ?? '—' }}</span>
    <span style="font-size:.72rem;color:{{ $m->status === 'published' ? '#15803d' : '#b45309' }}">{{ $m->status === 'published' ? __('team.admin.published') : __('team.admin.draft') }}</span>
    @if ($canMove)
        <span style="margin-inline-start:auto;display:flex;gap:.3rem;align-items:center">
            <button type="button" wire:click="nudge({{ $m->id }}, -1)" title="{{ __('team.admin.nudge_up') }}" style="border:1px solid #d1d5db;border-radius:.3rem;padding:0 .4rem">↑</button>
            <button type="button" wire:click="nudge({{ $m->id }}, 1)" title="{{ __('team.admin.nudge_down') }}" style="border:1px solid #d1d5db;border-radius:.3rem;padding:0 .4rem">↓</button>
            <select wire:change="moveTo({{ $m->id }}, $event.target.value)" aria-label="{{ __('team.admin.reports_to') }}" style="border:1px solid #d1d5db;border-radius:.4rem;font-size:.78rem;padding:.15rem .4rem;max-width:14rem">
                <option value="">{{ __('team.admin.nobody') }}</option>
                @foreach ($managers as $id => $label)
                    @continue($id === $m->id)
                    <option value="{{ $id }}" @selected($m->reports_to_id === $id)>{{ $label }}</option>
                @endforeach
            </select>
        </span>
    @endif
</div>
