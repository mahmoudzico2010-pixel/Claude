@php
    $__ok = ($settings['approved'] ?? 'off') === 'on'
        && filled($settings['figure'] ?? null) && filled($settings['as_of'] ?? null)
        && filled($content['unit'] ?? null) && filled($content['scope'] ?? null) && filled($content['source'] ?? null);
@endphp
@if ($__ok)
    <figure data-builder-node="{{ $node['id'] }}" class="wr-node" style="border-inline-start:4px solid #b8912f;background:#faf6ec;border-radius:.8rem;padding:1.1rem 1.3rem;margin:0">
        @if (filled($content['label'] ?? null))<figcaption style="font-weight:700;color:#14382a">{{ $content['label'] }}</figcaption>@endif
        <p style="font-size:2rem;font-weight:700;color:#14382a;margin:.2rem 0">{{ $settings['figure'] }} <span style="font-size:1rem;font-weight:600">{{ $content['unit'] }}</span></p>
        <p style="margin:0;color:#4a5a52;font-size:.9rem">{{ $content['scope'] }} · {{ $settings['as_of'] }} · {{ $content['source'] }}</p>
    </figure>
@endif
