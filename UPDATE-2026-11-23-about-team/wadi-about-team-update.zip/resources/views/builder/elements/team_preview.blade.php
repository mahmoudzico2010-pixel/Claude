@php
    $__members = \App\Models\TeamMember::query()->public()->where('show_on_about', true)
        ->with(['translations', 'department.translations', 'portrait'])->orderBy('display_order')->orderBy('id')
        ->limit(max(1, min(24, (int) ($settings['limit'] ?? 6))))->get();
@endphp
@if ($__members->isNotEmpty())
    @include('team._styles')
    <div data-builder-node="{{ $node['id'] }}" class="wr-node tm">
        <div class="tm-grid" style="justify-items:stretch">
            @foreach ($__members as $__m)<x-team-card :m="$__m" />@endforeach
        </div>
        @if (($settings['show_link'] ?? 'on') === 'on')
            <p style="margin-top:1.4rem"><a class="btn btn-secondary" href="{{ route('team.index', ['locale' => app()->getLocale()]) }}">{{ __('team.about_cta') }}</a></p>
        @endif
    </div>
@endif
