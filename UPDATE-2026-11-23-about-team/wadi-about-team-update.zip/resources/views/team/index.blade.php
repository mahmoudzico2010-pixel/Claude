@extends('layouts.public')

@section('content')
    @include('team._styles')
    <x-page-hero :eyebrow="__('team.eyebrow')" :title="__('team.page_title')" :subtitle="__('team.intro')" :breadcrumbs="$seo->breadcrumbs" pageKey="team" />

    <div class="tm">
        <div class="tm-wrap">
            @if ($preview)<div class="tm-banner" role="status">{{ __('team.admin.preview') }} — {{ __('team.admin.draft') }} + {{ __('team.admin.published') }}</div>@endif

            @if ($members->isEmpty())
                <section class="tm-sec"><p class="tm-sub">{{ __('team.no_members') }}</p></section>
            @else
                <a class="tm-skip" href="#tm-departments">{{ __('team.skip') }}</a>

                <section class="tm-sec" id="tm-chart" aria-labelledby="tm-chart-h">
                    <h2 class="tm-h2" id="tm-chart-h">{{ __('team.view_chart') }}</h2>
                    <nav class="tm-org tm-org-root" aria-label="{{ __('team.view_chart') }}">
                        @include('team._branch', ['nodes' => $tree, 'preview' => $preview, 'top' => true])
                    </nav>
                </section>

                <section class="tm-sec" id="tm-departments" aria-labelledby="tm-dept-h" style="border-top:1px solid var(--tm-line)">
                    <h2 class="tm-h2" id="tm-dept-h">{{ __('team.view_list') }}</h2>
                    <p>
                        <a class="tm-chip" href="{{ route('team.index', ['locale' => app()->getLocale()]) }}#tm-departments" @if (! $currentDept) aria-current="true" @endif>{{ __('team.all_departments') }}</a>
                        @foreach ($departments as $d)
                            <a class="tm-chip" href="{{ route('team.index', ['locale' => app()->getLocale(), 'department' => $d->slug]) }}#tm-departments" @if ($currentDept?->id === $d->id) aria-current="true" @endif>{{ $d->label() }}</a>
                        @endforeach
                    </p>
                    @foreach ($groups as $g)
                        <div style="margin-top:1.6rem">
                            @if ($g['department'])
                                <h3 class="tm-h2" style="font-size:1.15rem">{{ $g['department']->label() }}</h3>
                                @if (filled($g['department']->t('description')))<p class="tm-sub" style="margin-bottom:.8rem">{{ $g['department']->t('description') }}</p>@endif
                                @if ($g['department']->contact_url && ($u = \App\Support\Builder\SafeLink::href($g['department']->contact_url)))
                                    <p><a class="tm-chip" href="{{ $u }}">{{ __('team.contact') }}</a></p>
                                @endif
                            @endif
                            <div class="tm-grid">
                                @foreach ($g['members'] as $m)
                                    <x-team-card :m="$m" :preview="$preview" />
                                @endforeach
                            </div>
                        </div>
                    @endforeach
                </section>
            @endif
        </div>
    </div>

    <script>
    (function () {
        // Desktop: every branch open (a chart). Phone: first level open, deeper branches closed and expandable.
        var mq = window.matchMedia('(min-width:1024px)');
        function sync() {
            document.querySelectorAll('.tm-org details').forEach(function (d) {
                var depth = 0, p = d.parentElement;
                while (p && p !== document) { if (p.tagName === 'DETAILS') { depth++; } p = p.parentElement; }
                d.open = mq.matches ? true : depth < 1;
            });
        }
        sync();
        (mq.addEventListener ? mq.addEventListener('change', sync) : mq.addListener(sync));
    })();
    </script>
@endsection
