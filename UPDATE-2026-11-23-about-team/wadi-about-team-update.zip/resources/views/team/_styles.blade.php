@once
<style>
.tm{--tm-green:#14382a;--tm-green2:#1f4f3a;--tm-brass:#b8912f;--tm-ivory:#faf6ec;--tm-ink:#1c2a24;--tm-mut:#5b6b63;--tm-line:#d9d2bd;color:var(--tm-ink)}
.tm-wrap{max-width:76rem;margin-inline:auto;padding-inline:1.25rem}
.tm-sec{padding-block:3rem}
.tm-h2{font-size:1.5rem;font-weight:700;color:var(--tm-green);margin:0 0 .4rem}
.tm-sub{color:var(--tm-mut);margin:0 0 1.5rem;max-width:46rem}
.tm-card{position:relative;display:flex;flex-direction:column;align-items:center;text-align:center;gap:.35rem;background:#fff;border:1px solid var(--tm-line);border-radius:1rem;padding:1rem .9rem;width:100%;max-width:14.5rem;box-shadow:0 1px 0 rgba(20,56,42,.04);transition:box-shadow .2s,transform .2s}
.tm-card:hover,.tm-card:focus-within{box-shadow:0 10px 26px rgba(20,56,42,.14);transform:translateY(-2px)}
@media (prefers-reduced-motion:reduce){.tm-card{transition:none}.tm-card:hover,.tm-card:focus-within{transform:none}}
.tm-photo{width:4.6rem;height:4.6rem;border-radius:999px;overflow:hidden;background:var(--tm-green);display:grid;place-items:center;border:2px solid var(--tm-brass)}
.tm-photo img{width:100%;height:100%;object-fit:cover}
.tm-init{color:#fff;font-weight:700;font-size:1.25rem;letter-spacing:.03em}
.tm-name{margin:.2rem 0 0;font-size:1rem;font-weight:700;line-height:1.25}
.tm-name a{color:var(--tm-green);text-decoration:none}
.tm-name a::after{content:"";position:absolute;inset:0;border-radius:1rem}
.tm-name a:focus-visible{outline:3px solid var(--tm-brass);outline-offset:2px}
.tm-role{margin:0;font-size:.85rem;color:var(--tm-mut)}
.tm-dept{margin:.15rem 0 0;font-size:.72rem;font-weight:600;letter-spacing:.04em;color:var(--tm-green2);background:var(--tm-ivory);border-radius:.4rem;padding:.12rem .5rem}
.tm-draft{font-size:.7rem;color:#b45309;font-weight:700}
.tm-org ul{list-style:none;margin:0;padding:0}
.tm-org li{margin:0}
.tm-org summary{cursor:pointer;font-size:.85rem;font-weight:600;color:var(--tm-green2);padding:.45rem .7rem;border:1px solid var(--tm-line);border-radius:.6rem;background:var(--tm-ivory);width:max-content;margin:.5rem 0 0;list-style:none}
.tm-org summary::-webkit-details-marker{display:none}
.tm-org summary::before{content:"+ ";font-weight:700}
.tm-org details[open]>summary::before{content:"− "}
/* phone: vertical, stacked, expandable; never wider than the screen */
@media (max-width:1023.98px){
 .tm-org li{padding-block:.35rem}
 .tm-org li>details>ul{margin-inline-start:.9rem;padding-inline-start:.9rem;border-inline-start:2px solid var(--tm-line)}
 .tm-card{max-width:none;flex-direction:row;text-align:start;align-items:center;gap:.8rem}
 .tm-card .tm-body{flex:1;min-width:0}
}
@media (min-width:1024px){
 .tm-org>ul{display:flex;justify-content:center;gap:2.2rem;flex-wrap:wrap}
 .tm-org li{position:relative;display:flex;flex-direction:column;align-items:center;padding-inline:.65rem}
 .tm-org details>summary{display:none}
 .tm-org details>ul{display:flex;justify-content:center;flex-wrap:wrap;padding-top:1.6rem;position:relative}
 .tm-org details>ul::before{content:"";position:absolute;top:0;inset-inline-start:50%;height:1.6rem;border-inline-start:2px solid var(--tm-line)}
 .tm-org details>ul>li{padding-top:1.6rem}
 .tm-org details>ul>li::before,.tm-org details>ul>li::after{content:"";position:absolute;top:0;width:50%;height:1.6rem;border-top:2px solid var(--tm-line)}
 .tm-org details>ul>li::before{inset-inline-start:0}
 .tm-org details>ul>li::after{inset-inline-end:0;border-inline-start:2px solid var(--tm-line)}
 .tm-org details>ul>li:first-child::before{border-top:0}
 .tm-org details>ul>li:last-child::after{border-top:0}
}
.tm-grid{display:grid;gap:1rem;grid-template-columns:repeat(auto-fill,minmax(14rem,1fr));justify-items:center}
.tm-chip{display:inline-block;margin:.15rem;padding:.35rem .8rem;border:1px solid var(--tm-line);border-radius:999px;font-size:.85rem;color:var(--tm-green);text-decoration:none;background:#fff}
.tm-chip[aria-current="true"]{background:var(--tm-green);color:#fff;border-color:var(--tm-green)}
.tm-skip{position:absolute;inset-inline-start:-999px}
.tm-skip:focus{inset-inline-start:1rem;background:#fff;padding:.4rem .8rem;z-index:50;border:2px solid var(--tm-brass)}
.tm-banner{background:#fff3cd;border:1px solid #e0b84a;color:#7a5b00;padding:.6rem 1rem;border-radius:.6rem;margin:1rem 0;font-size:.85rem}
/* profile */
.tm-prof{display:grid;gap:2rem;grid-template-columns:1fr}
@media (min-width:860px){.tm-prof{grid-template-columns:16rem 1fr}}
.tm-prof .tm-big{width:14rem;height:14rem;border-radius:1.2rem;overflow:hidden;background:var(--tm-green);display:grid;place-items:center;border:3px solid var(--tm-brass)}
.tm-prof .tm-big img{width:100%;height:100%;object-fit:cover}
.tm-prof .tm-big .tm-init{font-size:3.4rem}
.tm-bio{line-height:1.8;font-size:1.02rem}
.tm-contact{list-style:none;margin:1.2rem 0;padding:0;display:flex;flex-wrap:wrap;gap:.6rem}
.tm-contact a{display:inline-flex;gap:.5rem;align-items:center;padding:.55rem 1rem;border-radius:.7rem;border:1px solid var(--tm-line);background:#fff;color:var(--tm-green);text-decoration:none;font-weight:600}
.tm-contact a:hover,.tm-contact a:focus-visible{background:var(--tm-green);color:#fff}
</style>
@endonce
