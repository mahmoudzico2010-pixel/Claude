@extends('layouts.public')

@section('content')
    @include('team._styles')
    @php
        $name = $member->displayName();
        $loc = app()->getLocale();
        $email = $member->publicEmail();
        $tel = $member->publicPhone() ? $member->telHref() : null;
        $wa = $member->publicWhatsapp() ? $member->whatsappHref() : null;
        $links = $member->publicLinks();
        $img = $member->portrait;
        $alt = $member->t('portrait_alt') ?: __('team.portrait_of', ['name' => $name]);
        $pv = $preview ? ['preview' => 1] : [];
    @endphp
    <x-page-hero :eyebrow="$department?->label() ?? __('team.page_title')" :title="$name" :subtitle="$member->t('job_title')" :breadcrumbs="$seo->breadcrumbs" :pageKey="'team:'.$member->slug" />

    <div class="tm"><div class="tm-wrap"><section class="tm-sec">
        @if ($preview)<div class="tm-banner" role="status">{{ __('team.admin.preview') }} — {{ $member->status === 'published' ? __('team.admin.published') : __('team.admin.draft') }}</div>@endif
        <div class="tm-prof">
            <div>
                <div class="tm-big">
                    @if ($img)
                        <img src="{{ $img->urlFor(640) }}" alt="{{ $alt }}" width="640" height="640" style="object-position:{{ (int) $member->portrait_focal_x }}% {{ (int) $member->portrait_focal_y }}%">
                    @else
                        <span class="tm-init" aria-hidden="true">{{ $member->initials() }}</span>
                    @endif
                </div>
                @if ($department)
                    <p style="margin-top:1rem"><strong>{{ __('team.department') }}:</strong>
                        <a href="{{ route('team.index', ['locale' => $loc, 'department' => $department->slug] + $pv) }}#tm-departments">{{ $department->label() }}</a></p>
                @endif
                @if ($manager)
                    <p><strong>{{ __('team.reports_to') }}:</strong>
                        <a href="{{ route('team.show', ['locale' => $loc, 'slug' => $manager->slug] + $pv) }}">{{ $manager->displayName() }}</a></p>
                @endif
            </div>
            <div>
                @if (filled($member->t('short_bio')))<p class="tm-bio" style="font-size:1.12rem;font-weight:600">{{ $member->t('short_bio') }}</p>@endif
                @if (filled($member->t('full_bio')))<div class="tm-bio">{!! nl2br(e($member->t('full_bio'))) !!}</div>@endif

                @if ($email || $tel || $wa || $links->isNotEmpty())
                    <h2 class="tm-h2" style="margin-top:1.6rem">{{ __('team.contact') }}</h2>
                    <ul class="tm-contact">
                        @if ($email)<li><a href="mailto:{{ $email }}">✉ {{ $email }}</a></li>@endif
                        @if ($tel)<li><a href="{{ $tel }}">☎ {{ $member->phone }}</a></li>@endif
                        @if ($wa)<li><a href="{{ $wa }}" rel="noopener noreferrer" target="_blank">{{ __('team.whatsapp') }}</a></li>@endif
                        @foreach ($links as $l)
                            <li><a href="{{ $l->safeUrl() }}" rel="noopener noreferrer" target="_blank">{{ $l->label ?: ucfirst($l->network) }}</a></li>
                        @endforeach
                    </ul>
                @endif

                @if ($reports->isNotEmpty())
                    <h2 class="tm-h2" style="margin-top:2rem">{{ __('team.works_with') }}</h2>
                    <div class="tm-grid" style="justify-items:start">
                        @foreach ($reports as $r)<x-team-card :m="$r" :preview="$preview" />@endforeach
                    </div>
                @endif

                <p style="margin-top:2rem"><a class="tm-chip" href="{{ route('team.index', ['locale' => $loc] + $pv) }}">← {{ __('team.back_to_team') }}</a></p>
            </div>
        </div>
    </section></div></div>
@endsection
