<ul @if (! empty($top)) role="list" @endif>
    @foreach ($nodes as $n)
        @php($m = $n['member'])
        <li>
            <x-team-card :m="$m" :preview="$preview" />
            @if ($n['children'])
                <details open>
                    <summary>{{ __('team.show_branch') }} ({{ count($n['children']) }})</summary>
                    @include('team._branch', ['nodes' => $n['children'], 'preview' => $preview, 'top' => false])
                </details>
            @endif
        </li>
    @endforeach
</ul>
