<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Filament\Pages\PhotoReviewQueue;
use App\Models\CatalogMediaReview;
use App\Models\MediaAsset;
use App\Models\Product;
use App\Models\ProductImage;
use App\Models\SiteSetting;
use App\Models\User;
use App\Services\Catalog\CatalogHierarchy;
use App\Services\Catalog\CatalogImport59;
use App\Services\Catalog\PhotoZipImporter;
use Database\Seeders\RolePermissionSeeder;
use Filament\Facades\Filament;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Livewire\Livewire;
use PHPUnit\Framework\Attributes\Test;
use RuntimeException;
use Tests\TestCase;
use ZipArchive;

final class PhotoZipImportTest extends TestCase
{
    use RefreshDatabase;

    private string $work;

    protected function setUp(): void
    {
        parent::setUp();
        Storage::fake('public');
        $this->seed(RolePermissionSeeder::class);
        Filament::setCurrentPanel('admin');
        SiteSetting::setMany(['maintenance_mode' => false], 'site');
        CatalogHierarchy::apply();
        $this->work = sys_get_temp_dir().'/wadi-zip-'.uniqid();
        mkdir($this->work);
        // a small catalogue with one existing photo that must never be disturbed
        file_put_contents("{$this->work}/BEKO0402.webp", 'bytes-0');
        (new CatalogImport59)->run(true, $this->work);
        $u = User::factory()->create(['is_active' => true]);
        $u->assignRole(User::ROLE_SUPER_ADMIN);
        $this->actingAs($u);
    }

    /** A real, decodable image whose bytes differ per $seed. */
    private function png(int $seed, int $size = 64): string
    {
        $im = imagecreatetruecolor($size, $size);
        imagefill($im, 0, 0, imagecolorallocate($im, ($seed * 53) % 255, ($seed * 97) % 255, ($seed * 31) % 255));
        for ($i = 0; $i < 6; $i++) {
            imagefilledellipse($im, ($seed * 7 + $i * 9) % $size, ($seed * 5 + $i * 11) % $size, 12, 12, imagecolorallocate($im, 255 - $seed, $i * 40, $seed));
        }
        ob_start();
        imagepng($im);

        return (string) ob_get_clean();
    }

    /** @param  array<string, string>  $files name => bytes */
    private function zip(array $files, string $name = 'photos.zip'): string
    {
        $path = $this->work.'/'.$name;
        @unlink($path);
        $z = new ZipArchive;
        $z->open($path, ZipArchive::CREATE);
        foreach ($files as $entry => $bytes) {
            $z->addFromString($entry, $bytes);
        }
        $z->close();

        return $path;
    }

    private function importer(): PhotoZipImporter
    {
        return app(PhotoZipImporter::class);
    }

    /** @return array<string, int> */
    private function counts(): array
    {
        return [
            'products' => Product::count(), 'links' => ProductImage::count(), 'media' => MediaAsset::count(), 'reviews' => CatalogMediaReview::count(),
            'primaries' => (int) Product::whereNotNull('primary_image_id')->count(), 'assigned' => CatalogMediaReview::where('status', 'assigned')->count(),
        ];
    }

    #[Test]
    public function new_photos_are_registered_and_queued_unassigned_without_touching_products_or_assignments(): void
    {
        $before = $this->counts();
        $primaries = Product::pluck('primary_image_id', 'id')->all();
        $links = ProductImage::orderBy('id')->get(['id', 'product_id', 'media_id', 'is_primary', 'display_order'])->toArray();

        $r = $this->importer()->import($this->zip(['images/a.png' => $this->png(1), 'images/b.png' => $this->png(2), 'README.txt' => 'hello', 'x/sheet.csv' => 'a,b']), 'photos.zip', auth()->user());

        $this->assertCount(2, $r['imported'], json_encode($r['rejected'] + $r['duplicates']));
        $this->assertSame(2, $r['ignored']);
        $this->assertSame([], $r['duplicates']);
        $this->assertSame([], $r['rejected']);

        $after = $this->counts();
        $this->assertSame($before['products'], $after['products'], 'no product is created');
        $this->assertSame($before['links'], $after['links'], 'no product photo link is created');
        $this->assertSame($before['primaries'], $after['primaries']);
        $this->assertSame($before['assigned'], $after['assigned']);
        $this->assertSame($before['media'] + 2, $after['media']);
        $this->assertSame($before['reviews'] + 2, $after['reviews']);
        $this->assertEquals($primaries, Product::pluck('primary_image_id', 'id')->all(), 'no primary image changed');
        $this->assertEquals($links, ProductImage::orderBy('id')->get(['id', 'product_id', 'media_id', 'is_primary', 'display_order'])->toArray(), 'no link changed');

        foreach ($r['imported'] as $i) {
            $review = CatalogMediaReview::findOrFail($i['review_id']);
            $this->assertSame('pending', $review->status);
            $this->assertNull($review->product_id);
            $media = MediaAsset::findOrFail($i['media_id']);
            $this->assertSame('products', $media->folder);
            $this->assertNotNull($media->checksum);
            Storage::disk('public')->assertExists($media->path);
        }
    }

    #[Test]
    public function importing_the_same_photos_again_creates_nothing_even_under_other_file_names(): void
    {
        $first = $this->importer()->import($this->zip(['a.png' => $this->png(3), 'b.png' => $this->png(4)]), 'one.zip', auth()->user());
        $this->assertCount(2, $first['imported']);
        $c1 = $this->counts();

        $again = $this->importer()->import($this->zip(['a.png' => $this->png(3), 'renamed-copy.png' => $this->png(4)], 'two.zip'), 'two.zip', auth()->user());
        $this->assertSame([], $again['imported']);
        $this->assertCount(2, $again['duplicates']);
        $this->assertSame($c1, $this->counts(), 'a duplicate import changes nothing');
        $this->assertStringContainsString('review queue', $again['duplicates'][0]['of']);
    }

    #[Test]
    public function a_photo_already_used_by_a_product_or_present_twice_in_the_zip_is_reported_not_imported(): void
    {
        $asset = MediaAsset::first();
        $existingBytes = (string) file_get_contents("{$this->work}/BEKO0402.webp");
        $this->assertSame(sha1($existingBytes), $asset->checksum);

        $r = $this->importer()->import($this->zip(['same-as-existing.webp' => $existingBytes, 'n1.png' => $this->png(5), 'n2.png' => $this->png(5)]), 'dups.zip', auth()->user());
        $this->assertCount(1, $r['imported']);
        $this->assertCount(2, $r['duplicates']);
        $this->assertStringContainsString('same-as-existing.webp', $r['duplicates'][0]['file']);
        $this->assertStringContainsString('identical to', $r['duplicates'][1]['of']);
    }

    #[Test]
    public function unsafe_paths_fake_images_and_non_photos_never_reach_the_library(): void
    {
        $before = $this->counts();
        $r = $this->importer()->import($this->zip([
            '../escape.png' => $this->png(6),
            '/abs/evil.png' => $this->png(7),
            'fake.png' => '<?php echo "x"; ?>',
            'shell.php' => '<?php system($_GET[0]);',
            'good.png' => $this->png(8),
            '__MACOSX/._good.png' => 'junk',
            '.hidden.png' => $this->png(9),
        ]), 'bad.zip', auth()->user());

        $this->assertSame(['good.png'], array_column($r['imported'], 'file'), json_encode($r));
        $names = array_column($r['rejected'], 'file');
        $this->assertContains('escape.png', $names);
        $this->assertContains('evil.png', $names);
        $this->assertContains('fake.png', $names);
        $this->assertSame($before['media'] + 1, $this->counts()['media']);
        $this->assertSame([], glob(storage_path('app/tmp/zipphoto-*')) ?: [], 'temporary files are removed');
    }

    #[Test]
    public function the_file_name_gives_a_suggestion_only_and_assignment_stays_a_separate_deliberate_step(): void
    {
        $p = Product::whereNotNull('slug')->firstOrFail();
        $r = $this->importer()->import($this->zip([$p->slug.'.png' => $this->png(10), 'unknown-name.png' => $this->png(11)]), 'named.zip', auth()->user());
        $this->assertCount(2, $r['imported']);
        $c0 = CatalogMediaReview::findOrFail($r['imported'][0]['review_id'])->candidates;
        $this->assertSame($p->slug, $c0[0]['slug']);
        $this->assertSame('high', $c0[0]['confidence']);
        $this->assertNull(CatalogMediaReview::findOrFail($r['imported'][1]['review_id'])->candidates);
        $this->assertSame(0, ProductImage::where('product_id', $p->id)->where('media_id', $r['imported'][0]['media_id'])->count(), 'a suggestion assigns nothing');

        // Now the reviewer assigns one as the gallery photo and one as primary, through the existing queue.
        $primaryBefore = $p->fresh()->primary_image_id;
        $c = Livewire::test(PhotoReviewQueue::class)->call('chooseProduct', $p->id)->set('selected', [$r['imported'][0]['review_id']])->set('primaryChoice', '')->call('assign');
        $this->assertSame($primaryBefore, $p->fresh()->primary_image_id, 'a gallery assignment leaves the primary alone');
        $this->assertSame(1, ProductImage::where('product_id', $p->id)->where('media_id', $r['imported'][0]['media_id'])->count());
        $c->call('focusOn', $r['imported'][1]['review_id'])->set('primaryChoice', 'this')->call('assign');
        $this->assertSame($r['imported'][1]['media_id'], $p->fresh()->primary_image_id);

        // ... and it can be undone, restoring the previous primary.
        (new \App\Services\Catalog\PhotoReviewService)->undo($r['imported'][1]['review_id'], auth()->user());
        $this->assertSame($primaryBefore, $p->fresh()->primary_image_id);
        $this->assertSame('pending', CatalogMediaReview::findOrFail($r['imported'][1]['review_id'])->status);
    }

    #[Test]
    public function an_existing_review_decision_and_its_assignment_survive_a_later_import(): void
    {
        $assigned = CatalogMediaReview::firstOrFail();
        $this->assertContains($assigned->status, ['pending', 'assigned']);
        $snapshot = $assigned->fresh()->only(['status', 'product_id', 'assigned_role', 'media_id']);

        $this->importer()->import($this->zip(['z.png' => $this->png(12)]), 'later.zip', auth()->user());
        $this->assertSame($snapshot, $assigned->fresh()->only(['status', 'product_id', 'assigned_role', 'media_id']));
    }

    #[Test]
    public function archives_that_are_unusable_or_too_big_are_refused_before_anything_is_written(): void
    {
        $before = $this->counts();

        foreach ([
            [fn () => $this->importer()->import($this->work.'/BEKO0402.webp', 'not.zip', auth()->user()), 'valid ZIP'],
            [fn () => $this->importer()->import($this->zip(['readme.txt' => 'x']), 'none.zip', auth()->user()), 'no JPG'],
        ] as [$call, $needle]) {
            try {
                $call();
                $this->fail('expected a refusal');
            } catch (RuntimeException $e) {
                $this->assertStringContainsString($needle, $e->getMessage());
            }
        }

        $many = [];
        for ($i = 0; $i < PhotoZipImporter::MAX_IMAGES + 1; $i++) {
            $many["p$i.png"] = $this->png($i % 200 + 20, 8 + ($i % 5));
        }
        try {
            $this->importer()->import($this->zip($many, 'many.zip'), 'many.zip', auth()->user());
            $this->fail('expected a refusal');
        } catch (RuntimeException $e) {
            $this->assertStringContainsString('maximum per ZIP', $e->getMessage());
        }
        $this->assertSame($before, $this->counts());
    }

    #[Test]
    public function only_users_who_may_edit_products_and_upload_media_can_import(): void
    {
        $viewer = User::factory()->create(['is_active' => true]);
        $viewer->assignRole(User::ROLE_VIEWER);
        $this->actingAs($viewer);
        $before = $this->counts();

        $this->expectException(AuthorizationException::class);
        try {
            $this->importer()->import($this->zip(['a.png' => $this->png(13)]), 'x.zip', $viewer);
        } finally {
            $this->assertSame($before, $this->counts());
        }
    }

    #[Test]
    public function the_photo_review_page_offers_the_zip_upload_and_shows_the_summary(): void
    {
        $zip = $this->zip(['one.png' => $this->png(14), 'two.png' => $this->png(15)], 'page.zip');
        $upload = \Illuminate\Http\UploadedFile::fake()->createWithContent('page.zip', (string) file_get_contents($zip));

        $c = Livewire::test(PhotoReviewQueue::class)->assertActionVisible('uploadZip')
            ->callAction('uploadZip', ['zip' => $upload])->assertHasNoActionErrors();
        $this->assertSame(2, CatalogMediaReview::where('reason', 'like', '%page.zip%')->where('status', 'pending')->count());
        $c->assertSet('status', 'pending')->assertSee('page.zip');
        $this->assertNotNull($c->get('zipResult'));
    }

    #[Test]
    public function the_upload_action_is_hidden_from_users_without_media_upload(): void
    {
        $viewer = User::factory()->create(['is_active' => true]);
        $viewer->assignRole(User::ROLE_VIEWER);
        $this->actingAs($viewer);
        $this->assertFalse($viewer->can(\App\Support\Permissions::MEDIA_UPLOAD) && $viewer->can(\App\Support\Permissions::PRODUCTS_UPDATE));
    }
}
