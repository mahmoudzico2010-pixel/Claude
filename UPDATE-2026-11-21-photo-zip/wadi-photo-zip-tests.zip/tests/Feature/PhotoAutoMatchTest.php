<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Filament\Pages\PhotoReviewQueue;
use App\Models\CatalogMediaReview;
use App\Models\MediaAsset;
use App\Models\Product;
use App\Models\ProductImage;
use App\Models\SiteSetting;
use App\Models\User;
use App\Services\Catalog\CatalogHierarchy;
use App\Services\Catalog\CatalogImport59;
use App\Services\Catalog\PhotoAutoMatcher;
use Database\Seeders\RolePermissionSeeder;
use Filament\Facades\Filament;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Storage;
use Livewire\Livewire;
use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;

final class PhotoAutoMatchTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        Storage::fake('public');
        $this->seed(RolePermissionSeeder::class);
        Filament::setCurrentPanel('admin');
        SiteSetting::setMany(['maintenance_mode' => false], 'site');
        CatalogHierarchy::apply();
        $dir = sys_get_temp_dir().'/wadi-am-'.uniqid();
        mkdir($dir);
        file_put_contents("$dir/BEKO0402.webp", 'x');
        (new CatalogImport59)->run(true, $dir);
        $u = User::factory()->create(['is_active' => true]);
        $u->assignRole(User::ROLE_SUPER_ADMIN);
        $this->actingAs($u);
    }

    /** Queue a photo under a file name, as the ZIP import would. */
    private function queue(string $file): CatalogMediaReview
    {
        $m = MediaAsset::create(['disk' => 'public', 'path' => 'media/products/'.uniqid().'.webp', 'filename' => $file, 'original_filename' => $file, 'mime_type' => 'image/webp', 'extension' => 'webp', 'size' => 1, 'folder' => 'products', 'checksum' => sha1($file.uniqid())]);

        return CatalogMediaReview::create(['media_id' => $m->id, 'original_filename' => $file, 'reason' => 'test', 'status' => 'pending']);
    }

    private function product(string $slug): Product
    {
        return Product::where('slug', $slug)->firstOrFail();
    }

    #[Test]
    public function strong_matches_are_assigned_primary_when_the_product_has_none_and_nothing_else_is_touched(): void
    {
        $p = $this->product('azizi-green-olives-halves');
        $p->forceFill(['primary_image_id' => null])->save();
        ProductImage::where('product_id', $p->id)->delete();
        $a = $this->queue('azizi-green-olives-halves.webp');
        $vague = $this->queue('dolce halves.jpg');
        $camera = $this->queue('IMG_2231.jpg');
        $products = Product::count();
        $otherPrimaries = Product::where('id', '!=', $p->id)->pluck('primary_image_id', 'id')->all();

        $r = app(PhotoAutoMatcher::class)->run('high', auth()->user());

        $this->assertSame(1, $r['assigned']);
        $this->assertSame($a->media_id, $p->fresh()->primary_image_id);
        $this->assertSame('assigned', $a->fresh()->status);
        $this->assertSame('pending', $vague->fresh()->status, 'a weak/ambiguous match stays in the queue');
        $this->assertSame('pending', $camera->fresh()->status);
        $this->assertSame($products, Product::count(), 'no product is created');
        $this->assertEquals($otherPrimaries, Product::where('id', '!=', $p->id)->pluck('primary_image_id', 'id')->all(), 'no other product changed');
    }

    #[Test]
    public function a_product_that_already_has_a_primary_keeps_it_and_the_match_joins_its_gallery(): void
    {
        $p = $this->product('azizi-green-olives-sliced');
        $existing = $this->queue('seed.webp');
        $link = ProductImage::create(['product_id' => $p->id, 'media_id' => $existing->media_id, 'is_primary' => true, 'display_order' => 0, 'source' => 'manual']);
        $this->assertSame($existing->media_id, $p->fresh()->primary_image_id);

        $new = $this->queue('azizi-green-olives-sliced.webp');
        $plan = app(PhotoAutoMatcher::class)->plan('high');
        $this->assertSame(0, $plan['primaries']);
        $this->assertSame(1, $plan['gallery']);

        app(PhotoAutoMatcher::class)->run('high', auth()->user());
        $this->assertSame($existing->media_id, $p->fresh()->primary_image_id, 'the existing primary is never replaced');
        $this->assertSame(1, ProductImage::where('product_id', $p->id)->where('media_id', $new->media_id)->where('is_primary', false)->count());
        $this->assertNotNull($link->fresh());
    }

    #[Test]
    public function several_photos_for_one_product_give_one_primary_and_the_rest_gallery(): void
    {
        $p = $this->product('picual-green-olives-stuffed');
        $p->forceFill(['primary_image_id' => null])->save();
        ProductImage::where('product_id', $p->id)->delete();
        $a = $this->queue('picual-green-olives-stuffed.webp');
        $b = $this->queue('Picual green olives stuffed (2).webp');

        $plan = app(PhotoAutoMatcher::class)->plan('high');
        $this->assertSame(1, $plan['primaries']);
        $this->assertSame(1, $plan['gallery']);
        app(PhotoAutoMatcher::class)->run('high', auth()->user());
        $this->assertSame(2, ProductImage::where('product_id', $p->id)->count());
        $this->assertSame(1, ProductImage::where('product_id', $p->id)->where('is_primary', true)->count());
    }

    #[Test]
    public function the_whole_run_can_be_undone_restoring_every_previous_primary(): void
    {
        $p = $this->product('aks-green-olives-pitted');
        $before = $p->fresh()->primary_image_id;
        $linksBefore = ProductImage::where('product_id', $p->id)->count();
        $a = $this->queue('aks-green-olives-pitted.webp');

        $r = app(PhotoAutoMatcher::class)->run('high', auth()->user());
        $this->assertGreaterThanOrEqual(1, $r['assigned']);
        $n = app(PhotoAutoMatcher::class)->undoRun($r['review_ids'], auth()->user());
        $this->assertSame(count($r['review_ids']), $n);
        $this->assertSame('pending', $a->fresh()->status);
        $this->assertSame($before, $p->fresh()->primary_image_id);
        $this->assertSame($linksBefore, ProductImage::where('product_id', $p->id)->count());
    }

    #[Test]
    public function the_preview_changes_nothing_medium_adds_possible_matches_but_close_calls_always_stay(): void
    {
        $this->queue('dolce halves.jpg');          // a possible match (one clear leader)
        $this->queue('green olives halves.png');   // many cultivars tie: a close call
        $links = ProductImage::count();
        $reviews = CatalogMediaReview::where('status', 'pending')->count();

        $high = app(PhotoAutoMatcher::class)->plan('high');
        $medium = app(PhotoAutoMatcher::class)->plan('medium');
        $this->assertSame($links, ProductImage::count(), 'a preview writes nothing');
        $this->assertSame($reviews, CatalogMediaReview::where('status', 'pending')->count());

        $files = fn (array $plan): array => collect($plan['assignments'])->flatMap(fn ($a) => array_merge($a['primary'] ? [$a['primary']['file']] : [], array_column($a['gallery'], 'file')))->all();
        $this->assertNotContains('dolce halves.jpg', $files($high), 'strong-only does not take a possible match');
        $this->assertContains('dolce halves.jpg', $files($medium));
        $this->assertNotContains('green olives halves.png', $files($medium), 'a close call is never assigned automatically');
        $this->assertContains('green olives halves.png', array_column($medium['skipped'], 'file'));
    }

    #[Test]
    public function a_user_who_may_not_edit_products_cannot_run_it(): void
    {
        $viewer = User::factory()->create(['is_active' => true]);
        $viewer->assignRole(User::ROLE_VIEWER);
        $this->actingAs($viewer);
        $this->queue('azizi-green-olives-halves.webp');
        $r = app(PhotoAutoMatcher::class)->run('high', $viewer);
        $this->assertSame(0, $r['assigned']);
        $this->assertSame(0, CatalogMediaReview::where('status', 'assigned')->count());
    }

    #[Test]
    public function the_page_has_a_match_all_button_with_a_preview_and_a_one_click_undo(): void
    {
        $this->queue('azizi-green-olives-halves.webp');
        $c = Livewire::test(PhotoReviewQueue::class)->assertActionVisible('matchAll')->assertActionHidden('undoMatchAll')
            ->callAction('matchAll', ['level' => 'high'])->assertHasNoActionErrors();
        $this->assertSame(1, CatalogMediaReview::where('status', 'assigned')->where('original_filename', 'azizi-green-olives-halves.webp')->count());
        $c->assertActionVisible('undoMatchAll')->callAction('undoMatchAll');
        $this->assertSame('pending', CatalogMediaReview::where('original_filename', 'azizi-green-olives-halves.webp')->value('status'));
    }
}
