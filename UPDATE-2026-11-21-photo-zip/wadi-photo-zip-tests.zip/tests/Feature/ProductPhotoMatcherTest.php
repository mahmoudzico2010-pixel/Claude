<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Models\CatalogMediaReview;
use App\Models\Product;
use App\Models\ProductImage;
use App\Models\SiteSetting;
use App\Services\Catalog\CatalogHierarchy;
use App\Services\Catalog\CatalogImport59;
use App\Services\Catalog\ProductPhotoMatcher;
use Database\Seeders\RolePermissionSeeder;
use Filament\Facades\Filament;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Storage;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;

final class ProductPhotoMatcherTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        Storage::fake('public');
        $this->seed(RolePermissionSeeder::class);
        Filament::setCurrentPanel('admin');
        SiteSetting::setMany(['maintenance_mode' => false], 'site');
        CatalogHierarchy::apply();
        $dir = sys_get_temp_dir().'/wadi-m-'.uniqid();
        mkdir($dir);
        file_put_contents("$dir/BEKO0402.webp", 'x');
        (new CatalogImport59)->run(true, $dir);
    }

    private function top(string $file): ?array
    {
        return (new ProductPhotoMatcher)->match($file, 3)[0] ?? null;
    }

    /** @return array<string, array{0: string, 1: string}> */
    public static function clearCases(): array
    {
        return [
            'exact slug' => ['azizi-green-olives-pitted.webp', 'azizi-green-olives-pitted'],
            'case, spaces, capital extension' => ['Azizi Pitted Green Olives.JPG', 'azizi-green-olives-pitted'],
            'underscores and a copy suffix' => ['picual_green_olives_stuffed - copy (2).png', 'picual-green-olives-stuffed'],
            'halved = halves' => ['Manzanilla green olives halved.webp', 'manzanilla-green-olives-halves'],
            'jalapeno spelled the site way' => ['sliced-red-jalape-os.webp', 'sliced-red-jalape-os'],
            'jalapeno spelled normally' => ['sliced red jalapeno.png', 'sliced-red-jalape-os'],
            'final suffix' => ['azizi_green_olives_whole-final.png', 'azizi-green-olives-whole'],
        ];
    }

    #[Test]
    #[DataProvider('clearCases')]
    public function clear_file_names_rank_the_right_product_first_with_high_confidence(string $file, string $slug): void
    {
        $t = $this->top($file);
        $this->assertNotNull($t, $file);
        $this->assertSame($slug, $t['slug'], $file);
        $this->assertSame('high', $t['confidence'], $file.' scored '.$t['score']);
    }

    #[Test]
    public function every_catalogue_slug_finds_itself_as_an_exact_match(): void
    {
        $matcher = new ProductPhotoMatcher;
        $miss = [];
        foreach (Product::pluck('slug') as $slug) {
            $top = $matcher->match($slug.'.webp', 1)[0] ?? null;
            if (! $top || $top['slug'] !== $slug || $top['score'] !== 100) {
                $miss[] = $slug;
            }
        }
        $this->assertSame([], $miss);
    }

    #[Test]
    public function a_cut_or_colour_that_contradicts_the_product_is_penalised(): void
    {
        $m = (new ProductPhotoMatcher)->match('azizi-green-olives-sliced.png', 3);
        $this->assertSame('azizi-green-olives-sliced', $m[0]['slug']);
        foreach (array_slice($m, 1) as $other) {
            $this->assertLessThan($m[0]['score'], $other['score']);
            $this->assertNotSame('high', $other['confidence'], $other['slug'].' must not look as sure as the real match');
        }
    }

    #[Test]
    public function vague_names_get_a_lower_confidence_and_alternatives_and_camera_names_get_nothing(): void
    {
        $vague = (new ProductPhotoMatcher)->match('dolce halves.jpg', 3);
        $this->assertNotSame('high', $vague[0]['confidence']);
        $this->assertGreaterThanOrEqual(2, count($vague), 'alternatives are offered');

        foreach (['IMG_2231.jpg', 'BEKO0402.webp', 'DSC00012.JPG', '1234.png', 'photo 3.png', 'random-product-xyz.png'] as $f) {
            $this->assertSame([], (new ProductPhotoMatcher)->match($f, 3), $f);
        }
    }

    #[Test]
    public function the_matcher_only_reads_it_never_changes_products_or_assignments(): void
    {
        $before = [Product::count(), ProductImage::count(), Product::pluck('primary_image_id', 'id')->all(), CatalogMediaReview::count()];
        (new ProductPhotoMatcher)->match('azizi-green-olives-pitted.webp');
        (new ProductPhotoMatcher)->match('anything at all.png');
        $this->assertEquals($before, [Product::count(), ProductImage::count(), Product::pluck('primary_image_id', 'id')->all(), CatalogMediaReview::count()]);
    }

    #[Test]
    public function a_generic_name_that_fits_many_products_is_never_called_a_strong_match(): void
    {
        $m = (new ProductPhotoMatcher)->match('green olives whole.png', 3);
        $this->assertNotSame([], $m);
        $this->assertNotSame('high', $m[0]['confidence'], 'many cultivars share this name — the reviewer must decide');
        $this->assertGreaterThanOrEqual(2, count($m));
    }

    #[Test]
    public function products_without_a_photo_win_a_tie(): void
    {
        $top = $this->top('green olives halves.png');
        $this->assertNotNull($top);
        $this->assertArrayHasKey('has_photo', $top);
    }
}
