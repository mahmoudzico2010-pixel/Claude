{{-- Preview of "Match all": what would be assigned and what stays in the queue. Nothing here changes anything. --}}
<div style="font-size:.9rem;display:flex;flex-direction:column;gap:.6rem" data-testid="match-plan">
    <p><strong>{{ __('photoreview.auto.summary', ['n' => $plan['will_assign'], 'p' => $plan['primaries'], 'g' => $plan['gallery'], 's' => count($plan['skipped'])]) }}</strong></p>
    @if ($plan['assignments'])
        <details open><summary style="cursor:pointer">{{ __('photoreview.auto.will') }} ({{ $plan['will_assign'] }})</summary>
            <ul style="margin:.25rem 0 0;padding-inline-start:1.2rem;list-style:disc;max-height:14rem;overflow:auto">
                @foreach ($plan['assignments'] as $a)
                    <li><span dir="auto">{{ $a['product'] }}</span>:
                        @if ($a['primary'])<span dir="ltr">{{ $a['primary']['file'] }}</span> <em>({{ __('photoreview.primary') }})</em>@endif
                        @foreach ($a['gallery'] as $g)<span dir="ltr">{{ $g['file'] }}</span> <em>({{ __('photoreview.gallery') }})</em>@if (! $loop->last), @endif @endforeach</li>
                @endforeach
            </ul></details>
    @endif
    @if ($plan['skipped'])
        <details><summary style="cursor:pointer;color:#a16207">{{ __('photoreview.auto.stay') }} ({{ count($plan['skipped']) }})</summary>
            <ul style="margin:.25rem 0 0;padding-inline-start:1.2rem;list-style:disc;max-height:10rem;overflow:auto">@foreach ($plan['skipped'] as $s)<li><span dir="ltr">{{ $s['file'] }}</span> — {{ $s['why'] }}</li>@endforeach</ul></details>
    @endif
    <p style="font-size:.8rem;color:#666">{{ __('photoreview.auto.safety') }}</p>
</div>
