<?php

declare(strict_types=1);

namespace App\Filament\Pages;

use App\Models\CatalogMediaReview;
use App\Models\ProductImage;
use App\Services\Catalog\PhotoReviewService;
use App\Support\Permissions;
use BackedEnum;
use App\Services\Catalog\PhotoZipImporter;
use App\Support\Uploads\UploadLimits;
use Filament\Actions\Action;
use App\Services\Catalog\PhotoAutoMatcher;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\Select;
use Filament\Schemas\Components\Html;
use Filament\Schemas\Components\Utilities\Get;
use Filament\Notifications\Notification;
use Filament\Pages\Page;
use Filament\Support\Icons\Heroicon;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Support\Facades\Auth;
use Livewire\Attributes\Url;
use Symfony\Component\HttpFoundation\StreamedResponse;

/** Resolve queued photographs: assign to a product (primary or gallery), mark group-only or rejected, undo, order the gallery. */
class PhotoReviewQueue extends Page
{
    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedPhoto;

    protected static ?int $navigationSort = 7;

    protected static ?string $slug = 'photo-review';

    protected string $view = 'filament.pages.photo-review-queue';

    #[Url]
    public string $status = 'pending';

    #[Url]
    public string $search = '';

    #[Url]
    public ?int $focus = null;

    /** @var array<int, int> */
    public array $selected = [];

    public string $productSearch = '';

    public ?int $productId = null;

    /** Review id of the ticked photo that becomes the primary ('' = none, keep the product's current primary). */
    public string $primaryChoice = '';

    /** Summary of the last ZIP import, shown above the queue until dismissed. @var array<string, mixed>|null */
    public ?array $zipResult = null;

    /** Review ids assigned by the last "Match all" run, so the whole run can be undone in one click. @var list<int> */
    public array $lastMatchRun = [];

    public static function getNavigationGroup(): ?string
    {
        return __('nav.groups.catalogue');
    }

    public static function getNavigationLabel(): string
    {
        return __('photoreview.nav');
    }

    public function getTitle(): string
    {
        return __('photoreview.title');
    }

    public static function getNavigationBadge(): ?string
    {
        try {
            $n = (int) (new PhotoReviewService)->counts()['pending'];
        } catch (\Throwable) {
            return null;
        }

        return $n > 0 ? (string) $n : null;
    }

    public static function getNavigationBadgeColor(): ?string
    {
        return 'warning';
    }

    public static function canAccess(): bool
    {
        return Auth::user()?->can(Permissions::PRODUCTS_UPDATE) ?? false;
    }

    private function svc(): PhotoReviewService
    {
        return new PhotoReviewService;
    }

    /** "Upload ZIP of photos": registers new images in the Media Library and queues them here as unassigned. Never creates products or touches assignments. */
    protected function getHeaderActions(): array
    {
        return [
            Action::make('matchAll')
                ->label(__('photoreview.auto.action'))
                ->icon(Heroicon::OutlinedSparkles)
                ->color('success')
                ->modalHeading(__('photoreview.auto.heading'))
                ->modalDescription(__('photoreview.auto.intro'))
                ->modalSubmitActionLabel(__('photoreview.auto.submit'))
                ->visible(fn (): bool => self::canAccess())
                ->fillForm(['level' => 'high'])
                ->schema([
                    Select::make('level')->label(__('photoreview.auto.level'))->live()->native(false)->selectablePlaceholder(false)
                        ->options(['high' => __('photoreview.auto.level_high'), 'medium' => __('photoreview.auto.level_medium')]),
                    Html::make(fn (Get $get): \Illuminate\Support\HtmlString => new \Illuminate\Support\HtmlString(view('filament.pages.photo-review-match-plan', ['plan' => app(PhotoAutoMatcher::class)->plan((string) ($get('level') ?: 'high'))])->render())),
                ])
                ->action(function (array $data): void {
                    $r = app(PhotoAutoMatcher::class)->run((string) ($data['level'] ?? 'high'), Auth::user());
                    $this->lastMatchRun = $r['review_ids'];
                    $this->zipResult = null;
                    Notification::make()->success()->title(__('photoreview.auto.done', ['n' => $r['assigned'], 'p' => $r['primaries'], 'g' => $r['gallery'], 's' => count($r['skipped'])]))->send();
                }),
            Action::make('undoMatchAll')
                ->label(fn (): string => __('photoreview.auto.undo', ['n' => count($this->lastMatchRun)]))
                ->icon(Heroicon::OutlinedArrowUturnLeft)
                ->color('warning')
                ->visible(fn (): bool => $this->lastMatchRun !== [] && self::canAccess())
                ->requiresConfirmation()
                ->action(function (): void {
                    $n = app(PhotoAutoMatcher::class)->undoRun($this->lastMatchRun, Auth::user());
                    $this->lastMatchRun = [];
                    Notification::make()->success()->title(__('photoreview.auto.undone', ['n' => $n]))->send();
                }),
            Action::make('uploadZip')
                ->label(__('photoreview.zip.action'))
                ->icon(Heroicon::OutlinedArchiveBoxArrowDown)
                ->color('primary')
                ->modalHeading(__('photoreview.zip.heading'))
                ->modalDescription(__('photoreview.zip.intro'))
                ->modalSubmitActionLabel(__('photoreview.zip.submit'))
                ->visible(fn (): bool => (Auth::user()?->can(Permissions::MEDIA_UPLOAD) ?? false) && self::canAccess())
                ->schema([
                    FileUpload::make('zip')
                        ->label(__('photoreview.zip.file'))
                        ->required()
                        ->storeFiles(false)
                        ->acceptedFileTypes(['application/zip', 'application/x-zip-compressed', 'application/x-zip', 'multipart/x-zip'])
                        ->maxSize(fn (): int => max(256, min(65536, UploadLimits::hostLimitKb())))
                        ->helperText(fn (): string => __('photoreview.zip.help', ['host' => (int) (UploadLimits::hostLimitKb() / 1024), 'max' => PhotoZipImporter::MAX_IMAGES])),
                ])
                ->action(function (array $data): void {
                    $file = $data['zip'] ?? null;
                    $path = is_object($file) && method_exists($file, 'getRealPath') ? (string) $file->getRealPath() : '';
                    if ($path === '') {
                        Notification::make()->danger()->title(__('photoreview.zip.failed', ['why' => __('photoreview.zip.not_zip')]))->send();

                        return;
                    }
                    try {
                        $r = app(PhotoZipImporter::class)->import($path, (string) $file->getClientOriginalName(), Auth::user());
                    } catch (AuthorizationException|\RuntimeException $e) {
                        Notification::make()->danger()->title(__('photoreview.zip.failed', ['why' => $e->getMessage()]))->persistent()->send();

                        return;
                    }
                    $this->zipResult = $r;
                    $this->status = 'pending';
                    // Show just this import (the search matches the reason, which names the ZIP); clearing the search shows the whole queue again.
                    $this->search = $r['imported'] !== [] ? $r['zip'] : $this->search;
                    $first = $this->svc()->queue('pending', '')->whereIn('media_id', array_column($r['imported'], 'media_id'))->first();
                    $this->focus = $first?->id ?? $this->focus;
                    Notification::make()->success()->title(__('photoreview.zip.done', ['n' => count($r['imported']), 'd' => count($r['duplicates']), 'r' => count($r['rejected'])]))->send();
                }),
        ];
    }

    public function dismissZipResult(): void
    {
        $this->zipResult = null;
    }

    /**
     * Existing products that the focused photo's FILE NAME points to, best first (score, confidence). A hint only: the reviewer still
     * chooses and assigns. Computed on the fly, so photos queued before this feature are matched too.
     *
     * @return list<array{product_id: int, slug: string, name: string, score: int, confidence: string, reasons: list<string>, has_photo: bool, ambiguous: bool}>
     */
    public function suggestionsFor(?CatalogMediaReview $r): array
    {
        try {
            return $r && $r->status === 'pending' ? app(\App\Services\Catalog\ProductPhotoMatcher::class)->match($r->original_filename, 3) : [];
        } catch (\Throwable $e) {
            report($e);      // a hint must never break the review page

            return [];
        }
    }

    public function mount(): void
    {
        $this->focus ??= $this->svc()->queue($this->status, $this->search)->first()?->id;
    }

    public function items()
    {
        return $this->svc()->queue($this->status, $this->search)->limit(120)->get();
    }

    public function focused(): ?CatalogMediaReview
    {
        return $this->focus ? CatalogMediaReview::with(['media', 'product'])->find($this->focus) : null;
    }

    public function counts(): array
    {
        return $this->svc()->counts();
    }

    public function results()
    {
        return $this->svc()->searchProducts($this->productSearch);
    }

    public function chosen()
    {
        return $this->productId ? \App\Models\Product::with(['translations', 'images.media', 'variety', 'form'])->find($this->productId) : null;
    }

    public function chooseProduct(int $id): void
    {
        $this->productId = $id;
    }

    public function focusOn(int $id): void
    {
        $this->focus = $id;
    }

    /** Assign the focused photo, or every ticked photo, to the chosen product. One of several ticked photos may be named primary; the rest go to the gallery. */
    public function assign(bool $next = false): void
    {
        $ids = $this->selected !== [] ? array_map('intval', $this->selected) : array_filter([$this->focus]);
        if ($this->productId === null || $ids === []) {
            Notification::make()->warning()->title(__('photoreview.need_both'))->send();

            return;
        }
        $primary = $this->primaryChoice !== '' ? (int) $this->primaryChoice : null;
        if (count($ids) === 1 && $this->primaryChoice === 'this') {
            $primary = (int) $ids[0];
        }
        $nextId = $next ? $this->nextAfter((int) ($this->focus ?? 0), $ids) : null;
        try {
            $r = $this->svc()->assign($ids, $this->productId, $primary, Auth::user());
        } catch (AuthorizationException $e) {
            Notification::make()->danger()->title(__('photoreview.denied', ['why' => $e->getMessage()]))->send();

            return;
        }
        Notification::make()->success()->title(__('photoreview.assigned_n', ['n' => $r['assigned']]))->send();
        $this->selected = [];
        $this->primaryChoice = '';
        if ($next) {
            $this->focus = $nextId;
        }
    }

    public function decide(string $status, bool $next = true): void
    {
        $ids = $this->selected !== [] ? $this->selected : array_filter([$this->focus]);
        $nextId = $this->nextAfter((int) ($this->focus ?? 0), array_map('intval', $ids));
        try {
            foreach ($ids as $id) {
                $this->svc()->markGroup((int) $id, Auth::user(), $status);
            }
        } catch (AuthorizationException $e) {
            Notification::make()->danger()->title(__('photoreview.denied', ['why' => $e->getMessage()]))->send();

            return;
        }
        $this->selected = [];
        if ($next) {
            $this->focus = $nextId;
        }
    }

    public function undo(int $id): void
    {
        try {
            $this->svc()->undo($id, Auth::user());
        } catch (AuthorizationException $e) {
            Notification::make()->danger()->title(__('photoreview.denied', ['why' => $e->getMessage()]))->send();

            return;
        }
        Notification::make()->success()->title(__('photoreview.back_queue'))->send();
    }

    public function move(int $mediaId, int $delta): void
    {
        try {
            $this->productId && $this->svc()->moveInGallery($this->productId, $mediaId, $delta, Auth::user());
        } catch (AuthorizationException $e) {
            Notification::make()->danger()->title(__('photoreview.denied', ['why' => $e->getMessage()]))->send();
        }
    }

    public function makePrimary(int $mediaId): void
    {
        try {
            $this->productId && $this->svc()->makePrimary($this->productId, $mediaId, Auth::user());
        } catch (AuthorizationException $e) {
            Notification::make()->danger()->title(__('photoreview.denied', ['why' => $e->getMessage()]))->send();
        }
    }

    /** The next unresolved photo after the current one in the filtered list (wraps; keeps the filters). */
    private function nextAfter(int $current, array $handled): ?int
    {
        $pending = $this->svc()->queue('pending', $this->search)->whereNotIn('id', $handled)->pluck('id')->all();
        foreach ($pending as $id) {
            if ($id > $current) {
                return (int) $id;
            }
        }

        return $pending[0] ?? null;
    }

    public function downloadMapping(): StreamedResponse
    {
        return response()->streamDownload(fn () => print ($this->svc()->csv()), 'photo-mapping.csv', ['Content-Type' => 'text/csv']);
    }
}
