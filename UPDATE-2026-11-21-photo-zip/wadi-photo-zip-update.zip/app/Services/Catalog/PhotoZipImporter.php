<?php

declare(strict_types=1);

namespace App\Services\Catalog;

use App\Models\AuditLog;
use App\Models\CatalogMediaReview;
use App\Models\MediaAsset;
use App\Models\Product;
use App\Models\User;
use App\Services\Media\MediaManager;
use App\Support\Permissions;
use App\Support\Uploads\UploadLimits;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use RuntimeException;
use Throwable;
use ZipArchive;

/**
 * Photo Review → "Upload ZIP of photos".
 *
 * What it does: opens the ZIP safely, registers every new image in the Media Library (same checks, renditions and file naming as
 * any other upload) and puts each one in the Photo Review queue as UNASSIGNED ("pending"), with a suggestion taken from the file name.
 *
 * What it never does: create a product, create or change a product image link, change a primary image, or touch an existing
 * review decision. Assigning is a separate, deliberate step in the queue (with Undo). A photo whose bytes are already in the
 * Media Library is reported as a duplicate and is not imported again, whichever file name it carries.
 */
final class PhotoZipImporter
{
    /** Extensions of photographs that are accepted from inside a ZIP; everything else in the archive is ignored (README, CSV, HTML …). */
    public const IMAGE_EXTENSIONS = ['webp', 'jpg', 'jpeg', 'png'];

    public const MAX_IMAGES = 100;

    public const MAX_ENTRIES = 1000;

    public const MAX_TOTAL_BYTES = 300 * 1024 * 1024;

    /** A single entry that expands to more than this many times its stored size is refused (extraction bomb). */
    public const MAX_RATIO = 100;

    public function __construct(private readonly MediaManager $media) {}

    /**
     * @return array{zip: string, imported: list<array{file: string, media_id: int, review_id: int, suggestion: ?string}>, duplicates: list<array{file: string, of: string}>, rejected: list<array{file: string, why: string}>, ignored: int, total_images: int}
     *
     * @throws AuthorizationException
     * @throws RuntimeException when the archive itself is unusable (not a ZIP, too large, unsafe)
     */
    public function import(string $zipPath, string $zipName, ?User $by): array
    {
        if (! $by || ! $by->can(Permissions::PRODUCTS_UPDATE) || ! $by->can(Permissions::MEDIA_UPLOAD)) {
            throw new AuthorizationException(__('photoreview.zip.denied'));
        }

        $zip = new ZipArchive;
        if ($zip->open($zipPath, ZipArchive::RDONLY) !== true) {
            throw new RuntimeException(__('photoreview.zip.not_zip'));
        }

        try {
            $entries = $this->plan($zip);
            $result = ['zip' => $zipName, 'imported' => [], 'duplicates' => [], 'rejected' => $entries['rejected'], 'ignored' => $entries['ignored'], 'total_images' => count($entries['images'])];

            @set_time_limit(0);
            $seenInZip = [];
            foreach ($entries['images'] as $e) {
                $base = $e['base'];
                $tmp = $this->extract($zip, $e['index'], $base);
                if ($tmp === null) {
                    $result['rejected'][] = ['file' => $base, 'why' => __('photoreview.zip.unreadable_entry')];

                    continue;
                }
                try {
                    $sum = (string) hash_file('sha1', $tmp);

                    if (isset($seenInZip[$sum])) {
                        $result['duplicates'][] = ['file' => $base, 'of' => __('photoreview.zip.same_in_zip', ['file' => $seenInZip[$sum]])];

                        continue;
                    }
                    $seenInZip[$sum] = $base;

                    $existing = MediaAsset::query()->where('checksum', $sum)->first();
                    if ($existing) {
                        $result['duplicates'][] = ['file' => $base, 'of' => $this->describe($existing)];

                        continue;
                    }

                    // The bytes must really be a JPEG, PNG or WebP picture: the extension in the ZIP proves nothing (a script renamed to .png is refused here,
                    // before the Media Library, whose own raster checks only run for content that already looks like an image).
                    $real = $this->realType($tmp);
                    if ($real === null) {
                        $result['rejected'][] = ['file' => $base, 'why' => __('photoreview.zip.not_image')];

                        continue;
                    }
                    $storeName = pathinfo($base, PATHINFO_FILENAME).'.'.$real;
                    $file = new UploadedFile($tmp, $storeName, null, null, true);
                    try {
                        $asset = $this->media->store($file, 'products');
                    } catch (Throwable $ex) {
                        $result['rejected'][] = ['file' => $base, 'why' => $ex->getMessage()];

                        continue;
                    }

                    [$candidates, $label] = $this->suggest($base);
                    $review = CatalogMediaReview::create([
                        'media_id' => $asset->getKey(),
                        'original_filename' => $base,
                        'candidates' => $candidates ?: null,
                        'reason' => __('photoreview.zip.reason', ['zip' => $zipName]),
                        'status' => 'pending',
                    ]);
                    $result['imported'][] = ['file' => $base, 'media_id' => (int) $asset->getKey(), 'review_id' => (int) $review->getKey(), 'suggestion' => $label];
                } finally {
                    @unlink($tmp);
                }
            }
        } finally {
            $zip->close();
        }

        $this->audit($by, $result);

        return $result;
    }

    /**
     * Decide, entry by entry, what may be read. Nothing is extracted here.
     *
     * @return array{images: list<array{index: int, base: string}>, rejected: list<array{file: string, why: string}>, ignored: int}
     */
    private function plan(ZipArchive $zip): array
    {
        if ($zip->numFiles === 0) {
            throw new RuntimeException(__('photoreview.zip.empty'));
        }
        if ($zip->numFiles > self::MAX_ENTRIES) {
            throw new RuntimeException(__('photoreview.zip.too_many_entries', ['max' => self::MAX_ENTRIES]));
        }

        $images = [];
        $rejected = [];
        $ignored = 0;
        $total = 0;
        $perFileMax = UploadLimits::bytes('image');

        for ($i = 0; $i < $zip->numFiles; $i++) {
            $st = $zip->statIndex($i);
            $name = (string) ($st['name'] ?? '');
            if ($name === '' || str_ends_with($name, '/')) {
                continue;                                   // directory entry
            }
            $base = basename(str_replace('\\', '/', $name));

            // Unsafe paths are refused outright (and reported); they are never used to build a destination anyway.
            if (str_contains($name, "\0") || str_starts_with($name, '/') || str_starts_with($name, '\\') || preg_match('#(^|[/\\\\])\.\.([/\\\\]|$)#', $name) === 1 || preg_match('#^[A-Za-z]:#', $name) === 1) {
                $rejected[] = ['file' => $base ?: $name, 'why' => __('photoreview.zip.unsafe_path')];

                continue;
            }
            // Mac resource forks, hidden files and non-photographs are ignored without noise.
            if (str_starts_with($name, '__MACOSX/') || str_starts_with($base, '.') || ! in_array(strtolower(pathinfo($base, PATHINFO_EXTENSION)), self::IMAGE_EXTENSIONS, true)) {
                $ignored++;

                continue;
            }
            // A symbolic link inside the archive is never followed.
            $zip->getExternalAttributesIndex($i, $opsys, $attr);
            if ($opsys === ZipArchive::OPSYS_UNIX && (($attr >> 16) & 0170000) === 0120000) {
                $rejected[] = ['file' => $base, 'why' => __('photoreview.zip.symlink')];

                continue;
            }

            $size = (int) ($st['size'] ?? 0);
            $comp = max(1, (int) ($st['comp_size'] ?? 1));
            if ($size > $perFileMax) {
                $rejected[] = ['file' => $base, 'why' => __('photoreview.zip.too_large_file', ['max' => UploadLimits::kb('image')])];

                continue;
            }
            if ($size / $comp > self::MAX_RATIO && $size > 1024 * 1024) {
                $rejected[] = ['file' => $base, 'why' => __('photoreview.zip.bomb')];

                continue;
            }
            $total += $size;
            if ($total > self::MAX_TOTAL_BYTES) {
                throw new RuntimeException(__('photoreview.zip.too_big_total', ['max' => (int) (self::MAX_TOTAL_BYTES / 1048576)]));
            }
            $images[] = ['index' => $i, 'base' => $base];
        }

        if (count($images) > self::MAX_IMAGES) {
            throw new RuntimeException(__('photoreview.zip.too_many_images', ['max' => self::MAX_IMAGES, 'n' => count($images)]));
        }
        if ($images === [] && $rejected === []) {
            throw new RuntimeException(__('photoreview.zip.no_images'));
        }

        return ['images' => $images, 'rejected' => $rejected, 'ignored' => $ignored];
    }

    /** Copy one entry to a private temporary file (streamed, size-capped); returns its path, or null when it cannot be read. */
    private function extract(ZipArchive $zip, int $index, string $base): ?string
    {
        $stream = $zip->getStreamIndex($index);
        if ($stream === false) {
            return null;
        }
        $dir = storage_path('app/tmp');
        if (! is_dir($dir)) {
            @mkdir($dir, 0775, true);
        }
        $tmp = $dir.'/zipphoto-'.bin2hex(random_bytes(8)).'.'.strtolower(pathinfo($base, PATHINFO_EXTENSION));
        $out = @fopen($tmp, 'wb');
        if ($out === false) {
            fclose($stream);

            return null;
        }
        $cap = UploadLimits::bytes('image') + 1;
        $written = 0;
        while (! feof($stream)) {
            $chunk = fread($stream, 65536);
            if ($chunk === false) {
                break;
            }
            $written += strlen($chunk);
            if ($written > $cap) {      // the archive lied about the size
                fclose($stream);
                fclose($out);
                @unlink($tmp);

                return null;
            }
            fwrite($out, $chunk);
        }
        fclose($stream);
        fclose($out);

        if ($written === 0) {
            @unlink($tmp);

            return null;
        }

        return $tmp;
    }

    /**
     * A hint only: the product whose slug equals the file name (no extension). It is shown in the queue; nothing is assigned.
     *
     * @return array{0: list<string>, 1: ?string} candidate product slugs, and a display label of the first one
     */
    private function suggest(string $base): array
    {
        $slug = strtolower((string) pathinfo($base, PATHINFO_FILENAME));
        $product = Product::query()->where('slug', $slug)->orWhere('import_key', $slug)->first();
        if (! $product) {
            return [[], null];
        }

        return [[(string) $product->slug], (string) ($product->t('name', 'en') ?: $product->slug)];
    }

    /** 'jpg' | 'png' | 'webp' when the file decodes as that picture type, else null. */
    private function realType(string $path): ?string
    {
        $info = @getimagesize($path);
        if ($info === false) {
            return null;
        }

        return match ($info[2] ?? null) {
            IMAGETYPE_JPEG => 'jpg',
            IMAGETYPE_PNG => 'png',
            IMAGETYPE_WEBP => 'webp',
            default => null,
        };
    }

    private function describe(MediaAsset $m): string
    {
        $used = \App\Models\ProductImage::query()->where('media_id', $m->getKey())->with('product')->first();
        $queued = CatalogMediaReview::query()->where('media_id', $m->getKey())->first();

        return __('photoreview.zip.dup_of', [
            'file' => $m->original_filename, 'id' => $m->getKey(),
            'where' => $used?->product ? __('photoreview.zip.where_product', ['name' => $used->product->t('name', 'en') ?: $used->product->slug]) : ($queued ? __('photoreview.zip.where_queue', ['status' => $queued->status]) : __('photoreview.zip.where_library')),
        ]);
    }

    /** @param  array<string, mixed>  $result */
    private function audit(User $by, array $result): void
    {
        try {
            AuditLog::create([
                'user_id' => $by->getKey(), 'user_name' => $by->name, 'action' => 'photo_review.zip_import',
                'auditable_type' => 'photo_review', 'auditable_id' => 0, 'auditable_label' => 'Photo ZIP: '.$result['zip'],
                'old_values' => null,
                'new_values' => ['imported' => count($result['imported']), 'duplicates' => count($result['duplicates']), 'rejected' => count($result['rejected']), 'ignored' => $result['ignored']],
                'ip_address' => request()?->ip(), 'user_agent' => substr((string) request()?->userAgent(), 0, 500) ?: null, 'created_at' => now(),
            ]);
        } catch (Throwable $e) {
            report($e);
        }
    }
}
