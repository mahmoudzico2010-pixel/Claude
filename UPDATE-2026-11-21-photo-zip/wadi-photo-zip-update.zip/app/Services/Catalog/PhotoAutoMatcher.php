<?php

declare(strict_types=1);

namespace App\Services\Catalog;

use App\Models\AuditLog;
use App\Models\CatalogMediaReview;
use App\Models\User;
use Illuminate\Auth\Access\AuthorizationException;
use Throwable;

/**
 * "Match all" — one click that assigns every still-unassigned photo whose FILE NAME clearly points to ONE existing product.
 *
 * Safe by construction:
 *  - only existing products; it never creates one;
 *  - a product that already has a primary photo keeps it: matched photos are added to its GALLERY only;
 *  - a product without a primary gets one photo as primary (the best match), the others go to the gallery;
 *  - near-ties ("close call"), weak matches and camera-style names are left in the queue;
 *  - it uses the same assign() as a manual decision, so every photo can be undone one by one (Undo), or all at once (undoRun()).
 */
final class PhotoAutoMatcher
{
    public const LEVELS = ['high', 'medium'];

    public function __construct(private readonly ProductPhotoMatcher $matcher, private readonly PhotoReviewService $reviews) {}

    /**
     * What a run would do, without changing anything.
     *
     * @return array{
     *   level: string,
     *   assignments: list<array{product_id: int, product: string, primary: ?array{review_id: int, file: string}, gallery: list<array{review_id: int, file: string}>}>,
     *   will_assign: int, primaries: int, gallery: int,
     *   skipped: list<array{review_id: int, file: string, why: string}>
     * }
     */
    public function plan(string $level = 'high'): array
    {
        $level = in_array($level, self::LEVELS, true) ? $level : 'high';
        $min = $level === 'high' ? 90 : 65;

        $byProduct = [];
        $skipped = [];
        foreach (CatalogMediaReview::query()->where('status', 'pending')->orderBy('id')->get() as $r) {
            $m = $this->matcher->match($r->original_filename, 3);
            $top = $m[0] ?? null;
            if ($top === null) {
                $skipped[] = ['review_id' => $r->id, 'file' => $r->original_filename, 'why' => 'no product in the file name'];

                continue;
            }
            if ($top['score'] < $min) {
                $skipped[] = ['review_id' => $r->id, 'file' => $r->original_filename, 'why' => 'weak match ('.$top['name'].' '.$top['score'].'%)'];

                continue;
            }
            if ($top['ambiguous']) {
                $skipped[] = ['review_id' => $r->id, 'file' => $r->original_filename, 'why' => 'close call between products ('.$top['name'].' / '.($m[1]['name'] ?? '?').') — choose by hand'];

                continue;
            }
            $byProduct[$top['product_id']][] = ['review' => $r, 'top' => $top];
        }

        $assignments = [];
        $primaries = $gallery = 0;
        foreach ($byProduct as $productId => $items) {
            $product = \App\Models\Product::find($productId);
            if (! $product) {
                continue;
            }
            // best score first (ties: oldest first)
            usort($items, fn (array $a, array $b): int => [$b['top']['score'], $a['review']->id] <=> [$a['top']['score'], $b['review']->id]);
            $hasPrimary = $product->primary_image_id !== null;
            $primary = null;
            $gal = [];
            foreach ($items as $i => $it) {
                $row = ['review_id' => (int) $it['review']->id, 'file' => (string) $it['review']->original_filename];
                if (! $hasPrimary && $i === 0) {
                    $primary = $row;
                    $primaries++;
                } else {
                    $gal[] = $row;
                    $gallery++;
                }
            }
            $assignments[] = ['product_id' => (int) $productId, 'product' => (string) ($product->t('name', 'en') ?: $product->slug), 'primary' => $primary, 'gallery' => $gal];
        }

        return ['level' => $level, 'assignments' => $assignments, 'will_assign' => $primaries + $gallery, 'primaries' => $primaries, 'gallery' => $gallery, 'skipped' => $skipped];
    }

    /**
     * @return array{assigned: int, primaries: int, gallery: int, skipped: list<array{review_id: int, file: string, why: string}>, review_ids: list<int>}
     */
    public function run(string $level, ?User $by): array
    {
        $plan = $this->plan($level);
        $assigned = $primaries = $gallery = 0;
        $skipped = $plan['skipped'];
        $ids = [];

        foreach ($plan['assignments'] as $a) {
            $reviewIds = array_merge($a['primary'] ? [$a['primary']['review_id']] : [], array_column($a['gallery'], 'review_id'));
            try {
                $r = $this->reviews->assign($reviewIds, $a['product_id'], $a['primary']['review_id'] ?? null, $by);
            } catch (AuthorizationException $e) {
                foreach (array_merge($a['primary'] ? [$a['primary']] : [], $a['gallery']) as $row) {
                    $skipped[] = ['review_id' => $row['review_id'], 'file' => $row['file'], 'why' => 'not allowed to change this product'];
                }

                continue;
            }
            $assigned += $r['assigned'];
            $primaries += $a['primary'] ? 1 : 0;
            $gallery += count($a['gallery']);
            $ids = array_merge($ids, $reviewIds);
        }

        $this->audit($by, 'photo_review.auto_match', ['level' => $plan['level'], 'assigned' => $assigned, 'review_ids' => $ids]);

        return ['assigned' => $assigned, 'primaries' => $primaries, 'gallery' => $gallery, 'skipped' => $skipped, 'review_ids' => $ids];
    }

    /** Put every photo of a run back in the queue, reversing exactly what each assignment changed (the existing per-photo undo). */
    public function undoRun(array $reviewIds, ?User $by): int
    {
        $n = 0;
        // newest first, so a product's previous primary is restored in the right order
        foreach (array_reverse(array_values(array_map('intval', $reviewIds))) as $id) {
            $r = CatalogMediaReview::find($id);
            if ($r && $r->status === 'assigned') {
                $this->reviews->undo($id, $by);
                $n++;
            }
        }
        $this->audit($by, 'photo_review.auto_match_undo', ['undone' => $n, 'review_ids' => array_values($reviewIds)]);

        return $n;
    }

    /** @param  array<string, mixed>  $values */
    private function audit(?User $by, string $action, array $values): void
    {
        try {
            AuditLog::create([
                'user_id' => $by?->getKey(), 'user_name' => $by?->name, 'action' => $action, 'auditable_type' => 'photo_review', 'auditable_id' => 0,
                'auditable_label' => 'Photo review', 'old_values' => null, 'new_values' => $values,
                'ip_address' => request()?->ip(), 'user_agent' => substr((string) request()?->userAgent(), 0, 500) ?: null, 'created_at' => now(),
            ]);
        } catch (Throwable $e) {
            report($e);
        }
    }
}
