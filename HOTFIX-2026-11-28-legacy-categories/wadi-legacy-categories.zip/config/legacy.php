<?php

declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| Old-website address mapping (301)
|--------------------------------------------------------------------------
| Used by App\Http\Controllers\LegacyUrlRedirectController. A redirect happens only when the target exists on the new site.
| Add one line per old address you see in Google / Search Console:  'old-slug' => 'new-slug'.
| Evidence so far: the old shop used "<name>-products" category slugs (e.g. /product-category/green-olives-products).
*/
return [
    // old category slug => new category slug
    'categories' => [
        'green-olives-products' => 'green-olives',
    ],

    // old product slug => new product slug (only needed when the slug changed)
    'products' => [
    ],

    // Try the slug again without this ending when it has no exact match (e.g. "green-olives-products" -> "green-olives").
    'strip_suffixes' => ['-products'],
];
