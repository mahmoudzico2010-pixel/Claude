<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Services\Catalog\CatalogImport59;
use App\Models\Product;
use App\Models\SiteSetting;
use App\Services\Catalog\CatalogHierarchy;
use App\Services\Seo\Brand;
use App\Support\Locales;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Storage;
use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;

final class SeoReleaseTest extends TestCase
{
    use RefreshDatabase;

    private const LOCALES = ['ar', 'en', 'es', 'fr', 'it', 'pt', 'el', 'ru', 'zh', 'ur'];

    private function site(array $published = self::LOCALES): Product
    {
        Storage::fake('public');
        SiteSetting::setMany(['maintenance_mode' => false], 'site');
        SiteSetting::set(Locales::SETTING, $published, SiteSetting::TYPE_JSON);
        SiteSetting::flushCache();
        config(['wadi.enforce_locale_readiness' => false]);
        $this->seed(\Database\Seeders\PageSeeder::class);
        CatalogHierarchy::apply();
        (new CatalogImport59)->run(true, null);
        Product::whereNotNull('import_key')->update(['status' => 'published', 'published_at' => now()]);

        return Product::where('import_key', 'green:picual:pitted')->firstOrFail();
    }

    private function preferred(): void
    {
        config(['wadi.seo.public_url' => 'https://wadielrayan.net']);
    }

    #[Test]
    public function canonical_hreflang_and_og_use_the_configured_host_never_the_request_host_or_tracking_parameters(): void
    {
        $p = $this->site(['en', 'ar']);
        $this->preferred();
        $html = $this->call('GET', "http://attacker.example/en/products/{$p->slug}?utm_source=x&fbclid=1")->assertOk()->getContent();
        $this->assertStringContainsString('<link rel="canonical" href="https://wadielrayan.net/en/products/'.$p->slug.'">', $html);
        $this->assertStringContainsString('hreflang="x-default" href="https://wadielrayan.net/en/products/'.$p->slug.'"', $html);
        $this->assertStringContainsString('<meta property="og:url" content="https://wadielrayan.net/en/products/'.$p->slug.'">', $html);
        preg_match_all('#<(?:link rel="(?:canonical|alternate)"|meta property="og:url")[^>]*>#', explode('</head>', $html)[0], $tags);
        $this->assertNotEmpty($tags[0]);
        foreach ($tags[0] as $tag) {
            $this->assertStringNotContainsString('attacker.example', $tag);
            $this->assertStringNotContainsString('utm_source', $tag);
        }
    }

    #[Test]
    public function every_language_page_is_self_canonical_and_lists_the_same_reciprocal_alternates(): void
    {
        $p = $this->site(['en', 'ar']);
        $this->preferred();
        $sets = [];
        foreach (['en', 'ar'] as $l) {
            $html = $this->get("/$l/products/{$p->slug}")->getContent();
            $this->assertStringContainsString('<link rel="canonical" href="https://wadielrayan.net/'.$l.'/products/'.$p->slug.'">', $html);
            preg_match_all('/<link rel="alternate" hreflang="([^"]+)" href="([^"]+)"/', $html, $m);
            $sets[$l] = array_combine($m[1], $m[2]);
        }
        $this->assertSame($sets['en'], $sets['ar']);
        $this->assertSame(['en', 'ar', 'x-default'], array_values(array_unique(array_merge(array_keys($sets['en'])))) === ['ar', 'en', 'x-default'] ? ['en', 'ar', 'x-default'] : array_keys($sets['en']));
        $this->assertStringEndsWith('/en/products/'.$p->slug, $sets['en']['x-default']);
    }

    #[Test]
    public function a_language_without_a_real_translation_is_not_advertised_and_points_to_the_default_language(): void
    {
        $p = $this->site(self::LOCALES);
        $this->preferred();
        $p->translations()->where('locale', 'ur')->delete();
        $html = $this->get("/ur/products/{$p->slug}")->assertOk()->getContent();
        $this->assertStringContainsString('<link rel="canonical" href="https://wadielrayan.net/'.Locales::default().'/products/'.$p->slug.'">', $html);
        $this->assertStringNotContainsString('<link rel="alternate" hreflang="ur"', $html);
    }

    #[Test]
    public function only_a_real_page_number_survives_in_the_canonical_and_filters_are_dropped(): void
    {
        $this->site();
        $this->preferred();
        $html = $this->get('/en/products?page=2&sort=name&color=green')->getContent();
        $this->assertStringContainsString('<link rel="canonical" href="https://wadielrayan.net/en/products?page=2">', $html);
        $this->assertStringContainsString('<link rel="canonical" href="https://wadielrayan.net/en/products">', $this->get('/en/products?utm_campaign=a')->getContent());
    }

    #[Test]
    public function www_and_http_are_redirected_once_with_path_and_query_but_posts_admin_and_other_hosts_are_left_alone(): void
    {
        $this->site(['en', 'ar']);
        $this->preferred();
        $r = $this->call('GET', 'https://www.wadielrayan.net/en/products?page=2&utm_source=x');
        $r->assertStatus(301)->assertRedirect('https://wadielrayan.net/en/products?page=2&utm_source=x');
        $this->call('GET', 'http://wadielrayan.net/en')->assertStatus(301)->assertRedirect('https://wadielrayan.net/en');   // http -> https
        $this->call('GET', 'https://wadielrayan.net/en')->assertOk();                                   // no loop
        $post = $this->call('POST', 'https://www.wadielrayan.net/en/contact');
        $this->assertNotSame(301, $post->getStatusCode(), 'a form post is never bounced');
        $admin = $this->call('GET', 'https://www.wadielrayan.net/admin/login');
        $this->assertNotSame(301, $admin->getStatusCode(), 'the admin area is not redirected by the host rule');
        $this->call('GET', 'http://staging.example.org/en')->assertOk();                                                // unrelated host untouched
    }

    #[Test]
    public function titles_carry_the_brand_exactly_once(): void
    {
        $this->site(['en', 'ar']);
        SiteSetting::set('company.short_name_en', 'WADI EL RAYAN FOR FOOD INDUSTRIES', SiteSetting::TYPE_STRING);
        SiteSetting::flushCache();
        app()->setLocale('en');
        $this->assertSame('Wadi El Rayan', Brand::name('en'));
        $this->assertSame('Whole Manzanilla Green Olives | Wadi El Rayan', Brand::compose('Whole Manzanilla Green Olives'));
        $this->assertSame('Manzanilla Green Olives – Whole | Wadi El Rayan', Brand::compose('Manzanilla Green Olives – Whole | Wadi El Rayan'));
        $this->assertSame('About us - WADI EL RAYAN FOR FOOD INDUSTRIES', Brand::compose('About us - WADI EL RAYAN FOR FOOD INDUSTRIES'));
        foreach (['/en/products', '/en/contact', '/en/about'] as $url) {
            preg_match('#<title>(.*?)</title>#s', $this->get($url)->getContent(), $m);
            $this->assertSame(1, substr_count(mb_strtolower(html_entity_decode($m[1])), 'wadi el rayan'), $url.' => '.$m[1]);
        }
    }

    #[Test]
    public function the_homepage_has_one_main_heading_and_the_slides_are_subordinate(): void
    {
        $this->site(['en', 'ar']);
        foreach (['en', 'ar'] as $l) {
            $html = $this->get("/$l")->assertOk()->getContent();
            $this->assertSame(1, substr_count($html, '<h1'), $l.' h1 count');
            $this->assertStringContainsString(e(__('seo.home_h1', [], $l)), $html);
        }
    }

    #[Test]
    public function product_cards_have_descriptive_link_text_never_a_bare_read_more(): void
    {
        $this->site(['en', 'ar']);
        $html = $this->get('/en/products')->assertOk()->getContent();
        preg_match_all('#<a[^>]*>(.*?)</a>#s', $html, $m);
        foreach ($m[1] as $inner) {
            $text = trim(preg_replace('/\s+/', ' ', strip_tags($inner)));
            $this->assertNotSame('Read more', $text, 'a link whose whole text is "Read more"');
        }
        $this->assertMatchesRegularExpression('#Read more<span class="sr-only">: [^<]{3,}</span>#', $html);
    }

    #[Test]
    public function descriptions_are_page_specific_when_a_page_has_none_of_its_own(): void
    {
        $this->site(['en', 'ar']);
        SiteSetting::set('seo.description_en', 'One broad company description used everywhere.', SiteSetting::TYPE_STRING);
        SiteSetting::flushCache();
        $d = [];
        foreach (['/en/products', '/en/contact', '/en/private-label', '/en/request-a-quote'] as $url) {
            preg_match('#<meta name="description" content="([^"]*)"#', $this->get($url)->getContent(), $m);
            $d[$url] = html_entity_decode($m[1] ?? '');
            $this->assertNotSame('One broad company description used everywhere.', $d[$url], $url);
            $this->assertGreaterThan(60, mb_strlen($d[$url]), $url);
        }
        $this->assertCount(4, array_unique($d), 'each page has its own description');
    }

    #[Test]
    public function the_sitemap_lists_each_language_version_and_categories_on_the_preferred_host_with_reciprocal_alternates(): void
    {
        $p = $this->site(['en', 'ar']);
        $this->preferred();
        $p->update(['status' => 'draft']);
        $xml = $this->call('GET', 'https://wadielrayan.net/sitemap.xml')->assertOk()->getContent();
        preg_match_all('#<url>(.*?)</url>#s', $xml, $urls);
        $alt = [];
        foreach ($urls[1] as $u) {
            preg_match('#<loc>(.*?)</loc>#', $u, $loc);
            preg_match_all('#hreflang="([^"]+)" href="([^"]+)"#', $u, $a);
            $alt[$loc[1]] = array_combine($a[1], $a[2]);
            $this->assertStringStartsWith('https://wadielrayan.net/', $loc[1]);
        }
        $this->assertNotEmpty(array_filter(array_keys($alt), fn ($l) => str_contains($l, '/products/category/')), 'categories are listed');
        $this->assertArrayHasKey('https://wadielrayan.net/ar', $alt);
        $this->assertArrayHasKey('https://wadielrayan.net/en', $alt);
        foreach ($alt as $loc => $set) {
            $this->assertContains($loc, $set, "$loc lists itself");
            foreach ($set as $href) {
                $this->assertSame($set, $alt[$href] ?? null, "$loc -> $href is reciprocal");
            }
        }
        $this->assertStringNotContainsString('/products/'.$p->slug.'<', $xml, 'a draft product is not listed');
        $this->assertCount(count($alt), array_unique(array_keys($alt)), 'no duplicate <loc>');
    }

    #[Test]
    public function robots_declares_the_sitemap_keeps_admin_private_and_blocks_no_assets(): void
    {
        $static = (string) file_get_contents(public_path('robots.txt'));
        $this->assertStringContainsString('Sitemap: https://wadielrayan.net/sitemap.xml', $static);
        $this->assertStringContainsString('Disallow: /admin', $static);
        $this->assertDoesNotMatchRegularExpression('#Disallow:\s*/(css|js|build|storage/(app/)?public|images|fonts)#i', $static);
        $this->site(['en']);
        $this->preferred();
        $dyn = $this->get('/robots.txt')->getContent();
        $this->assertStringContainsString('Sitemap: https://wadielrayan.net/sitemap.xml', $dyn);
    }

    #[Test]
    public function structured_data_urls_follow_the_preferred_host_and_no_price_or_rating_is_invented(): void
    {
        $p = $this->site(['en', 'ar']);
        $this->preferred();
        $html = $this->get("/en/products/{$p->slug}")->getContent();
        preg_match_all('#<script type="application/ld\+json">(.*?)</script>#s', $html, $m);
        $types = [];
        foreach ($m[1] as $json) {
            $d = json_decode($json, true);
            $this->assertIsArray($d);
            $types[] = $d['@type'];
            $this->assertStringNotContainsString('127.0.0.1', $json);
            $this->assertStringNotContainsString('localhost', $json);
            $this->assertArrayNotHasKey('offers', $d);
            $this->assertArrayNotHasKey('aggregateRating', $d);
            $this->assertArrayNotHasKey('review', $d);
        }
        $this->assertSame(1, count(array_keys($types, 'Product', true)), 'one Product block');
        $this->assertSame(1, count(array_keys($types, 'BreadcrumbList', true)), 'one BreadcrumbList block');
        $this->assertStringContainsString('https://wadielrayan.net/en/products/'.$p->slug, $html);
    }

    #[Test]
    public function sixteen_hero_slides_still_give_one_main_heading_and_a_fallback_slide_is_marked_with_its_language(): void
    {
        $this->site(['en', 'ar']);
        \App\Models\HeroSlide::query()->delete();
        foreach (range(1, 16) as $i) {
            $slide = \App\Models\HeroSlide::create(['media_type' => 'image', 'is_active' => true, 'display_order' => $i, 'overlay_opacity' => 50, 'text_alignment' => 'start']);
            $slide->saveTranslations(['en' => ['title' => "Slide heading $i"]] + ($i > 1 ? ['ar' => ['title' => "عنوان الشريحة $i"]] : []));
        }
        app(\App\Services\Homepage\HomepagePublisher::class)->publish();
        \Illuminate\Support\Facades\Cache::flush();
        app()->forgetScopedInstances();

        $en = $this->get('/en')->assertOk()->getContent();
        $this->assertSame(1, substr_count($en, '<h1'), 'one main heading however many slides');
        $this->assertSame(16, preg_match_all('#<h2[^>]*>\s*Slide heading \d+#', $en), 'every slide heading is an <h2>');

        $ar = $this->get('/ar')->assertOk()->getContent();
        $this->assertSame(1, substr_count($ar, '<h1'));
        $this->assertMatchesRegularExpression('#<h2[^>]*lang="en"[^>]*dir="ltr"[^>]*>\s*Slide heading 1\s*</h2>#', $ar, 'English fallback text inside the Arabic page is marked lang=en');
        $this->assertDoesNotMatchRegularExpression('#<h2[^>]*lang="en"[^>]*>\s*عنوان#u', $ar);
    }

    #[Test]
    public function a_variety_whose_slug_has_capital_letters_opens_and_every_sitemap_url_resolves(): void
    {
        $this->site(['en', 'ar']);
        $this->preferred();
        $variety = \App\Models\Variety::query()->first();
        $variety->update(['slug' => 'Azizi']);
        \App\Models\Product::query()->whereNotNull('variety_id')->limit(1)->update(['variety_id' => $variety->id]);
        $this->get('/en/products/variety/Azizi')->assertOk();

        $xml = $this->call('GET', 'https://wadielrayan.net/sitemap.xml')->assertOk()->getContent();
        preg_match_all('#<loc>https://wadielrayan\.net(/[^<]*)</loc>#', $xml, $m);
        $this->assertNotEmpty($m[1]);
        foreach (array_slice(array_unique($m[1]), 0, 400) as $path) {
            $status = $this->get($path)->getStatusCode();
            $this->assertContains($status, [200, 301, 302], "$path answered $status but is listed in the sitemap");
        }
    }

    #[Test]
    public function old_website_addresses_redirect_once_to_the_same_page_and_never_to_the_homepage(): void
    {
        $p = $this->site(['en', 'ar']);
        $slug = $p->slug;
        $cat = \App\Models\Category::query()->where('is_active', true)->first();
        $this->get("/public/product/{$slug}")->assertStatus(301)->assertRedirect("/en/products/{$slug}");
        $this->get("/product/{$slug}")->assertStatus(301)->assertRedirect("/en/products/{$slug}");
        $this->get("/product/{$slug}/")->assertStatus(301)->assertRedirect("/en/products/{$slug}");
        $this->get("/shop/green-olives/{$slug}")->assertStatus(301)->assertRedirect("/en/products/{$slug}");
        $this->get("/shop/{$slug}.html")->assertStatus(301)->assertRedirect("/en/products/{$slug}");
        $this->get("/product-category/{$cat->slug}")->assertStatus(301)->assertRedirect("/en/products/category/{$cat->slug}");
        $this->get('/shop')->assertStatus(301)->assertRedirect('/en/products');
        $this->get('/contact-us')->assertStatus(301)->assertRedirect('/en/contact');
        $this->get('/about-us')->assertStatus(301)->assertRedirect('/en/about');
        $this->get('/public/en/products')->assertStatus(301)->assertRedirect('/en/products');
        // not guessed: unknown slugs and unrelated paths are real 404s (never the homepage), and nothing is taken from the request
        $this->get('/product/no-such-thing-here')->assertStatus(301)->assertRedirect('/en/products');
        $this->assertSame(url('/en/products'), $this->get('/public/product/../../etc/passwd')->headers->get('Location'));
        $this->get('/shop/https://evil.example/x')->assertNotFound();   // and a destination is never taken from the request
        $p->update(['status' => 'draft']);
        $this->get("/product/{$slug}")->assertStatus(301)->assertRedirect('/en/products');   // an unpublished product is not shown, the section is
    }

    #[Test]
    public function only_the_first_slide_image_is_loaded_up_front_and_the_rest_wait_for_their_turn(): void
    {
        $this->site(['en', 'ar']);
        \App\Models\HeroSlide::query()->delete();
        Storage::disk('public')->put('media/a.jpg', 'x');
        $asset = \App\Models\MediaAsset::create(['disk' => 'public', 'path' => 'media/a.jpg', 'filename' => 'a.jpg', 'original_filename' => 'a.jpg', 'mime_type' => 'image/jpeg', 'extension' => 'jpg', 'size' => 1, 'width' => 1920, 'height' => 1080]);
        foreach (range(1, 6) as $i) {
            $s = \App\Models\HeroSlide::create(['media_type' => 'image', 'image_id' => $asset->id, 'is_active' => true, 'display_order' => $i, 'overlay_opacity' => 40, 'text_alignment' => 'start']);
            $s->saveTranslations(['en' => ['title' => "Slide $i"]]);
        }
        app(\App\Services\Homepage\HomepagePublisher::class)->publish();
        \Illuminate\Support\Facades\Cache::flush();
        app()->forgetScopedInstances();
        $html = $this->get('/en')->assertOk()->getContent();
        $this->assertSame(6, substr_count($html, 'data-hero-slide='));
        $this->assertSame(1, preg_match_all('#<img[^>]*x-ref="poster\d"[^>]*\ssrc="[^"]*a\.jpg"#', $html), 'only the first slide has its real image address in src');
        $this->assertSame(5, substr_count($html, 'data-src='), 'the other five wait in data-src');
    }

    #[Test]
    public function an_old_category_slug_with_the_old_shop_suffix_or_an_explicit_mapping_reaches_the_new_category(): void
    {
        $this->site(['en', 'ar']);
        $cat = \App\Models\Category::query()->where('is_active', true)->first();
        config(['legacy.categories' => ['old-name' => $cat->slug]]);
        $this->get("/public/product-category/{$cat->slug}-products")->assertStatus(301)->assertRedirect("/en/products/category/{$cat->slug}");
        $this->get('/product-category/old-name')->assertStatus(301)->assertRedirect("/en/products/category/{$cat->slug}");
        $this->get('/shop/old-name')->assertStatus(301)->assertRedirect("/en/products/category/{$cat->slug}");
        // anything under the old shop paths that cannot be matched goes to the products section, never to the homepage
        $this->get('/public/product-category/never-existed-products')->assertStatus(301)->assertRedirect('/en/products');
    }

    #[Test]
    public function old_category_names_match_by_their_words_in_any_order_and_ambiguous_names_fall_back_to_the_section(): void
    {
        $this->site(['en', 'ar']);
        $slugs = \App\Models\Category::query()->where('is_active', true)->pluck('slug');
        $pair = $slugs->first(fn ($s) => substr_count($s, '-') >= 1);
        $reversed = implode('-', array_reverse(explode('-', $pair)));
        if ($reversed !== $pair) {
            $this->get("/product-category/{$reversed}-products")->assertStatus(301)->assertRedirect("/en/products/category/{$pair}");
        }
        $this->get('/product-category/zzzz-qqqq-products')->assertStatus(301)->assertRedirect('/en/products');
        $this->get('/contact-us-old-page')->assertNotFound();   // outside the old shop paths nothing is guessed
    }
}
